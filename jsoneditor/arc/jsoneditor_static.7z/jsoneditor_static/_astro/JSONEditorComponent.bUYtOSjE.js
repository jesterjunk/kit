import{j as rd}from"./jsx-runtime.D_zvdyIk.js";import{C as Dd,c as zt,O as a1,r as bg,t as ja,g as Ke,i as $o,P as i1,o as zr,q as $r,e as Nv,k as Cu,l as xi,Q as s1,f as Lv,h as ic,R as l1,S as u1,a as Fo,p as Bo,x as Uv,d as ra,T as c1,U as d1,u as xg,V as ln,W as pa,X as Ul,w as br,Y as xo,Z as v1,$ as ta,a0 as jg,a1 as Ao,a2 as mn,a3 as Po,a4 as Os,a5 as Dv,a6 as To,a7 as qv,a8 as ao,a9 as f1,aa as yg,ab as Es,ac as Dl,ad as Xo,ae as ia,af as Ni,ag as vn,ah as wg,ai as p1,aj as h1,ak as g1,al as m1,am as kg,an as As,ao as si,ap as li,aq as _g,m as Rs,ar as b1,as as x1,at as gs,au as $v,av as sc,aw as Ms,ax as Sg,ay as Cg,az as Og,aA as j1,aB as y1,aC as Fv,aD as Eg,aE as w1,aF as Ag,aG as Bv,aH as k1,aI as _1,aJ as S1,F as Si,aK as C1,aL as O1,aM as E1,n as sn,v as Eo,J as Wv,I as Hv,s as Vv,B as Ou,aN as Rg,aO as Mg,N as xl,y as Jv,aP as zg,aQ as Pg,b as ns,K as Gv,aR as Tg,E as lc,A as Kv,L as Ci,H as Ig,D as A1,G as R1,j as Wo,_ as M1,M as z1,z as kp}from"./index.B2YNouON.js";import{W as P1,A as T1,a as I1,d as N1,b as L1,c as U1}from"./json-schema-draft-06.BUXeb-dj.js";import{c as Ng,S as D1,v as q1,f as $1,u as F1}from"./debug.DRjTZKen.js";import{g as B1}from"./_commonjsHelpers.CqkleIqs.js";import{m as Oi,n as Qo,p as zs,q as wo,t as nr,r as ql,v as Wr,w as ui,S as W1,x as Yv,y as Eu,l as ht,z as Lg,A as Li,B as H1,C as Xv,D as Ug,E as V1,i as Zt,F as Dg,u as ei,f as qg,a as $g,b as J1,g as G1}from"./floating-ui.dom.BVVWGuUJ.js";import{W as _p,l as fo,r as Ui,a as io,c as cr,m as K1,h as La,b as Ua,e as uc,f as cc,d as Au,n as ci,o as Ra,k as dc,p as ms,s as Qv,q as Y1,t as X1,S as Ru,g as Q1,u as od,i as Pn,v as Fg}from"./isEmpty.yPRxPQfS.js";import{r as Z1}from"./index.BqJQxrZM.js";import{_ as ek}from"./preload-helper.CLcXU_4U.js";import{a as ti,v as jl,m as vc,n as tk,o as nk,H as ls,I as Bg,J as Wg,K as us,j as Va,L as Hg,M as Vg,N as rk,x as Mu,y as zu,O as qd,P as iu,Q as rs,R as ok,S as ak,w as fc,z as Jg,A as Zv,B as ef,C as ik,D as sk,T as Pu,k as tf,t as Sp,u as bs,s as Gg,E as lk,F as uk,q as Ei,G as ck,r as dk,p as vk,X as fk,U as pk,V as hk,W as gk}from"./index.BGd5Ky0j.js";import{H as mk,t as ol,s as Kg,V as bk,g as Cp,R as xk,D as jk,E as Hi,k as Op,C as al,l as yk,b as wk,h as kk,c as _k,f as Sk,e as Ck,m as Ok,n as Ek,o as Ak,p as Rk,q as Mk,r as zk,u as Pk,v as Tk,w as Ik,a as Vi,j as Nk,x as Lk,i as Uk,y as Dk,z as qk,d as $k,A as Fk,B as Bk,F as Wk,G as Hk,I as Vk,J as ad,L as Ep,M as Jk,K as Gk,N as Kk,O as Yk}from"./index.-DrlcFrU.js";import{u as Ap,Y as Xk}from"./fontUtils.BV5T5L3M.js";function Qk(e,t){for(var n=0;n<t.length;n++){const r=t[n];if(typeof r!="string"&&!Array.isArray(r)){for(const a in r)if(a!=="default"&&!(a in e)){const i=Object.getOwnPropertyDescriptor(r,a);i&&Object.defineProperty(e,a,i.get?i:{enumerable:!0,get:()=>r[a]})}}}return Object.freeze(Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}))}const Zk=Object.freeze(Object.defineProperty({__proto__:null,appendToJSONPointer:Dd,compileJSONPointer:zt,compileJSONPointerProp:a1,deleteIn:bg,existsIn:ja,getIn:Ke,immutableJSONPatch:$o,insertAt:i1,isJSONArray:zr,isJSONObject:$r,isJSONPatchAdd:Nv,isJSONPatchCopy:Cu,isJSONPatchMove:xi,isJSONPatchOperation:s1,isJSONPatchRemove:Lv,isJSONPatchReplace:ic,isJSONPatchTest:l1,parseFrom:u1,parseJSONPointer:Fo,parsePath:Bo,revertJSONPatch:Uv,setIn:ra,startsWithJSONPointer:c1,transform:d1,updateIn:xg},Symbol.toStringTag,{value:"Module"}));var e_=NaN;function Rp(e){return typeof e=="number"?e:Oi(e)?e_:+e}function pc(e,t){return function(n,r){var a;if(n===void 0&&r===void 0)return t;if(n!==void 0&&(a=n),r!==void 0){if(a===void 0)return r;typeof n=="string"||typeof r=="string"?(n=Qo(n),r=Qo(r)):(n=Rp(n),r=Rp(r)),a=e(n,r)}return a}}var Yg=pc(function(e,t){return e+t},0),t_="Expected a function";function Xg(e,t){if(typeof t!="function")throw new TypeError(t_);return e=ln(e),function(){if(--e<1)return t.apply(this,arguments)}}var Tu=_p&&new _p,Qg=Tu?function(e,t){return Tu.set(e,t),e}:pa;function yl(e){return function(){var t=arguments;switch(t.length){case 0:return new e;case 1:return new e(t[0]);case 2:return new e(t[0],t[1]);case 3:return new e(t[0],t[1],t[2]);case 4:return new e(t[0],t[1],t[2],t[3]);case 5:return new e(t[0],t[1],t[2],t[3],t[4]);case 6:return new e(t[0],t[1],t[2],t[3],t[4],t[5]);case 7:return new e(t[0],t[1],t[2],t[3],t[4],t[5],t[6])}var n=Ul(e.prototype),r=e.apply(n,t);return fo(r)?r:n}}var n_=1;function r_(e,t,n){var r=t&n_,a=yl(e);function i(){var s=this&&this!==Ui&&this instanceof i?a:e;return s.apply(r?n:this,arguments)}return i}var o_=Math.max;function Zg(e,t,n,r){for(var a=-1,i=e.length,s=n.length,l=-1,u=t.length,d=o_(i-s,0),c=Array(u+d),v=!r;++l<u;)c[l]=t[l];for(;++a<s;)(v||a<i)&&(c[n[a]]=e[a]);for(;d--;)c[l++]=e[a++];return c}var a_=Math.max;function em(e,t,n,r){for(var a=-1,i=e.length,s=-1,l=n.length,u=-1,d=t.length,c=a_(i-l,0),v=Array(c+d),f=!r;++a<c;)v[a]=e[a];for(var g=a;++u<d;)v[g+u]=t[u];for(;++s<l;)(f||a<i)&&(v[g+n[s]]=e[a++]);return v}function i_(e,t){for(var n=e.length,r=0;n--;)e[n]===t&&++r;return r}function hc(){}var s_=4294967295;function kn(e){this.__wrapped__=e,this.__actions__=[],this.__dir__=1,this.__filtered__=!1,this.__iteratees__=[],this.__takeCount__=s_,this.__views__=[]}kn.prototype=Ul(hc.prototype);kn.prototype.constructor=kn;var nf=Tu?function(e){return Tu.get(e)}:br,cs={},l_=Object.prototype,u_=l_.hasOwnProperty;function yu(e){for(var t=e.name+"",n=cs[t],r=u_.call(cs,t)?n.length:0;r--;){var a=n[r],i=a.func;if(i==null||i==e)return a.name}return t}function Ro(e,t){this.__wrapped__=e,this.__actions__=[],this.__chain__=!!t,this.__index__=0,this.__values__=void 0}Ro.prototype=Ul(hc.prototype);Ro.prototype.constructor=Ro;function tm(e){if(e instanceof kn)return e.clone();var t=new Ro(e.__wrapped__,e.__chain__);return t.__actions__=xo(e.__actions__),t.__index__=e.__index__,t.__values__=e.__values__,t}var c_=Object.prototype,d_=c_.hasOwnProperty;function y(e){if(io(e)&&!cr(e)&&!(e instanceof kn)){if(e instanceof Ro)return e;if(d_.call(e,"__wrapped__"))return tm(e)}return new Ro(e)}y.prototype=hc.prototype;y.prototype.constructor=y;function $d(e){var t=yu(e),n=y[t];if(typeof n!="function"||!(t in kn.prototype))return!1;if(e===n)return!0;var r=nf(n);return!!r&&e===r[0]}var nm=v1(Qg),v_=/\{\n\/\* \[wrapped with (.+)\] \*/,f_=/,? & /;function p_(e){var t=e.match(v_);return t?t[1].split(f_):[]}var h_=/\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/;function g_(e,t){var n=t.length;if(!n)return e;var r=n-1;return t[r]=(n>1?"& ":"")+t[r],t=t.join(n>2?", ":" "),e.replace(h_,`{
/* [wrapped with `+t+`] */
`)}function gc(e,t,n,r){for(var a=e.length,i=n+(r?1:-1);r?i--:++i<a;)if(t(e[i],i,e))return i;return-1}function rm(e){return e!==e}function m_(e,t,n){for(var r=n-1,a=e.length;++r<a;)if(e[r]===t)return r;return-1}function Ps(e,t,n){return t===t?m_(e,t,n):gc(e,rm,n)}function mc(e,t){var n=e==null?0:e.length;return!!n&&Ps(e,t,0)>-1}var b_=1,x_=2,j_=8,y_=16,w_=32,k_=64,__=128,S_=256,C_=512,O_=[["ary",__],["bind",b_],["bindKey",x_],["curry",j_],["curryRight",y_],["flip",C_],["partial",w_],["partialRight",k_],["rearg",S_]];function E_(e,t){return ta(O_,function(n){var r="_."+n[0];t&n[1]&&!mc(e,r)&&e.push(r)}),e.sort()}function om(e,t,n){var r=t+"";return jg(e,g_(r,E_(p_(r),n)))}var A_=4,R_=8,Mp=32,zp=64;function am(e,t,n,r,a,i,s,l,u,d){var c=t&R_,v=c?s:void 0,f=c?void 0:s,g=c?i:void 0,m=c?void 0:i;t|=c?Mp:zp,t&=~(c?zp:Mp),t&A_||(t&=-4);var b=[e,t,a,g,v,m,f,l,u,d],j=n.apply(void 0,b);return $d(e)&&nm(j,b),j.placeholder=r,om(j,e,t)}function Ts(e){var t=e;return t.placeholder}var M_=Math.min;function z_(e,t){for(var n=e.length,r=M_(t.length,n),a=xo(e);r--;){var i=t[r];e[r]=zs(i,n)?a[i]:void 0}return e}var Pp="__lodash_placeholder__";function ni(e,t){for(var n=-1,r=e.length,a=0,i=[];++n<r;){var s=e[n];(s===t||s===Pp)&&(e[n]=Pp,i[a++]=n)}return i}var P_=1,T_=2,I_=8,N_=16,L_=128,U_=512;function bc(e,t,n,r,a,i,s,l,u,d){var c=t&L_,v=t&P_,f=t&T_,g=t&(I_|N_),m=t&U_,b=f?void 0:yl(e);function j(){for(var w=arguments.length,O=Array(w),T=w;T--;)O[T]=arguments[T];if(g)var R=Ts(j),k=i_(O,R);if(r&&(O=Zg(O,r,a,g)),i&&(O=em(O,i,s,g)),w-=k,g&&w<d){var D=ni(O,R);return am(e,t,bc,j.placeholder,n,O,D,l,u,d-w)}var H=v?n:this,V=f?H[e]:e;return w=O.length,l?O=z_(O,l):m&&w>1&&O.reverse(),c&&u<w&&(O.length=u),this&&this!==Ui&&this instanceof j&&(V=b||yl(V)),V.apply(H,O)}return j}function D_(e,t,n){var r=yl(e);function a(){for(var i=arguments.length,s=Array(i),l=i,u=Ts(a);l--;)s[l]=arguments[l];var d=i<3&&s[0]!==u&&s[i-1]!==u?[]:ni(s,u);if(i-=d.length,i<n)return am(e,t,bc,a.placeholder,void 0,s,d,void 0,void 0,n-i);var c=this&&this!==Ui&&this instanceof a?r:e;return Ao(c,this,s)}return a}var q_=1;function $_(e,t,n,r){var a=t&q_,i=yl(e);function s(){for(var l=-1,u=arguments.length,d=-1,c=r.length,v=Array(c+u),f=this&&this!==Ui&&this instanceof s?i:e;++d<c;)v[d]=r[d];for(;u--;)v[d++]=arguments[++l];return Ao(f,a?n:this,v)}return s}var Tp="__lodash_placeholder__",id=1,F_=2,B_=4,Ip=8,il=128,Np=256,W_=Math.min;function H_(e,t){var n=e[1],r=t[1],a=n|r,i=a<(id|F_|il),s=r==il&&n==Ip||r==il&&n==Np&&e[7].length<=t[8]||r==(il|Np)&&t[7].length<=t[8]&&n==Ip;if(!(i||s))return e;r&id&&(e[2]=t[2],a|=n&id?0:B_);var l=t[3];if(l){var u=e[3];e[3]=u?Zg(u,l,t[4]):l,e[4]=u?ni(e[3],Tp):t[4]}return l=t[5],l&&(u=e[5],e[5]=u?em(u,l,t[6]):l,e[6]=u?ni(e[5],Tp):t[6]),l=t[7],l&&(e[7]=l),r&il&&(e[8]=e[8]==null?t[8]:W_(e[8],t[8])),e[9]==null&&(e[9]=t[9]),e[0]=t[0],e[1]=a,e}var V_="Expected a function",Lp=1,J_=2,Up=8,Dp=16,qp=32,G_=64,$p=Math.max;function Da(e,t,n,r,a,i,s,l){var u=t&J_;if(!u&&typeof e!="function")throw new TypeError(V_);var d=r?r.length:0;if(d||(t&=-97,r=a=void 0),s=s===void 0?s:$p(ln(s),0),l=l===void 0?l:ln(l),d-=a?a.length:0,t&G_){var c=r,v=a;r=a=void 0}var f=u?void 0:nf(e),g=[e,t,n,r,a,c,v,i,s,l];if(f&&H_(g,f),e=g[0],t=g[1],n=g[2],r=g[3],a=g[4],l=g[9]=g[9]===void 0?u?0:e.length:$p(g[9]-d,0),!l&&t&(Up|Dp)&&(t&=-25),!t||t==Lp)var m=r_(e,t,n);else t==Up||t==Dp?m=D_(e,t,l):(t==qp||t==(Lp|qp))&&!a.length?m=$_(e,t,n,r):m=bc.apply(void 0,g);var b=f?Qg:nm;return om(b(m,g),e,t)}var K_=128;function rf(e,t,n){return t=n?void 0:t,t=e&&t==null?e.length:t,Da(e,K_,void 0,void 0,void 0,void 0,t)}function Is(e){return mn(function(t,n){var r=-1,a=n.length,i=a>1?n[a-1]:void 0,s=a>2?n[2]:void 0;for(i=e.length>3&&typeof i=="function"?(a--,i):void 0,s&&Po(n[0],n[1],s)&&(i=a<3?void 0:i,a=1),t=Object(t);++r<a;){var l=n[r];l&&e(t,l,r,i)}return t})}var Y_=Object.prototype,X_=Y_.hasOwnProperty,im=Is(function(e,t){if(K1(t)||La(t)){Os(t,wo(t),e);return}for(var n in t)X_.call(t,n)&&Dv(e,n,t[n])}),Fd=Is(function(e,t){Os(t,To(t),e)}),wl=Is(function(e,t,n,r){Os(t,To(t),e,r)}),sm=Is(function(e,t,n,r){Os(t,wo(t),e,r)});function of(e,t){for(var n=-1,r=t.length,a=Array(r),i=e==null;++n<r;)a[n]=i?void 0:qv(e,t[n]);return a}function af(e){var t=e==null?0:e.length;return t?ao(e,1):[]}function qa(e){return jg(f1(e,void 0,af),e+"")}var lm=qa(of),Q_="[object Object]",Z_=Function.prototype,e2=Object.prototype,um=Z_.toString,t2=e2.hasOwnProperty,n2=um.call(Object);function Ns(e){if(!io(e)||Ua(e)!=Q_)return!1;var t=yg(e);if(t===null)return!0;var n=t2.call(t,"constructor")&&t.constructor;return typeof n=="function"&&n instanceof n&&um.call(n)==n2}var r2="[object DOMException]",o2="[object Error]";function xc(e){if(!io(e))return!1;var t=Ua(e);return t==o2||t==r2||typeof e.message=="string"&&typeof e.name=="string"&&!Ns(e)}var sf=mn(function(e,t){try{return Ao(e,void 0,t)}catch(n){return xc(n)?n:new Error(n)}}),a2="Expected a function";function lf(e,t){var n;if(typeof t!="function")throw new TypeError(a2);return e=ln(e),function(){return--e>0&&(n=t.apply(this,arguments)),e<=1&&(t=void 0),n}}var i2=1,s2=32,$l=mn(function(e,t,n){var r=i2;if(n.length){var a=ni(n,Ts($l));r|=s2}return Da(e,r,t,n,a)});$l.placeholder={};var cm=qa(function(e,t){return ta(t,function(n){n=Es(n),Dl(e,n,$l(e[n],e))}),e}),l2=1,u2=2,c2=32,jc=mn(function(e,t,n){var r=l2|u2;if(n.length){var a=ni(n,Ts(jc));r|=c2}return Da(t,r,e,n,a)});jc.placeholder={};function di(e,t,n){var r=e.length;return n=n===void 0?r:n,!t&&n>=r?e:Xo(e,t,n)}var d2="\\ud800-\\udfff",v2="\\u0300-\\u036f",f2="\\ufe20-\\ufe2f",p2="\\u20d0-\\u20ff",h2=v2+f2+p2,g2="\\ufe0e\\ufe0f",m2="\\u200d",b2=RegExp("["+m2+d2+h2+g2+"]");function Ls(e){return b2.test(e)}function x2(e){return e.split("")}var dm="\\ud800-\\udfff",j2="\\u0300-\\u036f",y2="\\ufe20-\\ufe2f",w2="\\u20d0-\\u20ff",k2=j2+y2+w2,_2="\\ufe0e\\ufe0f",S2="["+dm+"]",Bd="["+k2+"]",Wd="\\ud83c[\\udffb-\\udfff]",C2="(?:"+Bd+"|"+Wd+")",vm="[^"+dm+"]",fm="(?:\\ud83c[\\udde6-\\uddff]){2}",pm="[\\ud800-\\udbff][\\udc00-\\udfff]",O2="\\u200d",hm=C2+"?",gm="["+_2+"]?",E2="(?:"+O2+"(?:"+[vm,fm,pm].join("|")+")"+gm+hm+")*",A2=gm+hm+E2,R2="(?:"+[vm+Bd+"?",Bd,fm,pm,S2].join("|")+")",M2=RegExp(Wd+"(?="+Wd+")|"+R2+A2,"g");function z2(e){return e.match(M2)||[]}function Zo(e){return Ls(e)?z2(e):x2(e)}function mm(e){return function(t){t=nr(t);var n=Ls(t)?Zo(t):void 0,r=n?n[0]:t.charAt(0),a=n?di(n,1).join(""):t.slice(1);return r[e]()+a}}var yc=mm("toUpperCase");function uf(e){return yc(nr(e).toLowerCase())}function cf(e,t,n,r){var a=-1,i=e==null?0:e.length;for(r&&i&&(n=e[++a]);++a<i;)n=t(n,e[a],a,e);return n}function df(e){return function(t){return e?.[t]}}var P2={À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"},T2=df(P2),I2=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,N2="\\u0300-\\u036f",L2="\\ufe20-\\ufe2f",U2="\\u20d0-\\u20ff",D2=N2+L2+U2,q2="["+D2+"]",$2=RegExp(q2,"g");function vf(e){return e=nr(e),e&&e.replace(I2,T2).replace($2,"")}var F2=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g;function B2(e){return e.match(F2)||[]}var W2=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/;function H2(e){return W2.test(e)}var bm="\\ud800-\\udfff",V2="\\u0300-\\u036f",J2="\\ufe20-\\ufe2f",G2="\\u20d0-\\u20ff",K2=V2+J2+G2,xm="\\u2700-\\u27bf",jm="a-z\\xdf-\\xf6\\xf8-\\xff",Y2="\\xac\\xb1\\xd7\\xf7",X2="\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",Q2="\\u2000-\\u206f",Z2=" \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",ym="A-Z\\xc0-\\xd6\\xd8-\\xde",eS="\\ufe0e\\ufe0f",wm=Y2+X2+Q2+Z2,km="['’]",Fp="["+wm+"]",tS="["+K2+"]",_m="\\d+",nS="["+xm+"]",Sm="["+jm+"]",Cm="[^"+bm+wm+_m+xm+jm+ym+"]",rS="\\ud83c[\\udffb-\\udfff]",oS="(?:"+tS+"|"+rS+")",aS="[^"+bm+"]",Om="(?:\\ud83c[\\udde6-\\uddff]){2}",Em="[\\ud800-\\udbff][\\udc00-\\udfff]",Xi="["+ym+"]",iS="\\u200d",Bp="(?:"+Sm+"|"+Cm+")",sS="(?:"+Xi+"|"+Cm+")",Wp="(?:"+km+"(?:d|ll|m|re|s|t|ve))?",Hp="(?:"+km+"(?:D|LL|M|RE|S|T|VE))?",Am=oS+"?",Rm="["+eS+"]?",lS="(?:"+iS+"(?:"+[aS,Om,Em].join("|")+")"+Rm+Am+")*",uS="\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",cS="\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",dS=Rm+Am+lS,vS="(?:"+[nS,Om,Em].join("|")+")"+dS,fS=RegExp([Xi+"?"+Sm+"+"+Wp+"(?="+[Fp,Xi,"$"].join("|")+")",sS+"+"+Hp+"(?="+[Fp,Xi+Bp,"$"].join("|")+")",Xi+"?"+Bp+"+"+Wp,Xi+"+"+Hp,cS,uS,_m,vS].join("|"),"g");function pS(e){return e.match(fS)||[]}function ff(e,t,n){return e=nr(e),t=n?void 0:t,t===void 0?H2(e)?pS(e):B2(e):e.match(t)||[]}var hS="['’]",gS=RegExp(hS,"g");function Us(e){return function(t){return cf(ff(vf(t).replace(gS,"")),e,"")}}var Mm=Us(function(e,t,n){return t=t.toLowerCase(),e+(n?uf(t):t)});function zm(){if(!arguments.length)return[];var e=arguments[0];return cr(e)?e:[e]}var mS=Ui.isFinite,bS=Math.min;function pf(e){var t=Math[e];return function(n,r){if(n=ia(n),r=r==null?0:bS(ln(r),292),r&&mS(n)){var a=(nr(n)+"e").split("e"),i=t(a[0]+"e"+(+a[1]+r));return a=(nr(i)+"e").split("e"),+(a[0]+"e"+(+a[1]-r))}return t(n)}}var Pm=pf("ceil");function hf(e){var t=y(e);return t.__chain__=!0,t}var xS=Math.ceil,jS=Math.max;function Tm(e,t,n){(n?Po(e,t,n):t===void 0)?t=1:t=jS(ln(t),0);var r=e==null?0:e.length;if(!r||t<1)return[];for(var a=0,i=0,s=Array(xS(r/t));a<r;)s[i++]=Xo(e,a,a+=t);return s}function Di(e,t,n){return e===e&&(n!==void 0&&(e=e<=n?e:n),t!==void 0&&(e=e>=t?e:t)),e}function Im(e,t,n){return n===void 0&&(n=t,t=void 0),n!==void 0&&(n=ia(n),n=n===n?n:0),t!==void 0&&(t=ia(t),t=t===t?t:0),Di(ia(e),t,n)}var yS=4;function Nm(e){return Ni(e,yS)}var wS=4;function Lm(e,t){return t=typeof t=="function"?t:void 0,Ni(e,wS,t)}function Hd(){return new Ro(this.value(),this.__chain__)}function Um(e){for(var t=-1,n=e==null?0:e.length,r=0,a=[];++t<n;){var i=e[t];i&&(a[r++]=i)}return a}function Dm(){var e=arguments.length;if(!e)return[];for(var t=Array(e-1),n=arguments[0],r=e;r--;)t[r-1]=arguments[r];return ql(cr(n)?xo(n):[n],ao(t,1))}var kS="Expected a function";function qm(e){var t=e==null?0:e.length,n=vn;return e=t?Wr(e,function(r){if(typeof r[1]!="function")throw new TypeError(kS);return[n(r[0]),r[1]]}):[],mn(function(r){for(var a=-1;++a<t;){var i=e[a];if(Ao(i[0],this,r))return Ao(i[1],this,r)}})}function $m(e,t,n){var r=n.length;if(e==null)return!r;for(e=Object(e);r--;){var a=n[r],i=t[a],s=e[a];if(s===void 0&&!(a in e)||!i(s))return!1}return!0}function _S(e){var t=wo(e);return function(n){return $m(n,e,t)}}var SS=1;function Fm(e){return _S(Ni(e,SS))}function Bm(e,t){return t==null||$m(e,t,wo(t))}var CS=Object.prototype,OS=CS.hasOwnProperty,Wm=wg(function(e,t,n){OS.call(e,n)?++e[n]:Dl(e,n,1)});function Hm(e,t){var n=Ul(e);return t==null?n:p1(n,t)}var ES=8;function wc(e,t,n){t=n?void 0:t;var r=Da(e,ES,void 0,void 0,void 0,void 0,void 0,t);return r.placeholder=wc.placeholder,r}wc.placeholder={};var AS=16;function kc(e,t,n){t=n?void 0:t;var r=Da(e,AS,void 0,void 0,void 0,void 0,void 0,t);return r.placeholder=kc.placeholder,r}kc.placeholder={};function Vm(e,t){return e==null||e!==e?t:e}var Jm=Object.prototype,RS=Jm.hasOwnProperty,Gm=mn(function(e,t){e=Object(e);var n=-1,r=t.length,a=r>2?t[2]:void 0;for(a&&Po(t[0],t[1],a)&&(r=1);++n<r;)for(var i=t[n],s=To(i),l=-1,u=s.length;++l<u;){var d=s[l],c=e[d];(c===void 0||ui(c,Jm[d])&&!RS.call(e,d))&&(e[d]=i[d])}return e});function Vd(e,t,n){(n!==void 0&&!ui(e[t],n)||n===void 0&&!(t in e))&&Dl(e,t,n)}function Pr(e){return io(e)&&La(e)}function Jd(e,t){if(!(t==="constructor"&&typeof e[t]=="function")&&t!="__proto__")return e[t]}function gf(e){return Os(e,To(e))}function MS(e,t,n,r,a,i,s){var l=Jd(e,n),u=Jd(t,n),d=s.get(u);if(d){Vd(e,n,d);return}var c=i?i(l,u,n+"",e,t,s):void 0,v=c===void 0;if(v){var f=cr(u),g=!f&&uc(u),m=!f&&!g&&cc(u);c=u,f||g||m?cr(l)?c=l:Pr(l)?c=xo(l):g?(v=!1,c=h1(u,!0)):m?(v=!1,c=g1(u,!0)):c=[]:Ns(u)||Au(u)?(c=l,Au(l)?c=gf(l):(!fo(l)||ci(l))&&(c=m1(u))):v=!1}v&&(s.set(u,c),a(c,u,r,i,s),s.delete(u)),Vd(e,n,c)}function _c(e,t,n,r,a){e!==t&&kg(t,function(i,s){if(a||(a=new W1),fo(i))MS(e,t,s,n,_c,r,a);else{var l=r?r(Jd(e,s),i,s+"",e,t,a):void 0;l===void 0&&(l=i),Vd(e,s,l)}},To)}function Km(e,t,n,r,a,i){return fo(e)&&fo(t)&&(i.set(t,e),_c(e,t,void 0,Km,i),i.delete(t)),e}var mf=Is(function(e,t,n,r){_c(e,t,n,r)}),Ym=mn(function(e){return e.push(void 0,Km),Ao(mf,void 0,e)}),zS="Expected a function";function Xm(e,t,n){if(typeof e!="function")throw new TypeError(zS);return setTimeout(function(){e.apply(void 0,n)},t)}var Qm=mn(function(e,t){return Xm(e,1,t)}),Zm=mn(function(e,t,n){return Xm(e,ia(t)||0,n)});function bf(e,t,n){for(var r=-1,a=e==null?0:e.length;++r<a;)if(n(t,e[r]))return!0;return!1}var PS=200;function Fl(e,t,n,r){var a=-1,i=mc,s=!0,l=e.length,u=[],d=t.length;if(!l)return u;n&&(t=Wr(t,Ra(n))),r?(i=bf,s=!1):t.length>=PS&&(i=Eu,s=!1,t=new Yv(t));e:for(;++a<l;){var c=e[a],v=n==null?c:n(c);if(c=r||c!==0?c:0,s&&v===v){for(var f=d;f--;)if(t[f]===v)continue e;u.push(c)}else i(t,v,r)||u.push(c)}return u}var eb=mn(function(e,t){return Pr(e)?Fl(e,ao(t,1,Pr,!0)):[]}),tb=mn(function(e,t){var n=ht(t);return Pr(n)&&(n=void 0),Pr(e)?Fl(e,ao(t,1,Pr,!0),vn(n)):[]}),nb=mn(function(e,t){var n=ht(t);return Pr(n)&&(n=void 0),Pr(e)?Fl(e,ao(t,1,Pr,!0),void 0,n):[]}),rb=pc(function(e,t){return e/t},1);function ob(e,t,n){var r=e==null?0:e.length;return r?(t=n||t===void 0?1:ln(t),Xo(e,t<0?0:t,r)):[]}function ab(e,t,n){var r=e==null?0:e.length;return r?(t=n||t===void 0?1:ln(t),t=r-t,Xo(e,0,t<0?0:t)):[]}function Sc(e,t,n,r){for(var a=e.length,i=r?a:-1;(r?i--:++i<a)&&t(e[i],i,e););return n?Xo(e,r?0:i,r?i+1:a):Xo(e,r?i+1:0,r?a:i)}function ib(e,t){return e&&e.length?Sc(e,vn(t),!0,!0):[]}function sb(e,t){return e&&e.length?Sc(e,vn(t),!0):[]}function Gd(e,t){var n=cr(e)?ta:As;return n(e,si(t))}function lb(e,t,n){e=nr(e),t=Qo(t);var r=e.length;n=n===void 0?r:Di(ln(n),0,r);var a=n;return n-=t.length,n>=0&&e.slice(n,a)==t}function TS(e,t){return Wr(t,function(n){return[n,e[n]]})}function IS(e){var t=-1,n=Array(e.size);return e.forEach(function(r){n[++t]=[r,r]}),n}var NS="[object Map]",LS="[object Set]";function ub(e){return function(t){var n=dc(t);return n==NS?Lg(t):n==LS?IS(t):TS(t,e(t))}}var Kd=ub(wo),Yd=ub(To),US={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"},DS=df(US),cb=/[&<>"']/g,qS=RegExp(cb.source);function xf(e){return e=nr(e),e&&qS.test(e)?e.replace(cb,DS):e}var db=/[\\^$.*+?()[\]{}|]/g,$S=RegExp(db.source);function vb(e){return e=nr(e),e&&$S.test(e)?e.replace(db,"\\$&"):e}function fb(e,t){for(var n=-1,r=e==null?0:e.length;++n<r;)if(!t(e[n],n,e))return!1;return!0}function FS(e,t){var n=!0;return As(e,function(r,a,i){return n=!!t(r,a,i),n}),n}function pb(e,t,n){var r=cr(e)?fb:FS;return n&&Po(e,t,n)&&(t=void 0),r(e,vn(t))}var BS=4294967295;function jf(e){return e?Di(ln(e),0,BS):0}function WS(e,t,n,r){var a=e.length;for(n=ln(n),n<0&&(n=-n>a?0:a+n),r=r===void 0||r>a?a:ln(r),r<0&&(r+=a),r=n>r?0:jf(r);n<r;)e[n++]=t;return e}function hb(e,t,n,r){var a=e==null?0:e.length;return a?(n&&typeof n!="number"&&Po(e,t,n)&&(n=0,r=a),WS(e,t,n,r)):[]}function gb(e,t){var n=[];return As(e,function(r,a,i){t(r,a,i)&&n.push(r)}),n}function mb(e,t){var n=cr(e)?Li:gb;return n(e,vn(t))}function bb(e){return function(t,n,r){var a=Object(t);if(!La(t)){var i=vn(n);t=wo(t),n=function(l){return i(a[l],l,a)}}var s=e(t,n,r);return s>-1?a[i?t[s]:s]:void 0}}var HS=Math.max;function yf(e,t,n){var r=e==null?0:e.length;if(!r)return-1;var a=n==null?0:ln(n);return a<0&&(a=HS(r+a,0)),gc(e,vn(t),a)}var xb=bb(yf);function jb(e,t,n){var r;return n(e,function(a,i,s){if(t(a,i,s))return r=i,!1}),r}function yb(e,t){return jb(e,vn(t),li)}var VS=Math.max,JS=Math.min;function wf(e,t,n){var r=e==null?0:e.length;if(!r)return-1;var a=r-1;return n!==void 0&&(a=ln(n),a=n<0?VS(r+a,0):JS(a,r-1)),gc(e,vn(t),a,!0)}var wb=bb(wf);function kb(e,t){return jb(e,vn(t),_g)}function _b(e,t){return ao(Rs(e,t),1)}var GS=1/0;function Sb(e,t){return ao(Rs(e,t),GS)}function Cb(e,t,n){return n=n===void 0?1:ln(n),ao(Rs(e,t),n)}var KS=1/0;function Ob(e){var t=e==null?0:e.length;return t?ao(e,KS):[]}function Eb(e,t){var n=e==null?0:e.length;return n?(t=t===void 0?1:ln(t),ao(e,t)):[]}var YS=512;function Ab(e){return Da(e,YS)}var Rb=pf("floor"),XS="Expected a function",QS=8,ZS=32,eC=128,tC=256;function Mb(e){return qa(function(t){var n=t.length,r=n,a=Ro.prototype.thru;for(e&&t.reverse();r--;){var i=t[r];if(typeof i!="function")throw new TypeError(XS);if(a&&!s&&yu(i)=="wrapper")var s=new Ro([],!0)}for(r=s?r:n;++r<n;){i=t[r];var l=yu(i),u=l=="wrapper"?nf(i):void 0;u&&$d(u[0])&&u[1]==(eC|QS|ZS|tC)&&!u[4].length&&u[9]==1?s=s[yu(u[0])].apply(s,u[3]):s=i.length==1&&$d(i)?s[l]():s.thru(i)}return function(){var d=arguments,c=d[0];if(s&&d.length==1&&cr(c))return s.plant(c).value();for(var v=0,f=n?t[v].apply(this,d):c;++v<n;)f=t[v].call(this,f);return f}})}var zb=Mb(),Pb=Mb(!0);function Tb(e,t){return e==null?e:kg(e,si(t),To)}function Ib(e,t){return e==null?e:b1(e,si(t),To)}function Nb(e,t){return e&&li(e,si(t))}function Lb(e,t){return e&&_g(e,si(t))}function Ub(e){for(var t=-1,n=e==null?0:e.length,r={};++t<n;){var a=e[t];r[a[0]]=a[1]}return r}function Cc(e,t){return Li(t,function(n){return ci(e[n])})}function Db(e){return e==null?[]:Cc(e,wo(e))}function qb(e){return e==null?[]:Cc(e,To(e))}function kf(e,t){return e>t}function Oc(e){return function(t,n){return typeof t=="string"&&typeof n=="string"||(t=ia(t),n=ia(n)),e(t,n)}}var $b=Oc(kf),Fb=Oc(function(e,t){return e>=t}),nC=Object.prototype,rC=nC.hasOwnProperty;function oC(e,t){return e!=null&&rC.call(e,t)}function Bb(e,t){return e!=null&&x1(e,t,oC)}var aC=Math.max,iC=Math.min;function sC(e,t,n){return e>=iC(t,n)&&e<aC(t,n)}function Wb(e,t,n){return t=gs(t),n===void 0?(n=t,t=0):n=gs(n),e=ia(e),sC(e,t,n)}var lC="[object String]";function Bl(e){return typeof e=="string"||!cr(e)&&io(e)&&Ua(e)==lC}function _f(e,t){return Wr(t,function(n){return e[n]})}function qi(e){return e==null?[]:_f(e,wo(e))}var uC=Math.max;function Hb(e,t,n,r){e=La(e)?e:qi(e),n=n&&!r?ln(n):0;var a=e.length;return n<0&&(n=uC(a+n,0)),Bl(e)?n<=a&&e.indexOf(t,n)>-1:!!a&&Ps(e,t,n)>-1}var cC=Math.max;function Vb(e,t,n){var r=e==null?0:e.length;if(!r)return-1;var a=n==null?0:ln(n);return a<0&&(a=cC(r+a,0)),Ps(e,t,a)}var dC=Math.min;function Sf(e,t,n){for(var r=n?bf:mc,a=e[0].length,i=e.length,s=i,l=Array(i),u=1/0,d=[];s--;){var c=e[s];s&&t&&(c=Wr(c,Ra(t))),u=dC(c.length,u),l[s]=!n&&(t||a>=120&&c.length>=120)?new Yv(s&&c):void 0}c=e[0];var v=-1,f=l[0];e:for(;++v<a&&d.length<u;){var g=c[v],m=t?t(g):g;if(g=n||g!==0?g:0,!(f?Eu(f,m):r(d,m,n))){for(s=i;--s;){var b=l[s];if(!(b?Eu(b,m):r(e[s],m,n)))continue e}f&&f.push(m),d.push(g)}}return d}function Cf(e){return Pr(e)?e:[]}var Jb=mn(function(e){var t=Wr(e,Cf);return t.length&&t[0]===e[0]?Sf(t):[]}),Gb=mn(function(e){var t=ht(e),n=Wr(e,Cf);return t===ht(n)?t=void 0:n.pop(),n.length&&n[0]===e[0]?Sf(n,vn(t)):[]}),Kb=mn(function(e){var t=ht(e),n=Wr(e,Cf);return t=typeof t=="function"?t:void 0,t&&n.pop(),n.length&&n[0]===e[0]?Sf(n,void 0,t):[]});function vC(e,t,n,r){return li(e,function(a,i,s){t(r,n(a),i,s)}),r}function Yb(e,t){return function(n,r){return vC(n,e,t(r),{})}}var fC=Object.prototype,pC=fC.toString,Xb=Yb(function(e,t,n){t!=null&&typeof t.toString!="function"&&(t=pC.call(t)),e[t]=n},$v(pa)),Qb=Object.prototype,hC=Qb.hasOwnProperty,gC=Qb.toString,Zb=Yb(function(e,t,n){t!=null&&typeof t.toString!="function"&&(t=gC.call(t)),hC.call(e,t)?e[t].push(n):e[t]=[n]},vn);function ex(e,t){return t.length<2?e:sc(e,Xo(t,0,-1))}function Wl(e,t,n){t=Ms(t,e),e=ex(e,t);var r=e==null?e:e[Es(ht(t))];return r==null?void 0:Ao(r,e,n)}var tx=mn(Wl),nx=mn(function(e,t,n){var r=-1,a=typeof t=="function",i=La(e)?Array(e.length):[];return As(e,function(s){i[++r]=a?Ao(t,s,n):Wl(s,t,n)}),i}),mC="[object ArrayBuffer]";function bC(e){return io(e)&&Ua(e)==mC}var Vp=ms&&ms.isArrayBuffer,rx=Vp?Ra(Vp):bC,xC="[object Boolean]";function ox(e){return e===!0||e===!1||io(e)&&Ua(e)==xC}var jC="[object Date]";function yC(e){return io(e)&&Ua(e)==jC}var Jp=ms&&ms.isDate,ax=Jp?Ra(Jp):yC;function ix(e){return io(e)&&e.nodeType===1&&!Ns(e)}function sx(e,t,n){n=typeof n=="function"?n:void 0;var r=n?n(e,t):void 0;return r===void 0?H1(e,t,void 0,n):!!r}var wC=Ui.isFinite;function lx(e){return typeof e=="number"&&wC(e)}function Of(e){return typeof e=="number"&&e==ln(e)}function ux(e,t){return e===t||Sg(e,t,Cg(t))}function cx(e,t,n){return n=typeof n=="function"?n:void 0,Sg(e,t,Cg(t),n)}var kC="[object Number]";function Ef(e){return typeof e=="number"||io(e)&&Ua(e)==kC}function dx(e){return Ef(e)&&e!=+e}var _C=Y1?ci:Qv,SC="Unsupported core-js use. Try https://npms.io/search?q=ponyfill.";function vx(e){if(_C(e))throw new Error(SC);return X1(e)}function fx(e){return e==null}function px(e){return e===null}var CC="[object RegExp]";function OC(e){return io(e)&&Ua(e)==CC}var Gp=ms&&ms.isRegExp,Ec=Gp?Ra(Gp):OC,EC=9007199254740991;function hx(e){return Of(e)&&e>=-9007199254740991&&e<=EC}function gx(e){return e===void 0}var AC="[object WeakMap]";function mx(e){return io(e)&&dc(e)==AC}var RC="[object WeakSet]";function bx(e){return io(e)&&Ua(e)==RC}var MC=1;function xx(e){return vn(typeof e=="function"?e:Ni(e,MC))}var zC=Array.prototype,PC=zC.join;function jx(e,t){return e==null?"":PC.call(e,t)}var yx=Us(function(e,t,n){return e+(n?"-":"")+t.toLowerCase()}),wx=wg(function(e,t,n){Dl(e,n,t)});function TC(e,t,n){for(var r=n+1;r--;)if(e[r]===t)return r;return r}var IC=Math.max,NC=Math.min;function kx(e,t,n){var r=e==null?0:e.length;if(!r)return-1;var a=r;return n!==void 0&&(a=ln(n),a=a<0?IC(r+a,0):NC(a,r-1)),t===t?TC(e,t,a):gc(e,rm,a,!0)}var _x=Us(function(e,t,n){return e+(n?" ":"")+t.toLowerCase()}),Sx=mm("toLowerCase"),Cx=Oc(Og),Ox=Oc(function(e,t){return e<=t});function Ex(e,t){var n={};return t=vn(t),li(e,function(r,a,i){Dl(n,t(r,a,i),r)}),n}var LC=1;function Ax(e){return j1(Ni(e,LC))}var UC=1;function Rx(e,t){return y1(e,Ni(t,UC))}function Mx(e){return e&&e.length?Fv(e,pa,kf):void 0}function zx(e,t){return e&&e.length?Fv(e,vn(t),kf):void 0}function Af(e,t){for(var n,r=-1,a=e.length;++r<a;){var i=t(e[r]);i!==void 0&&(n=n===void 0?i:n+i)}return n}var DC=NaN;function Px(e,t){var n=e==null?0:e.length;return n?Af(e,t)/n:DC}function Tx(e){return Px(e,pa)}function Ix(e,t){return Px(e,vn(t))}var Nx=Is(function(e,t,n){_c(e,t,n)}),Lx=mn(function(e,t){return function(n){return Wl(n,e,t)}}),Ux=mn(function(e,t){return function(n){return Wl(e,n,t)}});function Dx(e){return e&&e.length?Fv(e,pa,Og):void 0}function qx(e,t,n){var r=wo(t),a=Cc(t,r),i=!(fo(n)&&"chain"in n)||!!n.chain,s=ci(e);return ta(a,function(l){var u=t[l];e[l]=u,s&&(e.prototype[l]=function(){var d=this.__chain__;if(i||d){var c=e(this.__wrapped__),v=c.__actions__=xo(this.__actions__);return v.push({func:u,args:arguments,thisArg:e}),c.__chain__=d,c}return u.apply(e,ql([this.value()],arguments))})}),e}var $x=pc(function(e,t){return e*t},1),qC="Expected a function";function Hl(e){if(typeof e!="function")throw new TypeError(qC);return function(){var t=arguments;switch(t.length){case 0:return!e.call(this);case 1:return!e.call(this,t[0]);case 2:return!e.call(this,t[0],t[1]);case 3:return!e.call(this,t[0],t[1],t[2])}return!e.apply(this,t)}}function $C(e){for(var t,n=[];!(t=e.next()).done;)n.push(t.value);return n}var FC="[object Map]",BC="[object Set]",sd=Ru?Ru.iterator:void 0;function Rf(e){if(!e)return[];if(La(e))return Bl(e)?Zo(e):xo(e);if(sd&&e[sd])return $C(e[sd]());var t=dc(e),n=t==FC?Lg:t==BC?Xv:qi;return n(e)}function Xd(){this.__values__===void 0&&(this.__values__=Rf(this.value()));var e=this.__index__>=this.__values__.length,t=e?void 0:this.__values__[this.__index__++];return{done:e,value:t}}function Fx(e,t){var n=e.length;if(n)return t+=t<0?n:0,zs(t,n)?e[t]:void 0}function Bx(e,t){return e&&e.length?Fx(e,ln(t)):void 0}function Wx(e){return e=ln(e),mn(function(t){return Fx(t,e)})}function Mf(e,t){return t=Ms(t,e),e=ex(e,t),e==null||delete e[Es(ht(t))]}function WC(e){return Ns(e)?void 0:e}var HC=1,VC=2,JC=4,Iu=qa(function(e,t){var n={};if(e==null)return n;var r=!1;t=Wr(t,function(i){return i=Ms(i,e),r||(r=i.length>1),i}),Os(e,Eg(e),n),r&&(n=Ni(n,HC|VC|JC,WC));for(var a=t.length;a--;)Mf(n,t[a]);return n});function Vl(e,t,n,r){if(!fo(e))return e;t=Ms(t,e);for(var a=-1,i=t.length,s=i-1,l=e;l!=null&&++a<i;){var u=Es(t[a]),d=n;if(u==="__proto__"||u==="constructor"||u==="prototype")return e;if(a!=s){var c=l[u];d=r?r(c,u,l):void 0,d===void 0&&(d=fo(c)?c:zs(t[a+1])?[]:{})}Dv(l,u,d),l=l[u]}return e}function Hx(e,t,n){for(var r=-1,a=t.length,i={};++r<a;){var s=t[r],l=sc(e,s);n(l,s)&&Vl(i,Ms(s,e),l)}return i}function zf(e,t){if(e==null)return{};var n=Wr(Eg(e),function(r){return[r]});return t=vn(t),Hx(e,n,function(r,a){return t(r,a[0])})}function Vx(e,t){return zf(e,Hl(vn(t)))}function Jx(e){return lf(2,e)}function Gx(e,t,n,r){return e==null?[]:(cr(t)||(t=t==null?[]:[t]),n=r?void 0:n,cr(n)||(n=n==null?[]:[n]),w1(e,t,n))}function Pf(e){return qa(function(t){return t=Wr(t,Ra(vn)),mn(function(n){var r=this;return e(t,function(a){return Ao(a,r,n)})})})}var Kx=Pf(Wr),GC=mn,KC=Math.min,Yx=GC(function(e,t){t=t.length==1&&cr(t[0])?Wr(t[0],Ra(vn)):Wr(ao(t,1),Ra(vn));var n=t.length;return mn(function(r){for(var a=-1,i=KC(r.length,n);++a<i;)r[a]=t[a].call(this,r[a]);return Ao(e,this,r)})}),Xx=Pf(fb),Qx=Pf(Ug),YC=9007199254740991,XC=Math.floor;function Qd(e,t){var n="";if(!e||t<1||t>YC)return n;do t%2&&(n+=e),t=XC(t/2),t&&(e+=e);while(t);return n}var QC=Ag("length"),Zx="\\ud800-\\udfff",ZC="\\u0300-\\u036f",eO="\\ufe20-\\ufe2f",tO="\\u20d0-\\u20ff",nO=ZC+eO+tO,rO="\\ufe0e\\ufe0f",oO="["+Zx+"]",Zd="["+nO+"]",ev="\\ud83c[\\udffb-\\udfff]",aO="(?:"+Zd+"|"+ev+")",e0="[^"+Zx+"]",t0="(?:\\ud83c[\\udde6-\\uddff]){2}",n0="[\\ud800-\\udbff][\\udc00-\\udfff]",iO="\\u200d",r0=aO+"?",o0="["+rO+"]?",sO="(?:"+iO+"(?:"+[e0,t0,n0].join("|")+")"+o0+r0+")*",lO=o0+r0+sO,uO="(?:"+[e0+Zd+"?",Zd,t0,n0,oO].join("|")+")",Kp=RegExp(ev+"(?="+ev+")|"+uO+lO,"g");function cO(e){for(var t=Kp.lastIndex=0;Kp.test(e);)++t;return t}function Ds(e){return Ls(e)?cO(e):QC(e)}var dO=Math.ceil;function Nu(e,t){t=t===void 0?" ":Qo(t);var n=t.length;if(n<2)return n?Qd(t,e):t;var r=Qd(t,dO(e/Ds(t)));return Ls(t)?di(Zo(r),0,e).join(""):r.slice(0,e)}var vO=Math.ceil,fO=Math.floor;function a0(e,t,n){e=nr(e),t=ln(t);var r=t?Ds(e):0;if(!t||r>=t)return e;var a=(t-r)/2;return Nu(fO(a),n)+e+Nu(vO(a),n)}function i0(e,t,n){e=nr(e),t=ln(t);var r=t?Ds(e):0;return t&&r<t?e+Nu(t-r,n):e}function s0(e,t,n){e=nr(e),t=ln(t);var r=t?Ds(e):0;return t&&r<t?Nu(t-r,n)+e:e}var pO=/^\s+/,hO=Ui.parseInt;function l0(e,t,n){return n||t==null?t=0:t&&(t=+t),hO(nr(e).replace(pO,""),t||0)}var gO=32,Jl=mn(function(e,t){var n=ni(t,Ts(Jl));return Da(e,gO,void 0,t,n)});Jl.placeholder={};var mO=64,Ac=mn(function(e,t){var n=ni(t,Ts(Ac));return Da(e,mO,void 0,t,n)});Ac.placeholder={};function bO(e,t){return Hx(e,t,function(n,r){return Bv(e,r)})}var u0=qa(function(e,t){return e==null?{}:bO(e,t)});function tv(e){for(var t,n=this;n instanceof hc;){var r=tm(n);r.__index__=0,r.__values__=void 0,t?a.__wrapped__=r:t=r;var a=r;n=n.__wrapped__}return a.__wrapped__=e,t}function c0(e){return function(t){return e==null?void 0:sc(e,t)}}function xO(e,t,n,r){for(var a=n-1,i=e.length;++a<i;)if(r(e[a],t))return a;return-1}var jO=Array.prototype,Yp=jO.splice;function Tf(e,t,n,r){var a=r?xO:Ps,i=-1,s=t.length,l=e;for(e===t&&(t=xo(t)),n&&(l=Wr(e,Ra(n)));++i<s;)for(var u=0,d=t[i],c=n?n(d):d;(u=a(l,c,u,r))>-1;)l!==e&&Yp.call(l,u,1),Yp.call(e,u,1);return e}function If(e,t){return e&&e.length&&t&&t.length?Tf(e,t):e}var d0=mn(If);function v0(e,t,n){return e&&e.length&&t&&t.length?Tf(e,t,vn(n)):e}function f0(e,t,n){return e&&e.length&&t&&t.length?Tf(e,t,void 0,n):e}var yO=Array.prototype,wO=yO.splice;function p0(e,t){for(var n=e?t.length:0,r=n-1;n--;){var a=t[n];if(n==r||a!==i){var i=a;zs(a)?wO.call(e,a,1):Mf(e,a)}}return e}var h0=qa(function(e,t){var n=e==null?0:e.length,r=of(e,t);return p0(e,Wr(t,function(a){return zs(a,n)?+a:a}).sort(k1)),r}),kO=Math.floor,_O=Math.random;function Nf(e,t){return e+kO(_O()*(t-e+1))}var SO=parseFloat,CO=Math.min,OO=Math.random;function g0(e,t,n){if(n&&typeof n!="boolean"&&Po(e,t,n)&&(t=n=void 0),n===void 0&&(typeof t=="boolean"?(n=t,t=void 0):typeof e=="boolean"&&(n=e,e=void 0)),e===void 0&&t===void 0?(e=0,t=1):(e=gs(e),t===void 0?(t=e,e=0):t=gs(t)),e>t){var r=e;e=t,t=r}if(n||e%1||t%1){var a=OO();return CO(e+a*(t-e+SO("1e-"+((a+"").length-1))),t)}return Nf(e,t)}var m0=_1(!0),EO=256,b0=qa(function(e,t){return Da(e,EO,void 0,void 0,void 0,t)});function x0(e,t,n,r,a){return a(e,function(i,s,l){n=r?(r=!1,i):t(n,i,s,l)}),n}function j0(e,t,n){var r=cr(e)?cf:x0,a=arguments.length<3;return r(e,vn(t),n,a,As)}function AO(e,t,n,r){var a=e==null?0:e.length;for(r&&a&&(n=e[--a]);a--;)n=t(n,e[a],a,e);return n}function y0(e,t,n){var r=cr(e)?AO:x0,a=arguments.length<3;return r(e,vn(t),n,a,S1)}function w0(e,t){var n=cr(e)?Li:gb;return n(e,Hl(vn(t)))}function k0(e,t){var n=[];if(!(e&&e.length))return n;var r=-1,a=[],i=e.length;for(t=vn(t);++r<i;){var s=e[r];t(s,r,e)&&(n.push(s),a.push(r))}return p0(e,a),n}function _0(e,t,n){return(n?Po(e,t,n):t===void 0)?t=1:t=ln(t),Qd(nr(e),t)}function S0(){var e=arguments,t=nr(e[0]);return e.length<3?t:t.replace(e[1],e[2])}var RO="Expected a function";function C0(e,t){if(typeof e!="function")throw new TypeError(RO);return t=t===void 0?t:ln(t),mn(e,t)}function O0(e,t,n){t=Ms(t,e);var r=-1,a=t.length;for(a||(a=1,e=void 0);++r<a;){var i=e?.[Es(t[r])];i===void 0&&(r=a,i=n),e=ci(i)?i.call(e):i}return e}var MO=Array.prototype,zO=MO.reverse;function Lu(e){return e==null?e:zO.call(e)}var E0=pf("round");function A0(e){var t=e.length;return t?e[Nf(0,t-1)]:void 0}function PO(e){return A0(qi(e))}function R0(e){var t=cr(e)?A0:PO;return t(e)}function Rc(e,t){var n=-1,r=e.length,a=r-1;for(t=t===void 0?r:t;++n<t;){var i=Nf(n,a),s=e[i];e[i]=e[n],e[n]=s}return e.length=t,e}function TO(e,t){return Rc(xo(e),Di(t,0,e.length))}function IO(e,t){var n=qi(e);return Rc(n,Di(t,0,n.length))}function M0(e,t,n){(n?Po(e,t,n):t===void 0)?t=1:t=ln(t);var r=cr(e)?TO:IO;return r(e,t)}function z0(e,t,n){return e==null?e:Vl(e,t,n)}function P0(e,t,n,r){return r=typeof r=="function"?r:void 0,e==null?e:Vl(e,t,n,r)}function NO(e){return Rc(xo(e))}function LO(e){return Rc(qi(e))}function T0(e){var t=cr(e)?NO:LO;return t(e)}var UO="[object Map]",DO="[object Set]";function I0(e){if(e==null)return 0;if(La(e))return Bl(e)?Ds(e):e.length;var t=dc(e);return t==UO||t==DO?e.size:Q1(e).length}function N0(e,t,n){var r=e==null?0:e.length;return r?(n&&typeof n!="number"&&Po(e,t,n)?(t=0,n=r):(t=t==null?0:ln(t),n=n===void 0?r:ln(n)),Xo(e,t,n)):[]}var L0=Us(function(e,t,n){return e+(n?"_":"")+t.toLowerCase()});function qO(e,t){var n;return As(e,function(r,a,i){return n=t(r,a,i),!n}),!!n}function U0(e,t,n){var r=cr(e)?Ug:qO;return n&&Po(e,t,n)&&(t=void 0),r(e,vn(t))}var $O=4294967295,FO=$O-1,BO=Math.floor,WO=Math.min;function Lf(e,t,n,r){var a=0,i=e==null?0:e.length;if(i===0)return 0;t=n(t);for(var s=t!==t,l=t===null,u=Oi(t),d=t===void 0;a<i;){var c=BO((a+i)/2),v=n(e[c]),f=v!==void 0,g=v===null,m=v===v,b=Oi(v);if(s)var j=r||m;else d?j=m&&(r||f):l?j=m&&f&&(r||!g):u?j=m&&f&&!g&&(r||!b):g||b?j=!1:j=r?v<=t:v<t;j?a=c+1:i=c}return WO(i,FO)}var HO=4294967295,VO=HO>>>1;function Mc(e,t,n){var r=0,a=e==null?r:e.length;if(typeof t=="number"&&t===t&&a<=VO){for(;r<a;){var i=r+a>>>1,s=e[i];s!==null&&!Oi(s)&&(n?s<=t:s<t)?r=i+1:a=i}return a}return Lf(e,t,pa,n)}function D0(e,t){return Mc(e,t)}function q0(e,t,n){return Lf(e,t,vn(n))}function $0(e,t){var n=e==null?0:e.length;if(n){var r=Mc(e,t);if(r<n&&ui(e[r],t))return r}return-1}function F0(e,t){return Mc(e,t,!0)}function B0(e,t,n){return Lf(e,t,vn(n),!0)}function W0(e,t){var n=e==null?0:e.length;if(n){var r=Mc(e,t,!0)-1;if(ui(e[r],t))return r}return-1}function H0(e,t){for(var n=-1,r=e.length,a=0,i=[];++n<r;){var s=e[n],l=t?t(s):s;if(!n||!ui(l,u)){var u=l;i[a++]=s===0?0:s}}return i}function V0(e){return e&&e.length?H0(e):[]}function J0(e,t){return e&&e.length?H0(e,vn(t)):[]}var JO=4294967295;function G0(e,t,n){return n&&typeof n!="number"&&Po(e,t,n)&&(t=n=void 0),n=n===void 0?JO:n>>>0,n?(e=nr(e),e&&(typeof t=="string"||t!=null&&!Ec(t))&&(t=Qo(t),!t&&Ls(e))?di(Zo(e),0,n):e.split(t,n)):[]}var GO="Expected a function",KO=Math.max;function K0(e,t){if(typeof e!="function")throw new TypeError(GO);return t=t==null?0:KO(ln(t),0),mn(function(n){var r=n[t],a=di(n,0,t);return r&&ql(a,r),Ao(e,this,a)})}var Y0=Us(function(e,t,n){return e+(n?" ":"")+yc(t)});function X0(e,t,n){return e=nr(e),n=n==null?0:Di(ln(n),0,e.length),t=Qo(t),e.slice(n,n+t.length)==t}function Q0(){return{}}function Z0(){return""}function ej(){return!0}var tj=pc(function(e,t){return e-t},0);function nj(e){return e&&e.length?Af(e,pa):0}function rj(e,t){return e&&e.length?Af(e,vn(t)):0}function oj(e){var t=e==null?0:e.length;return t?Xo(e,1,t):[]}function aj(e,t,n){return e&&e.length?(t=n||t===void 0?1:ln(t),Xo(e,0,t<0?0:t)):[]}function ij(e,t,n){var r=e==null?0:e.length;return r?(t=n||t===void 0?1:ln(t),t=r-t,Xo(e,t<0?0:t,r)):[]}function sj(e,t){return e&&e.length?Sc(e,vn(t),!1,!0):[]}function lj(e,t){return e&&e.length?Sc(e,vn(t)):[]}function uj(e,t){return t(e),e}var cj=Object.prototype,YO=cj.hasOwnProperty;function Xp(e,t,n,r){return e===void 0||ui(e,cj[n])&&!YO.call(r,n)?t:e}var XO={"\\":"\\","'":"'","\n":"n","\r":"r","\u2028":"u2028","\u2029":"u2029"};function QO(e){return"\\"+XO[e]}var dj=/<%=([\s\S]+?)%>/g,ZO=/<%-([\s\S]+?)%>/g,eE=/<%([\s\S]+?)%>/g,Uu={escape:ZO,evaluate:eE,interpolate:dj,variable:"",imports:{_:{escape:xf}}},tE="Invalid `variable` option passed into `_.template`",nE=/\b__p \+= '';/g,rE=/\b(__p \+=) '' \+/g,oE=/(__e\(.*?\)|\b__t\)) \+\n'';/g,aE=/[()=,{}\[\]\/\s]/,iE=/\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,su=/($^)/,sE=/['\n\r\u2028\u2029\\]/g,lE=Object.prototype,Qp=lE.hasOwnProperty;function vj(e,t,n){var r=Uu.imports._.templateSettings||Uu;n&&Po(e,t,n)&&(t=void 0),e=nr(e),t=wl({},t,r,Xp);var a=wl({},t.imports,r.imports,Xp),i=wo(a),s=_f(a,i),l,u,d=0,c=t.interpolate||su,v="__p += '",f=RegExp((t.escape||su).source+"|"+c.source+"|"+(c===dj?iE:su).source+"|"+(t.evaluate||su).source+"|$","g"),g=Qp.call(t,"sourceURL")?"//# sourceURL="+(t.sourceURL+"").replace(/\s/g," ")+`
`:"";e.replace(f,function(j,w,O,T,R,k){return O||(O=T),v+=e.slice(d,k).replace(sE,QO),w&&(l=!0,v+=`' +
__e(`+w+`) +
'`),R&&(u=!0,v+=`';
`+R+`;
__p += '`),O&&(v+=`' +
((__t = (`+O+`)) == null ? '' : __t) +
'`),d=k+j.length,j}),v+=`';
`;var m=Qp.call(t,"variable")&&t.variable;if(!m)v=`with (obj) {
`+v+`
}
`;else if(aE.test(m))throw new Error(tE);v=(u?v.replace(nE,""):v).replace(rE,"$1").replace(oE,"$1;"),v="function("+(m||"obj")+`) {
`+(m?"":`obj || (obj = {});
`)+"var __t, __p = ''"+(l?", __e = _.escape":"")+(u?`, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
`:`;
`)+v+`return __p
}`;var b=sf(function(){return Function(i,g+"return "+v).apply(void 0,s)});if(b.source=v,xc(b))throw b;return b}var uE="Expected a function";function fj(e,t,n){var r=!0,a=!0;if(typeof e!="function")throw new TypeError(uE);return fo(n)&&(r="leading"in n?!!n.leading:r,a="trailing"in n?!!n.trailing:a),Si(e,t,{leading:r,maxWait:t,trailing:a})}function Gl(e,t){return t(e)}function nv(){return this}function pj(e,t){var n=e;return n instanceof kn&&(n=n.value()),cf(t,function(r,a){return a.func.apply(a.thisArg,ql([r],a.args))},n)}function vl(){return pj(this.__wrapped__,this.__actions__)}function hj(e){return nr(e).toLowerCase()}function gj(e){return cr(e)?Wr(e,Es):Oi(e)?[e]:xo(C1(nr(e)))}var cE=9007199254740991;function mj(e){return e?Di(ln(e),-9007199254740991,cE):e===0?e:0}function bj(e){return nr(e).toUpperCase()}function xj(e,t,n){var r=cr(e),a=r||uc(e)||cc(e);if(t=vn(t),n==null){var i=e&&e.constructor;a?n=r?new i:[]:fo(e)?n=ci(i)?Ul(yg(e)):{}:n={}}return(a?ta:li)(e,function(s,l,u){return t(n,s,l,u)}),n}function jj(e,t){for(var n=e.length;n--&&Ps(t,e[n],0)>-1;);return n}function yj(e,t){for(var n=-1,r=e.length;++n<r&&Ps(t,e[n],0)>-1;);return n}function wj(e,t,n){if(e=nr(e),e&&(n||t===void 0))return O1(e);if(!e||!(t=Qo(t)))return e;var r=Zo(e),a=Zo(t),i=yj(r,a),s=jj(r,a)+1;return di(r,i,s).join("")}function kj(e,t,n){if(e=nr(e),e&&(n||t===void 0))return e.slice(0,E1(e)+1);if(!e||!(t=Qo(t)))return e;var r=Zo(e),a=jj(r,Zo(t))+1;return di(r,0,a).join("")}var dE=/^\s+/;function _j(e,t,n){if(e=nr(e),e&&(n||t===void 0))return e.replace(dE,"");if(!e||!(t=Qo(t)))return e;var r=Zo(e),a=yj(r,Zo(t));return di(r,a).join("")}var vE=30,fE="...",pE=/\w*$/;function Sj(e,t){var n=vE,r=fE;if(fo(t)){var a="separator"in t?t.separator:a;n="length"in t?ln(t.length):n,r="omission"in t?Qo(t.omission):r}e=nr(e);var i=e.length;if(Ls(e)){var s=Zo(e);i=s.length}if(n>=i)return e;var l=n-Ds(r);if(l<1)return r;var u=s?di(s,0,l).join(""):e.slice(0,l);if(a===void 0)return u+r;if(s&&(l+=u.length-l),Ec(a)){if(e.slice(l).search(a)){var d,c=u;for(a.global||(a=RegExp(a.source,nr(pE.exec(a))+"g")),a.lastIndex=0;d=a.exec(c);)var v=d.index;u=u.slice(0,v===void 0?l:v)}}else if(e.indexOf(Qo(a),l)!=l){var f=u.lastIndexOf(a);f>-1&&(u=u.slice(0,f))}return u+r}function Cj(e){return rf(e,1)}var hE={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"',"&#39;":"'"},gE=df(hE),Oj=/&(?:amp|lt|gt|quot|#39);/g,mE=RegExp(Oj.source);function Ej(e){return e=nr(e),e&&mE.test(e)?e.replace(Oj,gE):e}var bE=1/0,xE=od&&1/Xv(new od([,-0]))[1]==bE?function(e){return new od(e)}:br,jE=200;function ri(e,t,n){var r=-1,a=mc,i=e.length,s=!0,l=[],u=l;if(n)s=!1,a=bf;else if(i>=jE){var d=t?null:xE(e);if(d)return Xv(d);s=!1,a=Eu,u=new Yv}else u=t?[]:l;e:for(;++r<i;){var c=e[r],v=t?t(c):c;if(c=n||c!==0?c:0,s&&v===v){for(var f=u.length;f--;)if(u[f]===v)continue e;t&&u.push(v),l.push(c)}else a(u,v,n)||(u!==l&&u.push(v),l.push(c))}return l}var Aj=mn(function(e){return ri(ao(e,1,Pr,!0))}),Rj=mn(function(e){var t=ht(e);return Pr(t)&&(t=void 0),ri(ao(e,1,Pr,!0),vn(t))}),Mj=mn(function(e){var t=ht(e);return t=typeof t=="function"?t:void 0,ri(ao(e,1,Pr,!0),void 0,t)});function zj(e){return e&&e.length?ri(e):[]}function Pj(e,t){return e&&e.length?ri(e,vn(t)):[]}function Tj(e,t){return t=typeof t=="function"?t:void 0,e&&e.length?ri(e,void 0,t):[]}function Ij(e,t){return e==null?!0:Mf(e,t)}var yE=Math.max;function zc(e){if(!(e&&e.length))return[];var t=0;return e=Li(e,function(n){if(Pr(n))return t=yE(n.length,t),!0}),V1(t,function(n){return Wr(e,Ag(n))})}function Uf(e,t){if(!(e&&e.length))return[];var n=zc(e);return t==null?n:Wr(n,function(r){return Ao(t,void 0,r)})}function Nj(e,t,n,r){return Vl(e,t,n(sc(e,t)),r)}function Lj(e,t,n){return e==null?e:Nj(e,t,si(n))}function Uj(e,t,n,r){return r=typeof r=="function"?r:void 0,e==null?e:Nj(e,t,si(n),r)}var Dj=Us(function(e,t,n){return e+(n?" ":"")+t.toUpperCase()});function qj(e){return e==null?[]:_f(e,To(e))}var $j=mn(function(e,t){return Pr(e)?Fl(e,t):[]});function Fj(e,t){return Jl(si(t),e)}var Bj=qa(function(e){var t=e.length,n=t?e[0]:0,r=this.__wrapped__,a=function(i){return of(i,e)};return t>1||this.__actions__.length||!(r instanceof kn)||!zs(n)?this.thru(a):(r=r.slice(n,+n+(t?1:0)),r.__actions__.push({func:Gl,args:[a],thisArg:void 0}),new Ro(r,this.__chain__).thru(function(i){return t&&!i.length&&i.push(void 0),i}))});function Wj(){return hf(this)}function Hj(){var e=this.__wrapped__;if(e instanceof kn){var t=e;return this.__actions__.length&&(t=new kn(this)),t=t.reverse(),t.__actions__.push({func:Gl,args:[Lu],thisArg:void 0}),new Ro(t,this.__chain__)}return this.thru(Lu)}function Df(e,t,n){var r=e.length;if(r<2)return r?ri(e[0]):[];for(var a=-1,i=Array(r);++a<r;)for(var s=e[a],l=-1;++l<r;)l!=a&&(i[a]=Fl(i[a]||s,e[l],t,n));return ri(ao(i,1),t,n)}var Vj=mn(function(e){return Df(Li(e,Pr))}),Jj=mn(function(e){var t=ht(e);return Pr(t)&&(t=void 0),Df(Li(e,Pr),vn(t))}),Gj=mn(function(e){var t=ht(e);return t=typeof t=="function"?t:void 0,Df(Li(e,Pr),void 0,t)}),Kj=mn(zc);function Yj(e,t,n){for(var r=-1,a=e.length,i=t.length,s={};++r<a;){var l=r<i?t[r]:void 0;n(s,e[r],l)}return s}function Xj(e,t){return Yj(e||[],t||[],Dv)}function Qj(e,t){return Yj(e||[],t||[],Vl)}var Zj=mn(function(e){var t=e.length,n=t>1?e[t-1]:void 0;return n=typeof n=="function"?(e.pop(),n):void 0,Uf(e,n)});const rt={chunk:Tm,compact:Um,concat:Dm,difference:eb,differenceBy:tb,differenceWith:nb,drop:ob,dropRight:ab,dropRightWhile:ib,dropWhile:sb,fill:hb,findIndex:yf,findLastIndex:wf,flatten:af,flattenDeep:Ob,flattenDepth:Eb,fromPairs:Ub,head:Eo,indexOf:Vb,initial:sn,intersection:Jb,intersectionBy:Gb,intersectionWith:Kb,join:jx,lastIndexOf:kx,nth:Bx,pull:d0,pullAll:If,pullAllBy:v0,pullAllWith:f0,pullAt:h0,remove:k0,reverse:Lu,slice:N0,sortedIndex:D0,sortedIndexBy:q0,sortedIndexOf:$0,sortedLastIndex:F0,sortedLastIndexBy:B0,sortedLastIndexOf:W0,sortedUniq:V0,sortedUniqBy:J0,tail:oj,take:aj,takeRight:ij,takeRightWhile:sj,takeWhile:lj,union:Aj,unionBy:Rj,unionWith:Mj,uniq:zj,uniqBy:Pj,uniqWith:Tj,unzip:zc,unzipWith:Uf,without:$j,xor:Vj,xorBy:Jj,xorWith:Gj,zip:Kj,zipObject:Xj,zipObjectDeep:Qj,zipWith:Zj},dr={countBy:Wm,every:pb,filter:mb,find:xb,findLast:wb,flatMap:_b,flatMapDeep:Sb,flatMapDepth:Cb,forEach:Gd,forEachRight:Ou,groupBy:Wv,includes:Hb,invokeMap:nx,keyBy:wx,map:Rs,orderBy:Gx,partition:Hv,reduce:j0,reduceRight:y0,reject:w0,sample:R0,sampleSize:M0,shuffle:T0,size:I0,some:U0,sortBy:Vv},wE={now:Rg},Tr={after:Xg,ary:rf,before:lf,bind:$l,bindKey:jc,curry:wc,curryRight:kc,debounce:Si,defer:Qm,delay:Zm,flip:Ab,memoize:Mg,once:Jx,overArgs:Yx,partial:Jl,partialRight:Ac,rearg:b0,rest:C0,spread:K0,throttle:fj,unary:Cj,wrap:Fj},Ct={castArray:zm,clone:Nm,cloneDeep:xl,cloneDeepWith:Jv,cloneWith:Lm,conformsTo:Bm,eq:ui,gt:$b,gte:Fb,isArguments:Au,isArrayBuffer:rx,isArrayLike:La,isArrayLikeObject:Pr,isBoolean:ox,isBuffer:uc,isDate:ax,isElement:ix,isEmpty:Pn,isEqual:Zt,isEqualWith:sx,isError:xc,isFinite:lx,isFunction:ci,isInteger:Of,isLength:Fg,isMap:zg,isMatch:ux,isMatchWith:cx,isNaN:dx,isNative:vx,isNil:fx,isNull:px,isNumber:Ef,isObjectLike:io,isPlainObject:Ns,isRegExp:Ec,isSafeInteger:hx,isSet:Pg,isString:Bl,isSymbol:Oi,isTypedArray:cc,isUndefined:gx,isWeakMap:mx,isWeakSet:bx,lt:Cx,lte:Ox,toArray:Rf,toFinite:gs,toLength:jf,toNumber:ia,toPlainObject:gf,toSafeInteger:mj,toString:nr},so={add:Yg,ceil:Pm,divide:rb,floor:Rb,max:Mx,maxBy:zx,mean:Tx,meanBy:Ix,min:Dx,minBy:ns,multiply:$x,round:E0,subtract:tj,sum:nj,sumBy:rj},qf={clamp:Im,inRange:Wb,random:g0},Kt={assign:im,assignIn:Fd,assignInWith:wl,assignWith:sm,at:lm,create:Hm,defaults:Gm,defaultsDeep:Ym,findKey:yb,findLastKey:kb,forIn:Tb,forInRight:Ib,forOwn:Nb,forOwnRight:Lb,functions:Db,functionsIn:qb,get:qv,has:Bb,hasIn:Bv,invert:Xb,invertBy:Zb,invoke:tx,keysIn:To,mapKeys:Ex,mapValues:Gv,merge:Nx,mergeWith:mf,omit:Iu,omitBy:Vx,pick:u0,pickBy:zf,result:O0,set:z0,setWith:P0,toPairs:Kd,toPairsIn:Yd,transform:xj,unset:Ij,update:Lj,updateWith:Uj,values:qi,valuesIn:qj},ha={at:Bj,chain:hf,commit:Hd,next:Xd,plant:tv,reverse:Hj,tap:uj,toIterator:nv,value:vl,wrapperChain:Wj},Hn={camelCase:Mm,capitalize:uf,deburr:vf,endsWith:lb,escape:xf,escapeRegExp:vb,kebabCase:yx,lowerCase:_x,lowerFirst:Sx,pad:a0,padEnd:i0,padStart:s0,parseInt:l0,repeat:_0,replace:S0,snakeCase:L0,split:G0,startCase:Y0,startsWith:X0,template:vj,templateSettings:Uu,toLower:hj,toUpper:bj,trim:wj,trimEnd:kj,trimStart:_j,truncate:Sj,unescape:Ej,upperCase:Dj,upperFirst:yc,words:ff},Yn={attempt:sf,bindAll:cm,cond:qm,conforms:Fm,constant:$v,defaultTo:Vm,flow:zb,flowRight:Pb,iteratee:xx,matches:Ax,matchesProperty:Rx,method:Lx,methodOf:Ux,noop:br,nthArg:Wx,over:Kx,overEvery:Xx,overSome:Qx,property:Tg,propertyOf:c0,range:lc,rangeRight:m0,stubArray:Dg,stubFalse:Qv,stubObject:Q0,stubString:Z0,stubTrue:ej,times:Kv,toPath:gj,uniqueId:ei};function kE(){var e=new kn(this.__wrapped__);return e.__actions__=xo(this.__actions__),e.__dir__=this.__dir__,e.__filtered__=this.__filtered__,e.__iteratees__=xo(this.__iteratees__),e.__takeCount__=this.__takeCount__,e.__views__=xo(this.__views__),e}function _E(){if(this.__filtered__){var e=new kn(this);e.__dir__=-1,e.__filtered__=!0}else e=this.clone(),e.__dir__*=-1;return e}var SE=Math.max,CE=Math.min;function OE(e,t,n){for(var r=-1,a=n.length;++r<a;){var i=n[r],s=i.size;switch(i.type){case"drop":e+=s;break;case"dropRight":t-=s;break;case"take":t=CE(t,e+s);break;case"takeRight":e=SE(e,t-s);break}}return{start:e,end:t}}var EE=1,AE=2,RE=Math.min;function ME(){var e=this.__wrapped__.value(),t=this.__dir__,n=cr(e),r=t<0,a=n?e.length:0,i=OE(0,a,this.__views__),s=i.start,l=i.end,u=l-s,d=r?l:s-1,c=this.__iteratees__,v=c.length,f=0,g=RE(u,this.__takeCount__);if(!n||!r&&a==u&&g==u)return pj(e,this.__actions__);var m=[];e:for(;u--&&f<g;){d+=t;for(var b=-1,j=e[d];++b<v;){var w=c[b],O=w.iteratee,T=w.type,R=O(j);if(T==AE)j=R;else if(!R){if(T==EE)continue e;break e}}m[f++]=j}return m}/**
 * @license
 * Lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="es" -o ./`
 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */var zE="4.17.21",PE=2,TE=1,IE=3,ey=4294967295,NE=Array.prototype,LE=Object.prototype,ty=LE.hasOwnProperty,Zp=Ru?Ru.iterator:void 0,UE=Math.max,eh=Math.min,$f=function(e){return function(t,n,r){if(r==null){var a=fo(n),i=a&&wo(n),s=i&&i.length&&Cc(n,i);(s?s.length:a)||(r=n,n=t,t=this)}return e(t,n,r)}}(qx);y.after=Tr.after;y.ary=Tr.ary;y.assign=Kt.assign;y.assignIn=Kt.assignIn;y.assignInWith=Kt.assignInWith;y.assignWith=Kt.assignWith;y.at=Kt.at;y.before=Tr.before;y.bind=Tr.bind;y.bindAll=Yn.bindAll;y.bindKey=Tr.bindKey;y.castArray=Ct.castArray;y.chain=ha.chain;y.chunk=rt.chunk;y.compact=rt.compact;y.concat=rt.concat;y.cond=Yn.cond;y.conforms=Yn.conforms;y.constant=Yn.constant;y.countBy=dr.countBy;y.create=Kt.create;y.curry=Tr.curry;y.curryRight=Tr.curryRight;y.debounce=Tr.debounce;y.defaults=Kt.defaults;y.defaultsDeep=Kt.defaultsDeep;y.defer=Tr.defer;y.delay=Tr.delay;y.difference=rt.difference;y.differenceBy=rt.differenceBy;y.differenceWith=rt.differenceWith;y.drop=rt.drop;y.dropRight=rt.dropRight;y.dropRightWhile=rt.dropRightWhile;y.dropWhile=rt.dropWhile;y.fill=rt.fill;y.filter=dr.filter;y.flatMap=dr.flatMap;y.flatMapDeep=dr.flatMapDeep;y.flatMapDepth=dr.flatMapDepth;y.flatten=rt.flatten;y.flattenDeep=rt.flattenDeep;y.flattenDepth=rt.flattenDepth;y.flip=Tr.flip;y.flow=Yn.flow;y.flowRight=Yn.flowRight;y.fromPairs=rt.fromPairs;y.functions=Kt.functions;y.functionsIn=Kt.functionsIn;y.groupBy=dr.groupBy;y.initial=rt.initial;y.intersection=rt.intersection;y.intersectionBy=rt.intersectionBy;y.intersectionWith=rt.intersectionWith;y.invert=Kt.invert;y.invertBy=Kt.invertBy;y.invokeMap=dr.invokeMap;y.iteratee=Yn.iteratee;y.keyBy=dr.keyBy;y.keys=wo;y.keysIn=Kt.keysIn;y.map=dr.map;y.mapKeys=Kt.mapKeys;y.mapValues=Kt.mapValues;y.matches=Yn.matches;y.matchesProperty=Yn.matchesProperty;y.memoize=Tr.memoize;y.merge=Kt.merge;y.mergeWith=Kt.mergeWith;y.method=Yn.method;y.methodOf=Yn.methodOf;y.mixin=$f;y.negate=Hl;y.nthArg=Yn.nthArg;y.omit=Kt.omit;y.omitBy=Kt.omitBy;y.once=Tr.once;y.orderBy=dr.orderBy;y.over=Yn.over;y.overArgs=Tr.overArgs;y.overEvery=Yn.overEvery;y.overSome=Yn.overSome;y.partial=Tr.partial;y.partialRight=Tr.partialRight;y.partition=dr.partition;y.pick=Kt.pick;y.pickBy=Kt.pickBy;y.property=Yn.property;y.propertyOf=Yn.propertyOf;y.pull=rt.pull;y.pullAll=rt.pullAll;y.pullAllBy=rt.pullAllBy;y.pullAllWith=rt.pullAllWith;y.pullAt=rt.pullAt;y.range=Yn.range;y.rangeRight=Yn.rangeRight;y.rearg=Tr.rearg;y.reject=dr.reject;y.remove=rt.remove;y.rest=Tr.rest;y.reverse=rt.reverse;y.sampleSize=dr.sampleSize;y.set=Kt.set;y.setWith=Kt.setWith;y.shuffle=dr.shuffle;y.slice=rt.slice;y.sortBy=dr.sortBy;y.sortedUniq=rt.sortedUniq;y.sortedUniqBy=rt.sortedUniqBy;y.split=Hn.split;y.spread=Tr.spread;y.tail=rt.tail;y.take=rt.take;y.takeRight=rt.takeRight;y.takeRightWhile=rt.takeRightWhile;y.takeWhile=rt.takeWhile;y.tap=ha.tap;y.throttle=Tr.throttle;y.thru=Gl;y.toArray=Ct.toArray;y.toPairs=Kt.toPairs;y.toPairsIn=Kt.toPairsIn;y.toPath=Yn.toPath;y.toPlainObject=Ct.toPlainObject;y.transform=Kt.transform;y.unary=Tr.unary;y.union=rt.union;y.unionBy=rt.unionBy;y.unionWith=rt.unionWith;y.uniq=rt.uniq;y.uniqBy=rt.uniqBy;y.uniqWith=rt.uniqWith;y.unset=Kt.unset;y.unzip=rt.unzip;y.unzipWith=rt.unzipWith;y.update=Kt.update;y.updateWith=Kt.updateWith;y.values=Kt.values;y.valuesIn=Kt.valuesIn;y.without=rt.without;y.words=Hn.words;y.wrap=Tr.wrap;y.xor=rt.xor;y.xorBy=rt.xorBy;y.xorWith=rt.xorWith;y.zip=rt.zip;y.zipObject=rt.zipObject;y.zipObjectDeep=rt.zipObjectDeep;y.zipWith=rt.zipWith;y.entries=Kt.toPairs;y.entriesIn=Kt.toPairsIn;y.extend=Kt.assignIn;y.extendWith=Kt.assignInWith;$f(y,y);y.add=so.add;y.attempt=Yn.attempt;y.camelCase=Hn.camelCase;y.capitalize=Hn.capitalize;y.ceil=so.ceil;y.clamp=qf.clamp;y.clone=Ct.clone;y.cloneDeep=Ct.cloneDeep;y.cloneDeepWith=Ct.cloneDeepWith;y.cloneWith=Ct.cloneWith;y.conformsTo=Ct.conformsTo;y.deburr=Hn.deburr;y.defaultTo=Yn.defaultTo;y.divide=so.divide;y.endsWith=Hn.endsWith;y.eq=Ct.eq;y.escape=Hn.escape;y.escapeRegExp=Hn.escapeRegExp;y.every=dr.every;y.find=dr.find;y.findIndex=rt.findIndex;y.findKey=Kt.findKey;y.findLast=dr.findLast;y.findLastIndex=rt.findLastIndex;y.findLastKey=Kt.findLastKey;y.floor=so.floor;y.forEach=dr.forEach;y.forEachRight=dr.forEachRight;y.forIn=Kt.forIn;y.forInRight=Kt.forInRight;y.forOwn=Kt.forOwn;y.forOwnRight=Kt.forOwnRight;y.get=Kt.get;y.gt=Ct.gt;y.gte=Ct.gte;y.has=Kt.has;y.hasIn=Kt.hasIn;y.head=rt.head;y.identity=pa;y.includes=dr.includes;y.indexOf=rt.indexOf;y.inRange=qf.inRange;y.invoke=Kt.invoke;y.isArguments=Ct.isArguments;y.isArray=cr;y.isArrayBuffer=Ct.isArrayBuffer;y.isArrayLike=Ct.isArrayLike;y.isArrayLikeObject=Ct.isArrayLikeObject;y.isBoolean=Ct.isBoolean;y.isBuffer=Ct.isBuffer;y.isDate=Ct.isDate;y.isElement=Ct.isElement;y.isEmpty=Ct.isEmpty;y.isEqual=Ct.isEqual;y.isEqualWith=Ct.isEqualWith;y.isError=Ct.isError;y.isFinite=Ct.isFinite;y.isFunction=Ct.isFunction;y.isInteger=Ct.isInteger;y.isLength=Ct.isLength;y.isMap=Ct.isMap;y.isMatch=Ct.isMatch;y.isMatchWith=Ct.isMatchWith;y.isNaN=Ct.isNaN;y.isNative=Ct.isNative;y.isNil=Ct.isNil;y.isNull=Ct.isNull;y.isNumber=Ct.isNumber;y.isObject=fo;y.isObjectLike=Ct.isObjectLike;y.isPlainObject=Ct.isPlainObject;y.isRegExp=Ct.isRegExp;y.isSafeInteger=Ct.isSafeInteger;y.isSet=Ct.isSet;y.isString=Ct.isString;y.isSymbol=Ct.isSymbol;y.isTypedArray=Ct.isTypedArray;y.isUndefined=Ct.isUndefined;y.isWeakMap=Ct.isWeakMap;y.isWeakSet=Ct.isWeakSet;y.join=rt.join;y.kebabCase=Hn.kebabCase;y.last=ht;y.lastIndexOf=rt.lastIndexOf;y.lowerCase=Hn.lowerCase;y.lowerFirst=Hn.lowerFirst;y.lt=Ct.lt;y.lte=Ct.lte;y.max=so.max;y.maxBy=so.maxBy;y.mean=so.mean;y.meanBy=so.meanBy;y.min=so.min;y.minBy=so.minBy;y.stubArray=Yn.stubArray;y.stubFalse=Yn.stubFalse;y.stubObject=Yn.stubObject;y.stubString=Yn.stubString;y.stubTrue=Yn.stubTrue;y.multiply=so.multiply;y.nth=rt.nth;y.noop=Yn.noop;y.now=wE.now;y.pad=Hn.pad;y.padEnd=Hn.padEnd;y.padStart=Hn.padStart;y.parseInt=Hn.parseInt;y.random=qf.random;y.reduce=dr.reduce;y.reduceRight=dr.reduceRight;y.repeat=Hn.repeat;y.replace=Hn.replace;y.result=Kt.result;y.round=so.round;y.sample=dr.sample;y.size=dr.size;y.snakeCase=Hn.snakeCase;y.some=dr.some;y.sortedIndex=rt.sortedIndex;y.sortedIndexBy=rt.sortedIndexBy;y.sortedIndexOf=rt.sortedIndexOf;y.sortedLastIndex=rt.sortedLastIndex;y.sortedLastIndexBy=rt.sortedLastIndexBy;y.sortedLastIndexOf=rt.sortedLastIndexOf;y.startCase=Hn.startCase;y.startsWith=Hn.startsWith;y.subtract=so.subtract;y.sum=so.sum;y.sumBy=so.sumBy;y.template=Hn.template;y.times=Yn.times;y.toFinite=Ct.toFinite;y.toInteger=ln;y.toLength=Ct.toLength;y.toLower=Hn.toLower;y.toNumber=Ct.toNumber;y.toSafeInteger=Ct.toSafeInteger;y.toString=Ct.toString;y.toUpper=Hn.toUpper;y.trim=Hn.trim;y.trimEnd=Hn.trimEnd;y.trimStart=Hn.trimStart;y.truncate=Hn.truncate;y.unescape=Hn.unescape;y.uniqueId=Yn.uniqueId;y.upperCase=Hn.upperCase;y.upperFirst=Hn.upperFirst;y.each=dr.forEach;y.eachRight=dr.forEachRight;y.first=rt.head;$f(y,function(){var e={};return li(y,function(t,n){ty.call(y.prototype,n)||(e[n]=t)}),e}(),{chain:!1});y.VERSION=zE;(y.templateSettings=Hn.templateSettings).imports._=y;ta(["bind","bindKey","curry","curryRight","partial","partialRight"],function(e){y[e].placeholder=y});ta(["drop","take"],function(e,t){kn.prototype[e]=function(n){n=n===void 0?1:UE(ln(n),0);var r=this.__filtered__&&!t?new kn(this):this.clone();return r.__filtered__?r.__takeCount__=eh(n,r.__takeCount__):r.__views__.push({size:eh(n,ey),type:e+(r.__dir__<0?"Right":"")}),r},kn.prototype[e+"Right"]=function(n){return this.reverse()[e](n).reverse()}});ta(["filter","map","takeWhile"],function(e,t){var n=t+1,r=n==TE||n==IE;kn.prototype[e]=function(a){var i=this.clone();return i.__iteratees__.push({iteratee:vn(a),type:n}),i.__filtered__=i.__filtered__||r,i}});ta(["head","last"],function(e,t){var n="take"+(t?"Right":"");kn.prototype[e]=function(){return this[n](1).value()[0]}});ta(["initial","tail"],function(e,t){var n="drop"+(t?"":"Right");kn.prototype[e]=function(){return this.__filtered__?new kn(this):this[n](1)}});kn.prototype.compact=function(){return this.filter(pa)};kn.prototype.find=function(e){return this.filter(e).head()};kn.prototype.findLast=function(e){return this.reverse().find(e)};kn.prototype.invokeMap=mn(function(e,t){return typeof e=="function"?new kn(this):this.map(function(n){return Wl(n,e,t)})});kn.prototype.reject=function(e){return this.filter(Hl(vn(e)))};kn.prototype.slice=function(e,t){e=ln(e);var n=this;return n.__filtered__&&(e>0||t<0)?new kn(n):(e<0?n=n.takeRight(-e):e&&(n=n.drop(e)),t!==void 0&&(t=ln(t),n=t<0?n.dropRight(-t):n.take(t-e)),n)};kn.prototype.takeRightWhile=function(e){return this.reverse().takeWhile(e).reverse()};kn.prototype.toArray=function(){return this.take(ey)};li(kn.prototype,function(e,t){var n=/^(?:filter|find|map|reject)|While$/.test(t),r=/^(?:head|last)$/.test(t),a=y[r?"take"+(t=="last"?"Right":""):t],i=r||/^find/.test(t);a&&(y.prototype[t]=function(){var s=this.__wrapped__,l=r?[1]:arguments,u=s instanceof kn,d=l[0],c=u||cr(s),v=function(w){var O=a.apply(y,ql([w],l));return r&&f?O[0]:O};c&&n&&typeof d=="function"&&d.length!=1&&(u=c=!1);var f=this.__chain__,g=!!this.__actions__.length,m=i&&!f,b=u&&!g;if(!i&&c){s=b?s:new kn(this);var j=e.apply(s,l);return j.__actions__.push({func:Gl,args:[v],thisArg:void 0}),new Ro(j,f)}return m&&b?e.apply(this,l):(j=this.thru(v),m?r?j.value()[0]:j.value():j)})});ta(["pop","push","shift","sort","splice","unshift"],function(e){var t=NE[e],n=/^(?:push|sort|unshift)$/.test(e)?"tap":"thru",r=/^(?:pop|shift)$/.test(e);y.prototype[e]=function(){var a=arguments;if(r&&!this.__chain__){var i=this.value();return t.apply(cr(i)?i:[],a)}return this[n](function(s){return t.apply(cr(s)?s:[],a)})}});li(kn.prototype,function(e,t){var n=y[t];if(n){var r=n.name+"";ty.call(cs,r)||(cs[r]=[]),cs[r].push({name:t,func:n})}});cs[bc(void 0,PE).name]=[{name:"wrapper",func:void 0}];kn.prototype.clone=kE;kn.prototype.reverse=_E;kn.prototype.value=ME;y.prototype.at=ha.at;y.prototype.chain=ha.wrapperChain;y.prototype.commit=ha.commit;y.prototype.next=ha.next;y.prototype.plant=ha.plant;y.prototype.reverse=ha.reverse;y.prototype.toJSON=y.prototype.valueOf=y.prototype.value=ha.value;y.prototype.first=y.prototype.head;Zp&&(y.prototype[Zp]=ha.toIterator);/**
 * @license
 * Lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="es" -o ./`
 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */const ny=Object.freeze(Object.defineProperty({__proto__:null,add:Yg,after:Xg,ary:rf,assign:im,assignIn:Fd,assignInWith:wl,assignWith:sm,at:lm,attempt:sf,before:lf,bind:$l,bindAll:cm,bindKey:jc,camelCase:Mm,capitalize:uf,castArray:zm,ceil:Pm,chain:hf,chunk:Tm,clamp:Im,clone:Nm,cloneDeep:xl,cloneDeepWith:Jv,cloneWith:Lm,commit:Hd,compact:Um,concat:Dm,cond:qm,conforms:Fm,conformsTo:Bm,constant:$v,countBy:Wm,create:Hm,curry:wc,curryRight:kc,debounce:Si,deburr:vf,default:y,defaultTo:Vm,defaults:Gm,defaultsDeep:Ym,defer:Qm,delay:Zm,difference:eb,differenceBy:tb,differenceWith:nb,divide:rb,drop:ob,dropRight:ab,dropRightWhile:ib,dropWhile:sb,each:Gd,eachRight:Ou,endsWith:lb,entries:Kd,entriesIn:Yd,eq:ui,escape:xf,escapeRegExp:vb,every:pb,extend:Fd,extendWith:wl,fill:hb,filter:mb,find:xb,findIndex:yf,findKey:yb,findLast:wb,findLastIndex:wf,findLastKey:kb,first:Eo,flatMap:_b,flatMapDeep:Sb,flatMapDepth:Cb,flatten:af,flattenDeep:Ob,flattenDepth:Eb,flip:Ab,floor:Rb,flow:zb,flowRight:Pb,forEach:Gd,forEachRight:Ou,forIn:Tb,forInRight:Ib,forOwn:Nb,forOwnRight:Lb,fromPairs:Ub,functions:Db,functionsIn:qb,get:qv,groupBy:Wv,gt:$b,gte:Fb,has:Bb,hasIn:Bv,head:Eo,identity:pa,inRange:Wb,includes:Hb,indexOf:Vb,initial:sn,intersection:Jb,intersectionBy:Gb,intersectionWith:Kb,invert:Xb,invertBy:Zb,invoke:tx,invokeMap:nx,isArguments:Au,isArray:cr,isArrayBuffer:rx,isArrayLike:La,isArrayLikeObject:Pr,isBoolean:ox,isBuffer:uc,isDate:ax,isElement:ix,isEmpty:Pn,isEqual:Zt,isEqualWith:sx,isError:xc,isFinite:lx,isFunction:ci,isInteger:Of,isLength:Fg,isMap:zg,isMatch:ux,isMatchWith:cx,isNaN:dx,isNative:vx,isNil:fx,isNull:px,isNumber:Ef,isObject:fo,isObjectLike:io,isPlainObject:Ns,isRegExp:Ec,isSafeInteger:hx,isSet:Pg,isString:Bl,isSymbol:Oi,isTypedArray:cc,isUndefined:gx,isWeakMap:mx,isWeakSet:bx,iteratee:xx,join:jx,kebabCase:yx,keyBy:wx,keys:wo,keysIn:To,last:ht,lastIndexOf:kx,lodash:y,lowerCase:_x,lowerFirst:Sx,lt:Cx,lte:Ox,map:Rs,mapKeys:Ex,mapValues:Gv,matches:Ax,matchesProperty:Rx,max:Mx,maxBy:zx,mean:Tx,meanBy:Ix,memoize:Mg,merge:Nx,mergeWith:mf,method:Lx,methodOf:Ux,min:Dx,minBy:ns,mixin:qx,multiply:$x,negate:Hl,next:Xd,noop:br,now:Rg,nth:Bx,nthArg:Wx,omit:Iu,omitBy:Vx,once:Jx,orderBy:Gx,over:Kx,overArgs:Yx,overEvery:Xx,overSome:Qx,pad:a0,padEnd:i0,padStart:s0,parseInt:l0,partial:Jl,partialRight:Ac,partition:Hv,pick:u0,pickBy:zf,plant:tv,property:Tg,propertyOf:c0,pull:d0,pullAll:If,pullAllBy:v0,pullAllWith:f0,pullAt:h0,random:g0,range:lc,rangeRight:m0,rearg:b0,reduce:j0,reduceRight:y0,reject:w0,remove:k0,repeat:_0,replace:S0,rest:C0,result:O0,reverse:Lu,round:E0,sample:R0,sampleSize:M0,set:z0,setWith:P0,shuffle:T0,size:I0,slice:N0,snakeCase:L0,some:U0,sortBy:Vv,sortedIndex:D0,sortedIndexBy:q0,sortedIndexOf:$0,sortedLastIndex:F0,sortedLastIndexBy:B0,sortedLastIndexOf:W0,sortedUniq:V0,sortedUniqBy:J0,split:G0,spread:K0,startCase:Y0,startsWith:X0,stubArray:Dg,stubFalse:Qv,stubObject:Q0,stubString:Z0,stubTrue:ej,subtract:tj,sum:nj,sumBy:rj,tail:oj,take:aj,takeRight:ij,takeRightWhile:sj,takeWhile:lj,tap:uj,template:vj,templateSettings:Uu,throttle:fj,thru:Gl,times:Kv,toArray:Rf,toFinite:gs,toInteger:ln,toIterator:nv,toJSON:vl,toLength:jf,toLower:hj,toNumber:ia,toPairs:Kd,toPairsIn:Yd,toPath:gj,toPlainObject:gf,toSafeInteger:mj,toString:nr,toUpper:bj,transform:xj,trim:wj,trimEnd:kj,trimStart:_j,truncate:Sj,unary:Cj,unescape:Ej,union:Aj,unionBy:Rj,unionWith:Mj,uniq:zj,uniqBy:Pj,uniqWith:Tj,uniqueId:ei,unset:Ij,unzip:zc,unzipWith:Uf,update:Lj,updateWith:Uj,upperCase:Dj,upperFirst:yc,value:vl,valueOf:vl,values:qi,valuesIn:qj,without:$j,words:ff,wrap:Fj,wrapperAt:Bj,wrapperChain:Wj,wrapperCommit:Hd,wrapperLodash:y,wrapperNext:Xd,wrapperPlant:tv,wrapperReverse:Hj,wrapperToIterator:nv,wrapperValue:vl,xor:Vj,xorBy:Jj,xorWith:Gj,zip:Kj,zipObject:Xj,zipObjectDeep:Qj,zipWith:Zj},Symbol.toStringTag,{value:"Module"}));var ld={},th;function DE(){return th||(th=1,function(e){(function(t){function n(x){return x!==null?Object.prototype.toString.call(x)==="[object Array]":!1}function r(x){return x!==null?Object.prototype.toString.call(x)==="[object Object]":!1}function a(x,_){if(x===_)return!0;var E=Object.prototype.toString.call(x);if(E!==Object.prototype.toString.call(_))return!1;if(n(x)===!0){if(x.length!==_.length)return!1;for(var U=0;U<x.length;U++)if(a(x[U],_[U])===!1)return!1;return!0}if(r(x)===!0){var te={};for(var fe in x)if(hasOwnProperty.call(x,fe)){if(a(x[fe],_[fe])===!1)return!1;te[fe]=!0}for(var xe in _)if(hasOwnProperty.call(_,xe)&&te[xe]!==!0)return!1;return!0}return!1}function i(x){if(x===""||x===!1||x===null)return!0;if(n(x)&&x.length===0)return!0;if(r(x)){for(var _ in x)if(x.hasOwnProperty(_))return!1;return!0}else return!1}function s(x){for(var _=Object.keys(x),E=[],U=0;U<_.length;U++)E.push(x[_[U]]);return E}var l;typeof String.prototype.trimLeft=="function"?l=function(x){return x.trimLeft()}:l=function(x){return x.match(/^\s*(.*)/)[1]};var u=0,d=1,c=2,v=3,f=4,g=5,m=6,b=7,j=8,w=9,O={0:"number",1:"any",2:"string",3:"array",4:"object",5:"boolean",6:"expression",7:"null",8:"Array<number>",9:"Array<string>"},T="EOF",R="UnquotedIdentifier",k="QuotedIdentifier",D="Rbracket",H="Rparen",V="Comma",A="Colon",J="Rbrace",Z="Number",Y="Current",le="Expref",Ae="Pipe",ce="Or",we="And",$e="EQ",Ne="GT",ye="LT",ze="GTE",Re="LTE",We="NE",he="Flatten",ue="Star",me="Filter",ot="Dot",Ot="Not",ee="Lbrace",q="Lbracket",ae="Lparen",$="Literal",_e={".":ot,"*":ue,",":V,":":A,"{":ee,"}":J,"]":D,"(":ae,")":H,"@":Y},ne={"<":!0,">":!0,"=":!0,"!":!0},Ue={" ":!0,"	":!0,"\n":!0};function X(x){return x>="a"&&x<="z"||x>="A"&&x<="Z"||x==="_"}function L(x){return x>="0"&&x<="9"||x==="-"}function yt(x){return x>="a"&&x<="z"||x>="A"&&x<="Z"||x>="0"&&x<="9"||x==="_"}function Ze(){}Ze.prototype={tokenize:function(x){var _=[];this._current=0;for(var E,U,te;this._current<x.length;)if(X(x[this._current]))E=this._current,U=this._consumeUnquotedIdentifier(x),_.push({type:R,value:U,start:E});else if(_e[x[this._current]]!==void 0)_.push({type:_e[x[this._current]],value:x[this._current],start:this._current}),this._current++;else if(L(x[this._current]))te=this._consumeNumber(x),_.push(te);else if(x[this._current]==="[")te=this._consumeLBracket(x),_.push(te);else if(x[this._current]==='"')E=this._current,U=this._consumeQuotedIdentifier(x),_.push({type:k,value:U,start:E});else if(x[this._current]==="'")E=this._current,U=this._consumeRawStringLiteral(x),_.push({type:$,value:U,start:E});else if(x[this._current]==="`"){E=this._current;var fe=this._consumeLiteral(x);_.push({type:$,value:fe,start:E})}else if(ne[x[this._current]]!==void 0)_.push(this._consumeOperator(x));else if(Ue[x[this._current]]!==void 0)this._current++;else if(x[this._current]==="&")E=this._current,this._current++,x[this._current]==="&"?(this._current++,_.push({type:we,value:"&&",start:E})):_.push({type:le,value:"&",start:E});else if(x[this._current]==="|")E=this._current,this._current++,x[this._current]==="|"?(this._current++,_.push({type:ce,value:"||",start:E})):_.push({type:Ae,value:"|",start:E});else{var xe=new Error("Unknown character:"+x[this._current]);throw xe.name="LexerError",xe}return _},_consumeUnquotedIdentifier:function(x){var _=this._current;for(this._current++;this._current<x.length&&yt(x[this._current]);)this._current++;return x.slice(_,this._current)},_consumeQuotedIdentifier:function(x){var _=this._current;this._current++;for(var E=x.length;x[this._current]!=='"'&&this._current<E;){var U=this._current;x[U]==="\\"&&(x[U+1]==="\\"||x[U+1]==='"')?U+=2:U++,this._current=U}return this._current++,JSON.parse(x.slice(_,this._current))},_consumeRawStringLiteral:function(x){var _=this._current;this._current++;for(var E=x.length;x[this._current]!=="'"&&this._current<E;){var U=this._current;x[U]==="\\"&&(x[U+1]==="\\"||x[U+1]==="'")?U+=2:U++,this._current=U}this._current++;var te=x.slice(_+1,this._current-1);return te.replace("\\'","'")},_consumeNumber:function(x){var _=this._current;this._current++;for(var E=x.length;L(x[this._current])&&this._current<E;)this._current++;var U=parseInt(x.slice(_,this._current));return{type:Z,value:U,start:_}},_consumeLBracket:function(x){var _=this._current;return this._current++,x[this._current]==="?"?(this._current++,{type:me,value:"[?",start:_}):x[this._current]==="]"?(this._current++,{type:he,value:"[]",start:_}):{type:q,value:"[",start:_}},_consumeOperator:function(x){var _=this._current,E=x[_];if(this._current++,E==="!")return x[this._current]==="="?(this._current++,{type:We,value:"!=",start:_}):{type:Ot,value:"!",start:_};if(E==="<")return x[this._current]==="="?(this._current++,{type:Re,value:"<=",start:_}):{type:ye,value:"<",start:_};if(E===">")return x[this._current]==="="?(this._current++,{type:ze,value:">=",start:_}):{type:Ne,value:">",start:_};if(E==="="&&x[this._current]==="=")return this._current++,{type:$e,value:"==",start:_}},_consumeLiteral:function(x){this._current++;for(var _=this._current,E=x.length,U;x[this._current]!=="`"&&this._current<E;){var te=this._current;x[te]==="\\"&&(x[te+1]==="\\"||x[te+1]==="`")?te+=2:te++,this._current=te}var fe=l(x.slice(_,this._current));return fe=fe.replace("\\`","`"),this._looksLikeJSON(fe)?U=JSON.parse(fe):U=JSON.parse('"'+fe+'"'),this._current++,U},_looksLikeJSON:function(x){var _='[{"',E=["true","false","null"],U="-0123456789";if(x==="")return!1;if(_.indexOf(x[0])>=0)return!0;if(E.indexOf(x)>=0)return!0;if(U.indexOf(x[0])>=0)try{return JSON.parse(x),!0}catch{return!1}else return!1}};var Ce={};Ce[T]=0,Ce[R]=0,Ce[k]=0,Ce[D]=0,Ce[H]=0,Ce[V]=0,Ce[J]=0,Ce[Z]=0,Ce[Y]=0,Ce[le]=0,Ce[Ae]=1,Ce[ce]=2,Ce[we]=3,Ce[$e]=5,Ce[Ne]=5,Ce[ye]=5,Ce[ze]=5,Ce[Re]=5,Ce[We]=5,Ce[he]=9,Ce[ue]=20,Ce[me]=21,Ce[ot]=40,Ce[Ot]=45,Ce[ee]=50,Ce[q]=55,Ce[ae]=60;function st(){}st.prototype={parse:function(x){this._loadTokens(x),this.index=0;var _=this.expression(0);if(this._lookahead(0)!==T){var E=this._lookaheadToken(0),U=new Error("Unexpected token type: "+E.type+", value: "+E.value);throw U.name="ParserError",U}return _},_loadTokens:function(x){var _=new Ze,E=_.tokenize(x);E.push({type:T,value:"",start:x.length}),this.tokens=E},expression:function(x){var _=this._lookaheadToken(0);this._advance();for(var E=this.nud(_),U=this._lookahead(0);x<Ce[U];)this._advance(),E=this.led(U,E),U=this._lookahead(0);return E},_lookahead:function(x){return this.tokens[this.index+x].type},_lookaheadToken:function(x){return this.tokens[this.index+x]},_advance:function(){this.index++},nud:function(x){var _,E,U;switch(x.type){case $:return{type:"Literal",value:x.value};case R:return{type:"Field",name:x.value};case k:var te={type:"Field",name:x.value};if(this._lookahead(0)===ae)throw new Error("Quoted identifier not allowed for function names.");return te;case Ot:return E=this.expression(Ce.Not),{type:"NotExpression",children:[E]};case ue:return _={type:"Identity"},E=null,this._lookahead(0)===D?E={type:"Identity"}:E=this._parseProjectionRHS(Ce.Star),{type:"ValueProjection",children:[_,E]};case me:return this.led(x.type,{type:"Identity"});case ee:return this._parseMultiselectHash();case he:return _={type:he,children:[{type:"Identity"}]},E=this._parseProjectionRHS(Ce.Flatten),{type:"Projection",children:[_,E]};case q:return this._lookahead(0)===Z||this._lookahead(0)===A?(E=this._parseIndexExpression(),this._projectIfSlice({type:"Identity"},E)):this._lookahead(0)===ue&&this._lookahead(1)===D?(this._advance(),this._advance(),E=this._parseProjectionRHS(Ce.Star),{type:"Projection",children:[{type:"Identity"},E]}):this._parseMultiselectList();case Y:return{type:Y};case le:return U=this.expression(Ce.Expref),{type:"ExpressionReference",children:[U]};case ae:for(var fe=[];this._lookahead(0)!==H;)this._lookahead(0)===Y?(U={type:Y},this._advance()):U=this.expression(0),fe.push(U);return this._match(H),fe[0];default:this._errorToken(x)}},led:function(x,_){var E;switch(x){case ot:var U=Ce.Dot;return this._lookahead(0)!==ue?(E=this._parseDotRHS(U),{type:"Subexpression",children:[_,E]}):(this._advance(),E=this._parseProjectionRHS(U),{type:"ValueProjection",children:[_,E]});case Ae:return E=this.expression(Ce.Pipe),{type:Ae,children:[_,E]};case ce:return E=this.expression(Ce.Or),{type:"OrExpression",children:[_,E]};case we:return E=this.expression(Ce.And),{type:"AndExpression",children:[_,E]};case ae:for(var te=_.name,fe=[],xe,N;this._lookahead(0)!==H;)this._lookahead(0)===Y?(xe={type:Y},this._advance()):xe=this.expression(0),this._lookahead(0)===V&&this._match(V),fe.push(xe);return this._match(H),N={type:"Function",name:te,children:fe},N;case me:var Fe=this.expression(0);return this._match(D),this._lookahead(0)===he?E={type:"Identity"}:E=this._parseProjectionRHS(Ce.Filter),{type:"FilterProjection",children:[_,E,Fe]};case he:var Ge={type:he,children:[_]},Et=this._parseProjectionRHS(Ce.Flatten);return{type:"Projection",children:[Ge,Et]};case $e:case We:case Ne:case ze:case ye:case Re:return this._parseComparator(_,x);case q:var pe=this._lookaheadToken(0);return pe.type===Z||pe.type===A?(E=this._parseIndexExpression(),this._projectIfSlice(_,E)):(this._match(ue),this._match(D),E=this._parseProjectionRHS(Ce.Star),{type:"Projection",children:[_,E]});default:this._errorToken(this._lookaheadToken(0))}},_match:function(x){if(this._lookahead(0)===x)this._advance();else{var _=this._lookaheadToken(0),E=new Error("Expected "+x+", got: "+_.type);throw E.name="ParserError",E}},_errorToken:function(x){var _=new Error("Invalid token ("+x.type+'): "'+x.value+'"');throw _.name="ParserError",_},_parseIndexExpression:function(){if(this._lookahead(0)===A||this._lookahead(1)===A)return this._parseSliceExpression();var x={type:"Index",value:this._lookaheadToken(0).value};return this._advance(),this._match(D),x},_projectIfSlice:function(x,_){var E={type:"IndexExpression",children:[x,_]};return _.type==="Slice"?{type:"Projection",children:[E,this._parseProjectionRHS(Ce.Star)]}:E},_parseSliceExpression:function(){for(var x=[null,null,null],_=0,E=this._lookahead(0);E!==D&&_<3;){if(E===A)_++,this._advance();else if(E===Z)x[_]=this._lookaheadToken(0).value,this._advance();else{var U=this._lookahead(0),te=new Error("Syntax error, unexpected token: "+U.value+"("+U.type+")");throw te.name="Parsererror",te}E=this._lookahead(0)}return this._match(D),{type:"Slice",children:x}},_parseComparator:function(x,_){var E=this.expression(Ce[_]);return{type:"Comparator",name:_,children:[x,E]}},_parseDotRHS:function(x){var _=this._lookahead(0),E=[R,k,ue];if(E.indexOf(_)>=0)return this.expression(x);if(_===q)return this._match(q),this._parseMultiselectList();if(_===ee)return this._match(ee),this._parseMultiselectHash()},_parseProjectionRHS:function(x){var _;if(Ce[this._lookahead(0)]<10)_={type:"Identity"};else if(this._lookahead(0)===q)_=this.expression(x);else if(this._lookahead(0)===me)_=this.expression(x);else if(this._lookahead(0)===ot)this._match(ot),_=this._parseDotRHS(x);else{var E=this._lookaheadToken(0),U=new Error("Sytanx error, unexpected token: "+E.value+"("+E.type+")");throw U.name="ParserError",U}return _},_parseMultiselectList:function(){for(var x=[];this._lookahead(0)!==D;){var _=this.expression(0);if(x.push(_),this._lookahead(0)===V&&(this._match(V),this._lookahead(0)===D))throw new Error("Unexpected token Rbracket")}return this._match(D),{type:"MultiSelectList",children:x}},_parseMultiselectHash:function(){for(var x=[],_=[R,k],E,U,te,fe;;){if(E=this._lookaheadToken(0),_.indexOf(E.type)<0)throw new Error("Expecting an identifier token, got: "+E.type);if(U=E.value,this._advance(),this._match(A),te=this.expression(0),fe={type:"KeyValuePair",name:U,value:te},x.push(fe),this._lookahead(0)===V)this._match(V);else if(this._lookahead(0)===J){this._match(J);break}}return{type:"MultiSelectHash",children:x}}};function Me(x){this.runtime=x}Me.prototype={search:function(x,_){return this.visit(x,_)},visit:function(x,_){var E,U,te,fe,xe,N,Fe,Ge,Et,pe;switch(x.type){case"Field":return _!==null&&r(_)?(N=_[x.name],N===void 0?null:N):null;case"Subexpression":for(te=this.visit(x.children[0],_),pe=1;pe<x.children.length;pe++)if(te=this.visit(x.children[1],te),te===null)return null;return te;case"IndexExpression":return Fe=this.visit(x.children[0],_),Ge=this.visit(x.children[1],Fe),Ge;case"Index":if(!n(_))return null;var vt=x.value;return vt<0&&(vt=_.length+vt),te=_[vt],te===void 0&&(te=null),te;case"Slice":if(!n(_))return null;var Vt=x.children.slice(0),rr=this.computeSliceParams(_.length,Vt),fn=rr[0],$t=rr[1],Ln=rr[2];if(te=[],Ln>0)for(pe=fn;pe<$t;pe+=Ln)te.push(_[pe]);else for(pe=fn;pe>$t;pe+=Ln)te.push(_[pe]);return te;case"Projection":var wt=this.visit(x.children[0],_);if(!n(wt))return null;for(Et=[],pe=0;pe<wt.length;pe++)U=this.visit(x.children[1],wt[pe]),U!==null&&Et.push(U);return Et;case"ValueProjection":if(wt=this.visit(x.children[0],_),!r(wt))return null;Et=[];var hn=s(wt);for(pe=0;pe<hn.length;pe++)U=this.visit(x.children[1],hn[pe]),U!==null&&Et.push(U);return Et;case"FilterProjection":if(wt=this.visit(x.children[0],_),!n(wt))return null;var en=[],Jt=[];for(pe=0;pe<wt.length;pe++)E=this.visit(x.children[2],wt[pe]),i(E)||en.push(wt[pe]);for(var gt=0;gt<en.length;gt++)U=this.visit(x.children[1],en[gt]),U!==null&&Jt.push(U);return Jt;case"Comparator":switch(fe=this.visit(x.children[0],_),xe=this.visit(x.children[1],_),x.name){case $e:te=a(fe,xe);break;case We:te=!a(fe,xe);break;case Ne:te=fe>xe;break;case ze:te=fe>=xe;break;case ye:te=fe<xe;break;case Re:te=fe<=xe;break;default:throw new Error("Unknown comparator: "+x.name)}return te;case he:var on=this.visit(x.children[0],_);if(!n(on))return null;var it=[];for(pe=0;pe<on.length;pe++)U=on[pe],n(U)?it.push.apply(it,U):it.push(U);return it;case"Identity":return _;case"MultiSelectList":if(_===null)return null;for(Et=[],pe=0;pe<x.children.length;pe++)Et.push(this.visit(x.children[pe],_));return Et;case"MultiSelectHash":if(_===null)return null;Et={};var Ft;for(pe=0;pe<x.children.length;pe++)Ft=x.children[pe],Et[Ft.name]=this.visit(Ft.value,_);return Et;case"OrExpression":return E=this.visit(x.children[0],_),i(E)&&(E=this.visit(x.children[1],_)),E;case"AndExpression":return fe=this.visit(x.children[0],_),i(fe)===!0?fe:this.visit(x.children[1],_);case"NotExpression":return fe=this.visit(x.children[0],_),i(fe);case"Literal":return x.value;case Ae:return Fe=this.visit(x.children[0],_),this.visit(x.children[1],Fe);case Y:return _;case"Function":var Yt=[];for(pe=0;pe<x.children.length;pe++)Yt.push(this.visit(x.children[pe],_));return this.runtime.callFunction(x.name,Yt);case"ExpressionReference":var En=x.children[0];return En.jmespathType=le,En;default:throw new Error("Unknown node type: "+x.type)}},computeSliceParams:function(x,_){var E=_[0],U=_[1],te=_[2],fe=[null,null,null];if(te===null)te=1;else if(te===0){var xe=new Error("Invalid slice, step cannot be 0");throw xe.name="RuntimeError",xe}var N=te<0;return E===null?E=N?x-1:0:E=this.capSliceRange(x,E,te),U===null?U=N?-1:x:U=this.capSliceRange(x,U,te),fe[0]=E,fe[1]=U,fe[2]=te,fe},capSliceRange:function(x,_,E){return _<0?(_+=x,_<0&&(_=E<0?-1:0)):_>=x&&(_=E<0?x-1:x),_}};function at(x){this._interpreter=x,this.functionTable={abs:{_func:this._functionAbs,_signature:[{types:[u]}]},avg:{_func:this._functionAvg,_signature:[{types:[j]}]},ceil:{_func:this._functionCeil,_signature:[{types:[u]}]},contains:{_func:this._functionContains,_signature:[{types:[c,v]},{types:[d]}]},ends_with:{_func:this._functionEndsWith,_signature:[{types:[c]},{types:[c]}]},floor:{_func:this._functionFloor,_signature:[{types:[u]}]},length:{_func:this._functionLength,_signature:[{types:[c,v,f]}]},map:{_func:this._functionMap,_signature:[{types:[m]},{types:[v]}]},max:{_func:this._functionMax,_signature:[{types:[j,w]}]},merge:{_func:this._functionMerge,_signature:[{types:[f],variadic:!0}]},max_by:{_func:this._functionMaxBy,_signature:[{types:[v]},{types:[m]}]},sum:{_func:this._functionSum,_signature:[{types:[j]}]},starts_with:{_func:this._functionStartsWith,_signature:[{types:[c]},{types:[c]}]},min:{_func:this._functionMin,_signature:[{types:[j,w]}]},min_by:{_func:this._functionMinBy,_signature:[{types:[v]},{types:[m]}]},type:{_func:this._functionType,_signature:[{types:[d]}]},keys:{_func:this._functionKeys,_signature:[{types:[f]}]},values:{_func:this._functionValues,_signature:[{types:[f]}]},sort:{_func:this._functionSort,_signature:[{types:[w,j]}]},sort_by:{_func:this._functionSortBy,_signature:[{types:[v]},{types:[m]}]},join:{_func:this._functionJoin,_signature:[{types:[c]},{types:[w]}]},reverse:{_func:this._functionReverse,_signature:[{types:[c,v]}]},to_array:{_func:this._functionToArray,_signature:[{types:[d]}]},to_string:{_func:this._functionToString,_signature:[{types:[d]}]},to_number:{_func:this._functionToNumber,_signature:[{types:[d]}]},not_null:{_func:this._functionNotNull,_signature:[{types:[d],variadic:!0}]}}}at.prototype={callFunction:function(x,_){var E=this.functionTable[x];if(E===void 0)throw new Error("Unknown function: "+x+"()");return this._validateArgs(x,_,E._signature),E._func.call(this,_)},_validateArgs:function(x,_,E){var U;if(E[E.length-1].variadic){if(_.length<E.length)throw U=E.length===1?" argument":" arguments",new Error("ArgumentError: "+x+"() takes at least"+E.length+U+" but received "+_.length)}else if(_.length!==E.length)throw U=E.length===1?" argument":" arguments",new Error("ArgumentError: "+x+"() takes "+E.length+U+" but received "+_.length);for(var te,fe,xe,N=0;N<E.length;N++){xe=!1,te=E[N].types,fe=this._getTypeName(_[N]);for(var Fe=0;Fe<te.length;Fe++)if(this._typeMatches(fe,te[Fe],_[N])){xe=!0;break}if(!xe){var Ge=te.map(function(Et){return O[Et]}).join(",");throw new Error("TypeError: "+x+"() expected argument "+(N+1)+" to be type "+Ge+" but received type "+O[fe]+" instead.")}}},_typeMatches:function(x,_,E){if(_===d)return!0;if(_===w||_===j||_===v){if(_===v)return x===v;if(x===v){var U;_===j?U=u:_===w&&(U=c);for(var te=0;te<E.length;te++)if(!this._typeMatches(this._getTypeName(E[te]),U,E[te]))return!1;return!0}}else return x===_},_getTypeName:function(x){switch(Object.prototype.toString.call(x)){case"[object String]":return c;case"[object Number]":return u;case"[object Array]":return v;case"[object Boolean]":return g;case"[object Null]":return b;case"[object Object]":return x.jmespathType===le?m:f}},_functionStartsWith:function(x){return x[0].lastIndexOf(x[1])===0},_functionEndsWith:function(x){var _=x[0],E=x[1];return _.indexOf(E,_.length-E.length)!==-1},_functionReverse:function(x){var _=this._getTypeName(x[0]);if(_===c){for(var E=x[0],U="",te=E.length-1;te>=0;te--)U+=E[te];return U}else{var fe=x[0].slice(0);return fe.reverse(),fe}},_functionAbs:function(x){return Math.abs(x[0])},_functionCeil:function(x){return Math.ceil(x[0])},_functionAvg:function(x){for(var _=0,E=x[0],U=0;U<E.length;U++)_+=E[U];return _/E.length},_functionContains:function(x){return x[0].indexOf(x[1])>=0},_functionFloor:function(x){return Math.floor(x[0])},_functionLength:function(x){return r(x[0])?Object.keys(x[0]).length:x[0].length},_functionMap:function(x){for(var _=[],E=this._interpreter,U=x[0],te=x[1],fe=0;fe<te.length;fe++)_.push(E.visit(U,te[fe]));return _},_functionMerge:function(x){for(var _={},E=0;E<x.length;E++){var U=x[E];for(var te in U)_[te]=U[te]}return _},_functionMax:function(x){if(x[0].length>0){var _=this._getTypeName(x[0][0]);if(_===u)return Math.max.apply(Math,x[0]);for(var E=x[0],U=E[0],te=1;te<E.length;te++)U.localeCompare(E[te])<0&&(U=E[te]);return U}else return null},_functionMin:function(x){if(x[0].length>0){var _=this._getTypeName(x[0][0]);if(_===u)return Math.min.apply(Math,x[0]);for(var E=x[0],U=E[0],te=1;te<E.length;te++)E[te].localeCompare(U)<0&&(U=E[te]);return U}else return null},_functionSum:function(x){for(var _=0,E=x[0],U=0;U<E.length;U++)_+=E[U];return _},_functionType:function(x){switch(this._getTypeName(x[0])){case u:return"number";case c:return"string";case v:return"array";case f:return"object";case g:return"boolean";case m:return"expref";case b:return"null"}},_functionKeys:function(x){return Object.keys(x[0])},_functionValues:function(x){for(var _=x[0],E=Object.keys(_),U=[],te=0;te<E.length;te++)U.push(_[E[te]]);return U},_functionJoin:function(x){var _=x[0],E=x[1];return E.join(_)},_functionToArray:function(x){return this._getTypeName(x[0])===v?x[0]:[x[0]]},_functionToString:function(x){return this._getTypeName(x[0])===c?x[0]:JSON.stringify(x[0])},_functionToNumber:function(x){var _=this._getTypeName(x[0]),E;return _===u?x[0]:_===c&&(E=+x[0],!isNaN(E))?E:null},_functionNotNull:function(x){for(var _=0;_<x.length;_++)if(this._getTypeName(x[_])!==b)return x[_];return null},_functionSort:function(x){var _=x[0].slice(0);return _.sort(),_},_functionSortBy:function(x){var _=x[0].slice(0);if(_.length===0)return _;var E=this._interpreter,U=x[1],te=this._getTypeName(E.visit(U,_[0]));if([u,c].indexOf(te)<0)throw new Error("TypeError");for(var fe=this,xe=[],N=0;N<_.length;N++)xe.push([N,_[N]]);xe.sort(function(Ge,Et){var pe=E.visit(U,Ge[1]),vt=E.visit(U,Et[1]);if(fe._getTypeName(pe)!==te)throw new Error("TypeError: expected "+te+", received "+fe._getTypeName(pe));if(fe._getTypeName(vt)!==te)throw new Error("TypeError: expected "+te+", received "+fe._getTypeName(vt));return pe>vt?1:pe<vt?-1:Ge[0]-Et[0]});for(var Fe=0;Fe<xe.length;Fe++)_[Fe]=xe[Fe][1];return _},_functionMaxBy:function(x){for(var _=x[1],E=x[0],U=this.createKeyFunction(_,[u,c]),te=-1/0,fe,xe,N=0;N<E.length;N++)xe=U(E[N]),xe>te&&(te=xe,fe=E[N]);return fe},_functionMinBy:function(x){for(var _=x[1],E=x[0],U=this.createKeyFunction(_,[u,c]),te=1/0,fe,xe,N=0;N<E.length;N++)xe=U(E[N]),xe<te&&(te=xe,fe=E[N]);return fe},createKeyFunction:function(x,_){var E=this,U=this._interpreter,te=function(fe){var xe=U.visit(x,fe);if(_.indexOf(E._getTypeName(xe))<0){var N="TypeError: expected one of "+_+", received "+E._getTypeName(xe);throw new Error(N)}return xe};return te}};function Tt(x){var _=new st,E=_.parse(x);return E}function Je(x){var _=new Ze;return _.tokenize(x)}function qt(x,_){var E=new st,U=new at,te=new Me(U);U._interpreter=te;var fe=E.parse(_);return te.search(fe,x)}t.tokenize=Je,t.compile=Tt,t.search=qt,t.strictDeepEqual=a})(e)}(ld)),ld}var ry=DE();const oy=B1(ry),qE=Qk({__proto__:null,default:oy},[ry]);class $E{add(t,n,r){if(typeof arguments[0]!="string")for(let a in arguments[0])this.add(a,arguments[0][a],arguments[1]);else(Array.isArray(t)?t:[t]).forEach(function(a){this[a]=this[a]||[],n&&this[a][r?"unshift":"push"](n)},this)}run(t,n){this[t]=this[t]||[],this[t].forEach(function(r){r.call(n&&n.context?n.context:n,n)})}}class FE{constructor(t){this.jsep=t,this.registered={}}register(){for(var t=arguments.length,n=new Array(t),r=0;r<t;r++)n[r]=arguments[r];n.forEach(a=>{if(typeof a!="object"||!a.name||!a.init)throw new Error("Invalid JSEP plugin format");this.registered[a.name]||(a.init(this.jsep),this.registered[a.name]=a)})}}class se{static get version(){return"1.4.0"}static toString(){return"JavaScript Expression Parser (JSEP) v"+se.version}static addUnaryOp(t){return se.max_unop_len=Math.max(t.length,se.max_unop_len),se.unary_ops[t]=1,se}static addBinaryOp(t,n,r){return se.max_binop_len=Math.max(t.length,se.max_binop_len),se.binary_ops[t]=n,r?se.right_associative.add(t):se.right_associative.delete(t),se}static addIdentifierChar(t){return se.additional_identifier_chars.add(t),se}static addLiteral(t,n){return se.literals[t]=n,se}static removeUnaryOp(t){return delete se.unary_ops[t],t.length===se.max_unop_len&&(se.max_unop_len=se.getMaxKeyLen(se.unary_ops)),se}static removeAllUnaryOps(){return se.unary_ops={},se.max_unop_len=0,se}static removeIdentifierChar(t){return se.additional_identifier_chars.delete(t),se}static removeBinaryOp(t){return delete se.binary_ops[t],t.length===se.max_binop_len&&(se.max_binop_len=se.getMaxKeyLen(se.binary_ops)),se.right_associative.delete(t),se}static removeAllBinaryOps(){return se.binary_ops={},se.max_binop_len=0,se}static removeLiteral(t){return delete se.literals[t],se}static removeAllLiterals(){return se.literals={},se}get char(){return this.expr.charAt(this.index)}get code(){return this.expr.charCodeAt(this.index)}constructor(t){this.expr=t,this.index=0}static parse(t){return new se(t).parse()}static getMaxKeyLen(t){return Math.max(0,...Object.keys(t).map(n=>n.length))}static isDecimalDigit(t){return t>=48&&t<=57}static binaryPrecedence(t){return se.binary_ops[t]||0}static isIdentifierStart(t){return t>=65&&t<=90||t>=97&&t<=122||t>=128&&!se.binary_ops[String.fromCharCode(t)]||se.additional_identifier_chars.has(String.fromCharCode(t))}static isIdentifierPart(t){return se.isIdentifierStart(t)||se.isDecimalDigit(t)}throwError(t){const n=new Error(t+" at character "+this.index);throw n.index=this.index,n.description=t,n}runHook(t,n){if(se.hooks[t]){const r={context:this,node:n};return se.hooks.run(t,r),r.node}return n}searchHook(t){if(se.hooks[t]){const n={context:this};return se.hooks[t].find(function(r){return r.call(n.context,n),n.node}),n.node}}gobbleSpaces(){let t=this.code;for(;t===se.SPACE_CODE||t===se.TAB_CODE||t===se.LF_CODE||t===se.CR_CODE;)t=this.expr.charCodeAt(++this.index);this.runHook("gobble-spaces")}parse(){this.runHook("before-all");const t=this.gobbleExpressions(),n=t.length===1?t[0]:{type:se.COMPOUND,body:t};return this.runHook("after-all",n)}gobbleExpressions(t){let n=[],r,a;for(;this.index<this.expr.length;)if(r=this.code,r===se.SEMCOL_CODE||r===se.COMMA_CODE)this.index++;else if(a=this.gobbleExpression())n.push(a);else if(this.index<this.expr.length){if(r===t)break;this.throwError('Unexpected "'+this.char+'"')}return n}gobbleExpression(){const t=this.searchHook("gobble-expression")||this.gobbleBinaryExpression();return this.gobbleSpaces(),this.runHook("after-expression",t)}gobbleBinaryOp(){this.gobbleSpaces();let t=this.expr.substr(this.index,se.max_binop_len),n=t.length;for(;n>0;){if(se.binary_ops.hasOwnProperty(t)&&(!se.isIdentifierStart(this.code)||this.index+t.length<this.expr.length&&!se.isIdentifierPart(this.expr.charCodeAt(this.index+t.length))))return this.index+=n,t;t=t.substr(0,--n)}return!1}gobbleBinaryExpression(){let t,n,r,a,i,s,l,u,d;if(s=this.gobbleToken(),!s||(n=this.gobbleBinaryOp(),!n))return s;for(i={value:n,prec:se.binaryPrecedence(n),right_a:se.right_associative.has(n)},l=this.gobbleToken(),l||this.throwError("Expected expression after "+n),a=[s,i,l];n=this.gobbleBinaryOp();){if(r=se.binaryPrecedence(n),r===0){this.index-=n.length;break}i={value:n,prec:r,right_a:se.right_associative.has(n)},d=n;const c=v=>i.right_a&&v.right_a?r>v.prec:r<=v.prec;for(;a.length>2&&c(a[a.length-2]);)l=a.pop(),n=a.pop().value,s=a.pop(),t={type:se.BINARY_EXP,operator:n,left:s,right:l},a.push(t);t=this.gobbleToken(),t||this.throwError("Expected expression after "+d),a.push(i,t)}for(u=a.length-1,t=a[u];u>1;)t={type:se.BINARY_EXP,operator:a[u-1].value,left:a[u-2],right:t},u-=2;return t}gobbleToken(){let t,n,r,a;if(this.gobbleSpaces(),a=this.searchHook("gobble-token"),a)return this.runHook("after-token",a);if(t=this.code,se.isDecimalDigit(t)||t===se.PERIOD_CODE)return this.gobbleNumericLiteral();if(t===se.SQUOTE_CODE||t===se.DQUOTE_CODE)a=this.gobbleStringLiteral();else if(t===se.OBRACK_CODE)a=this.gobbleArray();else{for(n=this.expr.substr(this.index,se.max_unop_len),r=n.length;r>0;){if(se.unary_ops.hasOwnProperty(n)&&(!se.isIdentifierStart(this.code)||this.index+n.length<this.expr.length&&!se.isIdentifierPart(this.expr.charCodeAt(this.index+n.length)))){this.index+=r;const i=this.gobbleToken();return i||this.throwError("missing unaryOp argument"),this.runHook("after-token",{type:se.UNARY_EXP,operator:n,argument:i,prefix:!0})}n=n.substr(0,--r)}se.isIdentifierStart(t)?(a=this.gobbleIdentifier(),se.literals.hasOwnProperty(a.name)?a={type:se.LITERAL,value:se.literals[a.name],raw:a.name}:a.name===se.this_str&&(a={type:se.THIS_EXP})):t===se.OPAREN_CODE&&(a=this.gobbleGroup())}return a?(a=this.gobbleTokenProperty(a),this.runHook("after-token",a)):this.runHook("after-token",!1)}gobbleTokenProperty(t){this.gobbleSpaces();let n=this.code;for(;n===se.PERIOD_CODE||n===se.OBRACK_CODE||n===se.OPAREN_CODE||n===se.QUMARK_CODE;){let r;if(n===se.QUMARK_CODE){if(this.expr.charCodeAt(this.index+1)!==se.PERIOD_CODE)break;r=!0,this.index+=2,this.gobbleSpaces(),n=this.code}this.index++,n===se.OBRACK_CODE?(t={type:se.MEMBER_EXP,computed:!0,object:t,property:this.gobbleExpression()},t.property||this.throwError('Unexpected "'+this.char+'"'),this.gobbleSpaces(),n=this.code,n!==se.CBRACK_CODE&&this.throwError("Unclosed ["),this.index++):n===se.OPAREN_CODE?t={type:se.CALL_EXP,arguments:this.gobbleArguments(se.CPAREN_CODE),callee:t}:(n===se.PERIOD_CODE||r)&&(r&&this.index--,this.gobbleSpaces(),t={type:se.MEMBER_EXP,computed:!1,object:t,property:this.gobbleIdentifier()}),r&&(t.optional=!0),this.gobbleSpaces(),n=this.code}return t}gobbleNumericLiteral(){let t="",n,r;for(;se.isDecimalDigit(this.code);)t+=this.expr.charAt(this.index++);if(this.code===se.PERIOD_CODE)for(t+=this.expr.charAt(this.index++);se.isDecimalDigit(this.code);)t+=this.expr.charAt(this.index++);if(n=this.char,n==="e"||n==="E"){for(t+=this.expr.charAt(this.index++),n=this.char,(n==="+"||n==="-")&&(t+=this.expr.charAt(this.index++));se.isDecimalDigit(this.code);)t+=this.expr.charAt(this.index++);se.isDecimalDigit(this.expr.charCodeAt(this.index-1))||this.throwError("Expected exponent ("+t+this.char+")")}return r=this.code,se.isIdentifierStart(r)?this.throwError("Variable names cannot start with a number ("+t+this.char+")"):(r===se.PERIOD_CODE||t.length===1&&t.charCodeAt(0)===se.PERIOD_CODE)&&this.throwError("Unexpected period"),{type:se.LITERAL,value:parseFloat(t),raw:t}}gobbleStringLiteral(){let t="";const n=this.index,r=this.expr.charAt(this.index++);let a=!1;for(;this.index<this.expr.length;){let i=this.expr.charAt(this.index++);if(i===r){a=!0;break}else if(i==="\\")switch(i=this.expr.charAt(this.index++),i){case"n":t+=`
`;break;case"r":t+="\r";break;case"t":t+="	";break;case"b":t+="\b";break;case"f":t+="\f";break;case"v":t+="\v";break;default:t+=i}else t+=i}return a||this.throwError('Unclosed quote after "'+t+'"'),{type:se.LITERAL,value:t,raw:this.expr.substring(n,this.index)}}gobbleIdentifier(){let t=this.code,n=this.index;for(se.isIdentifierStart(t)?this.index++:this.throwError("Unexpected "+this.char);this.index<this.expr.length&&(t=this.code,se.isIdentifierPart(t));)this.index++;return{type:se.IDENTIFIER,name:this.expr.slice(n,this.index)}}gobbleArguments(t){const n=[];let r=!1,a=0;for(;this.index<this.expr.length;){this.gobbleSpaces();let i=this.code;if(i===t){r=!0,this.index++,t===se.CPAREN_CODE&&a&&a>=n.length&&this.throwError("Unexpected token "+String.fromCharCode(t));break}else if(i===se.COMMA_CODE){if(this.index++,a++,a!==n.length){if(t===se.CPAREN_CODE)this.throwError("Unexpected token ,");else if(t===se.CBRACK_CODE)for(let s=n.length;s<a;s++)n.push(null)}}else if(n.length!==a&&a!==0)this.throwError("Expected comma");else{const s=this.gobbleExpression();(!s||s.type===se.COMPOUND)&&this.throwError("Expected comma"),n.push(s)}}return r||this.throwError("Expected "+String.fromCharCode(t)),n}gobbleGroup(){this.index++;let t=this.gobbleExpressions(se.CPAREN_CODE);if(this.code===se.CPAREN_CODE)return this.index++,t.length===1?t[0]:t.length?{type:se.SEQUENCE_EXP,expressions:t}:!1;this.throwError("Unclosed (")}gobbleArray(){return this.index++,{type:se.ARRAY_EXP,elements:this.gobbleArguments(se.CBRACK_CODE)}}}const BE=new $E;Object.assign(se,{hooks:BE,plugins:new FE(se),COMPOUND:"Compound",SEQUENCE_EXP:"SequenceExpression",IDENTIFIER:"Identifier",MEMBER_EXP:"MemberExpression",LITERAL:"Literal",THIS_EXP:"ThisExpression",CALL_EXP:"CallExpression",UNARY_EXP:"UnaryExpression",BINARY_EXP:"BinaryExpression",ARRAY_EXP:"ArrayExpression",TAB_CODE:9,LF_CODE:10,CR_CODE:13,SPACE_CODE:32,PERIOD_CODE:46,COMMA_CODE:44,SQUOTE_CODE:39,DQUOTE_CODE:34,OPAREN_CODE:40,CPAREN_CODE:41,OBRACK_CODE:91,CBRACK_CODE:93,QUMARK_CODE:63,SEMCOL_CODE:59,COLON_CODE:58,unary_ops:{"-":1,"!":1,"~":1,"+":1},binary_ops:{"||":1,"??":1,"&&":2,"|":3,"^":4,"&":5,"==":6,"!=":6,"===":6,"!==":6,"<":7,">":7,"<=":7,">=":7,"<<":8,">>":8,">>>":8,"+":9,"-":9,"*":10,"/":10,"%":10,"**":11},right_associative:new Set(["**"]),additional_identifier_chars:new Set(["$","_"]),literals:{true:!0,false:!1,null:null},this_str:"this"});se.max_unop_len=se.getMaxKeyLen(se.unary_ops);se.max_binop_len=se.getMaxKeyLen(se.binary_ops);const Ma=e=>new se(e).parse(),WE=Object.getOwnPropertyNames(class{});Object.getOwnPropertyNames(se).filter(e=>!WE.includes(e)&&Ma[e]===void 0).forEach(e=>{Ma[e]=se[e]});Ma.Jsep=se;const HE="ConditionalExpression";var VE={name:"ternary",init(e){e.hooks.add("after-expression",function(n){if(n.node&&this.code===e.QUMARK_CODE){this.index++;const r=n.node,a=this.gobbleExpression();if(a||this.throwError("Expected expression"),this.gobbleSpaces(),this.code===e.COLON_CODE){this.index++;const i=this.gobbleExpression();if(i||this.throwError("Expected expression"),n.node={type:HE,test:r,consequent:a,alternate:i},r.operator&&e.binary_ops[r.operator]<=.9){let s=r;for(;s.right.operator&&e.binary_ops[s.right.operator]<=.9;)s=s.right;n.node.test=s.right,s.right=n.node,n.node=r}}else this.throwError("Expected :")}})}};Ma.plugins.register(VE);const nh=47,JE=92;var GE={name:"regex",init(e){e.hooks.add("gobble-token",function(n){if(this.code===nh){const r=++this.index;let a=!1;for(;this.index<this.expr.length;){if(this.code===nh&&!a){const i=this.expr.slice(r,this.index);let s="";for(;++this.index<this.expr.length;){const u=this.code;if(u>=97&&u<=122||u>=65&&u<=90||u>=48&&u<=57)s+=this.char;else break}let l;try{l=new RegExp(i,s)}catch(u){this.throwError(u.message)}return n.node={type:e.LITERAL,value:l,raw:this.expr.slice(r-1,this.index)},n.node=this.gobbleTokenProperty(n.node),n.node}this.code===e.OBRACK_CODE?a=!0:a&&this.code===e.CBRACK_CODE&&(a=!1),this.index+=this.code===JE?2:1}this.throwError("Unclosed Regex")}})}};const ud=43,KE=45,Qi={name:"assignment",assignmentOperators:new Set(["=","*=","**=","/=","%=","+=","-=","<<=",">>=",">>>=","&=","^=","|=","||=","&&=","??="]),updateOperators:[ud,KE],assignmentPrecedence:.9,init(e){const t=[e.IDENTIFIER,e.MEMBER_EXP];Qi.assignmentOperators.forEach(r=>e.addBinaryOp(r,Qi.assignmentPrecedence,!0)),e.hooks.add("gobble-token",function(a){const i=this.code;Qi.updateOperators.some(s=>s===i&&s===this.expr.charCodeAt(this.index+1))&&(this.index+=2,a.node={type:"UpdateExpression",operator:i===ud?"++":"--",argument:this.gobbleTokenProperty(this.gobbleIdentifier()),prefix:!0},(!a.node.argument||!t.includes(a.node.argument.type))&&this.throwError(`Unexpected ${a.node.operator}`))}),e.hooks.add("after-token",function(a){if(a.node){const i=this.code;Qi.updateOperators.some(s=>s===i&&s===this.expr.charCodeAt(this.index+1))&&(t.includes(a.node.type)||this.throwError(`Unexpected ${a.node.operator}`),this.index+=2,a.node={type:"UpdateExpression",operator:i===ud?"++":"--",argument:a.node,prefix:!1})}}),e.hooks.add("after-expression",function(a){a.node&&n(a.node)});function n(r){Qi.assignmentOperators.has(r.operator)?(r.type="AssignmentExpression",n(r.left),n(r.right)):r.operator||Object.values(r).forEach(a=>{a&&typeof a=="object"&&n(a)})}}};Ma.plugins.register(GE,Qi);Ma.addUnaryOp("typeof");Ma.addLiteral("null",null);Ma.addLiteral("undefined",void 0);const YE=new Set(["constructor","__proto__","__defineGetter__","__defineSetter__"]),lr={evalAst(e,t){switch(e.type){case"BinaryExpression":case"LogicalExpression":return lr.evalBinaryExpression(e,t);case"Compound":return lr.evalCompound(e,t);case"ConditionalExpression":return lr.evalConditionalExpression(e,t);case"Identifier":return lr.evalIdentifier(e,t);case"Literal":return lr.evalLiteral(e,t);case"MemberExpression":return lr.evalMemberExpression(e,t);case"UnaryExpression":return lr.evalUnaryExpression(e,t);case"ArrayExpression":return lr.evalArrayExpression(e,t);case"CallExpression":return lr.evalCallExpression(e,t);case"AssignmentExpression":return lr.evalAssignmentExpression(e,t);default:throw SyntaxError("Unexpected expression",e)}},evalBinaryExpression(e,t){return{"||":(r,a)=>r||a(),"&&":(r,a)=>r&&a(),"|":(r,a)=>r|a(),"^":(r,a)=>r^a(),"&":(r,a)=>r&a(),"==":(r,a)=>r==a(),"!=":(r,a)=>r!=a(),"===":(r,a)=>r===a(),"!==":(r,a)=>r!==a(),"<":(r,a)=>r<a(),">":(r,a)=>r>a(),"<=":(r,a)=>r<=a(),">=":(r,a)=>r>=a(),"<<":(r,a)=>r<<a(),">>":(r,a)=>r>>a(),">>>":(r,a)=>r>>>a(),"+":(r,a)=>r+a(),"-":(r,a)=>r-a(),"*":(r,a)=>r*a(),"/":(r,a)=>r/a(),"%":(r,a)=>r%a()}[e.operator](lr.evalAst(e.left,t),()=>lr.evalAst(e.right,t))},evalCompound(e,t){let n;for(let r=0;r<e.body.length;r++){e.body[r].type==="Identifier"&&["var","let","const"].includes(e.body[r].name)&&e.body[r+1]&&e.body[r+1].type==="AssignmentExpression"&&(r+=1);const a=e.body[r];n=lr.evalAst(a,t)}return n},evalConditionalExpression(e,t){return lr.evalAst(e.test,t)?lr.evalAst(e.consequent,t):lr.evalAst(e.alternate,t)},evalIdentifier(e,t){if(Object.hasOwn(t,e.name))return t[e.name];throw ReferenceError(`${e.name} is not defined`)},evalLiteral(e){return e.value},evalMemberExpression(e,t){const n=String(e.computed?lr.evalAst(e.property):e.property.name),r=lr.evalAst(e.object,t);if(r==null)throw TypeError(`Cannot read properties of ${r} (reading '${n}')`);if(!Object.hasOwn(r,n)&&YE.has(n))throw TypeError(`Cannot read properties of ${r} (reading '${n}')`);const a=r[n];return typeof a=="function"?a.bind(r):a},evalUnaryExpression(e,t){return{"-":r=>-lr.evalAst(r,t),"!":r=>!lr.evalAst(r,t),"~":r=>~lr.evalAst(r,t),"+":r=>+lr.evalAst(r,t),typeof:r=>typeof lr.evalAst(r,t)}[e.operator](e.argument)},evalArrayExpression(e,t){return e.elements.map(n=>lr.evalAst(n,t))},evalCallExpression(e,t){const n=e.arguments.map(a=>lr.evalAst(a,t));return lr.evalAst(e.callee,t)(...n)},evalAssignmentExpression(e,t){if(e.left.type!=="Identifier")throw SyntaxError("Invalid left-hand side in assignment");const n=e.left.name,r=lr.evalAst(e.right,t);return t[n]=r,t[n]}};class XE{constructor(t){this.code=t,this.ast=Ma(this.code)}runInNewContext(t){const n=Object.assign(Object.create(null),t);return lr.evalAst(this.ast,n)}}function $a(e,t){return e=e.slice(),e.push(t),e}function rv(e,t){return t=t.slice(),t.unshift(e),t}class QE extends Error{constructor(t){super('JSONPath should not be called with "new" (it prevents return of (unwrapped) scalar values)'),this.avoidNew=!0,this.value=t,this.name="NewError"}}function In(e,t,n,r,a){if(!(this instanceof In))try{return new In(e,t,n,r,a)}catch(s){if(!s.avoidNew)throw s;return s.value}typeof e=="string"&&(a=r,r=n,n=t,t=e,e=null);const i=e&&typeof e=="object";if(e=e||{},this.json=e.json||n,this.path=e.path||t,this.resultType=e.resultType||"value",this.flatten=e.flatten||!1,this.wrap=Object.hasOwn(e,"wrap")?e.wrap:!0,this.sandbox=e.sandbox||{},this.eval=e.eval===void 0?"safe":e.eval,this.ignoreEvalErrors=typeof e.ignoreEvalErrors>"u"?!1:e.ignoreEvalErrors,this.parent=e.parent||null,this.parentProperty=e.parentProperty||null,this.callback=e.callback||r||null,this.otherTypeCallback=e.otherTypeCallback||a||function(){throw new TypeError("You must supply an otherTypeCallback callback option with the @other() operator.")},e.autostart!==!1){const s={path:i?e.path:t};i?"json"in e&&(s.json=e.json):s.json=n;const l=this.evaluate(s);if(!l||typeof l!="object")throw new QE(l);return l}}In.prototype.evaluate=function(e,t,n,r){let a=this.parent,i=this.parentProperty,{flatten:s,wrap:l}=this;if(this.currResultType=this.resultType,this.currEval=this.eval,this.currSandbox=this.sandbox,n=n||this.callback,this.currOtherTypeCallback=r||this.otherTypeCallback,t=t||this.json,e=e||this.path,e&&typeof e=="object"&&!Array.isArray(e)){if(!e.path&&e.path!=="")throw new TypeError('You must supply a "path" property when providing an object argument to JSONPath.evaluate().');if(!Object.hasOwn(e,"json"))throw new TypeError('You must supply a "json" property when providing an object argument to JSONPath.evaluate().');({json:t}=e),s=Object.hasOwn(e,"flatten")?e.flatten:s,this.currResultType=Object.hasOwn(e,"resultType")?e.resultType:this.currResultType,this.currSandbox=Object.hasOwn(e,"sandbox")?e.sandbox:this.currSandbox,l=Object.hasOwn(e,"wrap")?e.wrap:l,this.currEval=Object.hasOwn(e,"eval")?e.eval:this.currEval,n=Object.hasOwn(e,"callback")?e.callback:n,this.currOtherTypeCallback=Object.hasOwn(e,"otherTypeCallback")?e.otherTypeCallback:this.currOtherTypeCallback,a=Object.hasOwn(e,"parent")?e.parent:a,i=Object.hasOwn(e,"parentProperty")?e.parentProperty:i,e=e.path}if(a=a||null,i=i||null,Array.isArray(e)&&(e=In.toPathString(e)),!e&&e!==""||!t)return;const u=In.toPathArray(e);u[0]==="$"&&u.length>1&&u.shift(),this._hasParentSelector=null;const d=this._trace(u,t,["$"],a,i,n).filter(function(c){return c&&!c.isParentSelector});return d.length?!l&&d.length===1&&!d[0].hasArrExpr?this._getPreferredOutput(d[0]):d.reduce((c,v)=>{const f=this._getPreferredOutput(v);return s&&Array.isArray(f)?c=c.concat(f):c.push(f),c},[]):l?[]:void 0};In.prototype._getPreferredOutput=function(e){const t=this.currResultType;switch(t){case"all":{const n=Array.isArray(e.path)?e.path:In.toPathArray(e.path);return e.pointer=In.toPointer(n),e.path=typeof e.path=="string"?e.path:In.toPathString(e.path),e}case"value":case"parent":case"parentProperty":return e[t];case"path":return In.toPathString(e[t]);case"pointer":return In.toPointer(e.path);default:throw new TypeError("Unknown result type")}};In.prototype._handleCallback=function(e,t,n){if(t){const r=this._getPreferredOutput(e);e.path=typeof e.path=="string"?e.path:In.toPathString(e.path),t(r,n,e)}};In.prototype._trace=function(e,t,n,r,a,i,s,l){let u;if(!e.length)return u={path:n,value:t,parent:r,parentProperty:a,hasArrExpr:s},this._handleCallback(u,i,"value"),u;const d=e[0],c=e.slice(1),v=[];function f(g){Array.isArray(g)?g.forEach(m=>{v.push(m)}):v.push(g)}if((typeof d!="string"||l)&&t&&Object.hasOwn(t,d))f(this._trace(c,t[d],$a(n,d),t,d,i,s));else if(d==="*")this._walk(t,g=>{f(this._trace(c,t[g],$a(n,g),t,g,i,!0,!0))});else if(d==="..")f(this._trace(c,t,n,r,a,i,s)),this._walk(t,g=>{typeof t[g]=="object"&&f(this._trace(e.slice(),t[g],$a(n,g),t,g,i,!0))});else{if(d==="^")return this._hasParentSelector=!0,{path:n.slice(0,-1),expr:c,isParentSelector:!0};if(d==="~")return u={path:$a(n,d),value:a,parent:r,parentProperty:null},this._handleCallback(u,i,"property"),u;if(d==="$")f(this._trace(c,t,n,null,null,i,s));else if(/^(-?\d*):(-?\d*):?(\d*)$/u.test(d))f(this._slice(d,c,t,n,r,a,i));else if(d.indexOf("?(")===0){if(this.currEval===!1)throw new Error("Eval [?(expr)] prevented in JSONPath expression.");const g=d.replace(/^\?\((.*?)\)$/u,"$1"),m=/@.?([^?]*)[['](\??\(.*?\))(?!.\)\])[\]']/gu.exec(g);m?this._walk(t,b=>{const j=[m[2]],w=m[1]?t[b][m[1]]:t[b];this._trace(j,w,n,r,a,i,!0).length>0&&f(this._trace(c,t[b],$a(n,b),t,b,i,!0))}):this._walk(t,b=>{this._eval(g,t[b],b,n,r,a)&&f(this._trace(c,t[b],$a(n,b),t,b,i,!0))})}else if(d[0]==="("){if(this.currEval===!1)throw new Error("Eval [(expr)] prevented in JSONPath expression.");f(this._trace(rv(this._eval(d,t,n.at(-1),n.slice(0,-1),r,a),c),t,n,r,a,i,s))}else if(d[0]==="@"){let g=!1;const m=d.slice(1,-2);switch(m){case"scalar":(!t||!["object","function"].includes(typeof t))&&(g=!0);break;case"boolean":case"string":case"undefined":case"function":typeof t===m&&(g=!0);break;case"integer":Number.isFinite(t)&&!(t%1)&&(g=!0);break;case"number":Number.isFinite(t)&&(g=!0);break;case"nonFinite":typeof t=="number"&&!Number.isFinite(t)&&(g=!0);break;case"object":t&&typeof t===m&&(g=!0);break;case"array":Array.isArray(t)&&(g=!0);break;case"other":g=this.currOtherTypeCallback(t,n,r,a);break;case"null":t===null&&(g=!0);break;default:throw new TypeError("Unknown value type "+m)}if(g)return u={path:n,value:t,parent:r,parentProperty:a},this._handleCallback(u,i,"value"),u}else if(d[0]==="`"&&t&&Object.hasOwn(t,d.slice(1))){const g=d.slice(1);f(this._trace(c,t[g],$a(n,g),t,g,i,s,!0))}else if(d.includes(",")){const g=d.split(",");for(const m of g)f(this._trace(rv(m,c),t,n,r,a,i,!0))}else!l&&t&&Object.hasOwn(t,d)&&f(this._trace(c,t[d],$a(n,d),t,d,i,s,!0))}if(this._hasParentSelector)for(let g=0;g<v.length;g++){const m=v[g];if(m&&m.isParentSelector){const b=this._trace(m.expr,t,m.path,r,a,i,s);if(Array.isArray(b)){v[g]=b[0];const j=b.length;for(let w=1;w<j;w++)g++,v.splice(g,0,b[w])}else v[g]=b}}return v};In.prototype._walk=function(e,t){if(Array.isArray(e)){const n=e.length;for(let r=0;r<n;r++)t(r)}else e&&typeof e=="object"&&Object.keys(e).forEach(n=>{t(n)})};In.prototype._slice=function(e,t,n,r,a,i,s){if(!Array.isArray(n))return;const l=n.length,u=e.split(":"),d=u[2]&&Number.parseInt(u[2])||1;let c=u[0]&&Number.parseInt(u[0])||0,v=u[1]&&Number.parseInt(u[1])||l;c=c<0?Math.max(0,c+l):Math.min(l,c),v=v<0?Math.max(0,v+l):Math.min(l,v);const f=[];for(let g=c;g<v;g+=d)this._trace(rv(g,t),n,r,a,i,s,!0).forEach(b=>{f.push(b)});return f};In.prototype._eval=function(e,t,n,r,a,i){this.currSandbox._$_parentProperty=i,this.currSandbox._$_parent=a,this.currSandbox._$_property=n,this.currSandbox._$_root=this.json,this.currSandbox._$_v=t;const s=e.includes("@path");s&&(this.currSandbox._$_path=In.toPathString(r.concat([n])));const l=this.currEval+"Script:"+e;if(!In.cache[l]){let u=e.replaceAll("@parentProperty","_$_parentProperty").replaceAll("@parent","_$_parent").replaceAll("@property","_$_property").replaceAll("@root","_$_root").replaceAll(/@([.\s)[])/gu,"_$_v$1");if(s&&(u=u.replaceAll("@path","_$_path")),this.currEval==="safe"||this.currEval===!0||this.currEval===void 0)In.cache[l]=new this.safeVm.Script(u);else if(this.currEval==="native")In.cache[l]=new this.vm.Script(u);else if(typeof this.currEval=="function"&&this.currEval.prototype&&Object.hasOwn(this.currEval.prototype,"runInNewContext")){const d=this.currEval;In.cache[l]=new d(u)}else if(typeof this.currEval=="function")In.cache[l]={runInNewContext:d=>this.currEval(u,d)};else throw new TypeError(`Unknown "eval" property "${this.currEval}"`)}try{return In.cache[l].runInNewContext(this.currSandbox)}catch(u){if(this.ignoreEvalErrors)return!1;throw new Error("jsonPath: "+u.message+": "+e)}};In.cache={};In.toPathString=function(e){const t=e,n=t.length;let r="$";for(let a=1;a<n;a++)/^(~|\^|@.*?\(\))$/u.test(t[a])||(r+=/^[0-9*]+$/u.test(t[a])?"["+t[a]+"]":"['"+t[a]+"']");return r};In.toPointer=function(e){const t=e,n=t.length;let r="";for(let a=1;a<n;a++)/^(~|\^|@.*?\(\))$/u.test(t[a])||(r+="/"+t[a].toString().replaceAll("~","~0").replaceAll("/","~1"));return r};In.toPathArray=function(e){const{cache:t}=In;if(t[e])return t[e].concat();const n=[],a=e.replaceAll(/@(?:null|boolean|number|string|integer|undefined|nonFinite|scalar|array|object|function|other)\(\)/gu,";$&;").replaceAll(/[['](\??\(.*?\))[\]'](?!.\])/gu,function(i,s){return"[#"+(n.push(s)-1)+"]"}).replaceAll(/\[['"]([^'\]]*)['"]\]/gu,function(i,s){return"['"+s.replaceAll(".","%@%").replaceAll("~","%%@@%%")+"']"}).replaceAll("~",";~;").replaceAll(/['"]?\.['"]?(?![^[]*\])|\[['"]?/gu,";").replaceAll("%@%",".").replaceAll("%%@@%%","~").replaceAll(/(?:;)?(\^+)(?:;)?/gu,function(i,s){return";"+s.split("").join(";")+";"}).replaceAll(/;;;|;;/gu,";..;").replaceAll(/;$|'?\]|'$/gu,"").split(";").map(function(i){const s=i.match(/#(\d+)/u);return!s||!s[1]?i:n[s[1]]});return t[e]=a,t[e].concat()};In.prototype.safeVm={Script:XE};const ZE=function(e,t,n){const r=e.length;for(let a=0;a<r;a++){const i=e[a];n(i)&&t.push(e.splice(a--,1)[0])}};class eA{constructor(t){this.code=t}runInNewContext(t){let n=this.code;const r=Object.keys(t),a=[];ZE(r,a,d=>typeof t[d]=="function");const i=r.map(d=>t[d]);n=a.reduce((d,c)=>{let v=t[c].toString();return/function/u.test(v)||(v="function "+v),"var "+c+"="+v+";"+d},"")+n,!/(['"])use strict\1/u.test(n)&&!r.includes("arguments")&&(n="var arguments = undefined;"+n),n=n.replace(/;\s*$/u,"");const l=n.lastIndexOf(";"),u=l!==-1?n.slice(0,l+1)+" return "+n.slice(l+1):" return "+n;return new Function(...r,u)(...i)}}In.prototype.vm={Script:eA};var tA=["mainAxis","crossAxis","fallbackPlacements","fallbackStrategy","fallbackAxisSideDirection","flipAlignment"],nA=["mainAxis","crossAxis","limiter"];function ay(e,t){if(e==null)return{};var n,r,a=function(s,l){if(s==null)return{};var u={};for(var d in s)if({}.hasOwnProperty.call(s,d)){if(l.indexOf(d)!==-1)continue;u[d]=s[d]}return u}(e,t);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);for(r=0;r<i.length;r++)n=i[r],t.indexOf(n)===-1&&{}.propertyIsEnumerable.call(e,n)&&(a[n]=e[n])}return a}function rh(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(a){return Object.getOwnPropertyDescriptor(e,a).enumerable})),n.push.apply(n,r)}return n}function Se(e){for(var t=1;t<arguments.length;t++){var n=arguments[t]!=null?arguments[t]:{};t%2?rh(Object(n),!0).forEach(function(r){rA(e,r,n[r])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):rh(Object(n)).forEach(function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(n,r))})}return e}function rA(e,t,n){return(t=function(r){var a=function(i,s){if(typeof i!="object"||!i)return i;var l=i[Symbol.toPrimitive];if(l!==void 0){var u=l.call(i,s);if(typeof u!="object")return u;throw new TypeError("@@toPrimitive must return a primitive value.")}return(s==="string"?String:Number)(i)}(r,"string");return typeof a=="symbol"?a:a+""}(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function oh(e,t,n,r,a,i,s){try{var l=e[i](s),u=l.value}catch(d){return void n(d)}l.done?t(u):Promise.resolve(u).then(r,a)}function Rt(e){return function(){var t=this,n=arguments;return new Promise(function(r,a){var i=e.apply(t,n);function s(u){oh(i,r,a,s,l,"next",u)}function l(u){oh(i,r,a,s,l,"throw",u)}s(void 0)})}}var ah,cd,ih,dd;typeof window<"u"&&((cd=(ah=(dd=(ih=window).__svelte)!==null&&dd!==void 0?dd:ih.__svelte={}).v)!==null&&cd!==void 0?cd:ah.v=new Set).add("5");var qs=!1;qs=!0;var ro=Symbol(),oA=!1,Pc=32,iy=64,vd=128,sa=256,ov=512,yo=1024,$s=2048,Fs=4096,Ya=8192,Ff=16384,Kl=65536,sy=1<<17,aA=1<<20,av=1<<21,la=Symbol("$state"),ly=Symbol("legacy props"),iA=Symbol(""),Yl=Array.isArray,sA=Array.prototype.indexOf,iv=Array.from,lA=Object.defineProperty,_a=Object.getOwnPropertyDescriptor,uy=Object.getOwnPropertyDescriptors,uA=Object.prototype,cA=Array.prototype,Bf=Object.getPrototypeOf,sh=Object.isExtensible;function sl(e){return typeof e=="function"}var lh=()=>{};function dA(e){return e()}function Du(e){for(var t=0;t<e.length;t++)e[t]()}var kl=[],fd=[];function cy(){var e=kl;kl=[],Du(e)}function Tc(e){kl.length===0&&queueMicrotask(cy),kl.push(e)}function uh(){var e;kl.length>0&&cy(),fd.length>0&&(e=fd,fd=[],Du(e))}function dy(e){return e===this.v}function Wf(e,t){return e!=e?t==t:e!==t||e!==null&&typeof e=="object"||typeof e=="function"}function vA(e,t){return e!==t}function Hf(e){return!Wf(e,this.v)}function gi(e,t){if(typeof e!="object"||e===null||la in e)return e;var n=Bf(e);if(n!==uA&&n!==cA)return e;var r=new Map,a=Yl(e),i=ba(0),s=Kn,l=u=>{var d,c=Kn;return da(s),d=u(),da(c),d};return a&&r.set("length",ba(e.length)),new Proxy(e,{defineProperty(u,d,c){"value"in c&&c.configurable!==!1&&c.enumerable!==!1&&c.writable!==!1||function(){throw new Error("https://svelte.dev/e/state_descriptors_fixed")}();var v=r.get(d);return v===void 0?(v=l(()=>ba(c.value)),r.set(d,v)):p(v,l(()=>gi(c.value))),!0},deleteProperty(u,d){var c=r.get(d);if(c===void 0)d in u&&r.set(d,l(()=>ba(ro)));else{if(a&&typeof d=="string"){var v=r.get("length"),f=Number(d);Number.isInteger(f)&&f<v.v&&p(v,f)}p(c,ro),ch(i)}return!0},get(u,d,c){var v;if(d===la)return e;var f=r.get(d),g=d in u;if(f===void 0&&(!g||(v=_a(u,d))!==null&&v!==void 0&&v.writable)&&(f=l(()=>ba(gi(g?u[d]:ro))),r.set(d,f)),f!==void 0){var m=o(f);return m===ro?void 0:m}return Reflect.get(u,d,c)},getOwnPropertyDescriptor(u,d){var c=Reflect.getOwnPropertyDescriptor(u,d);if(c&&"value"in c){var v=r.get(d);v&&(c.value=o(v))}else if(c===void 0){var f=r.get(d),g=f?.v;if(f!==void 0&&g!==ro)return{enumerable:!0,configurable:!0,value:g,writable:!0}}return c},has(u,d){var c;if(d===la)return!0;var v=r.get(d),f=v!==void 0&&v.v!==ro||Reflect.has(u,d);return(v!==void 0||hr!==null&&(!f||(c=_a(u,d))!==null&&c!==void 0&&c.writable))&&(v===void 0&&(v=l(()=>ba(f?gi(u[d]):ro)),r.set(d,v)),o(v)===ro)?!1:f},set(u,d,c,v){var f,g=r.get(d),m=d in u;if(a&&d==="length")for(var b=c;b<g.v;b+=1){var j=r.get(b+"");j!==void 0?p(j,ro):b in u&&(j=l(()=>ba(ro)),r.set(b+"",j))}g===void 0?(!m||(f=_a(u,d))!==null&&f!==void 0&&f.writable)&&(p(g=l(()=>ba(void 0)),l(()=>gi(c))),r.set(d,g)):(m=g.v!==ro,p(g,l(()=>gi(c))));var w=Reflect.getOwnPropertyDescriptor(u,d);if(w!=null&&w.set&&w.set.call(v,c),!m){if(a&&typeof d=="string"){var O=r.get("length"),T=Number(d);Number.isInteger(T)&&T>=O.v&&p(O,T+1)}ch(i)}return!0},ownKeys(u){o(i);var d=Reflect.ownKeys(u).filter(f=>{var g=r.get(f);return g===void 0||g.v!==ro});for(var[c,v]of r)v.v===ro||c in u||d.push(c);return d},setPrototypeOf(){(function(){throw new Error("https://svelte.dev/e/state_prototype_fixed")})()}})}function ch(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1;p(e,e.v+t)}function dh(e){try{if(e!==null&&typeof e=="object"&&la in e)return e[la]}catch{}return e}var _l=new Map;function Ai(e,t){return{f:0,v:e,reactions:null,equals:dy,rv:0,wv:0}}function ba(e,t){var n=Ai(e);return by(n),n}function P(e){var t,n,r=arguments.length>1&&arguments[1]!==void 0&&arguments[1],a=Ai(e);return r||(a.equals=Hf),qs&&Nn!==null&&Nn.l!==null&&((n=(t=Nn.l).s)!==null&&n!==void 0?n:t.s=[]).push(a),a}function go(e,t){return p(e,Mo(()=>o(e))),t}function p(e,t){var n,r=arguments.length>2&&arguments[2]!==void 0&&arguments[2];return Kn!==null&&!oa&&Vs()&&18&Kn.f&&((n=Ca)===null||n===void 0||!n.includes(e))&&function(){throw new Error("https://svelte.dev/e/state_unsafe_mutation")}(),Sl(e,r?gi(t):t)}function Sl(e,t){if(!e.equals(t)){var n=e.v;Xl?_l.set(e,t):_l.set(e,n),e.v=t,e.wv=jy(),vy(e,$s),Vs()&&hr!==null&&hr.f&yo&&!(96&hr.f)&&(_o===null?function(r){_o=r}([e]):_o.push(e))}return t}function vh(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1,n=o(e),r=t===1?n++:n--;return p(e,n),r}function vy(e,t){var n=e.reactions;if(n!==null)for(var r=Vs(),a=n.length,i=0;i<a;i++){var s=n[i],l=s.f;l&$s||(r||s!==hr)&&(ea(s,t),1280&l&&(2&l?vy(s,Fs):Dc(s)))}}function xs(e){var t=2050,n=Kn!==null&&2&Kn.f?Kn:null;return hr===null||n!==null&&n.f&sa?t|=sa:hr.f|=aA,{ctx:Nn,deps:null,effects:null,equals:dy,f:t,fn:e,reactions:null,rv:0,v:null,wv:0,parent:n??hr}}function co(e){var t=xs(e);return by(t),t}function de(e){var t=xs(e);return t.equals=Hf,t}function fy(e){var t=e.effects;if(t!==null){e.effects=null;for(var n=0;n<t.length;n+=1)va(t[n])}}function py(e){var t=function(n){var r,a=hr;oi(function(i){for(var s=i.parent;s!==null;){if(!(2&s.f))return s;s=s.parent}return null}(n));try{fy(n),r=wy(n)}finally{oi(a)}return r}(e);ea(e,(Ja||e.f&sa)&&e.deps!==null?Fs:yo),e.equals(t)||(e.v=t,e.wv=jy())}var Sa,hy,gy,my;function Ic(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:"";return document.createTextNode(e)}function mo(e){return gy.call(e)}function Nc(e){return my.call(e)}function z(e,t){return mo(e)}function ft(e,t){var n=mo(e);return n instanceof Comment&&n.data===""?Nc(n):n}function F(e){for(var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1,n=e;t--;)n=Nc(n);return n}var lu=!1,qu=!1,$u=null,ji=!1,Xl=!1;function fh(e){Xl=e}var ml=[],Kn=null,oa=!1;function da(e){Kn=e}var hr=null;function oi(e){hr=e}var Ca=null;function by(e){Kn!==null&&Kn.f&av&&(Ca===null?Ca=[e]:Ca.push(e))}var oo=null,po=0,_o=null,xy=1,Fu=0,Ja=!1,bi=null;function jy(){return++xy}function Bs(e){var t=e.f;if(t&$s)return!0;if(t&Fs){var n=e.deps,r=!!(t&sa);if(n!==null){var a,i,s=!!(t&ov),l=r&&hr!==null&&!Ja,u=n.length;if(s||l){var d=e,c=d.parent;for(a=0;a<u;a++){var v,f,g;i=n[a],(s||(v=i)===null||v===void 0||(v=v.reactions)===null||v===void 0||!v.includes(d))&&((g=(f=i).reactions)!==null&&g!==void 0?g:f.reactions=[]).push(d)}s&&(d.f^=ov),!l||c===null||c.f&sa||(d.f^=sa)}for(a=0;a<u;a++)if(Bs(i=n[a])&&py(i),i.wv>e.wv)return!0}r&&(hr===null||Ja)||ea(e,yo)}return!1}function Lc(e,t,n,r){if(lu){if(n===null&&(lu=!1),function(a){return!(a.f&Ff||a.parent!==null&&a.parent.f&vd)}(t))throw e}else n!==null&&(lu=!0),function(a,i){for(var s=i;s!==null;){if(s.f&vd)try{return void s.fn(a)}catch{s.f^=vd}s=s.parent}throw lu=!1,a}(e,t)}function yy(e,t){var n=!(arguments.length>2&&arguments[2]!==void 0)||arguments[2],r=e.reactions;if(r!==null)for(var a=0;a<r.length;a++){var i,s=r[a];(i=Ca)!==null&&i!==void 0&&i.includes(e)||(2&s.f?yy(s,t,!1):t===s&&(n?ea(s,$s):s.f&yo&&ea(s,Fs),Dc(s)))}}function wy(e){var t=oo,n=po,r=_o,a=Kn,i=Ja,s=Ca,l=Nn,u=oa,d=e.f;oo=null,po=0,_o=null,Ja=!!(d&sa)&&(oa||!ji||Kn===null),Kn=96&d?null:e,Ca=null,ph(e.ctx),oa=!1,Fu++,e.f|=av;try{var c=(0,e.fn)(),v=e.deps;if(oo!==null){var f;if(Bu(e,po),v!==null&&po>0)for(v.length=po+oo.length,f=0;f<oo.length;f++)v[po+f]=oo[f];else e.deps=v=oo;if(!Ja)for(f=po;f<v.length;f++){var g,m;((m=(g=v[f]).reactions)!==null&&m!==void 0?m:g.reactions=[]).push(e)}}else v!==null&&po<v.length&&(Bu(e,po),v.length=po);if(Vs()&&_o!==null&&!oa&&v!==null&&!(6146&e.f))for(f=0;f<_o.length;f++)yy(_o[f],e);return a!==null&&(Fu++,_o!==null&&(r===null?r=_o:r.push(..._o))),c}finally{oo=t,po=n,_o=r,Kn=a,Ja=i,Ca=s,ph(l),oa=u,e.f^=av}}function fA(e,t){var n=t.reactions;if(n!==null){var r=sA.call(n,e);if(r!==-1){var a=n.length-1;a===0?n=t.reactions=null:(n[r]=n[a],n.pop())}}n===null&&2&t.f&&(oo===null||!oo.includes(t))&&(ea(t,Fs),768&t.f||(t.f^=ov),fy(t),Bu(t,0))}function Bu(e,t){var n=e.deps;if(n!==null)for(var r=t;r<n.length;r++)fA(e,n[r])}function Uc(e){var t=e.f;if(!(t&Ff)){ea(e,yo);var n=hr,r=Nn,a=ji;hr=e,ji=!0;try{16&t?function(s){for(var l=s.first;l!==null;){var u=l.next;l.f&Pc||va(l),l=u}}(e):Oy(e),Cy(e);var i=wy(e);e.teardown=typeof i=="function"?i:null,e.wv=xy,e.deps}catch(s){Lc(s,e,n,r||e.ctx)}finally{ji=a,hr=n}}}function pA(){try{(function(){throw new Error("https://svelte.dev/e/effect_update_depth_exceeded")})()}catch(e){if($u===null)throw e;Lc(e,$u,null)}}function ky(){var e=ji;try{var t=0;for(ji=!0;ml.length>0;){t++>1e3&&pA();var n=ml,r=n.length;ml=[];for(var a=0;a<r;a++)hA(gA(n[a]))}}finally{qu=!1,ji=e,$u=null,_l.clear()}}function hA(e){var t=e.length;if(t!==0)for(var n=0;n<t;n++){var r=e[n];if(!(24576&r.f))try{Bs(r)&&(Uc(r),r.deps===null&&r.first===null&&r.nodes_start===null&&(r.teardown===null?Ey(r):r.fn=null))}catch(a){Lc(a,r,null,r.ctx)}}}function Dc(e){qu||(qu=!0,queueMicrotask(ky));for(var t=$u=e;t.parent!==null;){var n=(t=t.parent).f;if(96&n){if(!(n&yo))return;t.f^=yo}}ml.push(t)}function gA(e){for(var t=[],n=e;n!==null;){var r=n.f,a=!!(96&r);if(!(a&&r&yo||r&Ya)){if(4&r)t.push(n);else if(a)n.f^=yo;else{var i=Kn;try{Kn=n,Bs(n)&&Uc(n)}catch(u){Lc(u,n,null,n.ctx)}finally{Kn=i}}var s=n.first;if(s!==null){n=s;continue}}var l=n.parent;for(n=n.next;n===null&&l!==null;)n=l.next,l=l.parent}return t}function pr(e){for(uh();ml.length>0;)qu=!0,ky(),uh()}function _y(){return(_y=Rt(function*(){yield Promise.resolve(),pr()})).apply(this,arguments)}function o(e){var t,n=!!(2&e.f);if(bi!==null&&bi.add(e),Kn===null||oa){if(n&&e.deps===null&&e.effects===null){var r=e,a=r.parent;a===null||a.f&sa||(r.f^=sa)}}else if((t=Ca)===null||t===void 0||!t.includes(e)){var i=Kn.deps;e.rv<Fu&&(e.rv=Fu,oo===null&&i!==null&&i[po]===e?po++:oo===null?oo=[e]:Ja&&oo.includes(e)||oo.push(e))}return n&&Bs(r=e)&&py(r),Xl&&_l.has(e)?_l.get(e):e.v}function mA(e){var t=function(a){var i,s=bi,l=bi=new Set;try{if(Mo(a),s!==null)for(i of bi)s.add(i)}finally{bi=s}return l}(()=>Mo(e));for(var n of t)if(n.f&sy)for(var r of n.deps||[])2&r.f||Sl(r,r.v);else Sl(n,n.v)}function Mo(e){var t=oa;try{return oa=!0,e()}finally{oa=t}}var bA=-7169;function ea(e,t){e.f=e.f&bA|t}function M(e){if(typeof e=="object"&&e&&!(e instanceof EventTarget)){if(la in e)sv(e);else if(!Array.isArray(e))for(var t in e){var n=e[t];typeof n=="object"&&n&&la in n&&sv(n)}}}function sv(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:new Set;if(!(typeof e!="object"||e===null||e instanceof EventTarget||t.has(e))){for(var n in t.add(e),e instanceof Date&&e.getTime(),e)try{sv(e[n],t)}catch{}var r=Bf(e);if(r!==Object.prototype&&r!==Array.prototype&&r!==Map.prototype&&r!==Set.prototype&&r!==Date.prototype){var a=uy(r);for(var i in a){var s=a[i].get;if(s)try{s.call(e)}catch{}}}}}function Sy(e){hr===null&&Kn===null&&function(){throw new Error("https://svelte.dev/e/effect_orphan")}(),Kn!==null&&Kn.f&sa&&hr===null&&function(){throw new Error("https://svelte.dev/e/effect_in_unowned_derived")}(),Xl&&function(){throw new Error("https://svelte.dev/e/effect_in_teardown")}()}function Ws(e,t,n){var r=!(arguments.length>3&&arguments[3]!==void 0)||arguments[3],a=hr,i={ctx:Nn,deps:null,nodes_start:null,nodes_end:null,f:e|$s,first:null,fn:t,last:null,next:null,parent:a,prev:null,teardown:null,transitions:null,wv:0};if(n)try{Uc(i),i.f|=32768}catch(u){throw va(i),u}else t!==null&&Dc(i);if(!(n&&i.deps===null&&i.first===null&&i.nodes_start===null&&i.teardown===null&&!(1048704&i.f))&&r&&(a!==null&&function(u,d){var c=d.last;c===null?d.last=d.first=u:(c.next=u,u.prev=c,d.last=u)}(i,a),Kn!==null&&2&Kn.f)){var s,l=Kn;((s=l.effects)!==null&&s!==void 0?s:l.effects=[]).push(i)}return i}function Vf(e){var t=Ws(8,null,!1);return ea(t,yo),t.teardown=e,t}function lv(e){if(Sy(),!(hr!==null&&hr.f&Pc&&Nn!==null&&!Nn.m))return qr(e);var t,n=Nn;((t=n.e)!==null&&t!==void 0?t:n.e=[]).push({fn:e,effect:hr,reaction:Kn})}function qr(e){return Ws(4,e,!1)}function W(e,t){var n=Nn,r={effect:null,ran:!1};n.l.r1.push(r),r.effect=Hs(()=>{e(),r.ran||(r.ran=!0,p(n.l.r2,!0),Mo(t))})}function _n(){var e=Nn;Hs(()=>{if(o(e.l.r2)){for(var t of e.l.r1){var n=t.effect;n.f&yo&&ea(n,Fs),Bs(n)&&Uc(n),t.ran=!1}e.l.r2.v=!1}})}function Hs(e){return Ws(8,e,!0)}function Ee(e){var t=arguments.length>2&&arguments[2]!==void 0?arguments[2]:xs,n=(arguments.length>1&&arguments[1]!==void 0?arguments[1]:[]).map(t);return $i(()=>e(...n.map(o)))}function $i(e){return Ws(24|(arguments.length>1&&arguments[1]!==void 0?arguments[1]:0),e,!0)}function za(e){return Ws(40,e,!0,!(arguments.length>1&&arguments[1]!==void 0)||arguments[1])}function Cy(e){var t=e.teardown;if(t!==null){var n=Xl,r=Kn;fh(!0),da(null);try{t.call(null)}finally{fh(n),da(r)}}}function Oy(e){var t=arguments.length>1&&arguments[1]!==void 0&&arguments[1],n=e.first;for(e.first=e.last=null;n!==null;){var r=n.next;n.f&iy?n.parent=null:va(n,t),n=r}}function va(e){var t=!(arguments.length>1&&arguments[1]!==void 0)||arguments[1],n=!1;if((t||524288&e.f)&&e.nodes_start!==null){for(var r=e.nodes_start,a=e.nodes_end;r!==null;){var i=r===a?null:Nc(r);r.remove(),r=i}n=!0}Oy(e,t&&!n),Bu(e,0),ea(e,Ff);var s=e.transitions;if(s!==null)for(var l of s)l.stop();Cy(e);var u=e.parent;u!==null&&u.first!==null&&Ey(e),e.next=e.prev=e.teardown=e.ctx=e.deps=e.fn=e.nodes_start=e.nodes_end=null}function Ey(e){var t=e.parent,n=e.prev,r=e.next;n!==null&&(n.next=r),r!==null&&(r.prev=n),t!==null&&(t.first===e&&(t.first=r),t.last===e&&(t.last=n))}function js(e,t){var n=[];Jf(e,n,!0),Ay(n,()=>{va(e),t&&t()})}function Ay(e,t){var n=e.length;if(n>0){var r=()=>--n||t();for(var a of e)a.out(r)}else t()}function Jf(e,t,n){if(!(e.f&Ya)){if(e.f^=Ya,e.transitions!==null)for(var r of e.transitions)(r.is_global||n)&&t.push(r);for(var a=e.first;a!==null;){var i=a.next;Jf(a,t,!!(a.f&Kl||a.f&Pc)&&n),a=i}}}function Wu(e){Ry(e,!0)}function Ry(e,t){if(e.f&Ya){e.f^=Ya,e.f&yo||(e.f^=yo),Bs(e)&&(ea(e,$s),Dc(e));for(var n=e.first;n!==null;){var r=n.next;Ry(n,!!(n.f&Kl||n.f&Pc)&&t),n=r}if(e.transitions!==null)for(var a of e.transitions)(a.is_global||t)&&a.in()}}function Ql(e){throw new Error("https://svelte.dev/e/lifecycle_outside_component")}var Nn=null;function ph(e){Nn=e}function vi(e){return My().get(e)}function lt(e){var t=Nn={p:Nn,c:null,d:!1,e:null,m:!1,s:e,x:null,l:null};qs&&!(arguments.length>1&&arguments[1]!==void 0&&arguments[1])&&(Nn.l={s:null,u:null,r1:[],r2:Ai(!1)}),Vf(()=>{t.d=!0})}function ut(e){var t=Nn;if(t!==null){e!==void 0&&(t.x=e);var n=t.e;if(n!==null){var r=hr,a=Kn;t.e=null;try{for(var i=0;i<n.length;i++){var s=n[i];oi(s.effect),da(s.reaction),qr(s.fn)}}finally{oi(r),da(a)}}Nn=t.p,t.m=!0}return e||{}}function Vs(){return!qs||Nn!==null&&Nn.l===null}function My(e){var t,n;return Nn===null&&Ql(),(n=(t=Nn).c)!==null&&n!==void 0?n:t.c=new Map(function(r){for(var a=r.p;a!==null;){var i=a.c;if(i!==null)return i;a=a.p}return null}(Nn)||void 0)}var xA=["beforeinput","click","change","dblclick","contextmenu","focusin","focusout","input","keydown","keyup","mousedown","mousemove","mouseout","mouseover","mouseup","pointerdown","pointermove","pointerout","pointerover","pointerup","touchend","touchmove","touchstart"],jA={formnovalidate:"formNoValidate",ismap:"isMap",nomodule:"noModule",playsinline:"playsInline",readonly:"readOnly",defaultvalue:"defaultValue",defaultchecked:"defaultChecked",srcobject:"srcObject",novalidate:"noValidate",allowfullscreen:"allowFullscreen",disablepictureinpicture:"disablePictureInPicture",disableremoteplayback:"disableRemotePlayback"},yA=["touchstart","touchmove"];function wA(e){return yA.includes(e)}var hh=!1;function zy(e){var t=Kn,n=hr;da(null),oi(null);try{return e()}finally{da(t),oi(n)}}function Py(e,t,n){var r=arguments.length>3&&arguments[3]!==void 0?arguments[3]:n;e.addEventListener(t,()=>zy(n));var a=e.__on_r;e.__on_r=a?()=>{a(),r(!0)}:()=>r(!0),hh||(hh=!0,document.addEventListener("reset",i=>{Promise.resolve().then(()=>{if(!i.defaultPrevented)for(var s of i.target.elements){var l;(l=s.__on_r)===null||l===void 0||l.call(s)}})},{capture:!0}))}var Ty=new Set,uv=new Set;function Iy(e,t,n){var r=arguments.length>3&&arguments[3]!==void 0?arguments[3]:{};function a(i){if(r.capture||fl.call(t,i),!i.cancelBubble)return zy(()=>n?.call(this,i))}return e.startsWith("pointer")||e.startsWith("touch")||e==="wheel"?Tc(()=>{t.addEventListener(e,a,r)}):t.addEventListener(e,a,r),a}function be(e,t,n,r,a){var i={capture:r,passive:a},s=Iy(e,t,n,i);t!==document.body&&t!==window&&t!==document||Vf(()=>{t.removeEventListener(e,s,i)})}function Zl(e){for(var t=0;t<e.length;t++)Ty.add(e[t]);for(var n of uv)n(e)}function fl(e){var t,n=this,r=n.ownerDocument,a=e.type,i=((t=e.composedPath)===null||t===void 0?void 0:t.call(e))||[],s=i[0]||e.target,l=0,u=e.__root;if(u){var d=i.indexOf(u);if(d!==-1&&(n===document||n===window))return void(e.__root=n);var c=i.indexOf(n);if(c===-1)return;d<=c&&(l=d)}if((s=i[l]||e.target)!==n){lA(e,"currentTarget",{configurable:!0,get:()=>s||r});var v=Kn,f=hr;da(null),oi(null);try{for(var g,m=[];s!==null;){var b=s.assignedSlot||s.parentNode||s.host||null;try{var j=s["__"+a];if(j!=null&&(!s.disabled||e.target===s))if(Yl(j)){var[w,...O]=j;w.apply(s,[e,...O])}else j.call(s,e)}catch(k){g?m.push(k):g=k}if(e.cancelBubble||b===n||b===null)break;s=b}if(g){var T=function(k){queueMicrotask(()=>{throw k})};for(var R of m)T(R);throw g}}finally{e.__root=n,delete e.currentTarget,da(v),oi(f)}}}function Gf(e){var t=document.createElement("template");return t.innerHTML=e,t.content}function Ri(e,t){var n=hr;n.nodes_start===null&&(n.nodes_start=e,n.nodes_end=t)}function G(e,t){var n,r=!!(1&t),a=!!(2&t),i=!e.startsWith("<!>");return()=>{n===void 0&&(n=Gf(i?e:"<!>"+e),r||(n=mo(n)));var s=a||hy?document.importNode(n,!0):n.cloneNode(!0);return r?Ri(mo(s),s.lastChild):Ri(s,s),s}}function fi(e,t){var n,r=arguments.length>2&&arguments[2]!==void 0?arguments[2]:"svg",a=!e.startsWith("<!>"),i=!!(1&t),s="<".concat(r,">").concat(a?e:"<!>"+e,"</").concat(r,">");return()=>{if(!n){var l=mo(Gf(s));if(i)for(n=document.createDocumentFragment();mo(l);)n.appendChild(mo(l));else n=mo(l)}var u=n.cloneNode(!0);return i?Ri(mo(u),u.lastChild):Ri(u,u),u}}function Br(){var e=Ic((arguments.length>0&&arguments[0]!==void 0?arguments[0]:"")+"");return Ri(e,e),e}function xr(){var e=document.createDocumentFragment(),t=document.createComment(""),n=Ic();return e.append(t,n),Ri(t,n),e}function I(e,t){e!==null&&e.before(t)}function pt(e,t){var n,r=t==null?"":typeof t=="object"?t+"":t;r!==((n=e.__t)!==null&&n!==void 0?n:e.__t=e.nodeValue)&&(e.__t=r,e.nodeValue=r+"")}function kA(e,t){return function(n,r){var{target:a,anchor:i,props:s={},events:l,context:u}=r;(function(){if(Sa===void 0){Sa=window,hy=/Firefox/.test(navigator.userAgent);var g=Element.prototype,m=Node.prototype,b=Text.prototype;gy=_a(m,"firstChild").get,my=_a(m,"nextSibling").get,sh(g)&&(g.__click=void 0,g.__className=void 0,g.__attributes=null,g.__style=void 0,g.__e=void 0),sh(b)&&(b.__t=void 0)}})();var d=new Set,c=g=>{for(var m=0;m<g.length;m++){var b=g[m];if(!d.has(b)){d.add(b);var j=wA(b);a.addEventListener(b,fl,{passive:j});var w=Ji.get(b);w===void 0?(document.addEventListener(b,fl,{passive:j}),Ji.set(b,1)):Ji.set(b,w+1)}}};c(iv(Ty)),uv.add(c);var v=void 0,f=function(g){var m=Ws(iy,g,!0);return function(){var b=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return new Promise(j=>{b.outro?js(m,()=>{va(m),j(void 0)}):(va(m),j(void 0))})}}(()=>{var g=i??a.appendChild(Ic());return za(()=>{u&&(lt({}),Nn.c=u),l&&(s.$$events=l),v=n(g,s)||{},u&&ut()}),()=>{for(var m of d){a.removeEventListener(m,fl);var b=Ji.get(m);--b==0?(document.removeEventListener(m,fl),Ji.delete(m)):Ji.set(m,b)}var j;uv.delete(c),g!==i&&((j=g.parentNode)===null||j===void 0||j.removeChild(g))}});return cv.set(v,f),v}(e,t)}var Ji=new Map,cv=new WeakMap;function re(e,t){var[n,r]=arguments.length>2&&arguments[2]!==void 0?arguments[2]:[0,0],a=e,i=null,s=null,l=ro,u=!1,d=function(v){u=!0,c(!(arguments.length>1&&arguments[1]!==void 0)||arguments[1],v)},c=(v,f)=>{l!==(l=v)&&(l?(i?Wu(i):f&&(i=za(()=>f(a))),s&&js(s,()=>{s=null})):(s?Wu(s):f&&(s=za(()=>f(a,[n+1,r]))),i&&js(i,()=>{i=null})))};$i(()=>{u=!1,t(d),u||c(null,null)},n>0?Kl:0)}function Ny(e,t,n){var r,a=e,i=ro,s=Vs()?vA:Wf;$i(()=>{s(i,i=t())&&(r&&js(r),r=za(()=>n(a)))})}function Cr(e,t){return t}function jr(e,t,n,r,a){var i=arguments.length>5&&arguments[5]!==void 0?arguments[5]:null,s=e,l={flags:t,items:new Map,first:null};!(4&t)||(s=e.appendChild(Ic()));var u=null,d=!1,c=de(()=>{var v=n();return Yl(v)?v:v==null?[]:iv(v)});$i(()=>{var v=o(c),f=v.length;d&&f===0||(d=f===0,function(g,m,b,j,w,O,T){var R,k,D,H,V,A,J=!!(8&w),Z=!!(3&w),Y=g.length,le=m.items,Ae=m.first,ce=Ae,we=null,$e=[],Ne=[];if(J)for(A=0;A<Y;A+=1){var ye;H=O(D=g[A],A),(V=le.get(H))!==void 0&&((ye=V.a)===null||ye===void 0||ye.measure(),(k??(k=new Set)).add(V))}for(A=0;A<Y;A+=1)if(H=O(D=g[A],A),(V=le.get(H))!==void 0){var ze;if(Z&&_A(V,D,A,w),V.e.f&Ya&&(Wu(V.e),J&&((ze=V.a)===null||ze===void 0||ze.unfix(),(k??(k=new Set)).delete(V))),V!==ce){if(R!==void 0&&R.has(V)){if($e.length<Ne.length){var Re,We=Ne[0];we=We.prev;var he=$e[0],ue=$e[$e.length-1];for(Re=0;Re<$e.length;Re+=1)gh($e[Re],We,b);for(Re=0;Re<Ne.length;Re+=1)R.delete(Ne[Re]);Fa(m,he.prev,ue.next),Fa(m,we,he),Fa(m,ue,We),ce=We,we=ue,A-=1,$e=[],Ne=[]}else R.delete(V),gh(V,ce,b),Fa(m,V.prev,V.next),Fa(m,V,we===null?m.first:we.next),Fa(m,we,V),we=V;continue}for($e=[],Ne=[];ce!==null&&ce.k!==H;)ce.e.f&Ya||(R??(R=new Set)).add(ce),Ne.push(ce),ce=ce.next;if(ce===null)continue;V=ce}$e.push(V),we=V,ce=V.next}else we=SA(ce?ce.e.nodes_start:b,m,we,we===null?m.first:we.next,D,H,A,j,w,T),le.set(H,we),$e=[],Ne=[],ce=we.next;if(ce!==null||R!==void 0){for(var me=R===void 0?[]:iv(R);ce!==null;)ce.e.f&Ya||me.push(ce),ce=ce.next;var ot=me.length;if(ot>0){var Ot=4&w&&Y===0?b:null;if(J){for(A=0;A<ot;A+=1){var ee;(ee=me[A].a)===null||ee===void 0||ee.measure()}for(A=0;A<ot;A+=1){var q;(q=me[A].a)===null||q===void 0||q.fix()}}(function(ae,$,_e,ne){for(var Ue=[],X=$.length,L=0;L<X;L++)Jf($[L].e,Ue,!0);var yt=X>0&&Ue.length===0&&_e!==null;if(yt){var Ze=_e.parentNode;Ze.textContent="",Ze.append(_e),ne.clear(),Fa(ae,$[0].prev,$[X-1].next)}Ay(Ue,()=>{for(var Ce=0;Ce<X;Ce++){var st=$[Ce];yt||(ne.delete(st.k),Fa(ae,st.prev,st.next)),va(st.e,!yt)}})})(m,me,Ot,le)}}J&&Tc(()=>{if(k!==void 0)for(V of k){var ae;(ae=V.a)===null||ae===void 0||ae.apply()}}),hr.first=m.first&&m.first.e,hr.last=we&&we.e}(v,l,s,a,t,r,n),i!==null&&(f===0?u?Wu(u):u=za(()=>i(s)):u!==null&&js(u,()=>{u=null})),o(c))})}function _A(e,t,n,r){1&r&&Sl(e.v,t),2&r?Sl(e.i,n):e.i=n}function SA(e,t,n,r,a,i,s,l,u,d){var c=1&u?16&u?Ai(a):P(a):a,v=2&u?Ai(s):s,f={i:v,v:c,k:i,a:null,e:null,prev:n,next:r};try{return f.e=za(()=>l(e,c,v,d),!1),f.e.prev=n&&n.e,f.e.next=r&&r.e,n===null?t.first=f:(n.next=f,n.e.next=f.e),r!==null&&(r.prev=f,r.e.prev=f.e),f}finally{}}function gh(e,t,n){for(var r=e.next?e.next.e.nodes_start:n,a=t?t.e.nodes_start:n,i=e.e.nodes_start;i!==r;){var s=Nc(i);a.before(i),i=s}}function Fa(e,t,n){t===null?e.first=n:(t.next=n,t.e.next=n&&n.e),n!==null&&(n.prev=t,n.e.prev=t&&t.e)}function Ly(e,t,n,r,a){var i,s=e,l="";$i(()=>{var u;l!==(l=(u=t())!==null&&u!==void 0?u:"")&&(i!==void 0&&(va(i),i=void 0),l!==""&&(i=za(()=>{var d=l+"";n&&(d="<svg>".concat(d,"</svg>"));var c=Gf(d);if((n||r)&&(c=mo(c)),Ri(mo(c),c.lastChild),n||r)for(;mo(c);)s.before(mo(c));else s.before(c)})))})}function _r(e,t,n,r,a){var i,s=(i=t.$$slots)===null||i===void 0?void 0:i[n],l=!1;s===!0&&(s=t[n==="default"?"children":n],l=!0),s===void 0?a!==null&&a(e):s(e,l?()=>r:r)}function Uy(e,t,n){var r,a,i=e;$i(()=>{r!==(r=t())&&(a&&(js(a),a=null),r&&(a=za(()=>n(i,r))))},Kl)}function eo(e,t,n){qr(()=>{var r=Mo(()=>t(e,n?.())||{});if(n&&r!=null&&r.update){var a=!1,i={};Hs(()=>{var s=n();M(s),a&&Wf(i,s)&&(i=s,r.update(s))}),a=!0}if(r!=null&&r.destroy)return()=>r.destroy()})}function Dy(e){var t,n,r="";if(typeof e=="string"||typeof e=="number")r+=e;else if(typeof e=="object")if(Array.isArray(e)){var a=e.length;for(t=0;t<a;t++)e[t]&&(n=Dy(e[t]))&&(r&&(r+=" "),r+=n)}else for(n in e)e[n]&&(r&&(r+=" "),r+=n);return r}function ai(e){return typeof e=="object"?function(){for(var t,n,r=0,a="",i=arguments.length;r<i;r++)(t=arguments[r])&&(n=Dy(t))&&(a&&(a+=" "),a+=n);return a}(e):e??""}var mh=[...` 	
\r\f \v\uFEFF`];function bh(e){var t=arguments.length>1&&arguments[1]!==void 0&&arguments[1]?" !important;":";",n="";for(var r in e){var a=e[r];a!=null&&a!==""&&(n+=" "+r+": "+a+t)}return n}function pd(e){return e[0]!=="-"||e[1]!=="-"?e.toLowerCase():e}function Mt(e,t,n,r,a,i){if(e.__className!==n){var s=function(d,c,v){var f=d==null?"":""+d;if(c&&(f=f?f+" "+c:c),v){for(var g in v)if(v[g])f=f?f+" "+g:g;else if(f.length)for(var m=g.length,b=0;(b=f.indexOf(g,b))>=0;){var j=b+m;b!==0&&!mh.includes(f[b-1])||j!==f.length&&!mh.includes(f[j])?b=j:f=(b===0?"":f.substring(0,b))+f.substring(j+1)}}return f===""?null:f}(n,r,i);s==null?e.removeAttribute("class"):t?e.className=s:e.setAttribute("class",s),e.__className=n}else if(i&&a!==i)for(var l in i){var u=!!i[l];a!=null&&u===!!a[l]||e.classList.toggle(l,u)}return i}function hd(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},n=arguments.length>2?arguments[2]:void 0,r=arguments.length>3?arguments[3]:void 0;for(var a in n){var i=n[a];t[a]!==i&&(n[a]==null?e.style.removeProperty(a):e.style.setProperty(a,i,r))}}function Ho(e,t,n,r){if(e.__style!==t){var a=function(i,s){if(s){var l,u,d="";if(Array.isArray(s)?(l=s[0],u=s[1]):l=s,i){i=String(i).replaceAll(/\s*\/\*.*?\*\/\s*/g,"").trim();var c=!1,v=0,f=!1,g=[];l&&g.push(...Object.keys(l).map(pd)),u&&g.push(...Object.keys(u).map(pd));for(var m=0,b=-1,j=i.length,w=0;w<j;w++){var O=i[w];if(f?O==="/"&&i[w-1]==="*"&&(f=!1):c?c===O&&(c=!1):O==="/"&&i[w+1]==="*"?f=!0:O==='"'||O==="'"?c=O:O==="("?v++:O===")"&&v--,!f&&c===!1&&v===0){if(O===":"&&b===-1)b=w;else if(O===";"||w===j-1){if(b!==-1){var T=pd(i.substring(m,b).trim());g.includes(T)||(O!==";"&&w++,d+=" "+i.substring(m,w).trim()+";")}m=w+1,b=-1}}}}return l&&(d+=bh(l)),u&&(d+=bh(u,!0)),(d=d.trim())===""?null:d}return i==null?null:String(i)}(t,r);a==null?e.removeAttribute("style"):e.style.cssText=a,e.__style=t}else r&&(Array.isArray(r)?(hd(e,n?.[0],r[0]),hd(e,n?.[1],r[1],"important")):hd(e,n,r));return r}var Zi=Symbol("class"),ll=Symbol("style"),qy=Symbol("is custom element"),$y=Symbol("is html");function Mi(e,t){var n=Kf(e);n.value!==(n.value=t??void 0)&&(e.value!==t||t===0&&e.nodeName==="PROGRESS")&&(e.value=t??"")}function Cn(e,t,n,r){var a=Kf(e);a[t]!==(a[t]=n)&&(t==="loading"&&(e[iA]=n),n==null?e.removeAttribute(t):typeof n!="string"&&Fy(e).includes(t)?e[t]=n:e.setAttribute(t,n))}function wu(e,t,n,r){var a,i=Kf(e),s=i[qy],l=!i[$y],u=t||{},d=e.tagName==="OPTION";for(var c in t)c in n||(n[c]=null);n.class?n.class=ai(n.class):(r||n[Zi])&&(n.class=null),n[ll]&&((a=n.style)!==null&&a!==void 0||(n.style=null));var v,f,g,m,b,j,w=Fy(e),O=function(R){var k=n[R];if(d&&R==="value"&&k==null)return e.value=e.__value="",u[R]=k,0;if(R==="class")return v=e.namespaceURI==="http://www.w3.org/1999/xhtml",Mt(e,v,k,r,t?.[Zi],n[Zi]),u[R]=k,u[Zi]=n[Zi],0;if(R==="style")return Ho(e,k,t?.[ll],n[ll]),u[R]=k,u[ll]=n[ll],0;if(k===(f=u[R])||(u[R]=k,(g=R[0]+R[1])==="$$"))return 0;if(g==="on"){var D={},H="$$"+R,V=R.slice(2);if(m=function(le){return xA.includes(le)}(V),function(le){return le.endsWith("capture")&&le!=="gotpointercapture"&&le!=="lostpointercapture"}(V)&&(V=V.slice(0,-7),D.capture=!0),!m&&f){if(k!=null)return 0;e.removeEventListener(V,u[H],D),u[H]=null}if(k!=null)if(m)e["__".concat(V)]=k,Zl([V]);else{let le=function(Ae){u[R].call(this,Ae)};u[H]=Iy(V,e,le,D)}else m&&(e["__".concat(V)]=void 0)}else if(R==="style")Cn(e,R,k);else if(R==="autofocus")(function(le,Ae){if(Ae){var ce=document.body;le.autofocus=!0,Tc(()=>{document.activeElement===ce&&le.focus()})}})(e,!!k);else if(s||R!=="__value"&&(R!=="value"||k==null))if(R==="selected"&&d)(function(le,Ae){Ae?le.hasAttribute("selected")||le.setAttribute("selected",""):le.removeAttribute("selected")})(e,k);else if(b=R,l||(b=function(le){var Ae;return le=le.toLowerCase(),(Ae=jA[le])!==null&&Ae!==void 0?Ae:le}(b)),j=b==="defaultValue"||b==="defaultChecked",k!=null||s||j)j||w.includes(b)&&(s||typeof k!="string")?e[b]=k:typeof k!="function"&&Cn(e,b,k);else if(i[R]=null,b==="value"||b==="checked"){var A=e,J=t===void 0;if(b==="value"){var Z=A.defaultValue;A.removeAttribute(b),A.defaultValue=Z,A.value=A.__value=J?Z:null}else{var Y=A.defaultChecked;A.removeAttribute(b),A.defaultChecked=Y,A.checked=!!J&&Y}}else e.removeAttribute(R);else e.value=e.__value=k};for(var T in n)O(T);return u}function Kf(e){var t;return(t=e.__attributes)!==null&&t!==void 0?t:e.__attributes={[qy]:e.nodeName.includes("-"),[$y]:e.namespaceURI==="http://www.w3.org/1999/xhtml"}}var xh=new Map;function Fy(e){var t,n=xh.get(e.nodeName);if(n)return n;xh.set(e.nodeName,n=[]);for(var r=e,a=Element.prototype;a!==r;){for(var i in t=uy(r))t[i].set&&n.push(i);r=Bf(r)}return n}function Hu(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:t,r=Vs();Py(e,"input",a=>{var i=a?e.defaultValue:e.value;if(i=gd(e)?md(i):i,n(i),r&&i!==(i=t())){var s=e.selectionStart,l=e.selectionEnd;e.value=i??"",l!==null&&(e.selectionStart=s,e.selectionEnd=Math.min(l,e.value.length))}}),Mo(t)==null&&e.value&&n(gd(e)?md(e.value):e.value),Hs(()=>{var a=t();gd(e)&&a===md(e.value)||(e.type!=="date"||a||e.value)&&a!==e.value&&(e.value=a??"")})}function gd(e){var t=e.type;return t==="number"||t==="range"}function md(e){return e===""?null:+e}function _t(e,t,n){var r=_a(e,t);r&&r.set&&(e[t]=n,Vf(()=>{e[t]=null}))}function jh(e,t,n){if(e.multiple)return function(l,u){for(var d of l.options)d.selected=~u.indexOf(bl(d))}(e,t);for(var r of e.options){var a=bl(r);if(i=a,s=t,Object.is(dh(i),dh(s)))return void(r.selected=!0)}var i,s;n&&t===void 0||(e.selectedIndex=-1)}function CA(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:t,r=!0;Py(e,"change",a=>{var i,s=a?"[selected]":":checked";if(e.multiple)i=[].map.call(e.querySelectorAll(s),bl);else{var l,u=(l=e.querySelector(s))!==null&&l!==void 0?l:e.querySelector("option:not([disabled])");i=u&&bl(u)}n(i)}),qr(()=>{var a=t();if(jh(e,a,r),r&&a===void 0){var i=e.querySelector(":checked");i!==null&&(a=bl(i),n(a))}e.__value=a,r=!1}),function(a){qr(()=>{var i=new MutationObserver(()=>{var s=a.__value;jh(a,s)});return i.observe(a,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),()=>{i.disconnect()}})}(e)}function bl(e){return"__value"in e?e.__value:e.value}function yh(e,t){return e===t||e?.[la]===t}function tr(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},t=arguments.length>1?arguments[1]:void 0,n=arguments.length>2?arguments[2]:void 0;return qr(()=>{var r,a;return Hs(()=>{r=a,a=[],Mo(()=>{e!==n(...a)&&(t(e,...a),r&&yh(n(...r),e)&&t(null,...r))})}),()=>{Tc(()=>{a&&yh(n(...a),e)&&t(null,...a)})}}),e}function xa(e){return function(){for(var t=arguments.length,n=new Array(t),r=0;r<t;r++)n[r]=arguments[r];return n[0].stopPropagation(),e?.apply(this,n)}}function Ba(e){return function(){for(var t=arguments.length,n=new Array(t),r=0;r<t;r++)n[r]=arguments[r];return n[0].preventDefault(),e?.apply(this,n)}}function St(){var e=arguments.length>0&&arguments[0]!==void 0&&arguments[0],t=Nn,n=t.l.u;if(n){var r,a=()=>M(t.s);if(e){var i=0,s={},l=xs(()=>{var u=!1,d=t.s;for(var c in d)d[c]!==s[c]&&(s[c]=d[c],u=!0);return u&&i++,i});a=()=>o(l)}n.b.length&&(r=()=>{wh(t,a),Du(n.b)},Sy(),Hs(r)),lv(()=>{var u=Mo(()=>n.m.map(dA));return()=>{for(var d of u)typeof d=="function"&&d()}}),n.a.length&&lv(()=>{wh(t,a),Du(n.a)})}}function wh(e,t){if(e.l.s)for(var n of e.l.s)o(n);t()}function qc(e){var t=Ai(0);return function(){return arguments.length===1?(p(t,o(t)+1),arguments[0]):(o(t),e())}}function pl(e,t){var n,r=(n=e.$$events)===null||n===void 0?void 0:n[t.type],a=Yl(r)?r.slice():r==null?[]:[r];for(var i of a)i.call(this,t)}function Yr(e){Nn===null&&Ql(),qs&&Nn.l!==null?By(Nn).m.push(e):lv(()=>{var t=Mo(e);if(typeof t=="function")return t})}function zo(e){Nn===null&&Ql(),Yr(()=>()=>Mo(e))}function OA(){var e=Nn;return e===null&&Ql(),(t,n,r)=>{var a,i=(a=e.s.$$events)===null||a===void 0?void 0:a[t];if(i){var s=Yl(i)?i.slice():[i],l=function(d,c){var{bubbles:v=!1,cancelable:f=!1}=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};return new CustomEvent(d,{detail:c,bubbles:v,cancelable:f})}(t,n,r);for(var u of s)u.call(e.x,l);return!l.defaultPrevented}return!0}}function EA(e){Nn===null&&Ql(),Nn.l===null&&function(){throw new Error("https://svelte.dev/e/lifecycle_legacy_only")}(),By(Nn).b.push(e)}function By(e){var t,n=e.l;return(t=n.u)!==null&&t!==void 0?t:n.u={a:[],b:[],m:[]}}var uu=!1,AA={get(e,t){if(!e.exclude.includes(t))return o(e.version),t in e.special?e.special[t]():e.props[t]},set:(e,t,n)=>(t in e.special||(e.special[t]=h({get[t](){return e.props[t]}},t,4)),e.special[t](n),vh(e.version),!0),getOwnPropertyDescriptor(e,t){if(!e.exclude.includes(t))return t in e.props?{enumerable:!0,configurable:!0,value:e.props[t]}:void 0},deleteProperty:(e,t)=>(e.exclude.includes(t)||(e.exclude.push(t),vh(e.version)),!0),has:(e,t)=>!e.exclude.includes(t)&&t in e.props,ownKeys:e=>Reflect.ownKeys(e.props).filter(t=>!e.exclude.includes(t))};function cu(e,t){return new Proxy({props:e,exclude:t,special:{},version:Ai(0)},AA)}var RA={get(e,t){for(var n=e.props.length;n--;){var r=e.props[n];if(sl(r)&&(r=r()),typeof r=="object"&&r!==null&&t in r)return r[t]}},set(e,t,n){for(var r=e.props.length;r--;){var a=e.props[r];sl(a)&&(a=a());var i=_a(a,t);if(i&&i.set)return i.set(n),!0}return!1},getOwnPropertyDescriptor(e,t){for(var n=e.props.length;n--;){var r=e.props[n];if(sl(r)&&(r=r()),typeof r=="object"&&r!==null&&t in r){var a=_a(r,t);return a&&!a.configurable&&(a.configurable=!0),a}}},has(e,t){if(t===la||t===ly)return!1;for(var n of e.props)if(sl(n)&&(n=n()),n!=null&&t in n)return!0;return!1},ownKeys(e){var t=[];for(var n of e.props)for(var r in sl(n)&&(n=n()),n)t.includes(r)||t.push(r);return t}};function Xa(){for(var e=arguments.length,t=new Array(e),n=0;n<e;n++)t[n]=arguments[n];return new Proxy({props:t},RA)}function kh(e){var t,n;return(t=(n=e.ctx)===null||n===void 0?void 0:n.d)!==null&&t!==void 0&&t}function h(e,t,n,r){var a,i,s,l=!!(1&n),u=!qs||!!(2&n),d=!!(8&n),c=!!(16&n),v=!1;d?[s,v]=function(A){var J=uu;try{return uu=!1,[A(),uu]}finally{uu=J}}(()=>e[t]):s=e[t];var f,g=la in e||ly in e,m=d&&((a=(i=_a(e,t))===null||i===void 0?void 0:i.set)!==null&&a!==void 0?a:g&&t in e&&(A=>e[t]=A))||void 0,b=r,j=!0,w=!1,O=()=>(w=!0,j&&(j=!1,b=c?Mo(r):r),b);if(s===void 0&&r!==void 0&&(m&&u&&function(){throw new Error("https://svelte.dev/e/props_invalid_value")}(),s=O(),m&&m(s)),u)f=()=>{var A=e[t];return A===void 0?O():(j=!0,w=!1,A)};else{var T=(l?xs:de)(()=>e[t]);T.f|=sy,f=()=>{var A=o(T);return A!==void 0&&(b=void 0),A===void 0?b:A}}if(!(4&n))return f;if(m){var R=e.$$legacy;return function(A,J){return arguments.length>0?(u&&J&&!R&&!v||m(J?f():A),A):f()}}var k=!1,D=!1,H=P(s),V=xs(()=>{var A=f(),J=o(H);return k?(k=!1,D=!0,J):(D=!1,H.v=A)});return d&&o(V),l||(V.equals=Hf),function(A,J){if(bi!==null&&(k=D,f(),o(H)),arguments.length>0){var Z=J?o(V):u&&d?gi(A):A;if(!V.equals(Z)){if(k=!0,p(H,Z),w&&b!==void 0&&(b=Z),kh(V))return A;Mo(()=>o(V))}return A}return kh(V)?V.v:o(V)}}function Fr(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:function(r){var a=function(i){try{if(typeof window<"u"&&window.localStorage!==void 0)return window.localStorage[i]}catch{}}("debug");return a!=null&&a.endsWith("*")?r.startsWith(a.slice(0,-1)):r===a}(e);if(!t)return MA;var n=function(r){for(var a=0,i=0;i<r.length;i++)a=(a<<5)-a+r.charCodeAt(i),a|=0;return _h[Math.abs(a)%_h.length]}(e);return function(){for(var r=arguments.length,a=new Array(r),i=0;i<r;i++)a[i]=arguments[i];console.log("%c".concat(e),"color:".concat(n),...a)}}function MA(){}var _h=["#0000CC","#0099FF","#009400","#8dd200","#CCCC00","#CC9933","#ae04e7","#ff35d7","#FF3333","#FF6600","#FF9933","#FFCC33"],zA=0;function os(){return++zA}function Vr(e){return parseInt(e,10)}function Yf(e){return PA.test(e)}var PA=/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$/;function On(e){return typeof e=="object"&&e!==null&&(e.constructor===void 0||e.constructor.name==="Object")}function Ar(e){return typeof e=="object"&&e!==null&&(e.constructor===void 0||e.constructor.name==="Object"||e.constructor.name==="Array")}function TA(e){return e===!0||e===!1}function dv(e){if(typeof e=="number")return e>9466848e5&&isFinite(e)&&Math.floor(e)===e&&!isNaN(new Date(e).valueOf());if(typeof e=="bigint")return dv(Number(e));try{var t=e&&e.valueOf();if(t!==e)return dv(t)}catch{return!1}return!1}function Wy(e){(du=du||window.document.createElement("div")).style.color="",du.style.color=e;var t=du.style.color;return t!==""?t.replace(/\s+/g,"").toLowerCase():void 0}var du=void 0;function IA(e){return typeof e=="string"&&e.length<99&&!!Wy(e)}function Xf(e,t){if(typeof e=="number"||typeof e=="string"||typeof e=="boolean"||e===void 0)return typeof e;if(typeof e=="bigint")return"number";if(e===null)return"null";if(Array.isArray(e))return"array";if(On(e))return"object";var n=t.stringify(e);return n&&Yf(n)?"number":n==="true"||n==="false"?"boolean":n==="null"?"null":"unknown"}var NA=/^https?:\/\/\S+$/;function $c(e){return typeof e=="string"&&NA.test(e)}function Js(e,t){if(e==="")return"";var n=e.trim();return n==="null"?null:n==="true"||n!=="false"&&(Yf(n)?t.parse(n):e)}function LA(e){return UA.test(e)}var UA=/^-?[0-9]+$/,DA=[];function Sh(e,t){if(e.length!==t.length)return!1;for(var n=0;n<e.length;n++)if(e[n]!==t[n])return!1;return!0}function vv(e){var t=arguments.length>1&&arguments[1]!==void 0&&arguments[1],n={};if(!Array.isArray(e))throw new TypeError("Array expected");function r(s,l){(!Array.isArray(s)&&!On(s)||t&&l.length>0)&&(n[zt(l)]=!0),On(s)&&Object.keys(s).forEach(u=>{r(s[u],l.concat(u))})}for(var a=Math.min(e.length,1e4),i=0;i<a;i++)r(e[i],DA);return Object.keys(n).sort().map(Fo)}function Hy(e,t,n){if(!(t<=e))for(var r=e;r<t;r++)n(r)}function Vy(e,t){return e.length>t?e.slice(0,t):e}function Ch(e){return Se({},e)}function Oh(e){return Object.values(e)}function Eh(e,t,n,r){var a=e.slice(0),i=a.splice(t,n);return a.splice.apply(a,[t+r,0,...i]),a}function qA(e,t,n){return e.slice(0,t).concat(n).concat(e.slice(t))}function eu(e,t){try{return t.parse(e)}catch{return t.parse(Wo(e))}}function Jy(e,t){try{return eu(e,t)}catch{return}}function Fc(e,t){e=e.replace(Ky,"");try{return t(e)}catch{}try{return t("{"+e+"}")}catch{}try{return t("["+e+"]")}catch{}throw new Error("Failed to parse partial JSON")}function Gy(e){e=e.replace(Ky,"");try{return Wo(e)}catch{}try{var t=Wo("["+e+"]");return t.substring(1,t.length-1)}catch{}try{var n=Wo("{"+e+"}");return n.substring(1,n.length-1)}catch{}throw new Error("Failed to repair partial JSON")}var Ky=/,\s*$/;function ys(e,t){var n=Rh.exec(t);if(n){var r=Vr(n[2]),a=function(g,m){for(var b=arguments.length>2&&arguments[2]!==void 0?arguments[2]:0,j=arguments.length>3&&arguments[3]!==void 0?arguments[3]:g.length,w=0,O=b;O<j;O++)g.charAt(O)===m&&w++;return w}(e,`
`,0,r),i=r-e.lastIndexOf(`
`,r)-1;return{position:r,line:a,column:i,message:t.replace(Rh,()=>"line ".concat(a+1," column ").concat(i+1))}}var s=BA.exec(t),l=s?Vr(s[1]):void 0,u=l!==void 0?l-1:void 0,d=WA.exec(t),c=d?Vr(d[1]):void 0,v=c!==void 0?c-1:void 0,f=u!==void 0&&v!==void 0?function(g,m,b){for(var j=g.indexOf(`
`),w=1;w<m&&j!==-1;)j=g.indexOf(`
`,j+1),w++;return j!==-1?j+b+1:void 0}(e,u,v):void 0;return{position:f,line:u,column:v,message:t.replace(/^JSON.parse: /,"").replace(/ of the JSON data$/,"")}}function bd(e){return On(e)?e.json!==void 0?e.text!==void 0?'Content must contain either a property "json" or a property "text" but not both':void 0:e.text===void 0?'Content must contain either a property "json" or a property "text"':typeof e.text!="string"?'Content "text" property must be a string containing a JSON document. Did you mean to use the "json" property instead?':void 0:"Content must be an object"}function Cl(e){return On(e)&&typeof e.text=="string"}function Ol(e){return On(e)&&e.json!==void 0}function Yy(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:void 0,n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:JSON;return Cl(e)?e:{text:n.stringify(e.json,null,t)}}function Ah(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:JSON;return Ol(e)?e:{json:t.parse(e.text)}}function fv(e,t,n){return Yy(e,t,n).text}function $A(e,t){return FA(e,t)>t}function FA(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1/0;if(Cl(e))return e.text.length;var n=e.json,r=0;return function a(i){if(Array.isArray(i)){if((r+=i.length-1+2)>t)return;for(var s=0;s<i.length;s++)if(a(i[s]),r>t)return}else if(On(i)){var l=Object.keys(i);r+=2+l.length+(l.length-1);for(var u=0;u<l.length;u++){var d=l[u],c=i[d];r+=d.length+2,a(c)}}else r+=typeof i=="string"?i.length+2:String(i).length}(n),r}var Rh=/(position|char) (\d+)/,BA=/line (\d+)/,WA=/column (\d+)/;function Vu(e,t){return e.parse===t.parse&&e.stringify===t.stringify}var Lr,$n,Do,jo,Vo,Lo,Qa,HA=/[,:]\S/;function Qf(e){var{escapeControlCharacters:t,escapeUnicodeCharacters:n}=e;return t?n?VA:JA:n?GA:KA}(function(e){e.text="text",e.tree="tree",e.table="table"})(Lr||(Lr={})),function(e){e.after="after",e.inside="inside",e.key="key",e.value="value",e.multi="multi",e.text="text"}($n||($n={})),function(e){e.after="after",e.key="key",e.value="value",e.inside="inside"}(Do||(Do={})),function(e){e.info="info",e.warning="warning",e.error="error"}(jo||(jo={})),function(e){e.key="key",e.value="value"}(Vo||(Vo={})),function(e){e.asc="asc",e.desc="desc"}(Lo||(Lo={})),function(e){e.no="no",e.self="self",e.nextInside="nextInside"}(Qa||(Qa={}));var VA={escapeValue:e=>Xy(ew(String(e))),unescapeValue:e=>tw(Qy(e))},JA={escapeValue:e=>ew(String(e)),unescapeValue:e=>tw(e)},GA={escapeValue:e=>Xy(String(e)),unescapeValue:e=>Qy(e)},KA={escapeValue:e=>String(e),unescapeValue:e=>e};function Xy(e){return e.replace(/[^\x20-\x7F]/g,t=>{var n;return t==="\b"||t==="\f"||t===`
`||t==="\r"||t==="	"?t:"\\u"+("000"+((n=t.codePointAt(0))===null||n===void 0?void 0:n.toString(16))).slice(-4)})}function Qy(e){return e.replace(/\\u[a-fA-F0-9]{4}/g,t=>{try{var n=JSON.parse('"'+t+'"');return Zy[n]||n}catch{return t}})}var Zy={'"':'\\"',"\\":"\\\\","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","	":"\\t"},YA={'\\"':'"',"\\\\":"\\","\\/":"/","\\b":"\b","\\f":"\f","\\n":`
`,"\\r":"\r","\\t":"	"};function ew(e){return e.replace(/["\b\f\n\r\t\\]/g,t=>Zy[t]||t)}function tw(e){return e.replace(/\\["bfnrt\\]/g,t=>YA[t]||t)}function Bc(e){return typeof e!="string"?String(e):e.endsWith(`
`)?e+`
`:e}function nw(e,t){return Gs(e,n=>n.nodeName.toUpperCase()===t.toUpperCase())}function Ga(e,t,n){return Gs(e,r=>function(a,i,s){return typeof a.getAttribute=="function"&&a.getAttribute(i)===s}(r,t,n))}function Gs(e,t){return!!Zf(e,t)}function Zf(e,t){for(var n=e;n&&!t(n);)n=n.parentNode;return n}function tu(e){var t,n;return(t=e==null||(n=e.ownerDocument)===null||n===void 0?void 0:n.defaultView)!==null&&t!==void 0?t:void 0}function ep(e){var t=tu(e),n=t?.document.activeElement;return!!n&&Gs(n,r=>r===e)}function rw(e,t){return Zf(e,n=>n.nodeName===t)}function xd(e){return Ga(e,"data-type","selectable-key")?$n.key:Ga(e,"data-type","selectable-value")?$n.value:Ga(e,"data-type","insert-selection-area-inside")?$n.inside:Ga(e,"data-type","insert-selection-area-after")?$n.after:$n.multi}function pv(e){return encodeURIComponent(zt(e))}function ow(e){var t,n=Zf(e,a=>!(a==null||!a.hasAttribute)&&a.hasAttribute("data-path")),r=(t=n?.getAttribute("data-path"))!==null&&t!==void 0?t:void 0;return r?Fo(decodeURIComponent(r)):void 0}function XA(e){var{allElements:t,currentElement:n,direction:r,hasPrio:a=()=>!0,margin:i=10}=e,s=Rs(t.filter(function(w){var O=w.getBoundingClientRect();return O.width>0&&O.height>0}),u),l=u(n);function u(w){var O=w.getBoundingClientRect();return{x:O.left+O.width/2,y:O.top+O.height/2,rect:O,element:w}}function d(w,O){var T=arguments.length>2&&arguments[2]!==void 0?arguments[2]:1,R=w.x-O.x,k=(w.y-O.y)*T;return Math.sqrt(R*R+k*k)}var c=w=>d(w,l);if(r==="Left"||r==="Right"){var v=r==="Left"?s.filter(w=>{return O=l,w.rect.left+i<O.rect.left;var O}):s.filter(w=>{return O=l,w.rect.right>O.rect.right+i;var O}),f=v.filter(w=>{return O=w,T=l,Math.abs(O.y-T.y)<i;var O,T}),g=ns(f,c)||ns(v,w=>d(w,l,10));return g?.element}if(r==="Up"||r==="Down"){var m=r==="Up"?s.filter(w=>{return O=l,w.y+i<O.y;var O}):s.filter(w=>{return O=l,w.y>O.y+i;var O}),b=m.filter(w=>a(w.element)),j=ns(b,c)||ns(m,c);return j?.element}}function tp(){var e,t,n,r;return typeof navigator<"u"&&(e=(t=(n=navigator)===null||n===void 0||(n=n.platform)===null||n===void 0?void 0:n.toUpperCase().includes("MAC"))!==null&&t!==void 0?t:(r=navigator)===null||r===void 0||(r=r.userAgentData)===null||r===void 0||(r=r.platform)===null||r===void 0?void 0:r.toUpperCase().includes("MAC"))!==null&&e!==void 0&&e}function Pa(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:"+",n=[];np(e,arguments.length>2&&arguments[2]!==void 0?arguments[2]:tp)&&n.push("Ctrl"),e.altKey&&n.push("Alt"),e.shiftKey&&n.push("Shift");var r=e.key.length===1?e.key.toUpperCase():e.key;return r in QA||n.push(r),n.join(t)}function np(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:tp;return e.ctrlKey||e.metaKey&&t()}var QA={Ctrl:!0,Command:!0,Control:!0,Alt:!0,Option:!0,Shift:!0};function jt(e,t){t===void 0&&(t={});var n=t.insertAt;if(e&&typeof document<"u"){var r=document.head||document.getElementsByTagName("head")[0],a=document.createElement("style");a.type="text/css",n==="top"&&r.firstChild?r.insertBefore(a,r.firstChild):r.appendChild(a),a.styleSheet?a.styleSheet.cssText=e:a.appendChild(document.createTextNode(e))}}jt(`.jse-absolute-popup.svelte-1r8q3m8 {
  position: relative;
  left: 0;
  top: 0;
  width: 0;
  height: 0;
  z-index: 1001;
}
.jse-absolute-popup.svelte-1r8q3m8 .jse-hidden-input:where(.svelte-1r8q3m8) {
  position: fixed;
  left: 0;
  top: 0;
  width: 0;
  height: 0;
  padding: 0;
  margin: 0;
  border: none;
  outline: none;
  overflow: hidden;
}
.jse-absolute-popup.svelte-1r8q3m8 .jse-absolute-popup-content:where(.svelte-1r8q3m8) {
  position: absolute;
}`);var ZA=G('<div class="jse-absolute-popup-content svelte-1r8q3m8"><input type="text" readonly="" tabindex="-1" class="jse-hidden-input svelte-1r8q3m8"> <!></div>'),eR=G('<div role="none" class="jse-absolute-popup svelte-1r8q3m8"><!></div>');function tR(e,t){lt(t,!1);var n=h(t,"popup",8),r=h(t,"closeAbsolutePopup",8),a=P(),i=P();function s(v){n().options&&n().options.closeOnOuterClick&&!Gs(v.target,f=>f===o(a))&&r()(n().id)}function l(v){Pa(v)==="Escape"&&(v.preventDefault(),v.stopPropagation(),r()(n().id))}Yr(function(){o(i)&&o(i).focus()}),St();var u=eR();be("mousedown",Sa,function(v){s(v)},!0),be("keydown",Sa,l,!0),be("wheel",Sa,function(v){s(v)},!0);var d=z(u),c=v=>{var f=ZA(),g=z(f);tr(g,m=>p(i,m),()=>o(i)),Uy(F(g,2),()=>n().component,(m,b)=>{b(m,Xa(()=>n().props))}),Ee(m=>Ho(f,m),[()=>function(m,b){var j=m.getBoundingClientRect(),{left:w,top:O,positionAbove:T,positionLeft:R}=function(){if(b.anchor){var{anchor:k,width:D=0,height:H=0,offsetTop:V=0,offsetLeft:A=0,position:J}=b,{left:Z,top:Y,bottom:le,right:Ae}=k.getBoundingClientRect(),ce=J==="top"||Y+H>window.innerHeight&&Y>H,we=J==="left"||Z+D>window.innerWidth&&Z>D;return{left:we?Ae-A:Z+A,top:ce?Y-V:le+V,positionAbove:ce,positionLeft:we}}if(typeof b.left=="number"&&typeof b.top=="number"){var{left:$e,top:Ne,width:ye=0,height:ze=0}=b;return{left:$e,top:Ne,positionAbove:Ne+ze>window.innerHeight&&Ne>ze,positionLeft:$e+ye>window.innerWidth&&$e>ye}}throw new Error('Invalid config: pass either "left" and "top", or pass "anchor"')}();return(T?"bottom: ".concat(j.top-O,"px;"):"top: ".concat(O-j.top,"px;"))+(R?"right: ".concat(j.left-w,"px;"):"left: ".concat(w-j.left,"px;"))}(o(a),n().options)],de),I(v,f)};re(d,v=>{o(a)&&v(c)}),tr(u,v=>p(a,v),()=>o(a)),be("mousedown",u,function(v){v.stopPropagation()}),be("keydown",u,l),I(e,u),ut()}var nR=G("<!> <!>",1);function hv(e,t){lt(t,!1);var n,r,a=Fr("jsoneditor:AbsolutePopup"),i=P([],!0);function s(d){var c=o(i).findIndex(f=>f.id===d);if(c!==-1){var v=o(i)[c];v.options.onClose&&v.options.onClose(),p(i,o(i).filter(f=>f.id!==d))}}n="absolute-popup",r={openAbsolutePopup:function(d,c,v){a("open...",c,v);var f={id:os(),component:d,props:c||{},options:v||{}};return p(i,[...o(i),f]),f.id},closeAbsolutePopup:s},My().set(n,r),W(()=>o(i),()=>{a("popups",o(i))}),_n(),St(!0);var l=nR(),u=ft(l);jr(u,1,()=>o(i),Cr,(d,c)=>{tR(d,{get popup(){return o(c)},closeAbsolutePopup:s})}),_r(F(u,2),t,"default",{},null),I(e,l),ut()}function nu(e,t){for(var n=new Set(t),r=e.replace(/ \(copy( \d+)?\)$/,""),a=e,i=1;n.has(a);){var s="copy"+(i>1?" "+i:"");a="".concat(r," (").concat(s,")"),i++}return a}function El(e,t){var n=t-3;return e.length>t?e.substring(0,n)+"...":e}function Wc(e){if(e==="")return"";var t=e.toLowerCase();if(t==="null")return null;if(t==="true")return!0;if(t==="false")return!1;if(t!=="undefined"){var n=Number(e),r=parseFloat(e);return isNaN(n)||isNaN(r)?e:n}}var aw={id:"jsonquery",name:"JSONQuery",description:`
<p>
  Enter a <a href="https://jsonquerylang.org" target="_blank" 
  rel="noopener noreferrer">JSON Query</a> function to filter, sort, or transform the data.
  You can use functions like <code>get</code>, <code>filter</code>,
  <code>sort</code>, <code>pick</code>, <code>groupBy</code>, <code>uniq</code>, etcetera. 
  Example query: <code>filter(.age >= 18)</code>
</p>
`,createQuery:function(e,t){var{filter:n,sort:r,projection:a}=t,i=[];n&&n.path&&n.relation&&n.value&&i.push(["filter",[(s=n.relation,A1("1 ".concat(s," 1"))[0]),vu(n.path),Wc(n.value)]]);var s;return r&&r.path&&r.direction&&i.push(["sort",vu(r.path),r.direction==="desc"?"desc":"asc"]),a&&a.paths&&(a.paths.length>1?i.push(["pick",...a.paths.map(vu)]):i.push(["map",vu(a.paths[0])])),R1(["pipe",...i])},executeQuery:function(e,t){return t.trim()!==""?Ig(e,t):e}};function vu(e){return["get",...e]}var rR=fi("<g><!></g>");function oR(e,t){lt(t,!1);var n=870711,r=P(""),a=h(t,"data",8);function i(l){if(!l||!l.raw)return"";var u=l.raw,d={};return u=u.replace(/\s(?:xml:)?id=["']?([^"')\s]+)/g,(c,v)=>{var f="fa-".concat((n+=1).toString(16));return d[v]=f,' id="'.concat(f,'"')}),u=u.replace(/#(?:([^'")\s]+)|xpointer\(id\((['"]?)([^')]+)\2\)\))/g,(c,v,f,g)=>{var m=v||g;return m&&d[m]?"#".concat(d[m]):c}),u}W(()=>M(a()),()=>{p(r,i(a()))}),_n();var s=rR();Ly(z(s),()=>o(r),!0,!1),I(e,s),ut()}jt(`
  .fa-icon.svelte-1mc5hvj {
    display: inline-block;
    fill: currentColor;
  }
  .fa-flip-horizontal.svelte-1mc5hvj {
    transform: scale(-1, 1);
  }
  .fa-flip-vertical.svelte-1mc5hvj {
    transform: scale(1, -1);
  }
  .fa-spin.svelte-1mc5hvj {
    animation: svelte-1mc5hvj-fa-spin 1s 0s infinite linear;
  }
  .fa-inverse.svelte-1mc5hvj {
    color: #fff;
  }
  .fa-pulse.svelte-1mc5hvj {
    animation: svelte-1mc5hvj-fa-spin 1s infinite steps(8);
  }
  @keyframes svelte-1mc5hvj-fa-spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`);var aR=fi("<svg><!></svg>"),iR=fi("<path></path>"),sR=fi("<polygon></polygon>"),lR=fi("<!><!><!>",1);function dn(e,t){var n=cu(t,["children","$$slots","$$events","$$legacy"]),r=cu(n,["class","data","scale","spin","inverse","pulse","flip","label","style"]);lt(t,!1);var a=h(t,"class",8,""),i=h(t,"data",8),s=P(),l=h(t,"scale",8,1),u=h(t,"spin",8,!1),d=h(t,"inverse",8,!1),c=h(t,"pulse",8,!1),v=h(t,"flip",8,void 0),f=h(t,"label",8,""),g=h(t,"style",8,""),m=P(10),b=P(10),j=P(),w=P();function O(){var R=1;return l()!==void 0&&(R=Number(l())),isNaN(R)||R<=0?(console.warn('Invalid prop: prop "scale" should be a number over 0.'),1):1*R}function T(){return o(s)?Math.max(o(s).width,o(s).height)/16:1}W(()=>(M(i()),M(g()),M(l())),()=>{p(s,function(R){var k;if(R){if(!("definition"in R)){if("iconName"in R&&"icon"in R){R.iconName;var[D,H,,,V]=R.icon;k={width:D,height:H,paths:(Array.isArray(V)?V:[V]).map(A=>({d:A}))}}else k=R[Object.keys(R)[0]];return k}console.error("`import faIconName from '@fortawesome/package-name/faIconName` not supported - Please use `import { faIconName } from '@fortawesome/package-name/faIconName'` instead")}}(i())),g(),l(),p(m,o(s)?o(s).width/T()*O():0),p(b,o(s)?o(s).height/T()*O():0),p(j,function(){var R="";g()!==null&&(R+=g());var k=O();return k===1?R.length===0?"":R:(R===""||R.endsWith(";")||(R+="; "),"".concat(R,"font-size: ").concat(k,"em"))}()),p(w,o(s)?"0 0 ".concat(o(s).width," ").concat(o(s).height):"0 0 ".concat(o(m)," ").concat(o(b)))}),_n(),St(),function(R,k){var D,H=cu(k,["children","$$slots","$$events","$$legacy"]),V=cu(H,["class","width","height","box","spin","inverse","pulse","flip","style","label"]),A=h(k,"class",8,""),J=h(k,"width",8),Z=h(k,"height",8),Y=h(k,"box",8,"0 0 0 0"),le=h(k,"spin",8,!1),Ae=h(k,"inverse",8,!1),ce=h(k,"pulse",8,!1),we=h(k,"flip",8,"none"),$e=h(k,"style",8,""),Ne=h(k,"label",8,""),ye=aR();_r(z(ye),k,"default",{},null),Ee(ze=>{var Re;return D=wu(ye,D,Se(Se({version:"1.1",class:"fa-icon ".concat((Re=A())!==null&&Re!==void 0?Re:""),width:J(),height:Z(),"aria-label":Ne(),role:Ne()?"img":"presentation",viewBox:Y(),style:$e()},V),{},{[Zi]:ze}),"svelte-1mc5hvj")},[()=>({"fa-spin":le(),"fa-pulse":ce(),"fa-inverse":Ae(),"fa-flip-horizontal":we()==="horizontal","fa-flip-vertical":we()==="vertical"})],de),I(R,ye)}(e,Xa({get label(){return f()},get width(){return o(m)},get height(){return o(b)},get box(){return o(w)},get style(){return o(j)},get spin(){return u()},get flip(){return v()},get inverse(){return d()},get pulse(){return c()},get class(){return a()}},()=>r,{children:(R,k)=>{var D=xr();_r(ft(D),t,"default",{},H=>{var V=lR(),A=ft(V);jr(A,1,()=>{var le;return((le=o(s))===null||le===void 0?void 0:le.paths)||[]},Cr,(le,Ae)=>{var ce,we=iR();Ee(()=>ce=wu(we,ce,Se({},o(Ae)))),I(le,we)});var J=F(A);jr(J,1,()=>{var le;return((le=o(s))===null||le===void 0?void 0:le.polygons)||[]},Cr,(le,Ae)=>{var ce,we=sR();Ee(()=>ce=wu(we,ce,Se({},o(Ae)))),I(le,we)});var Z=F(J),Y=le=>{oR(le,{get data(){return o(s)},set data(Ae){p(s,Ae)},$$legacy:!0})};re(Z,le=>{var Ae;(Ae=o(s))!==null&&Ae!==void 0&&Ae.raw&&le(Y)}),I(H,V)}),I(R,D)},$$slots:{default:!0}})),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-boolean-toggle.svelte-1ryp01u {
  padding: 0;
  margin: 1px 0 0;
  vertical-align: top;
  display: inline-flex;
  color: var(--jse-value-color-boolean, #ff8c00);
}

.jse-boolean-toggle.svelte-1ryp01u:not(.jse-readonly) {
  cursor: pointer;
}`);var uR=G('<div role="checkbox" tabindex="-1"><!></div>');function cR(e,t){lt(t,!1);var n=h(t,"path",9),r=h(t,"value",9),a=h(t,"readOnly",9),i=h(t,"onPatch",9),s=h(t,"focus",9);St(!0);var l,u=uR(),d=z(u),c=de(()=>r()===!0?qg:$g);dn(d,{get data(){return o(c)}}),Ee(v=>{Cn(u,"aria-checked",r()===!0),l=Mt(u,1,"jse-boolean-toggle svelte-1ryp01u",null,l,v),Cn(u,"title",a()?"Boolean value ".concat(r()):"Click to toggle this boolean value")},[()=>({"jse-readonly":a()})],de),be("mousedown",u,function(v){v.stopPropagation(),a()||(i()([{op:"replace",path:zt(n()),value:!r()}]),s()())}),I(e,u),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-color-picker-popup.svelte-s1wu8v .picker_wrapper.popup,
.jse-color-picker-popup.svelte-s1wu8v .picker_wrapper.popup .picker_arrow::before,
.jse-color-picker-popup.svelte-s1wu8v .picker_wrapper.popup .picker_arrow::after {
  background: var(--jse-color-picker-background, var(--jse-panel-background, #ebebeb));
  line-height: normal;
}
.jse-color-picker-popup.svelte-s1wu8v .picker_slider,
.jse-color-picker-popup.svelte-s1wu8v .picker_sl,
.jse-color-picker-popup.svelte-s1wu8v .picker_editor input,
.jse-color-picker-popup.svelte-s1wu8v .picker_sample,
.jse-color-picker-popup.svelte-s1wu8v .picker_done button {
  box-shadow: var(--jse-color-picker-border-box-shadow, #cbcbcb 0 0 0 1px);
}
.jse-color-picker-popup.svelte-s1wu8v .picker_editor input {
  background: var(--jse-background-color, #fff);
  color: var(--jse-text-color, #4d4d4d);
}
.jse-color-picker-popup.svelte-s1wu8v .picker_done button {
  background: var(--jse-button-background, #e0e0e0);
  color: var(--jse-button-color, var(--jse-text-color, #4d4d4d));
}
.jse-color-picker-popup.svelte-s1wu8v .picker_done button:hover {
  background: var(--jse-button-background-highlight, #e7e7e7);
}`);var dR=G('<div class="jse-color-picker-popup svelte-s1wu8v"></div>');function vR(e,t){lt(t,!1);var n=h(t,"color",8),r=h(t,"onChange",8),a=h(t,"showOnTop",8),i=P(),s=()=>{};Yr(Rt(function*(){var u,d=new((u=yield ek(()=>import("./vanilla-picker.B6E6ObS_.js"),[]))===null||u===void 0?void 0:u.default)({parent:o(i),color:n(),popup:a()?"top":"bottom",onDone(c){var v=c.rgba[3]===1?c.hex.substring(0,7):c.hex;r()(v)}});d.show(),s=()=>{d.destroy()}})),zo(()=>{s()}),St();var l=dR();tr(l,u=>p(i,u),()=>o(i)),I(e,l),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-color-picker-button.svelte-xeg9n6 {
  font-size: var(--jse-font-size-mono, 14px);
  width: var(--jse-color-picker-button-size, 1em);
  height: var(--jse-color-picker-button-size, 1em);
  box-sizing: border-box;
  padding: 0;
  margin: 2px 0 0 calc(0.5 * var(--jse-padding, 10px));
  display: inline-flex;
  vertical-align: top;
  border: 1px solid var(--jse-text-color, #4d4d4d);
  border-radius: 2px;
  background: inherit;
  outline: none;
}

.jse-color-picker-button.svelte-xeg9n6:not(.jse-readonly) {
  cursor: pointer;
}`);var fR=G('<button type="button"></button>');function pR(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),{openAbsolutePopup:a}=vi("absolute-popup"),i=h(t,"path",9),s=h(t,"value",9),l=h(t,"readOnly",9),u=h(t,"onPatch",9),d=h(t,"focus",9);function c(m){u()([{op:"replace",path:zt(i()),value:m}]),v()}function v(){d()()}W(()=>M(s()),()=>{p(n,Wy(s()))}),W(()=>(M(l()),M(s())),()=>{p(r,l()?"Color ".concat(s()):"Click to open a color picker")}),_n(),St(!0);var f,g=fR();Ee(m=>{var b;f=Mt(g,1,"jse-color-picker-button svelte-xeg9n6",null,f,m),Ho(g,"background: ".concat((b=o(n))!==null&&b!==void 0?b:"")),Cn(g,"title",o(r)),Cn(g,"aria-label",o(r))},[()=>({"jse-readonly":l()})],de),be("click",g,function(m){var b,j;if(!l()){var w=m.target,O=w.getBoundingClientRect().top,T=((b=(j=tu(w))===null||j===void 0?void 0:j.innerHeight)!==null&&b!==void 0?b:0)-O<300&&O>300,R={color:s(),onChange:c,showOnTop:T};a(vR,R,{anchor:w,closeOnOuterClick:!0,onClose:v,offsetTop:18,offsetLeft:-8,height:300})}}),I(e,g),ut()}var jd=1e3,Al=100,gv=2e4,ds=[{start:0,end:Al}],hR=1048576,Mh=10485760,yd="Insert or paste contents, enter [ insert a new array, enter { to insert a new object, or start typing to insert a new value",rp="Open context menu (Click here, right click on the selection, or use the context menu button or Ctrl+Q)",ul="hover-insert-inside",wd="hover-insert-after",zh="hover-collection",kd="valid",Ph="repairable",ya=336,wa=260,hl=100,Th={[Lo.asc]:"ascending",[Lo.desc]:"descending"};function iw(e){for(var t=Vv(e,l=>l.start),n=[t[0]],r=0;r<t.length;r++){var a=n.length-1,i=n[a],s=t[r];s.start<=i.end?n[a]={start:Math.min(i.start,s.start),end:Math.max(i.end,s.end)}:n.push(s)}return n}function mv(e){return Ju(e)+Al}function Ju(e){return Math.floor(e/Al)*Al}function sw(e){return!!e&&(e.type==="space"||e.space===!0)}function ku(e){return!!e&&(e.type==="separator"||e.separator===!0)}function gR(e){return!!e&&e.type==="label"&&typeof e.text=="string"}function vs(e){return!!e&&typeof e.onClick=="function"}function _d(e){return!!e&&e.type==="dropdown-button"&&vs(e.main)&&Array.isArray(e.items)}function mR(e){return!!e&&e.type==="row"&&Array.isArray(e.items)}function bR(e){return!!e&&e.type==="column"&&Array.isArray(e.items)}function Ih(e){return On(e)&&On(e.parseError)}function xR(e){return On(e)&&Array.isArray(e.validationErrors)}function jR(e){return On(e)&&Array.isArray(e.path)&&typeof e.message=="string"&&"severity"in e}function yR(e){return On(e)&&jR(e)&&typeof e.isChildError=="boolean"}function wR(e){return On(e)&&typeof e.action=="function"&&On(e.props)}function Jo(e){return e!==void 0&&e.type==="object"}function Kr(e){return e!==void 0&&e.type==="array"}function op(e){return e!==void 0&&e.type==="value"}function zi(e){return Jo(e)||Kr(e)}function Nh(e){return e!==void 0&&Array.isArray(e.searchResults)}function Gu(e){return!!e&&e.type==="tree"}function Lh(e){return!!e&&e.type==="text"}function Uh(e){return!!e&&e.type==="mode"}function bv(e){var{json:t,expand:n}=e,r=function(a){var{json:i,factory:s}=a;return Array.isArray(i)?s.createArrayDocumentState():On(i)?s.createObjectDocumentState():i!==void 0?s.createValueDocumentState():void 0}({json:t,factory:sp});return n&&r?Uo(t,r,[],n):r}function ap(){var{expanded:e}=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{expanded:!1};return{type:"array",expanded:e,visibleSections:ds,items:[]}}function ip(){var{expanded:e}=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{expanded:!1};return{type:"object",expanded:e,properties:{}}}var sp={createObjectDocumentState:ip,createArrayDocumentState:ap,createValueDocumentState:function(){return{type:"value"}}};function lw(e,t,n,r){var{createObjectDocumentState:a,createArrayDocumentState:i,createValueDocumentState:s}=r;return function l(u,d,c){if(Array.isArray(u)){var v=Kr(d)?d:i();if(c.length===0)return v;var f=Vr(c[0]),g=l(u[f],v.items[f],c.slice(1));return ra(v,["items",c[0]],g)}if(On(u)){var m=Jo(d)?d:a();if(c.length===0)return m;var b=c[0],j=l(u[b],m.properties[b],c.slice(1));return ra(m,["properties",b],j)}return op(d)?d:s()}(e,t,n)}function ho(e,t){return Rl(e,t,arguments.length>2&&arguments[2]!==void 0?arguments[2]:[],(n,r)=>{if(n!==void 0&&r!==void 0)return Array.isArray(n)?Kr(r)?r:ap({expanded:!!zi(r)&&r.expanded}):On(n)?Jo(r)?r:ip({expanded:!!zi(r)&&r.expanded}):op(r)?r:void 0},()=>!0)}function Rl(e,t,n,r,a){var i=r(e,t,n);if(Array.isArray(e)&&Kr(i)&&a(i)){var s=[];return lp(e,i.visibleSections,u=>{var d=n.concat(String(u)),c=Rl(e[u],i.items[u],d,r,a);c!==void 0&&(s[u]=c)}),Sh(s,i.items)?i:Se(Se({},i),{},{items:s})}if(On(e)&&Jo(i)&&a(i)){var l={};return Object.keys(e).forEach(u=>{var d=n.concat(u),c=Rl(e[u],i.properties[u],d,r,a);c!==void 0&&(l[u]=c)}),Sh(Object.values(l),Object.values(i.properties))?i:Se(Se({},i),{},{properties:l})}return i}function lp(e,t,n){t.forEach(r=>{var{start:a,end:i}=r;Hy(a,Math.min(e.length,i),n)})}function Ml(e,t){for(var n=e,r=[],a=0;a<t.length;){if(Array.isArray(n)){var i=t[a];r.push("items",i),n=n[Vr(i)]}else{if(!On(n))throw new Error("Cannot convert path: Object or Array expected at index ".concat(a));var s=t[a];r.push("properties",s),n=n[s]}a++}return r}function Uo(e,t,n,r){for(var a=t,i=function(l){var u=n.slice(0,l);a=ws(e,a,u,(d,c)=>{var v=zi(c)&&!c.expanded?Se(Se({},c),{},{expanded:!0}):c;return Kr(v)?function(f,g){if(function(j,w){return j.some(O=>w>=O.start&&w<O.end)}(f.visibleSections,g))return f;var m=Ju(g),b={start:m,end:mv(m)};return Se(Se({},f),{},{visibleSections:iw(f.visibleSections.concat(b))})}(v,Vr(n[l])):v})},s=0;s<n.length;s++)i(s);return ws(e,a,n,(l,u)=>function(d,c,v,f){return Rl(d,c,v,(g,m,b)=>Array.isArray(g)&&f(b)?Kr(m)?m.expanded?m:Se(Se({},m),{},{expanded:!0}):ap({expanded:!0}):On(g)&&f(b)?Jo(m)?m.expanded?m:Se(Se({},m),{},{expanded:!0}):ip({expanded:!0}):m,g=>zi(g)&&g.expanded)}(l,u,[],r))}function Dh(e,t,n,r){return ws(e,t,n,(a,i)=>r?function(s,l,u){return Rl(s,l,u,(d,c)=>qh(c),()=>!0)}(a,i,n):qh(i))}function qh(e){return Kr(e)&&e.expanded?Se(Se({},e),{},{expanded:!1,visibleSections:ds}):Jo(e)&&e.expanded?Se(Se({},e),{},{expanded:!1}):e}function uw(e,t,n){var r={json:e,documentState:t},a=n.reduce((i,s)=>({json:$o(i.json,[s]),documentState:kR(i.json,i.documentState,s)}),r);return{json:a.json,documentState:ho(a.json,a.documentState)}}function kR(e,t,n){if(Nv(n))return $h(e,t,n,void 0);if(Lv(n))return Fh(e,t,n);if(ic(n)){var r=Bo(e,n.path),a=Oa(e,t,r);return a?Hc(e,t,r,{type:"value",enforceString:a}):t}return Cu(n)||xi(n)?function(i,s,l){if(xi(l)&&l.from===l.path)return s;var u=s,d=Bo(i,l.from),c=yi(i,u,d);return xi(l)&&(u=Fh(i,u,{path:l.from})),u=$h(i,u,{path:l.path},c),u}(e,t,n):t}function yi(e,t,n){try{return Ke(t,Ml(e,n))}catch{return}}function up(e,t,n,r,a){var i=lw(e,t,n,a);return xg(i,Ml(e,n),s=>{var l=Ke(e,n);return r(l,s)})}function Hc(e,t,n,r){return function(a,i,s,l,u){var d=lw(a,i,s,u);return ra(d,Ml(a,s),l)}(e,t,n,r,sp)}function ws(e,t,n,r){return up(e,t,n,r,sp)}function $h(e,t,n,r){var a=Bo(e,n.path),i=t;return i=ws(e,i,sn(a),(s,l)=>{if(!Kr(l))return l;var u=Vr(ht(a)),{items:d,visibleSections:c}=l;return Se(Se({},l),{},{items:u<d.length?qA(d,u,r!==void 0?[r]:Array(1)):d,visibleSections:cw(c,u,1)})}),Hc(e,i,a,r)}function Fh(e,t,n){var r=Bo(e,n.path),a=sn(r),i=Ke(e,a);return Array.isArray(i)?ws(e,t,a,(s,l)=>{if(!Kr(l))return l;var u=Vr(ht(r)),{items:d,visibleSections:c}=l;return Se(Se({},l),{},{items:d.slice(0,u).concat(d.slice(u+1)),visibleSections:cw(c,u,-1)})}):function(s,l,u){var d=Ml(s,u);return ja(l,d)?bg(l,Ml(s,u)):l}(e,t,r)}function cw(e,t,n){return function(r){for(var a=r.slice(0),i=1;i<a.length;)a[i-1].end===a[i].start&&(a[i-1]={start:a[i-1].start,end:a[i].end},a.splice(i)),i++;return a}(e.map(r=>({start:r.start>t?r.start+n:r.start,end:r.end>t?r.end+n:r.end})))}function Oa(e,t,n){var r,a=Ke(e,n),i=yi(e,t,n),s=op(i)?i.enforceString:void 0;return typeof s=="boolean"?s:typeof(r=a)=="string"&&typeof Js(r,JSON)!="string"}function ru(e,t){var n=arguments.length>2&&arguments[2]!==void 0&&arguments[2],r=e.indexOf(t);return r!==-1?n?e.slice(r):e.slice(r+1):[]}function cp(e,t){var n=[];return function r(a,i,s){n.push(s),zr(a)&&Kr(i)&&i.expanded&&lp(a,i.visibleSections,l=>{r(a[l],i.items[l],s.concat(String(l)))}),$r(a)&&Jo(i)&&i.expanded&&Object.keys(a).forEach(l=>{r(a[l],i.properties[l],s.concat(l))})}(e,t,[]),n}function dw(e,t){var n=!(arguments.length>2&&arguments[2]!==void 0)||arguments[2],r=[];return function a(i,s){r.push({path:s,type:Do.value});var l=yi(e,t,s);if(i&&zi(l)&&l.expanded){if(n&&r.push({path:s,type:Do.inside}),zr(i)){var u=Kr(l)?l.visibleSections:ds;lp(i,u,d=>{var c=s.concat(String(d));a(i[d],c),n&&r.push({path:c,type:Do.after})})}$r(i)&&Object.keys(i).forEach(d=>{var c=s.concat(d);r.push({path:c,type:Do.key}),a(i[d],c),n&&r.push({path:c,type:Do.after})})}}(e,[]),r}function Sd(e,t,n){var r=cp(e,t),a=r.map(zt).indexOf(zt(n));if(a!==-1&&a<r.length-1)return r[a+1]}function Pi(e,t,n){var r=arguments.length>3&&arguments[3]!==void 0?arguments[3]:10240;return Uo(e,t,n,$A({json:Ke(e,n)},r)?gl:dp)}function Cd(e,t,n){var r=yi(e,t,n);return zi(r)&&r.expanded?t:Pi(e,t,n)}function gl(e){return e.length===0||e.length===1&&e[0]==="0"}function Bh(e){return e.length===0}function dp(){return!0}function _u(){return!1}function Oo(e){return e&&e.type===$n.after||!1}function Gr(e){return e&&e.type===$n.inside||!1}function Dr(e){return e&&e.type===$n.key||!1}function zn(e){return e&&e.type===$n.value||!1}function ur(e){return e&&e.type===$n.multi||!1}function Vc(e){return ur(e)&&Zt(e.focusPath,e.anchorPath)}function zl(e){return ur(e)||Oo(e)||Gr(e)||Dr(e)||zn(e)}function Od(e){return e&&e.type===$n.text||!1}function ii(e,t){var n=[];return function(r,a,i){if(a){var s=wi(a),l=Qe(a);if(Zt(s,l))return i(s);if(r!==void 0){var u=fw(s,l);if(s.length===u.length||l.length===u.length)return i(u);var d=Qr(s,l),c=ka(r,d),v=Za(r,d),f=Aa(r,d,c),g=Aa(r,d,v);if(!(f===-1||g===-1)){var m=Ke(r,u);if($r(m)){for(var b=Object.keys(m),j=f;j<=g;j++){var w=i(u.concat(b[j]));if(w!==void 0)return w}return}if(zr(m)){for(var O=f;O<=g;O++){var T=i(u.concat(String(O)));if(T!==void 0)return T}return}throw new Error("Failed to create selection")}}}}(e,t,r=>{n.push(r)}),n}function vw(e){return Gr(e)?e.path:sn(Qe(e))}function ka(e,t){if(!ur(t))return t.path;var n=Aa(e,t,t.anchorPath);return Aa(e,t,t.focusPath)<n?t.focusPath:t.anchorPath}function Za(e,t){if(!ur(t))return t.path;var n=Aa(e,t,t.anchorPath);return Aa(e,t,t.focusPath)>n?t.focusPath:t.anchorPath}function Wh(e,t,n){var r=arguments.length>3&&arguments[3]!==void 0&&arguments[3];if(n){var a=r?Qe(n):ka(e,n),i=function(u,d,c){var v=cp(u,d),f=v.map(zt),g=zt(c),m=f.indexOf(g);if(m!==-1&&m>0)return v[m-1]}(e,t,a);if(r)return Gr(n)||Oo(n)?i!==void 0?Qr(a,a):void 0:i!==void 0?Qr(wi(n),i):void 0;if(Oo(n)||Gr(n))return rn(a);if(Dr(n)){if(i===void 0||i.length===0)return;var s=sn(i),l=Ke(e,s);return Array.isArray(l)||Pn(i)?rn(i):Ia(i)}return zn(n),i!==void 0?rn(i):void 0}}function Hh(e,t,n,r){if(!n)return{caret:void 0,previous:void 0,next:void 0};var a=dw(e,t,r),i=a.findIndex(s=>Zt(s.path,Qe(n))&&String(s.type)===String(n.type));return{caret:i!==-1?a[i]:void 0,previous:i!==-1&&i>0?a[i-1]:void 0,next:i!==-1&&i<a.length-1?a[i+1]:void 0}}function Gi(e,t){for(var n=cp(e,t),r=0;r<n.length-1&&n[r+1].length>n[r].length;)r++;var a=n[r];return a===void 0||a.length===0||Array.isArray(Ke(e,sn(a)))?rn(a):Ia(a)}function ks(e,t){if(t.length===1){var n=Eo(t);if(n.op==="replace")return rn(Bo(e,n.path))}if(!Pn(t)&&t.every(s=>s.op==="move")){var r=Eo(t),a=t.slice(1);if((Cu(r)||xi(r))&&r.from!==r.path&&a.every(s=>(Cu(s)||xi(s))&&s.from===s.path))return Ia(Bo(e,r.path))}var i=t.filter(s=>s.op!=="test"&&s.op!=="remove"&&(s.op!=="move"||s.from!==s.path)&&typeof s.path=="string").map(s=>Bo(e,s.path));if(!Pn(i))return{type:$n.multi,anchorPath:Eo(i),focusPath:ht(i)}}function fw(e,t){for(var n=0;n<e.length&&n<t.length&&e[n]===t[n];)n++;return e.slice(0,n)}function Ku(e){return Dr(e)||zn(e)||Vc(e)}function Vh(e,t){return Ku(t)&&Ar(Ke(e,Qe(t)))?Qe(t):sn(Qe(t))}function Ta(e,t){if(e.length<t.length)return!1;for(var n=0;n<t.length;n++)if(e[n]!==t[n])return!1;return!0}function aa(e){if(vo(e)){var{type:t,path:n}=e;return{type:t,path:n}}return e}function Ia(e){return{type:$n.key,path:e}}function vp(e,t){return{type:$n.key,path:e,edit:!0,initialValue:t}}function rn(e){return{type:$n.value,path:e}}function Yu(e,t){return{type:$n.value,path:e,edit:!0,initialValue:t}}function Na(e){return{type:$n.inside,path:e}}function Ea(e){return{type:$n.after,path:e}}function Qr(e,t){var n=fw(e,t),r=e.length>n.length&&t.length>n.length;return{type:$n.multi,anchorPath:r?n.concat(e[n.length]):n,focusPath:r?n.concat(t[n.length]):n}}function pw(e,t,n,r){if(Dr(t))return String(ht(t.path));if(zn(t)){var a=Ke(e,t.path);return typeof a=="string"?a:r.stringify(a,null,n)}if(ur(t)){if(Pn(t.focusPath))return r.stringify(e,null,n);var i=vw(t),s=Ke(e,i);if(Array.isArray(s)){if(Vc(t)){var l=Ke(e,t.focusPath);return r.stringify(l,null,n)}return ii(e,t).map(u=>{var d=Ke(e,u);return"".concat(r.stringify(d,null,n),",")}).join(`
`)}return ii(e,t).map(u=>{var d=ht(u),c=Ke(e,u);return"".concat(r.stringify(d),": ").concat(r.stringify(c,null,n),",")}).join(`
`)}}function vo(e){return(Dr(e)||zn(e))&&e.edit===!0}function as(e){return Dr(e)||zn(e)||ur(e)}function fu(e){return Dr(e)||zn(e)||Vc(e)}function xv(e){switch(e.type){case Do.key:return Ia(e.path);case Do.value:return rn(e.path);case Do.after:return Ea(e.path);case Do.inside:return Na(e.path)}}function Jh(e,t){switch(e){case $n.key:return Ia(t);case $n.value:return rn(t);case $n.after:return Ea(t);case $n.inside:return Na(t);case $n.multi:case $n.text:return Qr(t,t)}}function Gh(e,t,n){if(t)return Pl(e,t,n)||Ta(ur(t)?sn(t.focusPath):t.path,n)?t:void 0}function Pl(e,t,n){if(e===void 0||!t)return!1;if(Dr(t)||Gr(t)||Oo(t))return Zt(t.path,n);if(zn(t))return Ta(n,t.path);if(ur(t)){var r=ka(e,t),a=Za(e,t),i=sn(t.focusPath);if(!Ta(n,i)||n.length<=i.length)return!1;var s=Aa(e,t,r),l=Aa(e,t,a),u=Aa(e,t,n);return u!==-1&&u>=s&&u<=l}return!1}function Aa(e,t,n){var r=sn(t.focusPath);if(!Ta(n,r)||n.length<=r.length)return-1;var a=n[r.length],i=Ke(e,r);if($r(i))return Object.keys(i).indexOf(a);if(zr(i)){var s=Vr(a);if(s<i.length)return s}return-1}function Qe(e){return ur(e)?e.focusPath:e.path}function wi(e){return ur(e)?e.anchorPath:e.path}function Ks(){for(var e=[],t=arguments.length,n=new Array(t),r=0;r<t;r++)n[r]=arguments[r];for(var a of n)if(typeof a=="string"&&e.push(a),a&&typeof a=="object")for(var i in a)Object.hasOwnProperty.call(a,i)&&a[i]&&e.push(i);return e.join(" ")}function fp(e,t,n){return Ks("jse-value","jse-"+Xf(e,n),{"jse-url":$c(e),"jse-empty":typeof e=="string"&&e.length===0,"jse-table-cell":t===Lr.table})}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-value.jse-string.svelte-f9kmxj {
  color: var(--jse-value-color-string, #008000);
}
.jse-value.jse-object.svelte-f9kmxj, .jse-value.jse-array.svelte-f9kmxj {
  min-width: 16px;
  color: var(--jse-delimiter-color, rgba(0, 0, 0, 0.38));
}
.jse-value.jse-number.svelte-f9kmxj {
  color: var(--jse-value-color-number, #ee422e);
}
.jse-value.jse-boolean.svelte-f9kmxj {
  color: var(--jse-value-color-boolean, #ff8c00);
}
.jse-value.jse-null.svelte-f9kmxj {
  color: var(--jse-value-color-null, #004ed0);
}
.jse-value.jse-invalid.svelte-f9kmxj {
  color: var(--jse-text-color, #4d4d4d);
}
.jse-value.jse-url.svelte-f9kmxj {
  color: var(--jse-value-color-url, #008000);
  text-decoration: underline;
}

div.jse-editable-div.svelte-f9kmxj {
  min-width: 2em;
  padding: 0 5px;
  box-sizing: border-box;
  outline: none;
  border-radius: 1px;
  vertical-align: top;
  cursor: text !important;
  word-break: normal;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
div.jse-editable-div.jse-short-text.svelte-f9kmxj {
  overflow-wrap: normal;
}
div.jse-editable-div.jse-table-cell.svelte-f9kmxj {
  overflow-wrap: normal;
  white-space: nowrap;
}
div.jse-editable-div[contenteditable=true].svelte-f9kmxj {
  outline: var(--jse-edit-outline, 2px solid #656565);
  background: var(--jse-background-color, #fff);
  position: relative;
  display: inline-block;
  border-radius: 0;
  z-index: 3;
}
div.jse-editable-div.jse-empty.svelte-f9kmxj:not(:focus) {
  outline: 1px dotted var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  -moz-outline-radius: 2px;
}
div.jse-editable-div.jse-empty.svelte-f9kmxj::after {
  pointer-events: none;
  color: var(--jse-tag-background, rgba(0, 0, 0, 0.2));
}`);var _R=G('<div role="textbox" tabindex="0" contenteditable="true" spellcheck="false"></div>');function hw(e,t){lt(t,!1);var n=Fr("jsoneditor:EditableDiv"),r=h(t,"value",9),a=h(t,"initialValue",9),i=h(t,"shortText",9,!1),s=h(t,"label",9),l=h(t,"onChange",9),u=h(t,"onCancel",9),d=h(t,"onFind",9),c=h(t,"onPaste",9,br),v=h(t,"onValueClass",9,()=>""),f=P(void 0,!0),g=P(void 0,!0),m=!1;function b(){return o(f)?function(O){return O.replace(/\n$/,"")}(o(f).innerText):""}function j(O){o(f)&&go(f,o(f).innerText=Bc(O))}Yr(()=>{n("onMount",{value:r(),initialValue:a()}),j(a()!==void 0?a():r()),o(f)&&function(O){if(O.firstChild!=null){var T=document.createRange(),R=window.getSelection();T.setStart(O,1),T.collapse(!0),R?.removeAllRanges(),R?.addRange(T)}else O.focus()}(o(f))}),zo(()=>{var O=b();n("onDestroy",{closed:m,value:r(),newValue:O}),m||O===r()||l()(O,Qa.no)}),W(()=>(M(v()),M(r())),()=>{p(g,v()(r()))}),_n(),St(!0);var w=_R();tr(w,O=>p(f,O),()=>o(f)),Ee(O=>{Cn(w,"aria-label",s()),Mt(w,1,O,"svelte-f9kmxj")},[()=>ai(Ks("jse-editable-div",o(g),{"jse-short-text":i()}))],de),be("input",w,function(){var O=b();O===""&&j(""),p(g,v()(O))}),be("keydown",w,function(O){O.stopPropagation();var T=Pa(O);if(T==="Escape"&&(O.preventDefault(),m=!0,u()()),T==="Enter"||T==="Tab"){O.preventDefault(),m=!0;var R=b();l()(R,Qa.nextInside)}T==="Ctrl+F"&&(O.preventDefault(),d()(!1)),T==="Ctrl+H"&&(O.preventDefault(),d()(!0))}),be("paste",w,function(O){if(O.stopPropagation(),c()&&O.clipboardData){var T=O.clipboardData.getData("text/plain");c()(T)}}),be("blur",w,function(){var O=document.hasFocus(),T=b();n("handleBlur",{hasFocus:O,closed:m,value:r(),newValue:T}),document.hasFocus()&&!m&&(m=!0,T!==r()&&l()(T,Qa.self))}),I(e,w),ut()}function SR(e,t){lt(t,!1);var n=h(t,"path",9),r=h(t,"value",9),a=h(t,"selection",9),i=h(t,"mode",9),s=h(t,"parser",9),l=h(t,"normalization",9),u=h(t,"enforceString",9),d=h(t,"onPatch",9),c=h(t,"onPasteJson",9),v=h(t,"onSelect",9),f=h(t,"onFind",9),g=h(t,"focus",9),m=h(t,"findNextInside",9);function b(T){return u()?T:Js(T,s())}function j(){v()(rn(n())),g()()}St(!0);var w=de(()=>l().escapeValue(r())),O=de(()=>vo(a())?a().initialValue:void 0);hw(e,{get value(){return o(w)},get initialValue(){return o(O)},label:"Edit value",onChange:function(T,R){d()([{op:"replace",path:zt(n()),value:b(l().unescapeValue(T))}],(k,D,H)=>{if(!H||Zt(n(),Qe(H)))return{state:D,selection:R===Qa.nextInside?m()(n()):rn(n())}}),g()()},onCancel:j,onPaste:function(T){try{var R=s().parse(T);Ar(R)&&c()({path:n(),contents:R,onPasteAsJson:()=>{j();var k=[{op:"replace",path:zt(n()),value:R}];d()(k,(D,H)=>({state:Pi(D,H,n())}))}})}catch{}},get onFind(){return f()},onValueClass:function(T){return fp(b(l().unescapeValue(T)),i(),s())}}),ut()}function is(e,t,n){var r=sn(t),a=Ke(e,r);if(zr(a)){var i=Vr(ht(t));return n.map((d,c)=>({op:"add",path:zt(r.concat(String(i+c))),value:d.value}))}if($r(a)){var s=ht(t),l=Object.keys(a),u=s!==void 0?ru(l,s,!0):[];return[...n.map(d=>{var c=nu(d.key,l);return{op:"add",path:zt(r.concat(c)),value:d.value}}),...u.map(d=>Ti(r,d))]}throw new Error("Cannot create insert operations: parent must be an Object or Array")}function jv(e,t,n){var r=Ke(e,t);if(Array.isArray(r)){var a=r.length;return n.map((i,s)=>({op:"add",path:zt(t.concat(String(a+s))),value:i.value}))}return n.map(i=>{var s=nu(i.key,Object.keys(r));return{op:"add",path:zt(t.concat(s)),value:i.value}})}function ou(e,t,n,r){var a=nu(r,t.filter(s=>s!==n)),i=ru(t,n,!1);return[{op:"move",from:zt(e.concat(n)),path:zt(e.concat(a))},...i.map(s=>Ti(e,s))]}function gw(e,t){var n=ht(t);if(Pn(n))throw new Error("Cannot duplicate root object");var r=sn(n),a=ht(n),i=Ke(e,r);if(zr(i)){var s=ht(t),l=s?Vr(ht(s))+1:0;return[...t.map((c,v)=>({op:"copy",from:zt(c),path:zt(r.concat(String(v+l)))}))]}if($r(i)){var u=Object.keys(i),d=a!==void 0?ru(u,a,!1):[];return[...t.map(c=>{var v=nu(ht(c),u);return{op:"copy",from:zt(c),path:zt(r.concat(v))}}),...d.map(c=>Ti(r,c))]}throw new Error("Cannot create duplicate operations: parent must be an Object or Array")}function mw(e,t){if(zn(t))return[{op:"move",from:zt(t.path),path:""}];if(!ur(t))throw new Error("Cannot create extract operations: parent must be an Object or Array");var n=sn(t.focusPath),r=Ke(e,n);if(zr(r)){var a=ii(e,t).map(s=>{var l=Vr(ht(s));return r[l]});return[{op:"replace",path:"",value:a}]}if($r(r)){var i={};return ii(e,t).forEach(s=>{var l=String(ht(s));i[l]=r[l]}),[{op:"replace",path:"",value:i}]}throw new Error("Cannot extract: unsupported type of selection "+JSON.stringify(t))}function bw(e,t,n,r){if(Dr(t)){var a=Jy(n,r),i=sn(t.path),s=Ke(e,i);return ou(i,Object.keys(s),ht(t.path),typeof a=="string"?a:n)}if(zn(t)||ur(t)&&Pn(t.focusPath))try{return[{op:"replace",path:zt(Qe(t)),value:Fc(n,D=>eu(D,r))}]}catch{return[{op:"replace",path:zt(Qe(t)),value:n}]}if(ur(t)){var l=Ed(n,r);return function(D,H,V){var A=Eo(H),J=sn(A),Z=Ke(D,J);if(zr(Z)){var Y=Eo(H),le=Y?Vr(ht(Y)):0;return[...Xu(H),...V.map((Re,We)=>({op:"add",path:zt(J.concat(String(We+le))),value:Re.value}))]}if($r(Z)){var Ae=ht(H),ce=sn(Ae),we=ht(Ae),$e=Object.keys(Z),Ne=we!==void 0?ru($e,we,!1):[],ye=new Set(H.map(Re=>ht(Re))),ze=$e.filter(Re=>!ye.has(Re));return[...Xu(H),...V.map(Re=>{var We=nu(Re.key,ze);return{op:"add",path:zt(ce.concat(We)),value:Re.value}}),...Ne.map(Re=>Ti(ce,Re))]}throw new Error("Cannot create replace operations: parent must be an Object or Array")}(e,ii(e,t),l)}if(Oo(t)){var u=Ed(n,r),d=t.path,c=sn(d),v=Ke(e,c);if(zr(v)){var f=Vr(ht(d));return is(e,c.concat(String(f+1)),u)}if($r(v)){var g=String(ht(d)),m=Object.keys(v);if(Pn(m)||ht(m)===g)return jv(e,c,u);var b=m.indexOf(g),j=m[b+1];return is(e,c.concat(j),u)}throw new Error("Cannot create insert operations: parent must be an Object or Array")}if(Gr(t)){var w=Ed(n,r),O=t.path,T=Ke(e,O);if(zr(T))return is(e,O.concat("0"),w);if($r(T)){var R=Object.keys(T);if(Pn(R))return jv(e,O,w);var k=Eo(R);return is(e,O.concat(k),w)}throw new Error("Cannot create insert operations: parent must be an Object or Array")}throw new Error("Cannot insert: unsupported type of selection "+JSON.stringify(t))}function Xu(e){return e.map(t=>({op:"remove",path:zt(t)})).reverse()}function Ti(e,t){return{op:"move",from:zt(e.concat(t)),path:zt(e.concat(t))}}function Ed(e,t){var n=/^\s*{/.test(e),r=/^\s*\[/.test(e),a=Jy(e,t),i=a!==void 0?a:Fc(e,s=>eu(s,t));return n&&On(i)||r&&Array.isArray(i)?[{key:"New item",value:i}]:Array.isArray(i)?i.map((s,l)=>({key:"New item "+l,value:s})):On(i)?Object.keys(i).map(s=>({key:s,value:i[s]})):[{key:"New item",value:i}]}function xw(e,t){if(Dr(t)){var n=sn(t.path),r=Ke(e,n),a=ou(n,Object.keys(r),ht(t.path),"");return{operations:a,newSelection:ks(e,a)}}if(zn(t))return{operations:[{op:"replace",path:zt(t.path),value:""}],newSelection:t};if(ur(t)){var i=ii(e,t),s=Xu(i),l=ht(i);if(Pn(l))return{operations:[{op:"replace",path:"",value:""}],newSelection:rn([])};var u=sn(l),d=Ke(e,u);if(zr(d)){var c=Eo(i),v=Vr(ht(c));return{operations:s,newSelection:v===0?Na(u):Ea(u.concat(String(v-1)))}}if($r(d)){var f=Object.keys(d),g=Eo(i),m=ht(g),b=f.indexOf(m),j=f[b-1];return{operations:s,newSelection:b===0?Na(u):Ea(u.concat(j))}}throw new Error("Cannot create remove operations: parent must be an Object or Array")}throw new Error("Cannot remove: unsupported type of selection "+JSON.stringify(t))}function jw(e,t){return function(n){var r=arguments.length>1&&arguments[1]!==void 0?arguments[1]:Zt;return n.filter((a,i)=>{for(var s=i+1;s<n.length;s++)if(r(a,n[s]))return!1;return!0})}(Uv(e,t,{before:(n,r,a)=>{if(Lv(r)){var i=Fo(r.path);return{revertOperations:[...a,...Ad(n,i)]}}if(xi(r)){var s=Fo(r.from);return{revertOperations:r.from===r.path?[r,...Ad(n,s)]:[...a,...Ad(n,s)]}}return{document:n}}}))}function Ad(e,t){var n=sn(t),r=ht(t),a=Ke(e,n);return $r(a)?ru(Object.keys(a),r,!1).map(i=>Ti(n,i)):[]}function Kh(e){var t=e.activeIndex<e.items.length-1?e.activeIndex+1:e.items.length>0?0:-1,n=e.items[t],r=e.items.map((a,i)=>Se(Se({},a),{},{active:i===t}));return Se(Se({},e),{},{items:r,activeItem:n,activeIndex:t})}function Yh(e,t){var n,r=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},a=e.toLowerCase(),i=(n=r?.maxResults)!==null&&n!==void 0?n:1/0,s=r?.columns,l=[],u=[];function d(j){l.length>=i||l.push(j)}function c(j,w){if(zr(w)){var O=u.length;u.push("0");for(var T=0;T<w.length;T++)if(u[O]=String(T),c(j,w[T]),l.length>=i)return;u.pop()}else if($r(w)){var R=Object.keys(w),k=u.length;for(var D of(u.push(""),R))if(u[k]=D,Xh(D,j,u,Vo.key,d),c(j,w[D]),l.length>=i)return;u.pop()}else Xh(String(w),j,u,Vo.value,d)}if(e==="")return[];if(s){if(!Array.isArray(t))throw new Error("json must be an Array when option columns is defined");for(var v=0;v<t.length;v++){u[0]=String(v);for(var f=t[v],g=0;g<s.length;g++){var m=s[g];if(m.length===1)u[1]=m[0];else for(var b=0;b<m.length;b++)u[b+1]=m[b];for(;u.length>m.length+1;)u.pop();c(a,Ke(f,m))}if(l.length>=i)break}return l}return c(a,t),l}function Xh(e,t,n,r,a){var i=e.toLowerCase(),s=0,l=-1,u=-1;do(u=i.indexOf(t,l))!==-1&&(l=u+t.length,a({path:n.slice(0),field:r,fieldIndex:s,start:u,end:l}),s++);while(u!==-1)}function yv(e,t,n,r){return e.substring(0,n)+t+e.substring(r)}function Qh(e,t,n){var r=e;return Ou(n,a=>{r=yv(r,t,a.start,a.end)}),r}function CR(e,t,n,r,a){var{field:i,path:s,start:l,end:u}=r;if(i===Vo.key){var d=sn(s),c=Ke(e,d),v=ht(s),f=ou(d,Object.keys(c),v,yv(v,n,l,u));return{newSelection:ks(e,f),operations:f}}if(i===Vo.value){var g=Ke(e,s);if(g===void 0)throw new Error("Cannot replace: path not found ".concat(zt(s)));var m=typeof g=="string"?g:String(g),b=Oa(e,t,s),j=yv(m,n,l,u),w=[{op:"replace",path:zt(s),value:b?j:Js(j,a)}];return{newSelection:ks(e,w),operations:w}}throw new Error("Cannot replace: unknown type of search result field ".concat(i))}function Zh(e){return e.path.concat(e.field,String(e.fieldIndex))}var OR={createObjectDocumentState:()=>({type:"object",properties:{}}),createArrayDocumentState:()=>({type:"array",items:[]}),createValueDocumentState:()=>({type:"value"})};function yw(e,t){return t.reduce((n,r)=>function(a,i,s,l){return up(a,i,s,l,OR)}(e,n,r.path,(a,i)=>Se(Se({},i),{},{searchResults:i.searchResults?i.searchResults.concat(r):[r]})),void 0)}function wv(e){var t,n=(t=e?.searchResults)!==null&&t!==void 0?t:[],r=Jo(e)?Object.values(e.properties).flatMap(wv):Kr(e)?e.items.flatMap(wv):[];return n.concat(r)}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-highlight.svelte-5fb7bl {
  background-color: var(--jse-search-match-color, #ffe665);
  outline: var(--jse-search-match-outline, none);
}
.jse-highlight.jse-active.svelte-5fb7bl {
  background-color: var(--jse-search-match-active-color, var(--jse-search-match-color, #ffe665));
  outline: var(--jse-search-match-outline, 2px solid #e0be00);
}`);var ER=G("<span> </span>");function ww(e,t){lt(t,!1);var n=P(),r=h(t,"text",8),a=h(t,"searchResultItems",8);W(()=>(M(r()),M(a())),()=>{p(n,function(s,l){var u=[],d=0;for(var c of l){var v=s.slice(d,c.start);v!==""&&u.push({resultIndex:void 0,type:"normal",text:v,active:!1});var f=s.slice(c.start,c.end);u.push({resultIndex:c.resultIndex,type:"highlight",text:f,active:c.active}),d=c.end}var g=ht(l);return g&&g.end<s.length&&u.push({type:"normal",text:s.slice(g.end),resultIndex:void 0,active:!1}),u}(String(r()),a()))}),_n(),St();var i=xr();jr(ft(i),1,()=>o(n),Cr,(s,l)=>{var u=xr(),d=ft(u),c=f=>{var g=Br();Ee(()=>pt(g,o(l).text)),I(f,g)},v=f=>{var g,m=ER(),b=z(m);Ee((j,w,O)=>{g=Mt(m,1,"jse-highlight svelte-5fb7bl",null,g,j),Cn(m,"data-search-result-index",w),pt(b,O)},[()=>({"jse-active":o(l).active}),()=>String(o(l).resultIndex),()=>Bc(o(l).text)],de),I(f,m)};re(d,f=>{o(l).type==="normal"?f(c):f(v,!1)}),I(s,u)}),I(e,i),ut()}function kv(e){var t=1e3;if(e<900)return e.toFixed()+" B";var n=e/t;if(n<900)return n.toFixed(1)+" KB";var r=n/t;if(r<900)return r.toFixed(1)+" MB";var a=r/t;return a<900?a.toFixed(1)+" GB":(a/t).toFixed(1)+" TB"}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-tag.svelte-tqwlgz {
  border: none;
  font-size: 80%;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  color: var(--jse-tag-color, var(--jse-text-color-inverse, #fff));
  background: var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  border-radius: 2px;
  cursor: pointer;
  display: inline-block;
  padding: 0 4px;
  line-height: normal;
  margin: 1px 0;
}
.jse-tag.svelte-tqwlgz:hover {
  opacity: 0.8;
}
.jse-tag.svelte-tqwlgz:disabled {
  opacity: 0.7;
  cursor: inherit;
}`);var AR=G('<button type="button" class="jse-tag svelte-tqwlgz"><!></button>');function Su(e,t){lt(t,!0);var n=co(()=>t.onclick?a=>{a.preventDefault(),a.stopPropagation(),t.onclick()}:void 0),r=AR();r.__click=function(){for(var a,i=arguments.length,s=new Array(i),l=0;l<i;l++)s[l]=arguments[l];(a=o(n))===null||a===void 0||a.apply(this,s)},function(a,i){for(var s=arguments.length,l=new Array(s>2?s-2:0),u=2;u<s;u++)l[u-2]=arguments[u];var d,c=a,v=lh;$i(()=>{v!==(v=i())&&(d&&(va(d),d=null),d=za(()=>v(c,...l)))},Kl)}(z(r),()=>{var a;return(a=t.children)!==null&&a!==void 0?a:lh}),Ee(()=>r.disabled=!t.onclick),I(e,r),ut()}Zl(["click"]);function RR(e,t,n){typeof t.value=="string"&&o(n)&&np(e)&&(e.preventDefault(),e.stopPropagation(),window.open(t.value,"_blank"))}function MR(e,t){t.readOnly||(e.preventDefault(),t.onSelect(Yu(t.path)))}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-value.jse-string.svelte-c0g9qz {
  color: var(--jse-value-color-string, #008000);
}
.jse-value.jse-object.svelte-c0g9qz, .jse-value.jse-array.svelte-c0g9qz {
  min-width: 16px;
  color: var(--jse-delimiter-color, rgba(0, 0, 0, 0.38));
}
.jse-value.jse-number.svelte-c0g9qz {
  color: var(--jse-value-color-number, #ee422e);
}
.jse-value.jse-boolean.svelte-c0g9qz {
  color: var(--jse-value-color-boolean, #ff8c00);
}
.jse-value.jse-null.svelte-c0g9qz {
  color: var(--jse-value-color-null, #004ed0);
}
.jse-value.jse-invalid.svelte-c0g9qz {
  color: var(--jse-text-color, #4d4d4d);
}
.jse-value.jse-url.svelte-c0g9qz {
  color: var(--jse-value-color-url, #008000);
  text-decoration: underline;
}

.jse-value.svelte-c0g9qz {
  display: inline-block;
  min-width: 2em;
  padding: 0 5px;
  box-sizing: border-box;
  outline: none;
  border-radius: 1px;
  vertical-align: top;
  word-break: normal;
  overflow-wrap: anywhere;
  white-space: pre-wrap;
}
.jse-value.jse-table-cell.svelte-c0g9qz {
  overflow-wrap: normal;
  white-space: nowrap;
}
.jse-value.jse-empty.svelte-c0g9qz {
  min-width: 4em;
  outline: 1px dotted var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  -moz-outline-radius: 2px;
}
.jse-value.jse-empty.svelte-c0g9qz::after {
  pointer-events: none;
  color: var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  content: "value";
}`);var zR=G('<div role="button" tabindex="-1" data-type="selectable-value"><!> <!></div>');function PR(e,t){lt(t,!0);var n=ba(!0),r=co(()=>o(n)&&typeof t.value=="string"&&t.value.length>t.truncateTextSize&&(!t.searchResultItems||!t.searchResultItems.some(g=>g.active&&g.end>t.truncateTextSize))),a=co(()=>o(r)&&typeof t.value=="string"?t.value.substring(0,t.truncateTextSize).trim():t.value),i=co(()=>$c(t.value));function s(){p(n,!1)}var l=zR();l.__click=[RR,t,i],l.__dblclick=[MR,t];var u=z(l),d=g=>{var m=co(()=>t.normalization.escapeValue(o(a)));ww(g,{get text(){return o(m)},get searchResultItems(){return t.searchResultItems}})},c=g=>{var m=Br();Ee(b=>pt(m,b),[()=>Bc(t.normalization.escapeValue(o(a)))]),I(g,m)};re(u,g=>{t.searchResultItems?g(d):g(c,!1)});var v=F(u,2),f=g=>{Su(g,{onclick:s,children:(m,b)=>{var j=Br();Ee(w=>pt(j,"Show more (".concat(w??"",")")),[()=>kv(t.value.length)]),I(m,j)},$$slots:{default:!0}})};re(v,g=>{o(r)&&typeof t.value=="string"&&g(f)}),Ee(g=>{Mt(l,1,g,"svelte-c0g9qz"),Cn(l,"title",o(i)?"Ctrl+Click or Ctrl+Enter to open url in new window":void 0)},[()=>ai(fp(t.value,t.mode,t.parser))]),I(e,l),ut()}Zl(["click","dblclick"]);jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-tooltip.svelte-14y3y8t {
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  line-height: normal;
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px);
  border-radius: 3px;
  background: var(--jse-context-menu-background, #656565);
  color: var(--jse-context-menu-color, var(--jse-text-color-inverse, #fff));
  white-space: nowrap;
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
}`);var TR=G('<div class="jse-tooltip svelte-14y3y8t"> </div>');function IR(e,t){var n=h(t,"text",8),r=TR(),a=z(r);Ee(()=>pt(a,n())),I(e,r)}function _s(e,t){var n,{text:r,openAbsolutePopup:a,closeAbsolutePopup:i}=t;function s(){n=a(IR,{text:r},{position:"top",width:10*r.length,offsetTop:3,anchor:e,closeOnOuterClick:!0})}function l(){i(n)}return e.addEventListener("mouseenter",s),e.addEventListener("mouseleave",l),{destroy(){e.removeEventListener("mouseenter",s),e.removeEventListener("mouseleave",l)}}}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-timestamp.svelte-1jla5ec {
  padding: 0;
  margin: 0;
  vertical-align: middle;
  display: inline-flex;
  color: var(--jse-value-color-number, #ee422e);
}`);var NR=G('<div class="jse-timestamp svelte-1jla5ec"><!></div>');function LR(e,t){lt(t,!1);var n=P(void 0,!0),r=vi("absolute-popup"),a=h(t,"value",9);W(()=>M(a()),()=>{p(n,"Time: ".concat(new Date(a()).toString()))}),_n(),St(!0);var i=NR();dn(z(i),{data:J1}),eo(i,(s,l)=>_s?.(s,l),()=>Se({text:o(n)},r)),I(e,i),ut()}function _v(e){var t=[];return!e.isEditing&&TA(e.value)&&t.push({component:cR,props:e}),!e.isEditing&&IA(e.value)&&t.push({component:pR,props:e}),e.isEditing&&t.push({component:SR,props:e}),e.isEditing||t.push({component:PR,props:e}),!e.isEditing&&dv(e.value)&&t.push({component:LR,props:e}),t}function qo(e){return e.map((t,n)=>Jc.test(t)?"["+t+"]":/[.[\]]/.test(t)||t===""?'["'+function(r){return r.replace(/"/g,'\\"')}(t)+'"]':(n>0?".":"")+t).join("")}function UR(e){for(var t=[],n=0;n<e.length;)e[n]==="."&&n++,e[n]==="["?(n++,e[n]==='"'?(n++,t.push(r(i=>i==='"',!0)),a('"')):t.push(r(i=>i==="]")),a("]")):t.push(r(i=>i==="."||i==="["));function r(i){for(var s=arguments.length>1&&arguments[1]!==void 0&&arguments[1],l="";n<e.length&&!i(e[n]);)s&&e[n]==="\\"&&e[n+1]==='"'?(l+='"',n+=2):(l+=e[n],n++);return l}function a(i){if(e[n]!==i)throw new SyntaxError("Invalid JSON path: ".concat(i," expected at position ").concat(n));n++}return t}function Ha(e){return{value:e,label:Pn(e)?"(item root)":qo(e)}}function DR(e){if(Jc.test(e))return"["+e+"]";if(pp.test(e))return"."+e;var t=JSON.stringify(e);return"['"+t.substring(1,t.length-1).replace(/\\"/g,'"')+"']"}function Rd(e){return e.map(t=>Jc.test(t)?"?.[".concat(t,"]"):pp.test(t)?"?.".concat(t):"?.[".concat(JSON.stringify(t),"]")).join("")}var pp=/^[a-zA-Z$_][a-zA-Z$_\d]*$/,Jc=/^\d+$/,qR={},$R={showWizard:!0,showOriginal:!0},Qu=Math.min,ki=Math.max,Zu=Math.round,pu=Math.floor,ua=e=>({x:e,y:e}),FR={left:"right",right:"left",bottom:"top",top:"bottom"},BR={start:"end",end:"start"};function eg(e,t,n){return ki(e,Qu(t,n))}function Gc(e,t){return typeof e=="function"?e(t):e}function _i(e){return e.split("-")[0]}function ec(e){return e.split("-")[1]}function kw(e){return e==="x"?"y":"x"}function _w(e){return e==="y"?"height":"width"}function Ss(e){return["top","bottom"].includes(_i(e))?"y":"x"}function Sw(e){return kw(Ss(e))}function Md(e){return e.replace(/start|end/g,t=>BR[t])}function hu(e){return e.replace(/left|right|bottom|top/g,t=>FR[t])}function WR(e){return typeof e!="number"?function(t){return Se({top:0,right:0,bottom:0,left:0},t)}(e):{top:e,right:e,bottom:e,left:e}}function tc(e){var{x:t,y:n,width:r,height:a}=e;return{width:r,height:a,top:n,left:t,right:t+r,bottom:n+a,x:t,y:n}}function tg(e,t,n){var r,{reference:a,floating:i}=e,s=Ss(t),l=Sw(t),u=_w(l),d=_i(t),c=s==="y",v=a.x+a.width/2-i.width/2,f=a.y+a.height/2-i.height/2,g=a[u]/2-i[u]/2;switch(d){case"top":r={x:v,y:a.y-i.height};break;case"bottom":r={x:v,y:a.y+a.height};break;case"right":r={x:a.x+a.width,y:f};break;case"left":r={x:a.x-i.width,y:f};break;default:r={x:a.x,y:a.y}}switch(ec(t)){case"start":r[l]-=g*(n&&c?-1:1);break;case"end":r[l]+=g*(n&&c?-1:1)}return r}var HR=function(){var e=Rt(function*(t,n,r){for(var{placement:a="bottom",strategy:i="absolute",middleware:s=[],platform:l}=r,u=s.filter(Boolean),d=yield l.isRTL==null?void 0:l.isRTL(n),c=yield l.getElementRects({reference:t,floating:n,strategy:i}),{x:v,y:f}=tg(c,a,d),g=a,m={},b=0,j=0;j<u.length;j++){var{name:w,fn:O}=u[j],{x:T,y:R,data:k,reset:D}=yield O({x:v,y:f,initialPlacement:a,placement:g,strategy:i,middlewareData:m,rects:c,platform:l,elements:{reference:t,floating:n}});v=T??v,f=R??f,m=Se(Se({},m),{},{[w]:Se(Se({},m[w]),k)}),D&&b<=50&&(b++,typeof D=="object"&&(D.placement&&(g=D.placement),D.rects&&(c=D.rects===!0?yield l.getElementRects({reference:t,floating:n,strategy:i}):D.rects),{x:v,y:f}=tg(c,g,d)),j=-1)}return{x:v,y:f,placement:g,strategy:i,middlewareData:m}});return function(t,n,r){return e.apply(this,arguments)}}();function Cw(e,t){return Sv.apply(this,arguments)}function Sv(){return Sv=Rt(function*(e,t){var n;t===void 0&&(t={});var{x:r,y:a,platform:i,rects:s,elements:l,strategy:u}=e,{boundary:d="clippingAncestors",rootBoundary:c="viewport",elementContext:v="floating",altBoundary:f=!1,padding:g=0}=Gc(t,e),m=WR(g),b=l[f?v==="floating"?"reference":"floating":v],j=tc(yield i.getClippingRect({element:(n=yield i.isElement==null?void 0:i.isElement(b))==null||n?b:b.contextElement||(yield i.getDocumentElement==null?void 0:i.getDocumentElement(l.floating)),boundary:d,rootBoundary:c,strategy:u})),w=v==="floating"?{x:r,y:a,width:s.floating.width,height:s.floating.height}:s.reference,O=yield i.getOffsetParent==null?void 0:i.getOffsetParent(l.floating),T=(yield i.isElement==null?void 0:i.isElement(O))&&(yield i.getScale==null?void 0:i.getScale(O))||{x:1,y:1},R=tc(i.convertOffsetParentRelativeRectToViewportRelativeRect?yield i.convertOffsetParentRelativeRectToViewportRelativeRect({elements:l,rect:w,offsetParent:O,strategy:u}):w);return{top:(j.top-R.top+m.top)/T.y,bottom:(R.bottom-j.bottom+m.bottom)/T.y,left:(j.left-R.left+m.left)/T.x,right:(R.right-j.right+m.right)/T.x}}),Sv.apply(this,arguments)}function Cv(){return Cv=Rt(function*(e,t){var{placement:n,platform:r,elements:a}=e,i=yield r.isRTL==null?void 0:r.isRTL(a.floating),s=_i(n),l=ec(n),u=Ss(n)==="y",d=["left","top"].includes(s)?-1:1,c=i&&u?-1:1,v=Gc(t,e),{mainAxis:f,crossAxis:g,alignmentAxis:m}=typeof v=="number"?{mainAxis:v,crossAxis:0,alignmentAxis:null}:{mainAxis:v.mainAxis||0,crossAxis:v.crossAxis||0,alignmentAxis:v.alignmentAxis};return l&&typeof m=="number"&&(g=l==="end"?-1*m:m),u?{x:g*c,y:f*d}:{x:f*d,y:g*c}}),Cv.apply(this,arguments)}function Kc(){return typeof window<"u"}function Cs(e){return Ow(e)?(e.nodeName||"").toLowerCase():"#document"}function bo(e){var t;return(e==null||(t=e.ownerDocument)==null?void 0:t.defaultView)||window}function ca(e){var t;return(t=(Ow(e)?e.ownerDocument:e.document)||window.document)==null?void 0:t.documentElement}function Ow(e){return!!Kc()&&(e instanceof Node||e instanceof bo(e).Node)}function Go(e){return!!Kc()&&(e instanceof Element||e instanceof bo(e).Element)}function fa(e){return!!Kc()&&(e instanceof HTMLElement||e instanceof bo(e).HTMLElement)}function ng(e){return!(!Kc()||typeof ShadowRoot>"u")&&(e instanceof ShadowRoot||e instanceof bo(e).ShadowRoot)}function Tl(e){var{overflow:t,overflowX:n,overflowY:r,display:a}=Ko(e);return/auto|scroll|overlay|hidden|clip/.test(t+r+n)&&!["inline","contents"].includes(a)}function VR(e){return["table","td","th"].includes(Cs(e))}function nc(e){return[":popover-open",":modal"].some(t=>{try{return e.matches(t)}catch{return!1}})}function Ov(e){var t=hp(),n=Go(e)?Ko(e):e;return["transform","translate","scale","rotate","perspective"].some(r=>!!n[r]&&n[r]!=="none")||!!n.containerType&&n.containerType!=="normal"||!t&&!!n.backdropFilter&&n.backdropFilter!=="none"||!t&&!!n.filter&&n.filter!=="none"||["transform","translate","scale","rotate","perspective","filter"].some(r=>(n.willChange||"").includes(r))||["paint","layout","strict","content"].some(r=>(n.contain||"").includes(r))}function hp(){return!(typeof CSS>"u"||!CSS.supports)&&CSS.supports("-webkit-backdrop-filter","none")}function fs(e){return["html","body","#document"].includes(Cs(e))}function Ko(e){return bo(e).getComputedStyle(e)}function Yc(e){return Go(e)?{scrollLeft:e.scrollLeft,scrollTop:e.scrollTop}:{scrollLeft:e.scrollX,scrollTop:e.scrollY}}function Ka(e){if(Cs(e)==="html")return e;var t=e.assignedSlot||e.parentNode||ng(e)&&e.host||ca(e);return ng(t)?t.host:t}function Ew(e){var t=Ka(e);return fs(t)?e.ownerDocument?e.ownerDocument.body:e.body:fa(t)&&Tl(t)?t:Ew(t)}function Il(e,t,n){var r;t===void 0&&(t=[]),n===void 0&&(n=!0);var a=Ew(e),i=a===((r=e.ownerDocument)==null?void 0:r.body),s=bo(a);if(i){var l=Ev(s);return t.concat(s,s.visualViewport||[],Tl(a)?a:[],l&&n?Il(l):[])}return t.concat(a,Il(a,[],n))}function Ev(e){return e.parent&&Object.getPrototypeOf(e.parent)?e.frameElement:null}function Aw(e){var t=Ko(e),n=parseFloat(t.width)||0,r=parseFloat(t.height)||0,a=fa(e),i=a?e.offsetWidth:n,s=a?e.offsetHeight:r,l=Zu(n)!==i||Zu(r)!==s;return l&&(n=i,r=s),{width:n,height:r,$:l}}function gp(e){return Go(e)?e:e.contextElement}function ps(e){var t=gp(e);if(!fa(t))return ua(1);var n=t.getBoundingClientRect(),{width:r,height:a,$:i}=Aw(t),s=(i?Zu(n.width):n.width)/r,l=(i?Zu(n.height):n.height)/a;return s&&Number.isFinite(s)||(s=1),l&&Number.isFinite(l)||(l=1),{x:s,y:l}}var JR=ua(0);function Rw(e){var t=bo(e);return hp()&&t.visualViewport?{x:t.visualViewport.offsetLeft,y:t.visualViewport.offsetTop}:JR}function Ii(e,t,n,r){t===void 0&&(t=!1),n===void 0&&(n=!1);var a=e.getBoundingClientRect(),i=gp(e),s=ua(1);t&&(r?Go(r)&&(s=ps(r)):s=ps(e));var l=function(k,D,H){return D===void 0&&(D=!1),!(!H||D&&H!==bo(k))&&D}(i,n,r)?Rw(i):ua(0),u=(a.left+l.x)/s.x,d=(a.top+l.y)/s.y,c=a.width/s.x,v=a.height/s.y;if(i)for(var f=bo(i),g=r&&Go(r)?bo(r):r,m=f,b=Ev(m);b&&r&&g!==m;){var j=ps(b),w=b.getBoundingClientRect(),O=Ko(b),T=w.left+(b.clientLeft+parseFloat(O.paddingLeft))*j.x,R=w.top+(b.clientTop+parseFloat(O.paddingTop))*j.y;u*=j.x,d*=j.y,c*=j.x,v*=j.y,u+=T,d+=R,b=Ev(m=bo(b))}return tc({width:c,height:v,x:u,y:d})}function mp(e,t){var n=Yc(e).scrollLeft;return t?t.left+n:Ii(ca(e)).left+n}function Mw(e,t,n){n===void 0&&(n=!1);var r=e.getBoundingClientRect();return{x:r.left+t.scrollLeft-(n?0:mp(e,r)),y:r.top+t.scrollTop}}function rg(e,t,n){var r;if(t==="viewport")r=function(i,s){var l=bo(i),u=ca(i),d=l.visualViewport,c=u.clientWidth,v=u.clientHeight,f=0,g=0;if(d){c=d.width,v=d.height;var m=hp();(!m||m&&s==="fixed")&&(f=d.offsetLeft,g=d.offsetTop)}return{width:c,height:v,x:f,y:g}}(e,n);else if(t==="document")r=function(i){var s=ca(i),l=Yc(i),u=i.ownerDocument.body,d=ki(s.scrollWidth,s.clientWidth,u.scrollWidth,u.clientWidth),c=ki(s.scrollHeight,s.clientHeight,u.scrollHeight,u.clientHeight),v=-l.scrollLeft+mp(i),f=-l.scrollTop;return Ko(u).direction==="rtl"&&(v+=ki(s.clientWidth,u.clientWidth)-d),{width:d,height:c,x:v,y:f}}(ca(e));else if(Go(t))r=function(i,s){var l=Ii(i,!0,s==="fixed"),u=l.top+i.clientTop,d=l.left+i.clientLeft,c=fa(i)?ps(i):ua(1);return{width:i.clientWidth*c.x,height:i.clientHeight*c.y,x:d*c.x,y:u*c.y}}(t,n);else{var a=Rw(e);r={x:t.x-a.x,y:t.y-a.y,width:t.width,height:t.height}}return tc(r)}function zw(e,t){var n=Ka(e);return!(n===t||!Go(n)||fs(n))&&(Ko(n).position==="fixed"||zw(n,t))}function GR(e,t,n){var r=fa(t),a=ca(t),i=n==="fixed",s=Ii(e,!0,i,t),l={scrollLeft:0,scrollTop:0},u=ua(0);if(r||!r&&!i)if((Cs(t)!=="body"||Tl(a))&&(l=Yc(t)),r){var d=Ii(t,!0,i,t);u.x=d.x+t.clientLeft,u.y=d.y+t.clientTop}else a&&(u.x=mp(a));var c=!a||r||i?ua(0):Mw(a,l);return{x:s.left+l.scrollLeft-u.x-c.x,y:s.top+l.scrollTop-u.y-c.y,width:s.width,height:s.height}}function zd(e){return Ko(e).position==="static"}function og(e,t){if(!fa(e)||Ko(e).position==="fixed")return null;if(t)return t(e);var n=e.offsetParent;return ca(e)===n&&(n=n.ownerDocument.body),n}function ag(e,t){var n=bo(e);if(nc(e))return n;if(!fa(e)){for(var r=Ka(e);r&&!fs(r);){if(Go(r)&&!zd(r))return r;r=Ka(r)}return n}for(var a=og(e,t);a&&VR(a)&&zd(a);)a=og(a,t);return a&&fs(a)&&zd(a)&&!Ov(a)?n:a||function(i){for(var s=Ka(i);fa(s)&&!fs(s);){if(Ov(s))return s;if(nc(s))return null;s=Ka(s)}return null}(e)||n}var KR={convertOffsetParentRelativeRectToViewportRelativeRect:function(e){var{elements:t,rect:n,offsetParent:r,strategy:a}=e,i=a==="fixed",s=ca(r),l=!!t&&nc(t.floating);if(r===s||l&&i)return n;var u={scrollLeft:0,scrollTop:0},d=ua(1),c=ua(0),v=fa(r);if((v||!v&&!i)&&((Cs(r)!=="body"||Tl(s))&&(u=Yc(r)),fa(r))){var f=Ii(r);d=ps(r),c.x=f.x+r.clientLeft,c.y=f.y+r.clientTop}var g=!s||v||i?ua(0):Mw(s,u,!0);return{width:n.width*d.x,height:n.height*d.y,x:n.x*d.x-u.scrollLeft*d.x+c.x+g.x,y:n.y*d.y-u.scrollTop*d.y+c.y+g.y}},getDocumentElement:ca,getClippingRect:function(e){var{element:t,boundary:n,rootBoundary:r,strategy:a}=e,i=[...n==="clippingAncestors"?nc(t)?[]:function(u,d){var c=d.get(u);if(c)return c;for(var v=Il(u,[],!1).filter(w=>Go(w)&&Cs(w)!=="body"),f=null,g=Ko(u).position==="fixed",m=g?Ka(u):u;Go(m)&&!fs(m);){var b=Ko(m),j=Ov(m);j||b.position!=="fixed"||(f=null),(g?!j&&!f:!j&&b.position==="static"&&f&&["absolute","fixed"].includes(f.position)||Tl(m)&&!j&&zw(u,m))?v=v.filter(w=>w!==m):f=b,m=Ka(m)}return d.set(u,v),v}(t,this._c):[].concat(n),r],s=i[0],l=i.reduce((u,d)=>{var c=rg(t,d,a);return u.top=ki(c.top,u.top),u.right=Qu(c.right,u.right),u.bottom=Qu(c.bottom,u.bottom),u.left=ki(c.left,u.left),u},rg(t,s,a));return{width:l.right-l.left,height:l.bottom-l.top,x:l.left,y:l.top}},getOffsetParent:ag,getElementRects:function(){var e=Rt(function*(t){var n=this.getOffsetParent||ag,r=this.getDimensions,a=yield r(t.floating);return{reference:GR(t.reference,yield n(t.floating),t.strategy),floating:{x:0,y:0,width:a.width,height:a.height}}});return function(t){return e.apply(this,arguments)}}(),getClientRects:function(e){return Array.from(e.getClientRects())},getDimensions:function(e){var{width:t,height:n}=Aw(e);return{width:t,height:n}},getScale:ps,isElement:Go,isRTL:function(e){return Ko(e).direction==="rtl"}};function ig(e,t){return e.x===t.x&&e.y===t.y&&e.width===t.width&&e.height===t.height}function YR(e,t,n,r){r===void 0&&(r={});var{ancestorScroll:a=!0,ancestorResize:i=!0,elementResize:s=typeof ResizeObserver=="function",layoutShift:l=typeof IntersectionObserver=="function",animationFrame:u=!1}=r,d=gp(e),c=a||i?[...d?Il(d):[],...Il(t)]:[];c.forEach(j=>{a&&j.addEventListener("scroll",n,{passive:!0}),i&&j.addEventListener("resize",n)});var v,f=d&&l?function(j,w){var O,T=null,R=ca(j);function k(){var D;clearTimeout(O),(D=T)==null||D.disconnect(),T=null}return function D(H,V){H===void 0&&(H=!1),V===void 0&&(V=1),k();var A=j.getBoundingClientRect(),{left:J,top:Z,width:Y,height:le}=A;if(H||w(),Y&&le){var Ae={rootMargin:-pu(Z)+"px "+-pu(R.clientWidth-(J+Y))+"px "+-pu(R.clientHeight-(Z+le))+"px "+-pu(J)+"px",threshold:ki(0,Qu(1,V))||1},ce=!0;try{T=new IntersectionObserver(we,Se(Se({},Ae),{},{root:R.ownerDocument}))}catch{T=new IntersectionObserver(we,Ae)}T.observe(j)}function we($e){var Ne=$e[0].intersectionRatio;if(Ne!==V){if(!ce)return D();Ne?D(!1,Ne):O=setTimeout(()=>{D(!1,1e-7)},1e3)}Ne!==1||ig(A,j.getBoundingClientRect())||D(),ce=!1}}(!0),k}(d,n):null,g=-1,m=null;s&&(m=new ResizeObserver(j=>{var[w]=j;w&&w.target===d&&m&&(m.unobserve(t),cancelAnimationFrame(g),g=requestAnimationFrame(()=>{var O;(O=m)==null||O.observe(t)})),n()}),d&&!u&&m.observe(d),m.observe(t));var b=u?Ii(e):null;return u&&function j(){var w=Ii(e);b&&!ig(b,w)&&n(),b=w,v=requestAnimationFrame(j)}(),n(),()=>{var j;c.forEach(w=>{a&&w.removeEventListener("scroll",n),i&&w.removeEventListener("resize",n)}),f?.(),(j=m)==null||j.disconnect(),m=null,u&&cancelAnimationFrame(v)}}var XR=function(e){return e===void 0&&(e=0),{name:"offset",options:e,fn:t=>Rt(function*(){var n,r,{x:a,y:i,placement:s,middlewareData:l}=t,u=yield function(d,c){return Cv.apply(this,arguments)}(t,e);return s===((n=l.offset)==null?void 0:n.placement)&&(r=l.arrow)!=null&&r.alignmentOffset?{}:{x:a+u.x,y:i+u.y,data:Se(Se({},u),{},{placement:s})}})()}},QR=function(e){return e===void 0&&(e={}),{name:"shift",options:e,fn:t=>Rt(function*(){var{x:n,y:r,placement:a}=t,i=Gc(e,t),{mainAxis:s=!0,crossAxis:l=!1,limiter:u={fn:T=>{var{x:R,y:k}=T;return{x:R,y:k}}}}=i,d=ay(i,nA),c={x:n,y:r},v=yield Cw(t,d),f=Ss(_i(a)),g=kw(f),m=c[g],b=c[f];if(s){var j=g==="y"?"bottom":"right";m=eg(m+v[g==="y"?"top":"left"],m,m-v[j])}if(l){var w=f==="y"?"bottom":"right";b=eg(b+v[f==="y"?"top":"left"],b,b-v[w])}var O=u.fn(Se(Se({},t),{},{[g]:m,[f]:b}));return Se(Se({},O),{},{data:{x:O.x-n,y:O.y-r,enabled:{[g]:s,[f]:l}}})})()}},ZR=function(e){return e===void 0&&(e={}),{name:"flip",options:e,fn:t=>Rt(function*(){var n,r,{placement:a,middlewareData:i,rects:s,initialPlacement:l,platform:u,elements:d}=t,c=Gc(e,t),{mainAxis:v=!0,crossAxis:f=!0,fallbackPlacements:g,fallbackStrategy:m="bestFit",fallbackAxisSideDirection:b="none",flipAlignment:j=!0}=c,w=ay(c,tA);if((n=i.arrow)!=null&&n.alignmentOffset)return{};var O=_i(a),T=Ss(l),R=_i(l)===l,k=yield u.isRTL==null?void 0:u.isRTL(d.floating),D=g||(R||!j?[hu(l)]:function(ze){var Re=hu(ze);return[Md(ze),Re,Md(Re)]}(l)),H=b!=="none";!g&&H&&D.push(...function(ze,Re,We,he){var ue=ec(ze),me=function(ot,Ot,ee){var q=["left","right"],ae=["right","left"];switch(ot){case"top":case"bottom":return ee?Ot?ae:q:Ot?q:ae;case"left":case"right":return Ot?["top","bottom"]:["bottom","top"];default:return[]}}(_i(ze),We==="start",he);return ue&&(me=me.map(ot=>ot+"-"+ue),Re&&(me=me.concat(me.map(Md)))),me}(l,j,b,k));var V=[l,...D],A=yield Cw(t,w),J=[],Z=((r=i.flip)==null?void 0:r.overflows)||[];if(v&&J.push(A[O]),f){var Y=function(ze,Re,We){We===void 0&&(We=!1);var he=ec(ze),ue=Sw(ze),me=_w(ue),ot=ue==="x"?he===(We?"end":"start")?"right":"left":he==="start"?"bottom":"top";return Re.reference[me]>Re.floating[me]&&(ot=hu(ot)),[ot,hu(ot)]}(a,s,k);J.push(A[Y[0]],A[Y[1]])}if(Z=[...Z,{placement:a,overflows:J}],!J.every(ze=>ze<=0)){var le,Ae,ce=(((le=i.flip)==null?void 0:le.index)||0)+1,we=V[ce];if(we)return{data:{index:ce,overflows:Z},reset:{placement:we}};var $e=(Ae=Z.filter(ze=>ze.overflows[0]<=0).sort((ze,Re)=>ze.overflows[1]-Re.overflows[1])[0])==null?void 0:Ae.placement;if(!$e)switch(m){case"bestFit":var Ne,ye=(Ne=Z.filter(ze=>{if(H){var Re=Ss(ze.placement);return Re===T||Re==="y"}return!0}).map(ze=>[ze.placement,ze.overflows.filter(Re=>Re>0).reduce((Re,We)=>Re+We,0)]).sort((ze,Re)=>ze[1]-Re[1])[0])==null?void 0:Ne[0];ye&&($e=ye);break;case"initialPlacement":$e=l}if(a!==$e)return{reset:{placement:$e}}}return{}})()}};function eM(e){var t,n,r={autoUpdate:!0},a=e,i=u=>Se(Se(Se({},r),e||{}),u||{}),s=u=>{t&&n&&(a=i(u),((d,c,v)=>{var f=new Map,g=Se({platform:KR},v),m=Se(Se({},g.platform),{},{_c:f});return HR(d,c,Se(Se({},g),{},{platform:m}))})(t,n,a).then(d=>{var c;Object.assign(n.style,{position:d.strategy,left:"".concat(d.x,"px"),top:"".concat(d.y,"px")}),!((c=a)===null||c===void 0)&&c.onComputed&&a.onComputed(d)}))},l=u=>{zo(u.subscribe(d=>{t===void 0?(t=d,s()):(Object.assign(t,d),s())}))};return[u=>{if("subscribe"in u)return l(u),{};t=u,s()},(u,d)=>{var c;n=u,a=i(d),setTimeout(()=>s(d),0),s(d);var v=()=>{c&&(c(),c=void 0)},f=function(){var{autoUpdate:g}=arguments.length>0&&arguments[0]!==void 0?arguments[0]:a||{};v(),g!==!1&&function(){return _y.apply(this,arguments)}().then(()=>YR(t,n,()=>s(a),g===!0?{}:g))};return c=f(),{update(g){s(g),c=f(g)},destroy(){v()}}},s]}function tM(e){var{loadOptions:t,filterText:n,items:r,multiple:a,value:i,itemId:s,groupBy:l,filterSelectedItems:u,itemFilter:d,convertStringItemsToObjects:c,filterGroupedItems:v,label:f}=e;if(r&&t)return r;if(!r)return[];r&&r.length>0&&typeof r[0]!="object"&&(r=c(r));var g=r.filter(m=>{var b=d(m[f],n,m);return b&&a&&i!=null&&i.length&&(b=!i.some(j=>!!u&&j[s]===m[s])),b});return l&&(g=v(g)),g}function nM(e){return Pw.apply(this,arguments)}function Pw(){return(Pw=Rt(function*(e){var{dispatch:t,loadOptions:n,convertStringItemsToObjects:r,filterText:a}=e,i=yield n(a).catch(s=>{console.warn("svelte-select loadOptions error :>> ",s),t("error",{type:"loadOptions",details:s})});if(i&&!i.cancelled)return i?(i&&i.length>0&&typeof i[0]!="object"&&(i=r(i)),t("loaded",{items:i})):i=[],{filteredItems:i,loading:!1,focused:!0,listOpen:!0}})).apply(this,arguments)}jt(`
  svg.svelte-qbd276 {
      width: var(--chevron-icon-width, 20px);
      height: var(--chevron-icon-width, 20px);
      color: var(--chevron-icon-colour, currentColor);
  }
`);var rM=fi(`<svg width="100%" height="100%" viewBox="0 0 20 20" focusable="false" aria-hidden="true" class="svelte-qbd276"><path fill="currentColor" d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747
          3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0
          1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502
          0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0
          0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"></path></svg>`);jt(`
    svg.svelte-whdbu1 {
        width: var(--clear-icon-width, 20px);
        height: var(--clear-icon-width, 20px);
        color: var(--clear-icon-color, currentColor);
    }
`);var oM=fi(`<svg width="100%" height="100%" viewBox="-2 -2 50 50" focusable="false" aria-hidden="true" role="presentation" class="svelte-whdbu1"><path fill="currentColor" d="M34.923,37.251L24,26.328L13.077,37.251L9.436,33.61l10.923-10.923L9.436,11.765l3.641-3.641L24,19.047L34.923,8.124
    l3.641,3.641L27.641,22.688L38.564,33.61L34.923,37.251z"></path></svg>`);function Pd(e){I(e,oM())}jt(`
    .loading.svelte-1p3nqvd {
        width: var(--spinner-width, 20px);
        height: var(--spinner-height, 20px);
        color: var(--spinner-color, var(--icons-color));
        animation: svelte-1p3nqvd-rotate 0.75s linear infinite;
        transform-origin: center center;
        transform: none;
    }

    .circle_path.svelte-1p3nqvd {
        stroke-dasharray: 90;
        stroke-linecap: round;
    }

    @keyframes svelte-1p3nqvd-rotate {
        100% {
            transform: rotate(360deg);
        }
    }
`);var aM=fi('<svg class="loading svelte-1p3nqvd" viewBox="25 25 50 50"><circle class="circle_path svelte-1p3nqvd" cx="50" cy="50" r="20" fill="none" stroke="currentColor" stroke-width="5" stroke-miterlimit="10"></circle></svg>');jt(`
    .svelte-select.svelte-82qwg8 {
        /* deprecating camelCase custom props in favour of kebab-case for v5 */
        --borderRadius: var(--border-radius);
        --clearSelectColor: var(--clear-select-color);
        --clearSelectWidth: var(--clear-select-width);
        --disabledBackground: var(--disabled-background);
        --disabledBorderColor: var(--disabled-border-color);
        --disabledColor: var(--disabled-color);
        --disabledPlaceholderColor: var(--disabled-placeholder-color);
        --disabledPlaceholderOpacity: var(--disabled-placeholder-opacity);
        --errorBackground: var(--error-background);
        --errorBorder: var(--error-border);
        --groupItemPaddingLeft: var(--group-item-padding-left);
        --groupTitleColor: var(--group-title-color);
        --groupTitleFontSize: var(--group-title-font-size);
        --groupTitleFontWeight: var(--group-title-font-weight);
        --groupTitlePadding: var(--group-title-padding);
        --groupTitleTextTransform: var(--group-title-text-transform);
        --groupTitleBorderColor: var(--group-title-border-color);
        --groupTitleBorderWidth: var(--group-title-border-width);
        --groupTitleBorderStyle: var(--group-title-border-style);
        --indicatorColor: var(--chevron-color);
        --indicatorHeight: var(--chevron-height);
        --indicatorWidth: var(--chevron-width);
        --inputColor: var(--input-color);
        --inputLeft: var(--input-left);
        --inputLetterSpacing: var(--input-letter-spacing);
        --inputMargin: var(--input-margin);
        --inputPadding: var(--input-padding);
        --itemActiveBackground: var(--item-active-background);
        --itemColor: var(--item-color);
        --itemFirstBorderRadius: var(--item-first-border-radius);
        --itemHoverBG: var(--item-hover-bg);
        --itemHoverColor: var(--item-hover-color);
        --itemIsActiveBG: var(--item-is-active-bg);
        --itemIsActiveColor: var(--item-is-active-color);
        --itemIsNotSelectableColor: var(--item-is-not-selectable-color);
        --itemPadding: var(--item-padding);
        --listBackground: var(--list-background);
        --listBorder: var(--list-border);
        --listBorderRadius: var(--list-border-radius);
        --listEmptyColor: var(--list-empty-color);
        --listEmptyPadding: var(--list-empty-padding);
        --listEmptyTextAlign: var(--list-empty-text-align);
        --listMaxHeight: var(--list-max-height);
        --listPosition: var(--list-position);
        --listShadow: var(--list-shadow);
        --listZIndex: var(--list-z-index);
        --multiItemBG: var(--multi-item-bg);
        --multiItemBorderRadius: var(--multi-item-border-radius);
        --multiItemDisabledHoverBg: var(--multi-item-disabled-hover-bg);
        --multiItemDisabledHoverColor: var(--multi-item-disabled-hover-color);
        --multiItemHeight: var(--multi-item-height);
        --multiItemMargin: var(--multi-item-margin);
        --multiItemPadding: var(--multi-item-padding);
        --multiSelectInputMargin: var(--multi-select-input-margin);
        --multiSelectInputPadding: var(--multi-select-input-padding);
        --multiSelectPadding: var(--multi-select-padding);
        --placeholderColor: var(--placeholder-color);
        --placeholderOpacity: var(--placeholder-opacity);
        --selectedItemPadding: var(--selected-item-padding);
        --spinnerColor: var(--spinner-color);
        --spinnerHeight: var(--spinner-height);
        --spinnerWidth: var(--spinner-width);

        --internal-padding: 0 0 0 16px;

        border: var(--border, 1px solid #d8dbdf);
        border-radius: var(--border-radius, 6px);
        min-height: var(--height, 42px);
        position: relative;
        display: flex;
        align-items: stretch;
        padding: var(--padding, var(--internal-padding));
        background: var(--background, #fff);
        margin: var(--margin, 0);
        width: var(--width, 100%);
        font-size: var(--font-size, 16px);
        max-height: var(--max-height);
    }

    .svelte-82qwg8 {
        box-sizing: var(--box-sizing, border-box);
    }

    .svelte-select.svelte-82qwg8:hover {
        border: var(--border-hover, 1px solid #b2b8bf);
    }

    .value-container.svelte-82qwg8 {
        display: flex;
        flex: 1 1 0%;
        flex-wrap: wrap;
        align-items: center;
        gap: 5px 10px;
        padding: var(--value-container-padding, 5px 0);
        position: relative;
        overflow: var(--value-container-overflow, hidden);
        align-self: stretch;
    }

    .prepend.svelte-82qwg8,
    .indicators.svelte-82qwg8 {
        display: flex;
        flex-shrink: 0;
        align-items: center;
    }

    .indicators.svelte-82qwg8 {
        position: var(--indicators-position);
        top: var(--indicators-top);
        right: var(--indicators-right);
        bottom: var(--indicators-bottom);
    }

    input.svelte-82qwg8 {
        position: absolute;
        cursor: default;
        border: none;
        color: var(--input-color, var(--item-color));
        padding: var(--input-padding, 0);
        letter-spacing: var(--input-letter-spacing, inherit);
        margin: var(--input-margin, 0);
        min-width: 10px;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background: transparent;
        font-size: var(--font-size, 16px);
    }

    .svelte-82qwg8:not(.multi) > .value-container:where(.svelte-82qwg8) > input:where(.svelte-82qwg8) {
        width: 100%;
        height: 100%;
    }

    input.svelte-82qwg8::placeholder {
        color: var(--placeholder-color, #78848f);
        opacity: var(--placeholder-opacity, 1);
    }

    input.svelte-82qwg8:focus {
        outline: none;
    }

    .svelte-select.focused.svelte-82qwg8 {
        border: var(--border-focused, 1px solid #006fe8);
        border-radius: var(--border-radius-focused, var(--border-radius, 6px));
    }

    .disabled.svelte-82qwg8 {
        background: var(--disabled-background, #ebedef);
        border-color: var(--disabled-border-color, #ebedef);
        color: var(--disabled-color, #c1c6cc);
    }

    .disabled.svelte-82qwg8 input:where(.svelte-82qwg8)::placeholder {
        color: var(--disabled-placeholder-color, #c1c6cc);
        opacity: var(--disabled-placeholder-opacity, 1);
    }

    .selected-item.svelte-82qwg8 {
        position: relative;
        overflow: var(--selected-item-overflow, hidden);
        padding: var(--selected-item-padding, 0 20px 0 0);
        text-overflow: ellipsis;
        white-space: nowrap;
        color: var(--selected-item-color, inherit);
        font-size: var(--font-size, 16px);
    }

    .multi.svelte-82qwg8 .selected-item:where(.svelte-82qwg8) {
        position: absolute;
        line-height: var(--height, 42px);
        height: var(--height, 42px);
    }

    .selected-item.svelte-82qwg8:focus {
        outline: none;
    }

    .hide-selected-item.svelte-82qwg8 {
        opacity: 0;
    }

    .icon.svelte-82qwg8 {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .clear-select.svelte-82qwg8 {
        all: unset;
        display: flex;
        align-items: center;
        justify-content: center;
        width: var(--clear-select-width, 40px);
        height: var(--clear-select-height, 100%);
        color: var(--clear-select-color, var(--icons-color));
        margin: var(--clear-select-margin, 0);
        pointer-events: all;
        flex-shrink: 0;
    }

    .clear-select.svelte-82qwg8:focus {
        outline: var(--clear-select-focus-outline, 1px solid #006fe8);
    }

    .loading.svelte-82qwg8 {
        width: var(--loading-width, 40px);
        height: var(--loading-height);
        color: var(--loading-color, var(--icons-color));
        margin: var(--loading--margin, 0);
        flex-shrink: 0;
    }

    .chevron.svelte-82qwg8 {
        width: var(--chevron-width, 40px);
        height: var(--chevron-height, 40px);
        background: var(--chevron-background, transparent);
        pointer-events: var(--chevron-pointer-events, none);
        color: var(--chevron-color, var(--icons-color));
        border: var(--chevron-border, 0 0 0 1px solid #d8dbdf);
        flex-shrink: 0;
    }

    .multi.svelte-82qwg8 {
        padding: var(--multi-select-padding, var(--internal-padding));
    }

    .multi.svelte-82qwg8 input:where(.svelte-82qwg8) {
        padding: var(--multi-select-input-padding, 0);
        position: relative;
        margin: var(--multi-select-input-margin, 5px 0);
        flex: 1 1 40px;
    }

    .svelte-select.error.svelte-82qwg8 {
        border: var(--error-border, 1px solid #ff2d55);
        background: var(--error-background, #fff);
    }

    .a11y-text.svelte-82qwg8 {
        z-index: 9999;
        border: 0px;
        clip: rect(1px, 1px, 1px, 1px);
        height: 1px;
        width: 1px;
        position: absolute;
        overflow: hidden;
        padding: 0px;
        white-space: nowrap;
    }

    .multi-item.svelte-82qwg8 {
        background: var(--multi-item-bg, #ebedef);
        margin: var(--multi-item-margin, 0);
        outline: var(--multi-item-outline, 1px solid #ddd);
        border-radius: var(--multi-item-border-radius, 4px);
        height: var(--multi-item-height, 25px);
        line-height: var(--multi-item-height, 25px);
        display: flex;
        cursor: default;
        padding: var(--multi-item-padding, 0 5px);
        overflow: hidden;
        gap: var(--multi-item-gap, 4px);
        outline-offset: -1px;
        max-width: var(--multi-max-width, none);
        color: var(--multi-item-color, var(--item-color));
    }

    .multi-item.disabled.svelte-82qwg8:hover {
        background: var(--multi-item-disabled-hover-bg, #ebedef);
        color: var(--multi-item-disabled-hover-color, #c1c6cc);
    }

    .multi-item-text.svelte-82qwg8 {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .multi-item-clear.svelte-82qwg8 {
        display: flex;
        align-items: center;
        justify-content: center;
        --clear-icon-color: var(--multi-item-clear-icon-color, #000);
    }

    .multi-item.active.svelte-82qwg8 {
        outline: var(--multi-item-active-outline, 1px solid #006fe8);
    }

    .svelte-select-list.svelte-82qwg8 {
        box-shadow: var(--list-shadow, 0 2px 3px 0 rgba(44, 62, 80, 0.24));
        border-radius: var(--list-border-radius, 4px);
        max-height: var(--list-max-height, 252px);
        overflow-y: auto;
        background: var(--list-background, #fff);
        position: var(--list-position, absolute);
        z-index: var(--list-z-index, 2);
        border: var(--list-border);
    }

    .prefloat.svelte-82qwg8 {
        opacity: 0;
        pointer-events: none;
    }

    .list-group-title.svelte-82qwg8 {
        color: var(--group-title-color, #8f8f8f);
        cursor: default;
        font-size: var(--group-title-font-size, 16px);
        font-weight: var(--group-title-font-weight, 600);
        height: var(--height, 42px);
        line-height: var(--height, 42px);
        padding: var(--group-title-padding, 0 20px);
        text-overflow: ellipsis;
        overflow-x: hidden;
        white-space: nowrap;
        text-transform: var(--group-title-text-transform, uppercase);
        border-width: var(--group-title-border-width, medium);
        border-style: var(--group-title-border-style, none);
        border-color: var(--group-title-border-color, color);
    }

    .empty.svelte-82qwg8 {
        text-align: var(--list-empty-text-align, center);
        padding: var(--list-empty-padding, 20px 0);
        color: var(--list-empty-color, #78848f);
    }

    .item.svelte-82qwg8 {
        cursor: default;
        height: var(--item-height, var(--height, 42px));
        line-height: var(--item-line-height, var(--height, 42px));
        padding: var(--item-padding, 0 20px);
        color: var(--item-color, inherit);
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        transition: var(--item-transition, all 0.2s);
        align-items: center;
        width: 100%;
    }

    .item.group-item.svelte-82qwg8 {
        padding-left: var(--group-item-padding-left, 40px);
    }

    .item.svelte-82qwg8:active {
        background: var(--item-active-background, #b9daff);
    }

    .item.active.svelte-82qwg8 {
        background: var(--item-is-active-bg, #007aff);
        color: var(--item-is-active-color, #fff);
    }

    .item.first.svelte-82qwg8 {
        border-radius: var(--item-first-border-radius, 4px 4px 0 0);
    }

    .item.hover.svelte-82qwg8:not(.active) {
        background: var(--item-hover-bg, #e7f2ff);
        color: var(--item-hover-color, inherit);
    }

    .item.not-selectable.svelte-82qwg8,
    .item.hover.item.not-selectable.svelte-82qwg8,
    .item.active.item.not-selectable.svelte-82qwg8,
    .item.not-selectable.svelte-82qwg8:active {
        color: var(--item-is-not-selectable-color, #999);
        background: transparent;
    }

    .required.svelte-82qwg8 {
        opacity: 0;
        z-index: -1;
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
    }
`);var iM=G('<div class="list-item svelte-82qwg8" tabindex="-1" role="none"><div><!></div></div>'),sM=G('<div class="empty svelte-82qwg8">No options</div>'),lM=G('<div role="none"><!> <!> <!></div>'),uM=G('<span id="aria-selection" class="svelte-82qwg8"> </span> <span id="aria-context" class="svelte-82qwg8"> </span>',1),cM=G('<div class="multi-item-clear svelte-82qwg8"><!></div>'),dM=G('<div role="none"><span class="multi-item-text svelte-82qwg8"><!></span> <!></div>'),vM=G("<div><!></div>"),fM=G('<div class="icon loading svelte-82qwg8" aria-hidden="true"><!></div>'),pM=G('<button type="button" class="icon clear-select svelte-82qwg8"><!></button>'),hM=G('<div class="icon chevron svelte-82qwg8" aria-hidden="true"><!></div>'),gM=G('<input type="hidden" class="svelte-82qwg8">'),mM=G('<select class="required svelte-82qwg8" required tabindex="-1" aria-hidden="true"></select>'),bM=G('<div role="none"><!> <span aria-live="polite" aria-atomic="false" aria-relevant="additions text" class="a11y-text svelte-82qwg8"><!></span> <div class="prepend svelte-82qwg8"><!></div> <div class="value-container svelte-82qwg8"><!> <input></div> <div class="indicators svelte-82qwg8"><!> <!> <!></div> <!> <!></div>');function mi(e,t){var n=function(B){var ie={};for(var Oe in B.children&&(ie.default=!0),B.$$slots)ie[Oe]=!0;return ie}(t);lt(t,!1);var r,a=P(),i=P(),s=P(),l=P(),u=P(),d=P(),c=P(),v=P(),f=P(),g=OA(),m=h(t,"justValue",12,null),b=h(t,"filter",8,tM),j=h(t,"getItems",8,nM),w=h(t,"id",8,null),O=h(t,"name",8,null),T=h(t,"container",12,void 0),R=h(t,"input",12,void 0),k=h(t,"multiple",8,!1),D=h(t,"multiFullItemClearable",8,!1),H=h(t,"disabled",8,!1),V=h(t,"focused",12,!1),A=h(t,"value",12,null),J=h(t,"filterText",12,""),Z=h(t,"placeholder",8,"Please select"),Y=h(t,"placeholderAlwaysShow",8,!1),le=h(t,"items",12,null),Ae=h(t,"label",8,"label"),ce=h(t,"itemFilter",8,(B,ie,Oe)=>"".concat(B).toLowerCase().includes(ie.toLowerCase())),we=h(t,"groupBy",8,void 0),$e=h(t,"groupFilter",8,B=>B),Ne=h(t,"groupHeaderSelectable",8,!1),ye=h(t,"itemId",8,"value"),ze=h(t,"loadOptions",8,void 0),Re=h(t,"containerStyles",8,""),We=h(t,"hasError",8,!1),he=h(t,"filterSelectedItems",8,!0),ue=h(t,"required",8,!1),me=h(t,"closeListOnChange",8,!0),ot=h(t,"clearFilterTextOnBlur",8,!0),Ot=h(t,"createGroupHeaderItem",8,(B,ie)=>({value:B,[Ae()]:B})),ee=()=>o(c),q=h(t,"searchable",8,!0),ae=h(t,"inputStyles",8,""),$=h(t,"clearable",8,!0),_e=h(t,"loading",12,!1),ne=h(t,"listOpen",12,!1),Ue=h(t,"debounce",8,function(B){var ie=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1;clearTimeout(r),r=setTimeout(B,ie)}),X=h(t,"debounceWait",8,300),L=h(t,"hideEmptyState",8,!1),yt=h(t,"inputAttributes",24,()=>({})),Ze=h(t,"listAutoWidth",8,!0),Ce=h(t,"showChevron",8,!1),st=h(t,"listOffset",8,5),Me=h(t,"hoverItemIndex",12,0),at=h(t,"floatingConfig",24,()=>({})),Tt=h(t,"class",8,""),Je=P(),qt=P(),x=P(),_=P(),E=P();function U(B){return B.map((ie,Oe)=>({index:Oe,value:ie,label:"".concat(ie)}))}function te(B){var ie=[],Oe={};B.forEach(bn=>{var un=we()(bn);ie.includes(un)||(ie.push(un),Oe[un]=[],un&&Oe[un].push(Object.assign(Ot()(un,bn),{id:un,groupHeader:!0,selectable:Ne()}))),Oe[un].push(Object.assign({groupItem:!!un},bn))});var Dt=[];return $e()(ie).forEach(bn=>{Oe[bn]&&Dt.push(...Oe[bn])}),Dt}function fe(){var B=arguments.length>0&&arguments[0]!==void 0?arguments[0]:0,ie=arguments.length>1?arguments[1]:void 0;Me(B<0?0:B),!ie&&we()&&o(c)[Me()]&&!o(c)[Me()].selectable&&Yt(1)}function xe(){var B=!0;if(A()){var ie=[],Oe=[];A().forEach(Dt=>{ie.includes(Dt[ye()])?B=!1:(ie.push(Dt[ye()]),Oe.push(Dt))}),B||A(Oe)}return B}function N(B){var ie=B?B[ye()]:A()[ye()];return le().find(Oe=>Oe[ye()]===ie)}function Fe(B){return Ge.apply(this,arguments)}function Ge(){return(Ge=Rt(function*(B){var ie=A()[B];A().length===1?A(void 0):A(A().filter(Oe=>Oe!==ie)),g("clear",ie)})).apply(this,arguments)}function Et(B){if(V())switch(B.stopPropagation(),B.key){case"Escape":B.preventDefault(),$t();break;case"Enter":if(B.preventDefault(),ne()){if(o(c).length===0)break;var ie=o(c)[Me()];if(A()&&!k()&&A()[ye()]===ie[ye()]){$t();break}it(o(c)[Me()])}break;case"ArrowDown":B.preventDefault(),ne()?Yt(1):(ne(!0),p(Je,void 0));break;case"ArrowUp":B.preventDefault(),ne()?Yt(-1):(ne(!0),p(Je,void 0));break;case"Tab":if(ne()&&V()){if(o(c).length===0||A()&&A()[ye()]===o(c)[Me()][ye()])return $t();B.preventDefault(),it(o(c)[Me()]),$t()}break;case"Backspace":if(!k()||J().length>0)return;if(k()&&A()&&A().length>0){if(Fe(o(Je)!==void 0?o(Je):A().length-1),o(Je)===0||o(Je)===void 0)break;p(Je,A().length>o(Je)?o(Je)-1:void 0)}break;case"ArrowLeft":if(!A()||!k()||J().length>0)return;o(Je)===void 0?p(Je,A().length-1):A().length>o(Je)&&o(Je)!==0&&p(Je,o(Je)-1);break;case"ArrowRight":if(!A()||!k()||J().length>0||o(Je)===void 0)return;o(Je)===A().length-1?p(Je,void 0):o(Je)<A().length-1&&p(Je,o(Je)+1)}}function pe(B){var ie,Oe;V()&&R()===((ie=document)===null||ie===void 0?void 0:ie.activeElement)||(B&&g("focus",B),(Oe=R())===null||Oe===void 0||Oe.focus(),V(!0))}function vt(B){return Vt.apply(this,arguments)}function Vt(){return(Vt=Rt(function*(B){var ie;on||(ne()||V())&&(g("blur",B),$t(),V(!1),p(Je,void 0),(ie=R())===null||ie===void 0||ie.blur())})).apply(this,arguments)}function rr(){if(!H())return J().length>0?ne(!0):void ne(!ne())}function fn(){g("clear",A()),A(void 0),$t(),pe()}function $t(){ot()&&J(""),ne(!1)}EA(Rt(function*(){p(qt,A()),p(x,J()),p(_,k())})),Yr(()=>{ne()&&V(!0),V()&&R()&&R().focus()});var Ln=h(t,"ariaValues",8,B=>"Option ".concat(B,", selected.")),wt=h(t,"ariaListOpen",8,(B,ie)=>"You are currently focused on option ".concat(B,". There are ").concat(ie," results available.")),hn=h(t,"ariaFocused",8,()=>"Select is focused, type to refine list, press down to open the menu."),en,Jt=P(null);function gt(){clearTimeout(en),en=setTimeout(()=>{on=!1},100)}zo(()=>{var B;(B=o(Jt))===null||B===void 0||B.remove()});var on=!1;function it(B){B&&B.selectable!==!1&&function(ie){if(ie){J("");var Oe=Object.assign({},ie);if(Oe.groupHeader&&!Oe.selectable)return;A(k()?A()?A().concat([Oe]):[Oe]:A(Oe)),setTimeout(()=>{me()&&$t(),p(Je,void 0),g("change",A()),g("select",ie)})}}(B)}function Ft(B){on||Me(B)}function Yt(B){if(o(c).filter(Oe=>!Object.hasOwn(Oe,"selectable")||Oe.selectable===!0).length===0)return Me(0);B>0&&Me()===o(c).length-1?Me(0):B<0&&Me()===0?Me(o(c).length-1):Me(Me()+B);var ie=o(c)[Me()];ie&&ie.selectable===!1&&(B!==1&&B!==-1||Yt(B))}function En(B,ie,Oe){if(!k())return ie&&ie[Oe]===B[Oe]}var vr=Or,An=Or;function Or(B){return{update(ie){ie.scroll&&(gt(),B.scrollIntoView({behavior:"auto",block:"nearest"}))}}}var yr=P({strategy:"absolute",placement:"bottom-start",middleware:[XR(st()),ZR(),QR()],autoUpdate:!1}),[Sr,Ir,Er]=eM(o(yr)),Vn=P(!0);W(()=>(M(le()),M(A())),()=>{le(),A()&&function(){if(typeof A()=="string"){var B=(le()||[]).find(ie=>ie[ye()]===A());A(B||{[ye()]:A(),label:A()})}else k()&&Array.isArray(A())&&A().length>0&&A(A().map(ie=>typeof ie=="string"?{value:ie,label:ie}:ie))}()}),W(()=>(M(yt()),M(q())),()=>{!yt()&&q()||(p(E,Object.assign({autocapitalize:"none",autocomplete:"off",autocorrect:"off",spellcheck:!1,tabindex:0,type:"text","aria-autocomplete":"list"},yt())),w()&&go(E,o(E).id=w()),q()||go(E,o(E).readonly=!0))}),W(()=>M(k()),()=>{k()&&A()&&(Array.isArray(A())?A([...A()]):A([A()]))}),W(()=>(o(_),M(k())),()=>{o(_)&&!k()&&A()&&A(null)}),W(()=>(M(k()),M(A())),()=>{k()&&A()&&A().length>1&&xe()}),W(()=>M(A()),()=>{A()&&(k()?JSON.stringify(A())!==JSON.stringify(o(qt))&&xe()&&g("input",A()):o(qt)&&JSON.stringify(A()[ye()])===JSON.stringify(o(qt)[ye()])||g("input",A()))}),W(()=>(M(A()),M(k()),o(qt)),()=>{!A()&&k()&&o(qt)&&g("input",A())}),W(()=>(M(V()),M(R())),()=>{!V()&&R()&&$t()}),W(()=>(M(J()),o(x)),()=>{J()!==o(x)&&(ze()||J().length!==0)&&(ze()?Ue()(Rt(function*(){_e(!0);var B=yield j()({dispatch:g,loadOptions:ze(),convertStringItemsToObjects:U,filterText:J()});B?(_e(B.loading),ne(ne()?B.listOpen:J().length>0),V(ne()&&B.focused),le(we()?te(B.filteredItems):B.filteredItems)):(_e(!1),V(!0),ne(!0))}),X()):(ne(!0),k()&&p(Je,void 0)))}),W(()=>(M(b()),M(ze()),M(J()),M(le()),M(k()),M(A()),M(ye()),M(we()),M(Ae()),M(he()),M(ce())),()=>{p(c,b()({loadOptions:ze(),filterText:J(),items:le(),multiple:k(),value:A(),itemId:ye(),groupBy:we(),label:Ae(),filterSelectedItems:he(),itemFilter:ce(),convertStringItemsToObjects:U,filterGroupedItems:te}))}),W(()=>(M(k()),M(ne()),M(A()),o(c)),()=>{!k()&&ne()&&A()&&o(c)&&fe(o(c).findIndex(B=>B[ye()]===A()[ye()]),!0)}),W(()=>(M(ne()),M(k())),()=>{ne()&&k()&&Me(0)}),W(()=>M(J()),()=>{J()&&Me(0)}),W(()=>M(Me()),()=>{var B;B=Me(),g("hoverItem",B)}),W(()=>(M(k()),M(A())),()=>{p(a,k()?A()&&A().length>0:A())}),W(()=>(o(a),M(J())),()=>{p(i,o(a)&&J().length>0)}),W(()=>(o(a),M($()),M(H()),M(_e())),()=>{p(s,o(a)&&$()&&!H()&&!_e())}),W(()=>(M(Y()),M(k()),M(Z()),M(A())),()=>{var B;p(l,Y()&&k()||k()&&((B=A())===null||B===void 0?void 0:B.length)===0?Z():A()?"":Z())}),W(()=>(M(A()),M(k())),()=>{var B,ie;p(u,A()?(B=k(),ie=void 0,ie=B&&A().length>0?A().map(Oe=>Oe[Ae()]).join(", "):A()[Ae()],Ln()(ie)):"")}),W(()=>(o(c),M(Me()),M(V()),M(ne())),()=>{p(d,function(){if(!o(c)||o(c).length===0)return"";var B=o(c)[Me()];if(ne()&&B){var ie=o(c)?o(c).length:0;return wt()(B[Ae()],ie)}return hn()()}((o(c),Me(),V(),ne())))}),W(()=>M(le()),()=>{(function(B){B&&B.length!==0&&!B.some(ie=>typeof ie!="object")&&A()&&(k()?!A().some(ie=>!ie||!ie[ye()]):A()[ye()])&&(Array.isArray(A())?A(A().map(ie=>N(ie)||ie)):A(N()||A()))})(le())}),W(()=>(M(k()),M(A()),M(ye())),()=>{m((k(),A(),ye(),k()?A()?A().map(B=>B[ye()]):null:A()?A()[ye()]:A()))}),W(()=>(M(k()),o(qt),M(A())),()=>{k()||!o(qt)||A()||g("input",A())}),W(()=>(M(ne()),o(c),M(k()),M(A())),()=>{ne()&&o(c)&&!k()&&!A()&&fe()}),W(()=>o(c),()=>{(function(B){ne()&&g("filter",B)})(o(c))}),W(()=>(M(T()),M(at()),o(yr)),()=>{T()&&at()&&Er(Object.assign(o(yr),at()))}),W(()=>o(Jt),()=>{p(v,!!o(Jt))}),W(()=>(o(Jt),M(ne())),()=>{(function(B,ie){if(!B||!ie)return p(Vn,!0);setTimeout(()=>{p(Vn,!1)},0)})(o(Jt),ne())}),W(()=>(M(ne()),M(T()),o(Jt)),()=>{ne()&&T()&&o(Jt)&&function(){var{width:B}=T().getBoundingClientRect();go(Jt,o(Jt).style.width=Ze()?B+"px":"auto")}()}),W(()=>M(Me()),()=>{p(f,Me())}),W(()=>(M(R()),M(ne()),M(V())),()=>{R()&&ne()&&!V()&&pe()}),W(()=>(M(T()),M(at())),()=>{var B;T()&&((B=at())===null||B===void 0?void 0:B.autoUpdate)===void 0&&go(yr,o(yr).autoUpdate=!0)}),_n(),St();var Jn,gr=bM();be("click",Sa,function(B){var ie;ne()||V()||!T()||T().contains(B.target)||(ie=o(Jt))!==null&&ie!==void 0&&ie.contains(B.target)||vt()}),be("keydown",Sa,Et);var je=z(gr),an=B=>{var ie,Oe=lM(),Dt=z(Oe),bn=At=>{var Qn=xr();_r(ft(Qn),t,"list-prepend",{},null),I(At,Qn)};re(Dt,At=>{n["list-prepend"]&&At(bn)});var un=F(Dt,2),Rn=At=>{var Qn=xr();_r(ft(Qn),t,"list",{get filteredItems(){return o(c)}},null),I(At,Qn)},Xn=(At,Qn)=>{var xt=qe=>{var gn=xr();jr(ft(gn),1,()=>o(c),Cr,(Dn,xn,wr)=>{var to,C=iM(),oe=z(C);_r(z(oe),t,"item",{get item(){return o(xn)},index:wr},ve=>{var ke=Br();Ee(()=>{var Pe;return pt(ke,(Pe=o(xn))===null||Pe===void 0?void 0:Pe[Ae()])}),I(ve,ke)}),eo(oe,(ve,ke)=>vr?.(ve),()=>({scroll:En(o(xn),A(),ye()),listDom:o(v)})),eo(oe,(ve,ke)=>An?.(ve),()=>({scroll:o(f)===wr,listDom:o(v)})),Ee(ve=>to=Mt(oe,1,"item svelte-82qwg8",null,to,ve),[()=>{var ve,ke;return{"list-group-title":o(xn).groupHeader,active:En(o(xn),A(),ye()),first:(ke=wr,ke===0),hover:Me()===wr,"group-item":o(xn).groupItem,"not-selectable":((ve=o(xn))===null||ve===void 0?void 0:ve.selectable)===!1}}],de),be("mouseover",C,()=>Ft(wr)),be("focus",C,()=>Ft(wr)),be("click",C,xa(()=>function(ve){var{item:ke,i:Pe}=ve;if(ke?.selectable!==!1)return A()&&!k()&&A()[ye()]===ke[ye()]?$t():void(function(Be){return Be.groupHeader&&Be.selectable||Be.selectable||!Be.hasOwnProperty("selectable")}(ke)&&(Me(Pe),it(ke)))}({item:o(xn),i:wr}))),be("keydown",C,Ba(xa(function(ve){pl.call(this,t,ve)}))),I(Dn,C)}),I(qe,gn)},Nr=(qe,gn)=>{var Dn=xn=>{var wr=xr();_r(ft(wr),t,"empty",{},to=>{I(to,sM())}),I(xn,wr)};re(qe,xn=>{L()||xn(Dn)},gn)};re(At,qe=>{o(c).length>0?qe(xt):qe(Nr,!1)},Qn)};re(un,At=>{n.list?At(Rn):At(Xn,!1)});var Gn=F(un,2),ar=At=>{var Qn=xr();_r(ft(Qn),t,"list-append",{},null),I(At,Qn)};re(Gn,At=>{n["list-append"]&&At(ar)}),eo(Oe,At=>Ir?.(At)),tr(Oe,At=>p(Jt,At),()=>o(Jt)),qr(()=>be("scroll",Oe,gt)),qr(()=>be("pointerup",Oe,Ba(xa(function(At){pl.call(this,t,At)})))),qr(()=>be("mousedown",Oe,Ba(xa(function(At){pl.call(this,t,At)})))),Ee(At=>ie=Mt(Oe,1,"svelte-select-list svelte-82qwg8",null,ie,At),[()=>({prefloat:o(Vn)})],de),I(B,Oe)};re(je,B=>{ne()&&B(an)});var Q=F(je,2),Te=z(Q),tt=B=>{var ie=uM(),Oe=ft(ie),Dt=z(Oe),bn=z(F(Oe,2));Ee(()=>{pt(Dt,o(u)),pt(bn,o(d))}),I(B,ie)};re(Te,B=>{V()&&B(tt)});var Nt=F(Q,2);_r(z(Nt),t,"prepend",{},null);var et=F(Nt,2),Bt=z(et),yn=B=>{var ie=xr(),Oe=ft(ie),Dt=un=>{var Rn=xr();jr(ft(Rn),1,A,Cr,(Xn,Gn,ar)=>{var At,Qn=dM(),xt=z(Qn);_r(z(xt),t,"selection",{get selection(){return o(Gn)},index:ar},gn=>{var Dn=Br();Ee(()=>pt(Dn,o(Gn)[Ae()])),I(gn,Dn)});var Nr=F(xt,2),qe=gn=>{var Dn=cM();_r(z(Dn),t,"multi-clear-icon",{},xn=>{Pd(xn)}),be("pointerup",Dn,Ba(xa(()=>Fe(ar)))),I(gn,Dn)};re(Nr,gn=>{H()||D()||!Pd||gn(qe)}),Ee(gn=>At=Mt(Qn,1,"multi-item svelte-82qwg8",null,At,gn),[()=>({active:o(Je)===ar,disabled:H()})],de),be("click",Qn,Ba(()=>D()?Fe(ar):{})),be("keydown",Qn,Ba(xa(function(gn){pl.call(this,t,gn)}))),I(Xn,Qn)}),I(un,Rn)},bn=un=>{var Rn,Xn=vM();_r(z(Xn),t,"selection",{get selection(){return A()}},Gn=>{var ar=Br();Ee(()=>pt(ar,A()[Ae()])),I(Gn,ar)}),Ee(Gn=>Rn=Mt(Xn,1,"selected-item svelte-82qwg8",null,Rn,Gn),[()=>({"hide-selected-item":o(i)})],de),I(un,Xn)};re(Oe,un=>{k()?un(Dt):un(bn,!1)}),I(B,ie)};re(Bt,B=>{o(a)&&B(yn)});var Lt,Sn=F(Bt,2);tr(Sn,B=>R(B),()=>R());var mt=F(et,2),Ut=z(mt),dt=B=>{var ie=fM();_r(z(ie),t,"loading-icon",{},Oe=>{(function(Dt){I(Dt,aM())})(Oe)}),I(B,ie)};re(Ut,B=>{_e()&&B(dt)});var kt=F(Ut,2),Un=B=>{var ie=pM();_r(z(ie),t,"clear-icon",{},Oe=>{Pd(Oe)}),be("click",ie,fn),I(B,ie)};re(kt,B=>{o(s)&&B(Un)});var Fn=F(kt,2),Xt=B=>{var ie=hM();_r(z(ie),t,"chevron-icon",{get listOpen(){return ne()}},Oe=>{(function(Dt){I(Dt,rM())})(Oe)}),I(B,ie)};re(Fn,B=>{Ce()&&B(Xt)});var Wt=F(mt,2);_r(Wt,t,"input-hidden",{get value(){return A()}},B=>{var ie=gM();Ee(Oe=>{Cn(ie,"name",O()),Mi(ie,Oe)},[()=>A()?JSON.stringify(A()):null],de),I(B,ie)});var Gt=F(Wt,2),or=B=>{var ie=xr();_r(ft(ie),t,"required",{get value(){return A()}},Oe=>{I(Oe,mM())}),I(B,ie)};return re(Gt,B=>{!ue()||A()&&A().length!==0||B(or)}),qr(()=>be("pointerup",gr,Ba(rr))),tr(gr,B=>T(B),()=>T()),eo(gr,B=>Sr?.(B)),Ee(B=>{var ie;Jn=Mt(gr,1,"svelte-select ".concat((ie=Tt())!==null&&ie!==void 0?ie:""),"svelte-82qwg8",Jn,B),Ho(gr,Re()),Lt=wu(Sn,Lt,Se(Se({readOnly:!q()},o(E)),{},{placeholder:o(l),style:ae(),disabled:H()}),"svelte-82qwg8")},[()=>({multi:k(),disabled:H(),focused:V(),"list-open":ne(),"show-chevron":Ce(),error:We()})],de),be("keydown",Sn,Et),be("blur",Sn,vt),be("focus",Sn,pe),Hu(Sn,J),I(e,gr),_t(t,"getFilteredItems",ee),_t(t,"handleClear",fn),ut({getFilteredItems:ee,handleClear:fn})}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
table.jse-transform-wizard.svelte-qbze6z {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
}
table.jse-transform-wizard.svelte-qbze6z input:where(.svelte-qbze6z) {
  font-family: inherit;
  font-size: inherit;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) th:where(.svelte-qbze6z) {
  font-weight: normal;
  text-align: left;
  width: 60px;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) {
  width: 100%;
  display: flex;
  flex-direction: row;
  margin-bottom: calc(0.5 * var(--jse-padding, 10px));
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select .multi-item {
  align-items: center;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select .value-container {
  gap: 0 !important;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select.jse-filter-path {
  flex: 4;
  margin-right: calc(0.5 * var(--jse-padding, 10px));
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select.jse-filter-relation {
  flex: 1.5;
  margin-right: calc(0.5 * var(--jse-padding, 10px));
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select.jse-sort-path {
  flex: 3;
  margin-right: calc(0.5 * var(--jse-padding, 10px));
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select.jse-sort-direction {
  flex: 1;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select.jse-projection-paths {
  flex: 1;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .svelte-select input {
  box-sizing: border-box;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .jse-filter-value:where(.svelte-qbze6z) {
  flex: 4;
  padding: 4px 8px;
  border: var(--jse-input-border, 1px solid #d8dbdf);
  border-radius: var(--jse-input-radius, 3px);
  outline: none;
  background: var(--jse-input-background, var(--jse-background-color, #fff));
  color: inherit;
}
table.jse-transform-wizard.svelte-qbze6z tr:where(.svelte-qbze6z) td:where(.svelte-qbze6z) .jse-horizontal:where(.svelte-qbze6z) .jse-filter-value:where(.svelte-qbze6z):focus {
  border: var(--jse-input-border-focus, 1px solid var(--jse-input-border-focus, var(--jse-theme-color, #3883fa)));
}`);var xM=G('<table class="jse-transform-wizard svelte-qbze6z"><tbody><tr class="svelte-qbze6z"><th class="svelte-qbze6z">Filter</th><td class="svelte-qbze6z"><div class="jse-horizontal svelte-qbze6z"><!> <!> <input class="jse-filter-value svelte-qbze6z"></div></td></tr><tr class="svelte-qbze6z"><th class="svelte-qbze6z">Sort</th><td class="svelte-qbze6z"><div class="jse-horizontal svelte-qbze6z"><!> <!></div></td></tr><tr class="svelte-qbze6z"><th class="svelte-qbze6z">Pick</th><td class="svelte-qbze6z"><div class="jse-horizontal svelte-qbze6z"><!></div></td></tr></tbody></table>');function jM(e,t){var n,r,a,i,s;lt(t,!1);var l=P(void 0,!0),u=P(void 0,!0),d=P(void 0,!0),c=P(void 0,!0),v=P(void 0,!0),f=P(void 0,!0),g=Fr("jsoneditor:TransformWizard"),m=h(t,"json",9),b=h(t,"queryOptions",29,()=>({})),j=h(t,"onChange",9),w=["==","!=","<","<=",">",">="].map(he=>({value:he,label:he})),O=[{value:"asc",label:"ascending"},{value:"desc",label:"descending"}],T=P((n=b())!==null&&n!==void 0&&(n=n.filter)!==null&&n!==void 0&&n.path?Ha(b().filter.path):void 0,!0),R=P((r=w.find(he=>{var ue;return he.value===((ue=b().filter)===null||ue===void 0?void 0:ue.relation)}))!==null&&r!==void 0?r:w[0],!0),k=P(((a=b())===null||a===void 0||(a=a.filter)===null||a===void 0?void 0:a.value)||"",!0),D=P((i=b())!==null&&i!==void 0&&(i=i.sort)!==null&&i!==void 0&&i.path?Ha(b().sort.path):void 0,!0),H=P((s=O.find(he=>{var ue;return he.value===((ue=b().sort)===null||ue===void 0?void 0:ue.direction)}))!==null&&s!==void 0?s:O[0],!0);W(()=>M(m()),()=>{p(l,Array.isArray(m()))}),W(()=>(o(l),M(m())),()=>{p(u,o(l)?vv(m()):[])}),W(()=>(o(l),M(m())),()=>{p(d,o(l)?vv(m(),!0):[])}),W(()=>(o(u),Ha),()=>{p(c,o(u).map(Ha))}),W(()=>(o(d),Ha),()=>{p(v,o(d)?o(d).map(Ha):[])}),W(()=>(M(b()),o(v),Zt),()=>{var he;p(f,(he=b())!==null&&he!==void 0&&(he=he.projection)!==null&&he!==void 0&&he.paths&&o(v)?b().projection.paths.map(ue=>o(v).find(me=>Zt(me.value,ue))).filter(ue=>!!ue):void 0)}),W(()=>o(T),()=>{var he,ue,me;ue=(he=o(T))===null||he===void 0?void 0:he.value,Zt((me=b())===null||me===void 0||(me=me.filter)===null||me===void 0?void 0:me.path,ue)||(g("changeFilterPath",ue),b(ra(b(),["filter","path"],ue,!0)),j()(b()))}),W(()=>o(R),()=>{var he,ue,me;ue=(he=o(R))===null||he===void 0?void 0:he.value,Zt((me=b())===null||me===void 0||(me=me.filter)===null||me===void 0?void 0:me.relation,ue)||(g("changeFilterRelation",ue),b(ra(b(),["filter","relation"],ue,!0)),j()(b()))}),W(()=>o(k),()=>{var he,ue;he=o(k),Zt((ue=b())===null||ue===void 0||(ue=ue.filter)===null||ue===void 0?void 0:ue.value,he)||(g("changeFilterValue",he),b(ra(b(),["filter","value"],he,!0)),j()(b()))}),W(()=>o(D),()=>{var he,ue,me;ue=(he=o(D))===null||he===void 0?void 0:he.value,Zt((me=b())===null||me===void 0||(me=me.sort)===null||me===void 0?void 0:me.path,ue)||(g("changeSortPath",ue),b(ra(b(),["sort","path"],ue,!0)),j()(b()))}),W(()=>o(H),()=>{var he,ue,me;ue=(he=o(H))===null||he===void 0?void 0:he.value,Zt((me=b())===null||me===void 0||(me=me.sort)===null||me===void 0?void 0:me.direction,ue)||(g("changeSortDirection",ue),b(ra(b(),["sort","direction"],ue,!0)),j()(b()))}),W(()=>o(f),()=>{(function(he){var ue;Zt((ue=b())===null||ue===void 0||(ue=ue.projection)===null||ue===void 0?void 0:ue.paths,he)||(g("changeProjectionPaths",he),b(ra(b(),["projection","paths"],he,!0)),j()(b()))})(o(f)?o(f).map(he=>he.value):void 0)}),_n(),St(!0);var V=xM(),A=z(V),J=z(A),Z=F(z(J)),Y=z(Z),le=z(Y);mi(le,{class:"jse-filter-path",showChevron:!0,get items(){return o(c)},get value(){return o(T)},set value(he){p(T,he)},$$legacy:!0});var Ae=F(le,2);mi(Ae,{class:"jse-filter-relation",showChevron:!0,clearable:!1,items:w,get value(){return o(R)},set value(he){p(R,he)},$$legacy:!0});var ce=F(Ae,2),we=F(J),$e=F(z(we)),Ne=z($e),ye=z(Ne);mi(ye,{class:"jse-sort-path",showChevron:!0,get items(){return o(c)},get value(){return o(D)},set value(he){p(D,he)},$$legacy:!0}),mi(F(ye,2),{class:"jse-sort-direction",showChevron:!0,clearable:!1,items:O,get value(){return o(H)},set value(he){p(H,he)},$$legacy:!0});var ze=F(we),Re=F(z(ze)),We=z(Re);mi(z(We),{class:"jse-projection-paths",multiple:!0,showChevron:!0,get items(){return o(v)},get value(){return o(f)},set value(he){p(f,he)},$$legacy:!0}),Hu(ce,()=>o(k),he=>p(k,he)),I(e,V),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-select-query-language.svelte-atm4um {
  position: relative;
  width: 32px;
}
.jse-select-query-language.svelte-atm4um .jse-select-query-language-container:where(.svelte-atm4um) {
  position: absolute;
  top: 0;
  right: 0;
  display: flex;
  flex-direction: column;
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
}
.jse-select-query-language.svelte-atm4um .jse-select-query-language-container:where(.svelte-atm4um) .jse-query-language:where(.svelte-atm4um) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  text-align: left;
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  white-space: nowrap;
  color: var(--jse-context-menu-color, var(--jse-text-color-inverse, #fff));
  background: var(--jse-context-menu-background, #656565);
}
.jse-select-query-language.svelte-atm4um .jse-select-query-language-container:where(.svelte-atm4um) .jse-query-language:where(.svelte-atm4um):hover {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
}`);var yM=G('<button type="button"><!> </button>'),wM=G('<div class="jse-select-query-language svelte-atm4um"><div class="jse-select-query-language-container svelte-atm4um"></div></div>');function kM(e,t){lt(t,!1);var n=h(t,"queryLanguages",8),r=h(t,"queryLanguageId",12),a=h(t,"onChangeQueryLanguage",8);St();var i=wM();jr(z(i),5,n,Cr,(s,l)=>{var u,d=yM(),c=z(d),v=m=>{dn(m,{data:qg})},f=m=>{dn(m,{data:$g})};re(c,m=>{o(l).id===r()?m(v):m(f,!1)});var g=F(c);Ee(m=>{var b;u=Mt(d,1,"jse-query-language svelte-atm4um",null,u,m),Cn(d,"title","Select ".concat(o(l).name," as query language")),pt(g," ".concat((b=o(l).name)!==null&&b!==void 0?b:""))},[()=>({selected:o(l).id===r()})],de),be("click",d,()=>{return m=o(l).id,r(m),void a()(m);var m}),I(s,d)}),I(e,i),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-header.svelte-1y24war {
  display: flex;
  background: var(--jse-theme-color, #3883fa);
  color: var(--jse-menu-color, var(--jse-text-color-inverse, #fff));
}
.jse-header.svelte-1y24war .jse-title:where(.svelte-1y24war) {
  flex: 1;
  padding: 5px;
  vertical-align: middle;
}
.jse-header.svelte-1y24war button:where(.svelte-1y24war) {
  border: none;
  background: transparent;
  min-width: 32px;
  color: inherit;
  cursor: pointer;
}
.jse-header.svelte-1y24war button:where(.svelte-1y24war):hover {
  background: rgba(255, 255, 255, 0.1);
}`);var _M=G('<button type="button" class="jse-fullscreen svelte-1y24war" title="Toggle full screen"><!></button>'),SM=G('<div class="jse-header svelte-1y24war"><div class="jse-title svelte-1y24war"> </div> <!> <!> <button type="button" class="jse-close svelte-1y24war"><!></button></div>');function rc(e,t){lt(t,!1);var n=h(t,"title",9,"Modal"),r=h(t,"fullScreenButton",9,!1),a=h(t,"fullscreen",13,!1),i=h(t,"onClose",9,void 0);St(!0);var s=SM(),l=z(s),u=z(l),d=F(l,2);_r(d,t,"actions",{},null);var c=F(d,2),v=g=>{var m=_M(),b=z(m),j=de(()=>a()?tk:nk);dn(b,{get data(){return o(j)}}),be("click",m,()=>a(!a())),I(g,m)};re(c,g=>{r()&&g(v)});var f=F(c,2);dn(z(f),{data:vc}),Ee(()=>pt(u,n())),be("click",f,()=>{var g;return(g=i())===null||g===void 0?void 0:g()}),I(e,s),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-config.svelte-1kpylsp {
  border: none;
  background: transparent;
  min-width: 32px;
  color: inherit;
  cursor: pointer;
}
.jse-config.svelte-1kpylsp:hover {
  background: rgba(255, 255, 255, 0.1);
}
.jse-config.hide.svelte-1kpylsp {
  display: none;
}`);var CM=G('<button slot="actions" type="button" title="Select a query language"><!></button>'),Td=Fr("jsoneditor:AutoScrollHandler");function sg(e){var t,n;function r(l){return l<20?200:l<50?400:1200}function a(){if(e){var l=.05*(t||0);e.scrollTop+=l}}function i(l){n&&l===t||(s(),Td("startAutoScroll",l),t=l,n=setInterval(a,50))}function s(){n&&(Td("stopAutoScroll"),clearInterval(n),n=void 0,t=void 0)}return Td("createAutoScrollHandler",e),{onDrag:function(l){if(e){var u=l.clientY,{top:d,bottom:c}=e.getBoundingClientRect();u<d?i(-r(d-u)):u>c?i(r(u-c)):s()}},onDragEnd:function(){s()}}}var OM=(e,t,n,r)=>(e/=r/2)<1?n/2*e*e+t:-n/2*(--e*(e-2)-1)+t,Tw=()=>{var e,t,n,r,a,i,s,l,u,d,c,v,f;function g(j){return j.getBoundingClientRect().top-(e.getBoundingClientRect?e.getBoundingClientRect().top:0)+n}function m(j){e.scrollTo?e.scrollTo(e.scrollLeft,j):e.scrollTop=j}function b(j){d||(d=j),m(i(c=j-d,n,l,u)),f=!0,c<u?requestAnimationFrame(b):function(){m(n+l),t&&s&&(t.setAttribute("tabindex","-1"),t.focus()),typeof v=="function"&&v(),d=0,f=!1}()}return function(j){var w=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};switch(u=1e3,a=w.offset||0,v=w.callback,i=w.easing||OM,s=w.a11y||!1,typeof w.container){case"object":e=w.container;break;case"string":e=document.querySelector(w.container);break;default:e=window.document.documentElement}switch(n=e.scrollTop,typeof j){case"number":t=void 0,s=!1,r=n+j;break;case"object":r=g(t=j);break;case"string":t=document.querySelector(j),r=g(t)}switch(l=r-n+a,typeof w.duration){case"number":u=w.duration;break;case"function":u=w.duration(l)}f?d=0:requestAnimationFrame(b)}};function ss(e,t){var n=Date.now(),r=e();return t(Date.now()-n),r}var es=Fr("validation"),EM={createObjectDocumentState:()=>({type:"object",properties:{}}),createArrayDocumentState:()=>({type:"array",items:[]}),createValueDocumentState:()=>({type:"value"})};function lg(e,t,n,r){return up(e,t,n,r,EM)}function Iw(e,t,n,r){if(es("validateJSON"),!t)return[];if(n!==r){var a=n.stringify(e);return t(a!==void 0?r.parse(a):void 0)}return t(e)}function AM(e,t,n,r){if(es("validateText"),e.length>104857600)return{validationErrors:[{path:[],message:"Validation turned off: the document is too large",severity:jo.info}]};if(e.length!==0)try{var a=ss(()=>n.parse(e),u=>es("validate: parsed json in ".concat(u," ms")));if(!t)return;var i=n===r?a:ss(()=>r.parse(e),u=>es("validate: parsed json with the validationParser in ".concat(u," ms"))),s=ss(()=>t(i),u=>es("validate: validated json in ".concat(u," ms")));return Pn(s)?void 0:{validationErrors:s}}catch(u){var l=ss(()=>function(d,c){if(d.length>hR)return!1;try{return c.parse(Wo(d)),!0}catch{return!1}}(e,n),d=>es("validate: checked whether repairable in ".concat(d," ms")));return{parseError:ys(e,u.message||u.toString()),isRepairable:l}}}var gu=Fr("jsoneditor:FocusTracker");function bp(e){var t,{onMount:n,onDestroy:r,getWindow:a,hasFocus:i,onFocus:s,onBlur:l}=e,u=!1;function d(){var v=i();v&&(clearTimeout(t),u||(gu("focus"),s(),u=v))}function c(){u&&(clearTimeout(t),t=setTimeout(()=>{i()||(gu("blur"),u=!1,l())}))}n(()=>{gu("mount FocusTracker");var v=a();v&&(v.addEventListener("focusin",d,!0),v.addEventListener("focusout",c,!0))}),r(()=>{gu("destroy FocusTracker");var v=a();v&&(v.removeEventListener("focusin",d,!0),v.removeEventListener("focusout",c,!0))})}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-message.svelte-czprfx {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  padding: var(--jse-padding, 10px);
  display: flex;
  gap: var(--jse-padding, 10px);
  flex-wrap: wrap;
  align-items: stretch;
}
.jse-message.jse-success.svelte-czprfx {
  background: var(--message-success-background, #9ac45d);
  color: var(--jse-message-success-color, #fff);
}
.jse-message.svelte-czprfx .jse-text:where(.svelte-czprfx) {
  display: flex;
  flex: 1;
  min-width: 60%;
  align-items: center;
}
.jse-message.svelte-czprfx .jse-text.jse-clickable:where(.svelte-czprfx) {
  cursor: pointer;
}
.jse-message.svelte-czprfx .jse-text.jse-clickable:where(.svelte-czprfx):hover {
  background-color: rgba(255, 255, 255, 0.1);
}
.jse-message.jse-error.svelte-czprfx {
  background: var(--jse-message-error-background, var(--jse-error-color, #ee5341));
  color: var(--jse-message-error-color, #fff);
}
.jse-message.jse-warning.svelte-czprfx {
  background: var(--jse-message-warning-background, #ffde5c);
  color: var(--jse-message-warning-color, #4d4d4d);
}
.jse-message.jse-info.svelte-czprfx {
  background: var(--jse-message-info-background, #4f91ff);
  color: var(--jse-message-info-color, #fff);
}
.jse-message.svelte-czprfx .jse-actions:where(.svelte-czprfx) {
  display: flex;
  gap: var(--jse-padding, 10px);
}
.jse-message.svelte-czprfx .jse-actions:where(.svelte-czprfx) button.jse-action:where(.svelte-czprfx) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-message-action-background, rgba(255, 255, 255, 0.2));
  color: inherit;
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px);
}
.jse-message.svelte-czprfx .jse-actions:where(.svelte-czprfx) button.jse-action:where(.svelte-czprfx):hover {
  background: var(--jse-message-action-background-highlight, rgba(255, 255, 255, 0.3));
}`);var RM=G('<button type="button" class="jse-button jse-action jse-primary svelte-czprfx"><!> </button>'),MM=G('<div><div role="button" tabindex="-1"><div class="jse-text-centered"><!> </div></div> <div class="jse-actions svelte-czprfx"></div></div>');function Yo(e,t){lt(t,!1);var n=h(t,"type",9,"success"),r=h(t,"icon",9,void 0),a=h(t,"message",9,void 0),i=h(t,"actions",25,()=>[]),s=h(t,"onClick",9,void 0),l=h(t,"onClose",9,void 0);l()&&zo(l()),St(!0);var u,d=MM(),c=z(d),v=z(c),f=z(v),g=b=>{dn(b,{get data(){return r()}})};re(f,b=>{r()&&b(g)});var m=F(f);jr(F(c,2),5,i,Cr,(b,j)=>{var w=RM(),O=z(w),T=k=>{dn(k,{get data(){return o(j).icon}})};re(O,k=>{o(j).icon&&k(T)});var R=F(O);Ee(()=>{var k;Cn(w,"title",o(j).title),w.disabled=o(j).disabled,pt(R," ".concat((k=o(j).text)!==null&&k!==void 0?k:""))}),be("click",w,()=>{o(j).onClick&&o(j).onClick()}),be("mousedown",w,()=>{o(j).onMouseDown&&o(j).onMouseDown()}),I(b,w)}),Ee(b=>{var j,w;Mt(d,1,"jse-message jse-".concat((j=n())!==null&&j!==void 0?j:""),"svelte-czprfx"),u=Mt(c,1,"jse-text svelte-czprfx",null,u,b),pt(m," ".concat((w=a())!==null&&w!==void 0?w:""))},[()=>({"jse-clickable":!!s()})],de),be("click",c,function(){s()&&s()()}),I(e,d),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-validation-errors-overview.svelte-1uindol {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  overflow: auto;
  max-height: 25%;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) {
  border-collapse: collapse;
  width: 100%;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) {
  cursor: pointer;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr.jse-validation-error:where(.svelte-1uindol) {
  background: var(--jse-message-error-background, var(--jse-error-color, #ee5341));
  color: var(--jse-message-error-color, #fff);
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr.jse-validation-warning:where(.svelte-1uindol) {
  background: var(--jse-message-warning-background, #ffde5c);
  color: var(--jse-message-warning-color, #4d4d4d);
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr.jse-validation-warning:where(.svelte-1uindol):hover {
  filter: brightness(105%);
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr.jse-validation-info:where(.svelte-1uindol) {
  background: var(--jse-message-info-background, #4f91ff);
  color: var(--jse-message-info-color, #fff);
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol):hover {
  filter: brightness(110%);
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) td:where(.svelte-1uindol) {
  padding: 4px var(--jse-padding, 10px);
  vertical-align: middle;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) td.jse-validation-error-icon:where(.svelte-1uindol) {
  width: 36px;
  box-sizing: border-box;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) td.jse-validation-error-action:where(.svelte-1uindol) {
  width: 36px;
  box-sizing: border-box;
  padding: 0;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) td.jse-validation-error-action:where(.svelte-1uindol) button.jse-validation-errors-collapse:where(.svelte-1uindol) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  width: 36px;
  height: 26px;
  cursor: pointer;
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) td.jse-validation-error-action:where(.svelte-1uindol) button.jse-validation-errors-collapse:where(.svelte-1uindol):hover {
  background-color: rgba(255, 255, 255, 0.2);
}
.jse-validation-errors-overview.svelte-1uindol table:where(.svelte-1uindol) tr:where(.svelte-1uindol) td:where(.svelte-1uindol) div.jse-validation-errors-expand:where(.svelte-1uindol) {
  display: inline-block;
  position: relative;
  top: 3px;
}`);var zM=G('<button type="button" class="jse-validation-errors-collapse svelte-1uindol" title="Collapse validation errors"><!></button>'),PM=G('<tr tabindex="0"><td class="jse-validation-error-icon svelte-1uindol"><!></td><td class="jse-validation-error-path svelte-1uindol"> </td><td class="jse-validation-error-message svelte-1uindol"> </td><td class="jse-validation-error-action svelte-1uindol"><!></td></tr>'),TM=G('<tr class="jse-validation-error svelte-1uindol"><td class="svelte-1uindol"></td><td class="svelte-1uindol"></td><td class="svelte-1uindol"> </td><td class="svelte-1uindol"></td></tr>'),IM=G('<table class="jse-validation-errors-overview-expanded svelte-1uindol"><tbody><!><!></tbody></table>'),NM=G('<table class="jse-validation-errors-overview-collapsed svelte-1uindol"><tbody><tr><td class="jse-validation-error-icon svelte-1uindol"><!></td><td class="jse-validation-error-count svelte-1uindol"> <div class="jse-validation-errors-expand svelte-1uindol"><!></div></td></tr></tbody></table>'),LM=G('<div class="jse-validation-errors-overview svelte-1uindol"><!></div>');function xp(e,t){lt(t,!1);var n=P(void 0,!0),r=h(t,"validationErrors",9),a=h(t,"selectError",9),i=P(!0,!0);function s(){p(i,!1)}function l(){p(i,!0)}W(()=>M(r()),()=>{p(n,r().length)}),_n(),St(!0);var u=xr(),d=ft(u),c=v=>{var f=LM(),g=z(f),m=j=>{var w=IM(),O=z(w),T=z(O);jr(T,1,()=>Vy(r(),100),Cr,(D,H,V)=>{var A=PM(),J=z(A);dn(z(J),{data:Ei});var Z=F(J),Y=z(Z),le=F(Z),Ae=z(le),ce=z(F(le)),we=$e=>{var Ne=zM();dn(z(Ne),{data:dk}),be("click",Ne,xa(s)),I($e,Ne)};re(ce,$e=>{V===0&&r().length>1&&$e(we)}),Ee($e=>{var Ne;Mt(A,1,"jse-validation-".concat((Ne=o(H).severity)!==null&&Ne!==void 0?Ne:""),"svelte-1uindol"),pt(Y,$e),pt(Ae,o(H).message)},[()=>qo(o(H).path)],de),be("click",A,()=>{setTimeout(()=>a()(o(H)))}),I(D,A)});var R=F(T),k=D=>{var H=TM(),V=F(z(H),2),A=z(V);Ee(()=>pt(A,"(and ".concat(o(n)-100," more errors)"))),I(D,H)};re(R,D=>{o(n)>100&&D(k)}),I(j,w)},b=j=>{var w=NM(),O=z(w),T=z(O),R=z(T);dn(z(R),{data:Ei});var k=z(F(R));dn(z(F(k)),{data:Gg}),Ee(D=>{var H;Mt(T,1,"jse-validation-".concat(D??""),"svelte-1uindol"),pt(k,"".concat((H=o(n))!==null&&H!==void 0?H:""," validation errors "))},[()=>{return D=r(),[jo.error,jo.warning,jo.info].find(H=>D.some(V=>V.severity===H));var D}],de),be("click",T,l),I(j,w)};re(g,j=>{o(i)||o(n)===1?j(m):j(b,!1)}),I(v,f)};re(d,v=>{Pn(r())||v(c)}),I(e,u),ut()}function oc(e,t){if(e)return e.addEventListener("keydown",n),{destroy(){e.removeEventListener("keydown",n)}};function n(r){r.key==="Escape"&&(r.preventDefault(),r.stopPropagation(),t())}}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
dialog.jse-modal.svelte-1s9c2ql {
  border-radius: 3px;
  font-size: var(--jse-padding, 10px);
  border: none;
  padding: 0;
  display: flex;
  min-width: 0;
  margin: auto;
  overflow: visible;
  transition: width 0.1s ease-in-out, height 0.1s ease-in-out;
}
dialog.jse-modal.jse-sort-modal.svelte-1s9c2ql {
  width: 400px;
}
dialog.jse-modal.jse-repair-modal.svelte-1s9c2ql {
  width: 600px;
  height: 500px;
}
dialog.jse-modal.jse-jsoneditor-modal.svelte-1s9c2ql {
  width: 800px;
  height: 600px;
}
dialog.jse-modal.jse-transform-modal.svelte-1s9c2ql {
  width: 1200px;
  height: 800px;
}
dialog.jse-modal.jse-fullscreen.svelte-1s9c2ql {
  width: 100%;
  height: 100%;
}
dialog.jse-modal.svelte-1s9c2ql::backdrop {
  background: var(--jse-overlay-background, rgba(0, 0, 0, 0.3));
}
dialog.jse-modal[open].svelte-1s9c2ql {
  animation: svelte-1s9c2ql-zoom 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}
dialog.jse-modal[open].svelte-1s9c2ql::backdrop {
  animation: svelte-1s9c2ql-fade 0.2s ease-out;
}
dialog.jse-modal.svelte-1s9c2ql .jse-modal-inner:where(.svelte-1s9c2ql) {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  padding: 0;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  line-height: normal;
  background: var(--jse-modal-background, #f5f5f5);
  color: var(--jse-text-color, #4d4d4d);
}
@keyframes svelte-1s9c2ql-zoom {
  from {
    transform: scale(0.95);
  }
  to {
    transform: scale(1);
  }
}
@keyframes svelte-1s9c2ql-fade {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
dialog.jse-modal.svelte-1s9c2ql .svelte-select {
  --border: var(--jse-svelte-select-border, 1px solid #d8dbdf);
  --item-is-active-bg: var(--jse-item-is-active-bg, #3883fa);
  --border-radius: var(--jse-svelte-select-border-radius, 3px);
  --background: var(--jse-svelte-select-background, #fff);
  --padding: var(--jse-svelte-select-padding, 0 10px);
  --multi-select-padding: var(--jse-svelte-select-multi-select-padding, 0 10px);
  --font-size: var(--jse-svelte-select-font-size, var(--jse-font-size, 16px));
  --height: 36px;
  --multi-item-height: 28px;
  --multi-item-margin: 2px;
  --multi-item-padding: 2px 8px;
  --multi-item-border-radius: 6px;
  --indicator-top: 8px;
}`);var UM=G('<dialog><div class="jse-modal-inner svelte-1s9c2ql"><!></div></dialog>');function Nl(e,t){lt(t,!1);var n=h(t,"className",8,void 0),r=h(t,"fullscreen",8,!1),a=h(t,"onClose",8),i=P();function s(){a()()}Yr(()=>o(i).showModal()),zo(()=>o(i).close()),St();var l,u=UM(),d=z(u);_r(z(d),t,"default",{},null),tr(u,c=>p(i,c),()=>o(i)),qr(()=>be("close",u,s)),qr(()=>{return be("pointerdown",u,(c=s,function(){for(var v=arguments.length,f=new Array(v),g=0;g<v;g++)f[g]=arguments[g];f[0].target===this&&c?.apply(this,f)}));var c}),qr(()=>be("cancel",u,Ba(function(c){pl.call(this,t,c)}))),eo(u,(c,v)=>oc?.(c,v),()=>s),Ee((c,v)=>l=Mt(u,1,c,"svelte-1s9c2ql",l,v),[()=>ai(Ks("jse-modal",n())),()=>({"jse-fullscreen":r()})],de),I(e,u),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-modal-contents.svelte-189qksl {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 20px;
  overflow: auto;
  min-width: 0;
  min-height: 0;
}
.jse-modal-contents.svelte-189qksl .jse-actions:where(.svelte-189qksl) {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding-top: var(--jse-padding, 10px);
}
.jse-modal-contents.svelte-189qksl .jse-actions:where(.svelte-189qksl) button.jse-primary:where(.svelte-189qksl) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-primary-background, var(--jse-theme-color, #3883fa));
  color: var(--jse-button-primary-color, #fff);
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-modal-contents.svelte-189qksl .jse-actions:where(.svelte-189qksl) button.jse-primary:where(.svelte-189qksl):hover {
  background: var(--jse-button-primary-background-highlight, var(--jse-theme-color-highlight, #5f9dff));
}
.jse-modal-contents.svelte-189qksl .jse-actions:where(.svelte-189qksl) button.jse-primary:where(.svelte-189qksl):disabled {
  background: var(--jse-button-primary-background-disabled, #9d9d9d);
}

.jse-shortcuts.svelte-189qksl {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  margin: calc(2 * var(--jse-padding, 10px)) 0;
}
.jse-shortcuts.svelte-189qksl .jse-shortcut:where(.svelte-189qksl) .jse-key:where(.svelte-189qksl) {
  font-size: 200%;
  color: var(--jse-theme-color, #3883fa);
}`);var DM=G('<!> <div class="jse-modal-contents svelte-189qksl"><div>Clipboard permission is disabled by your browser. You can use:</div> <div class="jse-shortcuts svelte-189qksl"><div class="jse-shortcut svelte-189qksl"><div class="jse-key svelte-189qksl"></div> for copy</div> <div class="jse-shortcut svelte-189qksl"><div class="jse-key svelte-189qksl"></div> for cut</div> <div class="jse-shortcut svelte-189qksl"><div class="jse-key svelte-189qksl"></div> for paste</div></div> <div class="jse-actions svelte-189qksl"><button type="button" class="jse-primary svelte-189qksl">Close</button></div></div>',1);function Nw(e,t){lt(t,!1);var n=h(t,"onClose",9),r=tp()?"⌘":"Ctrl";St(!0),Nl(e,{get onClose(){return n()},className:"jse-copy-paste",children:(a,i)=>{var s=DM(),l=ft(s);rc(l,{title:"Copying and pasting",get onClose(){return n()}});var u=F(l,2),d=F(z(u),2),c=z(d);z(c).textContent="".concat(r??"","+C");var v=F(c,2);z(v).textContent="".concat(r??"","+X"),z(F(v,2)).textContent="".concat(r??"","+V"),be("click",z(F(d,2)),function(){for(var f,g=arguments.length,m=new Array(g),b=0;b<g;b++)m[b]=arguments[b];(f=n())===null||f===void 0||f.apply(this,m)}),I(a,s)},$$slots:{default:!0}}),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-menu.svelte-pf7s2l {
  background: var(--jse-theme-color, #3883fa);
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size-main-menu, 14px);
  color: var(--jse-menu-color, var(--jse-text-color-inverse, #fff));
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
  position: relative;
}
.jse-menu.svelte-pf7s2l .jse-button:where(.svelte-pf7s2l) {
  font-family: inherit;
  font-size: inherit;
  line-height: 1.5em;
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  width: var(--jse-menu-button-size, 32px);
  height: var(--jse-menu-button-size, 32px);
  padding: calc(0.5 * var(--jse-padding, 10px));
  margin: 0;
  border-radius: 0;
  display: inline-flex;
  align-items: center;
  text-align: center;
  justify-content: center;
}
.jse-menu.svelte-pf7s2l .jse-button:where(.svelte-pf7s2l):hover, .jse-menu.svelte-pf7s2l .jse-button:where(.svelte-pf7s2l):focus {
  background: var(--jse-theme-color-highlight, #5f9dff);
}
.jse-menu.svelte-pf7s2l .jse-button:where(.svelte-pf7s2l):disabled {
  color: var(--jse-menu-color, var(--jse-text-color-inverse, #fff));
  opacity: 0.5;
  background: transparent;
}
.jse-menu.svelte-pf7s2l .jse-button.jse-group-button:where(.svelte-pf7s2l) {
  width: auto;
  height: calc(var(--jse-menu-button-size, 32px) - var(--jse-padding, 10px));
  margin: calc(0.5 * var(--jse-padding, 10px)) 0;
  padding: 0 calc(0.5 * var(--jse-padding, 10px)) 1px;
  border: 1px solid var(--jse-menu-color, var(--jse-text-color-inverse, #fff));
}
.jse-menu.svelte-pf7s2l .jse-button.jse-group-button:where(.svelte-pf7s2l):not(.jse-last) {
  border-right: none;
}
.jse-menu.svelte-pf7s2l .jse-button.jse-group-button.jse-first:where(.svelte-pf7s2l) {
  margin-left: calc(0.5 * var(--jse-padding, 10px));
}
.jse-menu.svelte-pf7s2l .jse-button.jse-group-button.jse-last:where(.svelte-pf7s2l) {
  margin-right: calc(0.5 * var(--jse-padding, 10px));
}
.jse-menu.svelte-pf7s2l .jse-button.jse-group-button:where(.svelte-pf7s2l):hover, .jse-menu.svelte-pf7s2l .jse-button.jse-group-button:where(.svelte-pf7s2l):focus {
  background: var(--jse-theme-color-highlight, #5f9dff);
}
.jse-menu.svelte-pf7s2l .jse-button.jse-group-button.jse-selected:where(.svelte-pf7s2l) {
  background: var(--jse-menu-color, var(--jse-text-color-inverse, #fff));
  color: var(--jse-theme-color, #3883fa);
}
.jse-menu.svelte-pf7s2l .jse-space:where(.svelte-pf7s2l) {
  flex: 1;
}
.jse-menu.svelte-pf7s2l .jse-separator:where(.svelte-pf7s2l) {
  background: var(--jse-menu-color, var(--jse-text-color-inverse, #fff));
  opacity: 0.3;
  width: 1px;
  margin: 3px;
}`);var qM=G('<div class="jse-separator svelte-pf7s2l"></div>'),$M=G('<div class="jse-space svelte-pf7s2l"></div>'),FM=G('<button type="button"><!> <!></button>'),BM=G('<div class="jse-menu svelte-pf7s2l"><!> <!> <!></div>');function Xc(e,t){lt(t,!1);var n=h(t,"items",25,()=>[]);St(!0);var r=BM(),a=z(r);_r(a,t,"left",{},null);var i=F(a,2);jr(i,1,n,Cr,(s,l)=>{var u=xr(),d=ft(u),c=f=>{I(f,qM())},v=(f,g)=>{var m=j=>{I(j,$M())},b=(j,w)=>{var O=R=>{var k=FM(),D=z(k),H=J=>{dn(J,{get data(){return o(l).icon}})};re(D,J=>{o(l).icon&&J(H)});var V=F(D,2),A=J=>{var Z=Br();Ee(()=>pt(Z,o(l).text)),I(J,Z)};re(V,J=>{o(l).text&&J(A)}),Ee(()=>{var J;Mt(k,1,"jse-button ".concat((J=o(l).className)!==null&&J!==void 0?J:""),"svelte-pf7s2l"),Cn(k,"title",o(l).title),k.disabled=o(l).disabled||!1}),be("click",k,function(){for(var J,Z=arguments.length,Y=new Array(Z),le=0;le<Z;le++)Y[le]=arguments[le];(J=o(l).onClick)===null||J===void 0||J.apply(this,Y)}),I(R,k)},T=R=>{var k=Br();Ee(D=>pt(k,D),[()=>function(D){return console.error("Unknown type of menu item",D),"???"}(o(l))],de),I(R,k)};re(j,R=>{vs(o(l))?R(O):R(T,!1)},w)};re(f,j=>{sw(o(l))?j(m):j(b,!1)},g)};re(d,f=>{ku(o(l))?f(c):f(v,!1)}),I(s,u)}),_r(F(i,2),t,"right",{},null),I(e,r),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-json-repair-component.svelte-3golau {
  flex: 1;
  display: flex;
  flex-direction: column;
  background: var(--jse-background-color, #fff);
  color: var(--jse-text-color, #4d4d4d);
}
.jse-json-repair-component.svelte-3golau .jse-info:where(.svelte-3golau) {
  padding: calc(0.5 * var(--jse-padding, 10px));
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  vertical-align: center;
}
.jse-json-repair-component.svelte-3golau .jse-json-text:where(.svelte-3golau) {
  flex: 1;
  border: none;
  padding: 2px;
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  background: var(--jse-input-background, var(--jse-background-color, #fff));
  color: var(--jse-text-color, #4d4d4d);
  resize: none;
  outline: none;
}`);var WM=G('<div slot="left" class="jse-info svelte-3golau">Repair invalid JSON, then click apply</div>'),HM=G('<div class="jse-json-repair-component svelte-3golau"><!> <!> <textarea class="jse-json-text svelte-3golau" autocomplete="off" autocapitalize="off" spellcheck="false"></textarea></div>');function VM(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=P(void 0,!0),i=P(void 0,!0),s=P(void 0,!0),l=P(void 0,!0),u=h(t,"text",13,""),d=h(t,"readOnly",9,!1),c=h(t,"onParse",9),v=h(t,"onRepair",9),f=h(t,"onChange",9,void 0),g=h(t,"onApply",9),m=h(t,"onCancel",9),b=Fr("jsoneditor:JSONRepair"),j=P(void 0,!0);function w(){if(o(j)&&o(n)){var Z=o(n).position!==void 0?o(n).position:0;o(j).setSelectionRange(Z,Z),o(j).focus()}}function O(){g()(u())}function T(){try{u(v()(u())),f()&&f()(u())}catch{}}var R=P(void 0,!0);W(()=>M(u()),()=>{p(n,function(Z){try{return void c()(Z)}catch(Y){return ys(Z,Y.message)}}(u()))}),W(()=>M(u()),()=>{p(r,function(Z){try{return v()(Z),!0}catch{return!1}}(u()))}),W(()=>o(n),()=>{b("error",o(n))}),W(()=>M(m()),()=>{p(R,[{type:"space"},{type:"button",icon:vc,title:"Cancel repair",className:"jse-cancel",onClick:m()}])}),W(()=>Sp,()=>{p(a,{icon:Sp,text:"Show me",title:"Scroll to the error location",onClick:w})}),W(()=>bs,()=>{p(i,{icon:bs,text:"Auto repair",title:"Automatically repair JSON",onClick:T})}),W(()=>(o(r),o(a),o(i)),()=>{p(s,o(r)?[o(a),o(i)]:[o(a)])}),W(()=>M(d()),()=>{p(l,[{icon:tf,text:"Apply",title:"Apply fixed JSON",disabled:d(),onClick:O}])}),_n(),St(!0);var k=HM(),D=z(k);Xc(D,{get items(){return o(R)},$$slots:{left:(Z,Y)=>{I(Z,WM())}}});var H=F(D,2),V=Z=>{var Y=de(()=>"Cannot parse JSON: ".concat(o(n).message));Yo(Z,{type:"error",icon:Ei,get message(){return o(Y)},get actions(){return o(s)}})},A=Z=>{Yo(Z,{type:"success",message:"JSON is valid now and can be parsed.",get actions(){return o(l)}})};re(H,Z=>{o(n)?Z(V):Z(A,!1)});var J=F(H,2);tr(J,Z=>p(j,Z),()=>o(j)),Ee(()=>{J.readOnly=d(),Mi(J,u())}),be("input",J,function(Z){b("handleChange");var Y=Z.target.value;u()!==Y&&(u(Y),f()&&f()(u()))}),I(e,k),ut()}function Lw(e,t){lt(t,!1);var n=h(t,"text",13),r=h(t,"onParse",9),a=h(t,"onRepair",9),i=h(t,"onApply",9),s=h(t,"onClose",9);function l(d){i()(d),s()()}function u(){s()()}St(!0),Nl(e,{get onClose(){return s()},className:"jse-repair-modal",children:(d,c)=>{VM(d,{get onParse(){return r()},get onRepair(){return a()},onApply:l,onCancel:u,get text(){return n()},set text(v){n(v)},$$legacy:!0})},$$slots:{default:!0}}),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
div.jse-collapsed-items.svelte-1h6hzoq {
  margin-left: calc(var(--level) * var(--jse-indent-size, calc(1em + 4px)));
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  color: var(--jse-collapsed-items-link-color, rgba(0, 0, 0, 0.38));
  padding: calc(0.5 * var(--jse-padding, 10px));
  border: 8px solid transparent;
  border-width: 8px 0;
  background-color: var(--jse-contents-background-color, transparent);
  background-image: linear-gradient(var(--jse-collapsed-items-background-color, #f5f5f5), var(--jse-collapsed-items-background-color, #f5f5f5)), linear-gradient(to bottom right, transparent 50.5%, var(--jse-collapsed-items-background-color, #f5f5f5) 50.5%), linear-gradient(to bottom left, transparent 50.5%, var(--jse-collapsed-items-background-color, #f5f5f5) 50.5%), linear-gradient(to top right, transparent 50.5%, var(--jse-collapsed-items-background-color, #f5f5f5) 50.5%), linear-gradient(to top left, transparent 50.5%, var(--jse-collapsed-items-background-color, #f5f5f5) 50.5%);
  background-repeat: repeat, repeat-x, repeat-x, repeat-x, repeat-x;
  background-position: 0 0, 8px 0, 8px 0, 8px 100%, 8px 100%;
  background-size: auto auto, 16px 16px, 16px 16px, 16px 16px, 16px 16px;
  background-clip: padding-box, border-box, border-box, border-box, border-box;
  background-origin: padding-box, border-box, border-box, border-box, border-box;
  display: flex;
}
div.jse-collapsed-items.jse-selected.svelte-1h6hzoq {
  background-color: var(--jse-selection-background-color, #d3d3d3);
  --jse-collapsed-items-background-color: var(--jse-collapsed-items-selected-background-color, #c2c2c2);
}
div.jse-collapsed-items.svelte-1h6hzoq div.jse-text:where(.svelte-1h6hzoq),
div.jse-collapsed-items.svelte-1h6hzoq button.jse-expand-items:where(.svelte-1h6hzoq) {
  margin: 0 calc(0.5 * var(--jse-padding, 10px));
}
div.jse-collapsed-items.svelte-1h6hzoq div.jse-text:where(.svelte-1h6hzoq) {
  display: inline;
}
div.jse-collapsed-items.svelte-1h6hzoq button.jse-expand-items:where(.svelte-1h6hzoq) {
  font-family: inherit;
  font-size: inherit;
  color: var(--jse-collapsed-items-link-color, rgba(0, 0, 0, 0.38));
  background: none;
  border: none;
  padding: 0;
  text-decoration: underline;
  cursor: pointer;
}
div.jse-collapsed-items.svelte-1h6hzoq button.jse-expand-items:where(.svelte-1h6hzoq):hover, div.jse-collapsed-items.svelte-1h6hzoq button.jse-expand-items:where(.svelte-1h6hzoq):focus {
  color: var(--jse-collapsed-items-link-color-highlight, #ee5341);
}`);var JM=G('<button type="button" class="jse-expand-items svelte-1h6hzoq"> </button>'),GM=G('<div role="none"><div><div class="jse-text svelte-1h6hzoq"> </div> <!></div></div>');function KM(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=P(void 0,!0),i=P(void 0,!0),s=P(void 0,!0),l=h(t,"visibleSections",9),u=h(t,"sectionIndex",9),d=h(t,"total",9),c=h(t,"path",9),v=h(t,"selection",9),f=h(t,"onExpandSection",9),g=h(t,"context",9);W(()=>(M(l()),M(u())),()=>{p(n,l()[u()])}),W(()=>o(n),()=>{p(r,o(n).end)}),W(()=>(M(l()),M(u()),M(d())),()=>{p(a,l()[u()+1]?l()[u()+1].start:d())}),W(()=>(M(g()),M(v()),M(c()),o(r)),()=>{p(i,Pl(g().getJson(),v(),c().concat(String(o(r)))))}),W(()=>(o(r),o(a)),()=>{p(s,function(R,k){var D={start:R,end:Math.min(mv(R),k)},H=Math.max(Ju((R+k)/2),R),V={start:H,end:Math.min(mv(H),k)},A=Ju(k),J=A===k?A-Al:A,Z={start:Math.max(J,R),end:k},Y=[D],le=V.start>=D.end&&V.end<=Z.start;return le&&Y.push(V),Z.start>=(le?V.end:D.end)&&Y.push(Z),Y}(o(r),o(a)))}),_n(),St(!0);var m,b,j=GM(),w=z(j),O=z(w),T=z(O);jr(F(O,2),1,()=>o(s),Cr,(R,k)=>{var D=JM(),H=z(D);Ee(()=>{var V,A;return pt(H,"show ".concat((V=o(k).start)!==null&&V!==void 0?V:"","-").concat((A=o(k).end)!==null&&A!==void 0?A:""))}),be("click",D,()=>f()(c(),o(k))),I(R,D)}),Ee(R=>{var k,D;m=Mt(j,1,"jse-collapsed-items svelte-1h6hzoq",null,m,R),b=Ho(j,"",b,{"--level":c().length+2}),pt(T,"Items ".concat((k=o(r))!==null&&k!==void 0?k:"","-").concat((D=o(a))!==null&&D!==void 0?D:""))},[()=>({"jse-selected":o(i)})],de),be("mousemove",j,function(R){R.stopPropagation()}),I(e,j),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-context-menu-pointer.svelte-137iwnw {
  position: absolute;
  top: calc(-0.5 * var(--jse-context-menu-pointer-size, calc(1em + 4px)));
  right: calc(-0.5 * var(--jse-context-menu-pointer-size, calc(1em + 4px)));
  width: var(--jse-context-menu-pointer-size, calc(1em + 4px));
  height: var(--jse-context-menu-pointer-size, calc(1em + 4px));
  padding: 0;
  margin: 0;
  cursor: pointer;
  background: transparent;
  border-radius: 2px;
  background: var(--jse-context-menu-pointer-hover-background, #b2b2b2);
  color: var(--jse-context-menu-pointer-color, var(--jse-context-menu-color, var(--jse-text-color-inverse, #fff)));
  border: none;
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
}
.jse-context-menu-pointer.jse-root.svelte-137iwnw {
  top: 0;
  right: calc(-2px - var(--jse-context-menu-pointer-size, calc(1em + 4px)));
}
.jse-context-menu-pointer.jse-insert.svelte-137iwnw {
  right: -1px;
}
.jse-context-menu-pointer.svelte-137iwnw:hover {
  background: var(--jse-context-menu-pointer-background-highlight, var(--jse-context-menu-background-highlight, #7a7a7a));
}
.jse-context-menu-pointer.jse-selected.svelte-137iwnw {
  background: var(--jse-context-menu-pointer-background, var(--jse-context-menu-background, #656565));
}
.jse-context-menu-pointer.jse-selected.svelte-137iwnw:hover {
  background: var(--jse-context-menu-pointer-background-highlight, var(--jse-context-menu-background-highlight, #7a7a7a));
}`);var YM=G('<button type="button"><!></button>');function Wa(e,t){lt(t,!1);var n=h(t,"root",9,!1),r=h(t,"insert",9,!1),a=h(t,"selected",9),i=h(t,"onContextMenu",9);St(!0);var s,l=YM();Cn(l,"title",rp),dn(z(l),{data:ti}),Ee(u=>s=Mt(l,1,"jse-context-menu-pointer svelte-137iwnw",null,s,u),[()=>({"jse-root":n(),"jse-insert":r(),"jse-selected":a()})],de),be("click",l,function(u){for(var d=u.target;d&&d.nodeName!=="BUTTON";)d=d.parentNode;d&&i()({anchor:d,left:0,top:0,width:wa,height:ya,offsetTop:2,offsetLeft:0,showTip:!0})}),I(e,l),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-key.svelte-2iqnqn {
  display: inline-block;
  min-width: 2em;
  padding: 0 5px;
  box-sizing: border-box;
  outline: none;
  border-radius: 1px;
  vertical-align: top;
  color: var(--jse-key-color, #1a1a1a);
  word-break: normal;
  overflow-wrap: normal;
  white-space: pre-wrap;
}
.jse-key.jse-empty.svelte-2iqnqn {
  min-width: 3em;
  outline: 1px dotted var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  -moz-outline-radius: 2px;
}
.jse-key.jse-empty.svelte-2iqnqn::after {
  pointer-events: none;
  color: var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  content: "key";
}`);var XM=G('<div role="none" data-type="selectable-key"><!></div>'),QM=G("<!> <!>",1),ZM=G('<div role="button" tabindex="-1" class="jse-value" data-type="selectable-value"></div>');function Uw(e,t){lt(t,!0);var n=co(()=>zn(t.selection)&&vo(t.selection)),r=co(()=>t.context.onRenderValue({path:t.path,value:t.value,mode:t.context.mode,truncateTextSize:t.context.truncateTextSize,readOnly:t.context.readOnly,enforceString:t.enforceString,isEditing:o(n),parser:t.context.parser,normalization:t.context.normalization,selection:t.selection,searchResultItems:t.searchResultItems,onPatch:t.context.onPatch,onPasteJson:t.context.onPasteJson,onSelect:t.context.onSelect,onFind:t.context.onFind,findNextInside:t.context.findNextInside,focus:t.context.focus})),a=xr();jr(ft(a),17,()=>o(r),Cr,(i,s)=>{var l=xr(),u=ft(l),d=v=>{var f=ZM(),g=co(()=>o(s).action);eo(f,(m,b)=>{var j;return(j=o(g))===null||j===void 0?void 0:j(m,b)},()=>o(s).props),I(v,f)},c=v=>{var f=xr(),g=co(()=>o(s).component);Uy(ft(f),()=>o(g),(m,b)=>{b(m,Xa(()=>o(s).props))}),I(v,f)};re(u,v=>{wR(o(s))?v(d):v(c,!1)}),I(i,l)}),I(e,a),ut()}var ez={selecting:!1,selectionAnchor:void 0,selectionAnchorType:void 0,selectionFocus:void 0,dragging:!1};function Id(e){var{json:t,selection:n,deltaY:r,items:a}=e;if(!n)return{operations:void 0,updatedSelection:void 0,offset:0};var i=r<0?function(c){for(var{json:v,items:f,selection:g,deltaY:m}=c,b=ka(v,g),j=f.findIndex(D=>Zt(D.path,b)),w=()=>{var D;return(D=f[O-1])===null||D===void 0?void 0:D.height},O=j,T=0;w()!==void 0&&Math.abs(m)>T+w()/2;)T+=w(),O-=1;var R=f[O].path,k=O-j;return O!==j&&f[O]!==void 0?{beforePath:R,offset:k}:void 0}({json:t,selection:n,deltaY:r,items:a}):function(c){for(var v,{json:f,items:g,selection:m,deltaY:b}=c,j=Za(f,m),w=g.findIndex(J=>Zt(J.path,j)),O=0,T=w,R=()=>{var J;return(J=g[T+1])===null||J===void 0?void 0:J.height};R()!==void 0&&Math.abs(b)>O+R()/2;)O+=R(),T+=1;var k=sn(j),D=Ke(f,k),H=Array.isArray(D)?T:T+1,V=(v=g[H])===null||v===void 0?void 0:v.path,A=T-w;return V?{beforePath:V,offset:A}:{append:!0,offset:A}}({json:t,selection:n,deltaY:r,items:a});if(!i||i.offset===0)return{operations:void 0,updatedSelection:void 0,offset:0};var s=function(c,v,f){if(!v)return[];var g="beforePath"in f?f.beforePath:void 0,m="append"in f?f.append:void 0,b=sn(Qe(v)),j=Ke(c,b);if(!(m||g&&Ta(g,b)&&g.length>b.length))return[];var w=ka(c,v),O=Za(c,v),T=ht(w),R=ht(O),k=g?g[b.length]:void 0;if(!$r(j)){if(zr(j)){var D=Vr(T),H=Vr(R),V=k!==void 0?Vr(k):j.length;return Kv(H-D+1,V<D?le=>({op:"move",from:zt(b.concat(String(D+le))),path:zt(b.concat(String(V+le)))}):()=>({op:"move",from:zt(b.concat(String(D))),path:zt(b.concat(String(V)))}))}throw new Error("Cannot create move operations: parent must be an Object or Array")}var A=Object.keys(j),J=A.indexOf(T),Z=A.indexOf(R),Y=m?A.length:k!==void 0?A.indexOf(k):-1;return J!==-1&&Z!==-1&&Y!==-1?Y>J?[...A.slice(J,Z+1),...A.slice(Y,A.length)].map(le=>Ti(b,le)):[...A.slice(Y,J),...A.slice(Z+1,A.length)].map(le=>Ti(b,le)):[]}(t,n,i),l=sn(ka(t,n)),u=Ke(t,l);if(Array.isArray(u)){var d=function(c){var v,f,{items:g,json:m,selection:b,offset:j}=c,w=ka(m,b),O=Za(m,b),T=g.findIndex(H=>Zt(H.path,w)),R=g.findIndex(H=>Zt(H.path,O)),k=(v=g[T+j])===null||v===void 0?void 0:v.path,D=(f=g[R+j])===null||f===void 0?void 0:f.path;return Qr(k,D)}({items:a,json:t,selection:n,offset:i.offset});return{operations:s,updatedSelection:d,offset:i.offset}}return{operations:s,updatedSelection:void 0,offset:i.offset}}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
button.jse-validation-error.svelte-1a8aobl {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  padding: 0;
  margin: 0;
  vertical-align: top;
  display: inline-flex;
  color: var(--jse-error-color, #ee5341);
}

button.jse-validation-info.svelte-1a8aobl {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  padding: 0;
  margin: 0;
  vertical-align: top;
  display: inline-flex;
  color: var(--jse-info-color, #4f91ff);
}

button.jse-validation-warning.svelte-1a8aobl {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  padding: 0;
  margin: 0;
  vertical-align: top;
  display: inline-flex;
  color: var(--jse-warning-color, #fdc539);
}`);var tz=G('<button type="button"><!></button>');function hs(e,t){lt(t,!1);var n=P(),r=vi("absolute-popup"),a=h(t,"validationError",8),i=h(t,"onExpand",8);W(()=>M(a()),()=>{p(n,yR(a())&&a().isChildError?"Contains invalid data":a().message)}),_n(),St();var s=tz();dn(z(s),{data:Ei}),qr(()=>be("click",s,function(){for(var l,u=arguments.length,d=new Array(u),c=0;c<u;c++)d[c]=arguments[c];(l=i())===null||l===void 0||l.apply(this,d)})),eo(s,(l,u)=>_s?.(l,u),()=>Se({text:o(n)},r)),Ee(()=>{var l;return Mt(s,1,"jse-validation-".concat((l=a().severity)!==null&&l!==void 0?l:""),"svelte-1a8aobl")}),I(e,s),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-expand.svelte-oawf7x {
  width: var(--jse-indent-size, calc(1em + 4px));
  padding: 0;
  margin: 0;
  border: none;
  cursor: pointer;
  background: transparent;
  color: var(--jse-delimiter-color, rgba(0, 0, 0, 0.38));
  font-size: var(--jse-font-size-mono, 14px);
  height: var(--jse-line-height, calc(1em + 4px));
}
.jse-expand.svelte-oawf7x:hover {
  opacity: 0.8;
}

.jse-meta.svelte-oawf7x,
.jse-separator.svelte-oawf7x,
.jse-index.svelte-oawf7x,
.jse-bracket.svelte-oawf7x {
  vertical-align: top;
  color: var(--jse-delimiter-color, rgba(0, 0, 0, 0.38));
}

.jse-index.svelte-oawf7x {
  padding: 0 calc(0.5 * var(--jse-padding, 10px));
}

.jse-bracket.svelte-oawf7x {
  padding: 0 2px;
}
.jse-bracket.jse-expanded.svelte-oawf7x {
  padding-right: var(--jse-padding, 10px);
}

.jse-identifier.svelte-oawf7x {
  vertical-align: top;
  position: relative;
}

.jse-json-node.svelte-oawf7x {
  position: relative;
  color: var(--jse-text-color, #4d4d4d);
}
.jse-json-node.jse-root.svelte-oawf7x {
  min-height: 100%;
  padding-bottom: 2px;
  box-sizing: border-box;
}
.jse-json-node.jse-root.svelte-oawf7x > .jse-contents-outer:where(.svelte-oawf7x) > .jse-contents:where(.svelte-oawf7x) {
  padding-left: 0;
}
.jse-json-node.svelte-oawf7x .jse-props:where(.svelte-oawf7x),
.jse-json-node.svelte-oawf7x .jse-items:where(.svelte-oawf7x) {
  position: relative;
}
.jse-json-node.svelte-oawf7x .jse-header-outer:where(.svelte-oawf7x),
.jse-json-node.svelte-oawf7x .jse-footer-outer:where(.svelte-oawf7x) {
  display: flex;
  margin-left: calc(var(--level) * var(--jse-indent-size, calc(1em + 4px)));
}
.jse-json-node.svelte-oawf7x .jse-header:where(.svelte-oawf7x) {
  position: relative;
}
.jse-json-node.svelte-oawf7x .jse-header:where(.svelte-oawf7x) .jse-meta:where(.svelte-oawf7x) > .jse-meta-inner:where(.svelte-oawf7x) {
  display: flex;
  justify-content: center;
}
.jse-json-node.svelte-oawf7x .jse-contents-outer:where(.svelte-oawf7x) {
  display: flex;
  margin-left: calc(var(--level) * var(--jse-indent-size, calc(1em + 4px)));
}
.jse-json-node.svelte-oawf7x .jse-header:where(.svelte-oawf7x),
.jse-json-node.svelte-oawf7x .jse-contents:where(.svelte-oawf7x) {
  display: flex;
  flex-direction: row;
  align-items: flex-start;
}
.jse-json-node.svelte-oawf7x .jse-contents:where(.svelte-oawf7x) {
  padding-left: var(--jse-indent-size, calc(1em + 4px));
  cursor: var(--jse-contents-cursor, pointer);
}
.jse-json-node.svelte-oawf7x .jse-contents:where(.svelte-oawf7x) .jse-value-outer:where(.svelte-oawf7x) {
  display: inline-flex;
}
.jse-json-node.svelte-oawf7x .jse-footer:where(.svelte-oawf7x) {
  display: inline-flex;
  padding-left: calc(var(--jse-indent-size, calc(1em + 4px)) + 5px);
}
.jse-json-node.svelte-oawf7x .jse-header:where(.svelte-oawf7x),
.jse-json-node.svelte-oawf7x .jse-contents:where(.svelte-oawf7x),
.jse-json-node.svelte-oawf7x .jse-footer:where(.svelte-oawf7x) {
  background: var(--jse-contents-background-color, transparent);
}
.jse-json-node.svelte-oawf7x .jse-insert-selection-area:where(.svelte-oawf7x) {
  padding: 0 calc(0.5 * var(--jse-padding, 10px));
  flex: 1;
}
.jse-json-node.svelte-oawf7x .jse-insert-selection-area.jse-inside:where(.svelte-oawf7x) {
  display: inline-flex;
  align-items: center;
}
.jse-json-node.svelte-oawf7x .jse-insert-selection-area.jse-after:where(.svelte-oawf7x) {
  display: flex;
  align-items: flex-end;
}
.jse-json-node.svelte-oawf7x .jse-context-menu-pointer-anchor:where(.svelte-oawf7x) {
  position: relative;
}
.jse-json-node.svelte-oawf7x .jse-insert-area:where(.svelte-oawf7x) {
  display: flex;
  position: relative;
  z-index: 1;
  margin-left: calc(var(--level) * var(--jse-indent-size, calc(1em + 4px)));
  max-width: 250px;
  min-width: 100px;
  height: 0;
  margin-right: calc(0.5 * var(--jse-padding, 10px));
  outline: 1px solid;
}
.jse-json-node.svelte-oawf7x .jse-insert-area.jse-hovered:where(.svelte-oawf7x) {
  outline-color: var(--jse-context-menu-pointer-hover-background, #b2b2b2);
}
.jse-json-node.svelte-oawf7x .jse-key-outer:where(.svelte-oawf7x) {
  position: relative;
}
.jse-json-node.svelte-oawf7x .jse-key-outer:where(.svelte-oawf7x):hover,
.jse-json-node.svelte-oawf7x .jse-value-outer:where(.svelte-oawf7x):hover,
.jse-json-node.svelte-oawf7x .jse-meta:where(.svelte-oawf7x):hover,
.jse-json-node.svelte-oawf7x .jse-footer:where(.svelte-oawf7x):hover {
  background: var(--jse-hover-background-color, rgba(0, 0, 0, 0.06));
  cursor: var(--jse-contents-cursor, pointer);
}
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-items .jse-header,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-items .jse-contents,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-props .jse-header,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-props .jse-contents,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-footer {
  background: var(--jse-hover-background-color, rgba(0, 0, 0, 0.06));
  cursor: var(--jse-contents-cursor, pointer);
}
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-value-outer .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-value-outer .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-meta .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-meta .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-items .jse-header .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-items .jse-header .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-items .jse-contents .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-items .jse-contents .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-props .jse-header .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-props .jse-header .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-props .jse-contents .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-props .jse-contents .jse-meta,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-footer .jse-value-outer,
.jse-json-node.jse-hovered.svelte-oawf7x:not(.jse-selected):not(.jse-selected-value) .jse-footer .jse-meta {
  background: none;
}
.jse-json-node.jse-selected.svelte-oawf7x .jse-header:where(.svelte-oawf7x),
.jse-json-node.jse-selected.svelte-oawf7x .jse-contents:where(.svelte-oawf7x),
.jse-json-node.jse-selected.svelte-oawf7x .jse-footer:where(.svelte-oawf7x) {
  background: var(--jse-selection-background-color, #d3d3d3);
  cursor: var(--jse-contents-selected-cursor, grab);
}
.jse-json-node.jse-selected.svelte-oawf7x .jse-key-outer:where(.svelte-oawf7x):hover,
.jse-json-node.jse-selected.svelte-oawf7x .jse-value-outer:where(.svelte-oawf7x):hover,
.jse-json-node.jse-selected.svelte-oawf7x .jse-meta:where(.svelte-oawf7x):hover,
.jse-json-node.jse-selected.svelte-oawf7x .jse-footer:where(.svelte-oawf7x):hover {
  background: inherit;
  cursor: inherit;
}
.jse-json-node.svelte-oawf7x .jse-key-outer.jse-selected-key:where(.svelte-oawf7x) {
  background: var(--jse-selection-background-color, #d3d3d3);
  cursor: var(--jse-contents-selected-cursor, grab);
}
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-value-outer,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-meta,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-items .jse-header,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-items .jse-contents,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-props .jse-header,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-props .jse-contents,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-footer {
  background: var(--jse-selection-background-color, #d3d3d3);
  cursor: var(--jse-contents-selected-cursor, grab);
}
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-value-outer .jse-key-outer:hover,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-meta .jse-key-outer:hover,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-items .jse-header .jse-key-outer:hover,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-items .jse-contents .jse-key-outer:hover,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-props .jse-header .jse-key-outer:hover,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-props .jse-contents .jse-key-outer:hover,
.jse-json-node.jse-selected-value.svelte-oawf7x .jse-footer .jse-key-outer:hover {
  background: inherit;
  cursor: inherit;
}
.jse-json-node.jse-readonly.svelte-oawf7x {
  --jse-contents-selected-cursor: pointer;
}
.jse-json-node.svelte-oawf7x .jse-insert-area.jse-selected:where(.svelte-oawf7x) {
  outline-color: var(--jse-context-menu-pointer-background, var(--jse-context-menu-background, #656565));
}`);var sr=qc(()=>ez),nz=G('<div class="jse-separator svelte-oawf7x">:</div>'),rz=G('<div class="jse-bracket svelte-oawf7x">[</div> <!> &nbsp;',1),oz=G('<div class="jse-bracket svelte-oawf7x">[</div> <!> <div class="jse-bracket svelte-oawf7x">]</div>',1),az=G('<div class="jse-context-menu-pointer-anchor svelte-oawf7x"><!></div>'),iz=G('<div role="none" class="jse-insert-selection-area jse-inside svelte-oawf7x" data-type="insert-selection-area-inside"></div>'),sz=G('<div role="none" class="jse-insert-selection-area jse-after svelte-oawf7x" data-type="insert-selection-area-after"></div>'),lz=G('<div data-type="insert-selection-area-inside"><!></div>'),uz=G('<div slot="identifier" class="jse-identifier svelte-oawf7x"><div class="jse-index svelte-oawf7x"> </div></div>'),cz=G("<!> <!>",1),dz=G('<div role="none" class="jse-insert-selection-area jse-after svelte-oawf7x" data-type="insert-selection-area-after"></div>'),vz=G('<div class="jse-items svelte-oawf7x"><!> <!></div> <div class="jse-footer-outer svelte-oawf7x"><div data-type="selectable-value" class="jse-footer svelte-oawf7x"><span class="jse-bracket svelte-oawf7x">]</span></div> <!></div>',1),fz=G('<div class="jse-header-outer svelte-oawf7x"><div class="jse-header svelte-oawf7x"><button type="button" class="jse-expand svelte-oawf7x" title="Expand or collapse this array (Ctrl+Click to expand/collapse recursively)"><!></button> <!> <!> <div class="jse-meta svelte-oawf7x"><div class="jse-meta-inner svelte-oawf7x" data-type="selectable-value"><!></div></div> <!></div> <!> <!></div> <!>',1),pz=G('<div class="jse-separator svelte-oawf7x">:</div>'),hz=G('<div class="jse-bracket jse-expanded svelte-oawf7x">&lbrace;</div>'),gz=G('<div class="jse-bracket svelte-oawf7x">&lbrace;</div> <!> <div class="jse-bracket svelte-oawf7x">&rbrace;</div>',1),mz=G('<div class="jse-context-menu-pointer-anchor svelte-oawf7x"><!></div>'),bz=G('<div role="none" class="jse-insert-selection-area jse-inside svelte-oawf7x" data-type="insert-selection-area-inside"></div>'),xz=G('<div role="none" class="jse-insert-selection-area jse-after svelte-oawf7x" data-type="insert-selection-area-after"></div>'),jz=G('<div data-type="insert-selection-area-inside"><!></div>'),yz=G('<div slot="identifier"><!></div>'),wz=G('<div role="none" class="jse-insert-selection-area jse-after svelte-oawf7x" data-type="insert-selection-area-after"></div>'),kz=G('<div class="jse-props svelte-oawf7x"><!> <!></div> <div class="jse-footer-outer svelte-oawf7x"><div data-type="selectable-value" class="jse-footer svelte-oawf7x"><div class="jse-bracket svelte-oawf7x">&rbrace;</div></div> <!></div>',1),_z=G('<div class="jse-header-outer svelte-oawf7x"><div class="jse-header svelte-oawf7x"><button type="button" class="jse-expand svelte-oawf7x" title="Expand or collapse this object (Ctrl+Click to expand/collapse recursively)"><!></button> <!> <!> <div class="jse-meta svelte-oawf7x" data-type="selectable-value"><div class="jse-meta-inner svelte-oawf7x"><!></div></div> <!></div> <!> <!></div> <!>',1),Sz=G('<div class="jse-separator svelte-oawf7x">:</div>'),Cz=G('<div class="jse-context-menu-pointer-anchor svelte-oawf7x"><!></div>'),Oz=G('<div role="none" class="jse-insert-selection-area jse-after svelte-oawf7x" data-type="insert-selection-area-after"></div>'),Ez=G('<div class="jse-contents-outer svelte-oawf7x"><div class="jse-contents svelte-oawf7x"><!> <!> <div class="jse-value-outer svelte-oawf7x"><!></div> <!></div> <!> <!></div>'),Az=G('<div data-type="insert-selection-area-after"><!></div>'),Rz=G('<div role="treeitem" tabindex="-1"><!> <!></div>');function Av(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=h(t,"pointer",9),i=h(t,"value",9),s=h(t,"state",9),l=h(t,"validationErrors",9),u=h(t,"searchResults",9),d=h(t,"selection",9),c=h(t,"context",9),v=h(t,"onDragSelectionStart",9),f=Fr("jsoneditor:JSONNode"),g=P(void 0,!0),m=void 0,b=P(void 0,!0),j=P(void 0,!0),w=P(void 0,!0),O=P(void 0,!0),T=P(void 0,!0),R=P(void 0,!0),k=P(void 0,!0);function D(ee){ee.stopPropagation();var q=np(ee);c().onExpand(o(j),!o(w),q)}function H(){c().onExpand(o(j),!0)}function V(ee,q){var ae=ou(o(j),Object.keys(i()),ee,q);return c().onPatch(ae),ht(Fo(ae[0].path))}function A(ee){c().onDrag(ee)}function J(ee){sr().selecting&&(sr(sr().selecting=!1),ee.stopPropagation()),c().onDragEnd(),document.removeEventListener("mousemove",A,!0),document.removeEventListener("mouseup",J)}function Z(){var ee;return((ee=c().findElement([]))===null||ee===void 0||(ee=ee.getBoundingClientRect())===null||ee===void 0?void 0:ee.top)||0}function Y(ee,q){var ae=Z()-ee.initialContentTop;return q.clientY-ee.initialClientY-ae}function le(ee){if(!c().readOnly&&d()){var q=sn(Qe(d()));if(Zt(o(j),q)){var ae=function(X,L){var yt=[];function Ze(_){var E=o(j).concat(_),U=c().findElement(E);U!==void 0&&yt.push({path:E,height:U.clientHeight})}if(Array.isArray(i())){var Ce=c().getJson();if(Ce===void 0)return;var st=ka(Ce,X),Me=Za(Ce,X),at=parseInt(ht(st),10),Tt=parseInt(ht(Me),10),Je=L.find(_=>at>=_.start&&Tt<=_.end);if(!Je)return;var{start:qt,end:x}=Je;Hy(qt,Math.min(i().length,x),_=>Ze(String(_)))}else Object.keys(i()).forEach(Ze);return yt}(d(),o(T)||ds);if(f("dragSelectionStart",{selection:d(),items:ae}),ae){var $=c().getJson();if($!==void 0){var _e=ka($,d()),ne=ae.findIndex(X=>Zt(X.path,_e)),{offset:Ue}=Id({json:$,selection:c().getSelection(),deltaY:0,items:ae});p(b,{initialTarget:ee.target,initialClientY:ee.clientY,initialContentTop:Z(),selectionStartIndex:ne,selectionItemsCount:ii($,d()).length,items:ae,offset:Ue,didMoveItems:!1}),sr(sr().dragging=!0),document.addEventListener("mousemove",Ae,!0),document.addEventListener("mouseup",ce)}}else f("Cannot drag the current selection (probably spread over multiple sections)")}else v()(ee)}}function Ae(ee){if(o(b)){var q=c().getJson();if(q===void 0)return;var ae=Y(o(b),ee),{offset:$}=Id({json:q,selection:c().getSelection(),deltaY:ae,items:o(b).items});$!==o(b).offset&&(f("drag selection",$,ae),p(b,Se(Se({},o(b)),{},{offset:$,didMoveItems:!0})))}}function ce(ee){if(o(b)){var q=c().getJson();if(q===void 0)return;var ae=Y(o(b),ee),{operations:$,updatedSelection:_e}=Id({json:q,selection:c().getSelection(),deltaY:ae,items:o(b).items});if($)c().onPatch($,(X,L)=>({state:L,selection:_e??d()}));else if(ee.target===o(b).initialTarget&&!o(b).didMoveItems){var ne=xd(ee.target),Ue=ow(ee.target);Ue&&c().onSelect(Jh(ne,Ue))}p(b,void 0),sr(sr().dragging=!1),document.removeEventListener("mousemove",Ae,!0),document.removeEventListener("mouseup",ce)}}function we(ee){ee.shiftKey||(ee.stopPropagation(),ee.preventDefault(),c().onSelect(Na(o(j))))}function $e(ee){ee.shiftKey||(ee.stopPropagation(),ee.preventDefault(),c().onSelect(Ea(o(j))))}function Ne(ee){c().onSelect(Na(o(j))),c().onContextMenu(ee)}function ye(ee){c().onSelect(Ea(o(j))),c().onContextMenu(ee)}W(()=>M(a()),()=>{p(j,Fo(a()))}),W(()=>M(a()),()=>{p(n,encodeURIComponent(a()))}),W(()=>M(s()),()=>{p(w,!!zi(s())&&s().expanded)}),W(()=>(M(i()),M(s())),()=>{p(O,Oa(i(),s(),[]))}),W(()=>M(s()),()=>{p(T,Kr(s())?s().visibleSections:void 0)}),W(()=>M(l()),()=>{var ee;p(R,(ee=l())===null||ee===void 0?void 0:ee.validationError)}),W(()=>(M(c()),M(d()),o(j)),()=>{p(k,Pl(c().getJson(),d(),o(j)))}),W(()=>o(j),()=>{p(r,o(j).length===0)}),_n(),St(!0);var ze,Re,We=Rz(),he=z(We),ue=ee=>{var q=fz(),ae=ft(q),$=z(ae),_e=z($),ne=z(_e),Ue=N=>{dn(N,{data:ti})},X=N=>{dn(N,{data:jl})};re(ne,N=>{o(w)?N(Ue):N(X,!1)});var L=F(_e,2);_r(L,t,"identifier",{},null);var yt=F(L,2),Ze=N=>{I(N,nz())};re(yt,N=>{o(r)||N(Ze)});var Ce=F(yt,2),st=z(Ce),Me=z(st),at=N=>{var Fe=rz();Su(F(ft(Fe),2),{children:(Ge,Et)=>{var pe=Br();Ee(()=>{var vt,Vt;return pt(pe,"".concat((vt=i().length)!==null&&vt!==void 0?vt:"",`
                `).concat((Vt=i().length===1?"item":"items")!==null&&Vt!==void 0?Vt:""))}),I(Ge,pe)},$$slots:{default:!0}}),I(N,Fe)},Tt=N=>{var Fe=oz();Su(F(ft(Fe),2),{onclick:H,children:(Ge,Et)=>{var pe=Br();Ee(()=>{var vt,Vt;return pt(pe,"".concat((vt=i().length)!==null&&vt!==void 0?vt:"",`
                `).concat((Vt=i().length===1?"item":"items")!==null&&Vt!==void 0?Vt:""))}),I(Ge,pe)},$$slots:{default:!0}}),I(N,Fe)};re(Me,N=>{o(w)?N(at):N(Tt,!1)});var Je=F(Ce,2),qt=N=>{var Fe=az();Wa(z(Fe),{get root(){return o(r)},selected:!0,get onContextMenu(){return c().onContextMenu}}),I(N,Fe)};re(Je,N=>{!c().readOnly&&o(k)&&d()&&(zn(d())||ur(d()))&&!vo(d())&&Zt(Qe(d()),o(j))&&N(qt)});var x=F($,2),_=N=>{hs(N,{get validationError(){return o(R)},onExpand:H})};re(x,N=>{!o(R)||o(w)&&o(R).isChildError||N(_)});var E=F(x,2),U=N=>{var Fe=iz();be("click",Fe,we),I(N,Fe)},te=N=>{var Fe=sz();be("click",Fe,$e),I(N,Fe)};re(E,N=>{o(w)?N(U):N(te,!1)});var fe=F(ae,2),xe=N=>{var Fe=vz(),Ge=ft(Fe),Et=z(Ge),pe=fn=>{var $t,Ln,wt=lz();Cn(wt,"title",yd);var hn=z(wt),en=de(()=>o(k)&&Gr(d()));Wa(hn,{insert:!0,get selected(){return o(en)},onContextMenu:Ne}),Ee(Jt=>{$t=Mt(wt,1,"jse-insert-area jse-inside svelte-oawf7x",null,$t,Jt),Ln=Ho(wt,"",Ln,{"--level":o(j).length+1})},[()=>({"jse-hovered":o(g)===ul,"jse-selected":o(k)&&Gr(d())})],de),I(fn,wt)};re(Et,fn=>{!c().readOnly&&(o(g)===ul||o(k)&&Gr(d()))&&fn(pe)}),jr(F(Et,2),1,()=>o(T)||ds,Cr,(fn,$t,Ln)=>{var wt=cz(),hn=ft(wt);jr(hn,1,()=>function(gt,on,it){var Ft=on.start,Yt=Math.min(on.end,gt.length),En=lc(Ft,Yt);return it&&it.offset!==0?Eh(En,it.selectionStartIndex,it.selectionItemsCount,it.offset).map((vr,An)=>({index:vr,gutterIndex:An})):En.map(vr=>({index:vr,gutterIndex:vr}))}(i(),o($t),o(b)),gt=>gt.index,(gt,on)=>{var it=xr(),Ft=de(()=>Kr(l())?l().items[o(on).index]:void 0),Yt=de(()=>Gh(c().getJson(),d(),o(j).concat(String(o(on).index)))),En=ft(it),vr=de(()=>Dd(a(),o(on).index)),An=de(()=>Kr(s())?s().items[o(on).index]:void 0),Or=de(()=>Kr(u())?u().items[o(on).index]:void 0);Av(En,{get value(){return i()[o(on).index]},get pointer(){return o(vr)},get state(){return o(An)},get validationErrors(){return o(Ft)},get searchResults(){return o(Or)},get selection(){return o(Yt)},get context(){return c()},onDragSelectionStart:le,$$slots:{identifier:(yr,Sr)=>{var Ir=uz(),Er=z(Ir),Vn=z(Er);Ee(()=>pt(Vn,o(on).gutterIndex)),I(yr,Ir)}}}),I(gt,it)});var en=F(hn,2),Jt=gt=>{var on=de(()=>o(T)||ds);KM(gt,{get visibleSections(){return o(on)},sectionIndex:Ln,get total(){return i().length},get path(){return o(j)},get onExpandSection(){return c().onExpandSection},get selection(){return d()},get context(){return c()}})};re(en,gt=>{o($t).end<i().length&&gt(Jt)}),I(fn,wt)});var vt=F(Ge,2),Vt=F(z(vt),2),rr=fn=>{var $t=dz();be("click",$t,$e),I(fn,$t)};re(Vt,fn=>{o(r)||fn(rr)}),I(N,Fe)};re(fe,N=>{o(w)&&N(xe)}),be("click",_e,D),I(ee,q)},me=(ee,q)=>{var ae=_e=>{var ne=_z(),Ue=ft(ne),X=z(Ue),L=z(X),yt=z(L),Ze=pe=>{dn(pe,{data:ti})},Ce=pe=>{dn(pe,{data:jl})};re(yt,pe=>{o(w)?pe(Ze):pe(Ce,!1)});var st=F(L,2);_r(st,t,"identifier",{},null);var Me=F(st,2),at=pe=>{I(pe,pz())};re(Me,pe=>{o(r)||pe(at)});var Tt=F(Me,2),Je=z(Tt),qt=z(Je),x=pe=>{I(pe,hz())},_=pe=>{var vt=gz();Su(F(ft(vt),2),{onclick:H,children:(Vt,rr)=>{var fn=Br();Ee(($t,Ln)=>pt(fn,"".concat($t??"",`
                `).concat(Ln??"")),[()=>Object.keys(i()).length,()=>Object.keys(i()).length===1?"prop":"props"],de),I(Vt,fn)},$$slots:{default:!0}}),I(pe,vt)};re(qt,pe=>{o(w)?pe(x):pe(_,!1)});var E=F(Tt,2),U=pe=>{var vt=mz();Wa(z(vt),{get root(){return o(r)},selected:!0,get onContextMenu(){return c().onContextMenu}}),I(pe,vt)};re(E,pe=>{!c().readOnly&&o(k)&&d()&&(zn(d())||ur(d()))&&!vo(d())&&Zt(Qe(d()),o(j))&&pe(U)});var te=F(X,2),fe=pe=>{hs(pe,{get validationError(){return o(R)},onExpand:H})};re(te,pe=>{!o(R)||o(w)&&o(R).isChildError||pe(fe)});var xe=F(te,2),N=pe=>{var vt=bz();be("click",vt,we),I(pe,vt)},Fe=(pe,vt)=>{var Vt=rr=>{var fn=xz();be("click",fn,$e),I(rr,fn)};re(pe,rr=>{o(r)||rr(Vt)},vt)};re(xe,pe=>{o(w)?pe(N):pe(Fe,!1)});var Ge=F(Ue,2),Et=pe=>{var vt=kz(),Vt=ft(vt),rr=z(Vt),fn=hn=>{var en,Jt,gt=jz();Cn(gt,"title",yd);var on=z(gt),it=de(()=>o(k)&&Gr(d()));Wa(on,{insert:!0,get selected(){return o(it)},onContextMenu:Ne}),Ee(Ft=>{en=Mt(gt,1,"jse-insert-area jse-inside svelte-oawf7x",null,en,Ft),Jt=Ho(gt,"",Jt,{"--level":o(j).length+1})},[()=>({"jse-hovered":o(g)===ul,"jse-selected":o(k)&&Gr(d())})],de),I(hn,gt)};re(rr,hn=>{!c().readOnly&&(o(g)===ul||o(k)&&Gr(d()))&&hn(fn)}),jr(F(rr,2),1,()=>function(hn,en){var Jt=Object.keys(hn);return en&&en.offset!==0?Eh(Jt,en.selectionStartIndex,en.selectionItemsCount,en.offset):Jt}(i(),o(b)),Cr,(hn,en)=>{var Jt=xr(),gt=de(()=>Dd(a(),o(en))),on=de(()=>Jo(u())?u().properties[o(en)]:void 0),it=de(()=>Jo(l())?l().properties[o(en)]:void 0),Ft=de(()=>o(j).concat(o(en))),Yt=de(()=>Gh(c().getJson(),d(),o(Ft))),En=ft(Jt),vr=de(()=>Jo(s())?s().properties[o(en)]:void 0);Av(En,{get value(){return i()[o(en)]},get pointer(){return o(gt)},get state(){return o(vr)},get validationErrors(){return o(it)},get searchResults(){return o(on)},get selection(){return o(Yt)},get context(){return c()},onDragSelectionStart:le,$$slots:{identifier:(An,Or)=>{var yr,Sr=yz(),Ir=z(Sr),Er=de(()=>{return Vn=o(on),(Jn=Nh(Vn)?Vn.searchResults.filter(gr=>gr.field===Vo.key):void 0)&&Jn.length>0?Jn:void 0;var Vn,Jn});(function(Vn,Jn){lt(Jn,!1);var gr=P(void 0,!0),je=P(void 0,!0),an=h(Jn,"pointer",9),Q=h(Jn,"key",9),Te=h(Jn,"selection",9),tt=h(Jn,"searchResultItems",9),Nt=h(Jn,"onUpdateKey",9),et=h(Jn,"context",9),Bt=P(void 0,!0);function yn(Xt){o(je)||et().readOnly||(Xt.preventDefault(),et().onSelect(vp(o(Bt))))}function Lt(Xt,Wt){var Gt=Nt()(Q(),et().normalization.unescapeValue(Xt)),or=sn(o(Bt)).concat(Gt);et().onSelect(Wt===Qa.nextInside?rn(or):Ia(or)),Wt!==Qa.self&&et().focus()}function Sn(){et().onSelect(Ia(o(Bt))),et().focus()}W(()=>M(an()),()=>{p(Bt,Fo(an()))}),W(()=>(M(Te()),o(Bt)),()=>{p(gr,Dr(Te())&&Zt(Te().path,o(Bt)))}),W(()=>(o(gr),M(Te())),()=>{p(je,o(gr)&&vo(Te()))}),_n(),St(!0);var mt=QM(),Ut=ft(mt),dt=Xt=>{var Wt=de(()=>et().normalization.escapeValue(Q())),Gt=de(()=>vo(Te())?Te().initialValue:void 0);hw(Xt,{get value(){return o(Wt)},get initialValue(){return o(Gt)},label:"Edit key",shortText:!0,onChange:Lt,onCancel:Sn,get onFind(){return et().onFind}})},kt=Xt=>{var Wt,Gt=XM(),or=z(Gt),B=Oe=>{var Dt=de(()=>et().normalization.escapeValue(Q()));ww(Oe,{get text(){return o(Dt)},get searchResultItems(){return tt()}})},ie=Oe=>{var Dt=Br();Ee(bn=>pt(Dt,bn),[()=>Bc(et().normalization.escapeValue(Q()))],de),I(Oe,Dt)};re(or,Oe=>{tt()?Oe(B):Oe(ie,!1)}),Ee(Oe=>Wt=Mt(Gt,1,"jse-key svelte-2iqnqn",null,Wt,Oe),[()=>({"jse-empty":Q()===""})],de),be("dblclick",Gt,yn),I(Xt,Gt)};re(Ut,Xt=>{!et().readOnly&&o(je)?Xt(dt):Xt(kt,!1)});var Un=F(Ut,2),Fn=Xt=>{Wa(Xt,{selected:!0,get onContextMenu(){return et().onContextMenu}})};re(Un,Xt=>{et().readOnly||!o(gr)||o(je)||Xt(Fn)}),I(Vn,mt),ut()})(Ir,{get pointer(){return o(gt)},get key(){return o(en)},get selection(){return o(Yt)},get searchResultItems(){return o(Er)},get context(){return c()},onUpdateKey:V}),Ee(Vn=>yr=Mt(Sr,1,"jse-key-outer svelte-oawf7x",null,yr,Vn),[()=>({"jse-selected-key":Dr(o(Yt))&&Zt(o(Yt).path,o(Ft))})],de),I(An,Sr)}}}),I(hn,Jt)});var $t=F(Vt,2),Ln=F(z($t),2),wt=hn=>{var en=wz();be("click",en,$e),I(hn,en)};re(Ln,hn=>{o(r)||hn(wt)}),I(pe,vt)};re(Ge,pe=>{o(w)&&pe(Et)}),be("click",L,D),I(_e,ne)},$=_e=>{var ne=Ez(),Ue=z(ne),X=z(Ue);_r(X,t,"identifier",{},null);var L=F(X,2),yt=E=>{I(E,Sz())};re(L,E=>{o(r)||E(yt)});var Ze=F(L,2),Ce=z(Ze),st=de(()=>o(k)?d():void 0),Me=de(()=>{return E=u(),(U=Nh(E)?E.searchResults.filter(te=>te.field===Vo.value):void 0)&&U.length>0?U:void 0;var E,U});Uw(Ce,{get path(){return o(j)},get value(){return i()},get enforceString(){return o(O)},get selection(){return o(st)},get searchResultItems(){return o(Me)},get context(){return c()}});var at=F(Ze,2),Tt=E=>{var U=Cz();Wa(z(U),{get root(){return o(r)},selected:!0,get onContextMenu(){return c().onContextMenu}}),I(E,U)};re(at,E=>{!c().readOnly&&o(k)&&d()&&(zn(d())||ur(d()))&&!vo(d())&&Zt(Qe(d()),o(j))&&E(Tt)});var Je=F(Ue,2),qt=E=>{hs(E,{get validationError(){return o(R)},onExpand:H})};re(Je,E=>{o(R)&&E(qt)});var x=F(Je,2),_=E=>{var U=Oz();be("click",U,$e),I(E,U)};re(x,E=>{o(r)||E(_)}),I(_e,ne)};re(ee,_e=>{On(i())?_e(ae):_e($,!1)},q)};re(he,ee=>{Array.isArray(i())?ee(ue):ee(me,!1)});var ot=F(he,2),Ot=ee=>{var q,ae=Az();Cn(ae,"title",yd);var $=z(ae),_e=de(()=>o(k)&&Oo(d()));Wa($,{insert:!0,get selected(){return o(_e)},onContextMenu:ye}),Ee(ne=>q=Mt(ae,1,"jse-insert-area jse-after svelte-oawf7x",null,q,ne),[()=>({"jse-hovered":o(g)===wd,"jse-selected":o(k)&&Oo(d())})],de),I(ee,ae)};re(ot,ee=>{!c().readOnly&&(o(g)===wd||o(k)&&Oo(d()))&&ee(Ot)}),Ee((ee,q)=>{ze=Mt(We,1,ee,"svelte-oawf7x",ze,q),Cn(We,"data-path",o(n)),Cn(We,"aria-selected",o(k)),Re=Ho(We,"",Re,{"--level":o(j).length})},[()=>ai(Ks("jse-json-node",{"jse-expanded":o(w)},c().onClassName(o(j),i()))),()=>({"jse-root":o(r),"jse-selected":o(k)&&ur(d()),"jse-selected-value":o(k)&&zn(d()),"jse-readonly":c().readOnly,"jse-hovered":o(g)===zh})],de),be("mousedown",We,function(ee){if((ee.buttons===1||ee.buttons===2)&&!((q=ee.target).nodeName==="DIV"&&q.contentEditable==="true"||ee.buttons===1&&nw(ee.target,"BUTTON"))){var q;ee.stopPropagation(),ee.preventDefault(),c().focus(),document.addEventListener("mousemove",A,!0),document.addEventListener("mouseup",J);var ae=xd(ee.target),$=c().getJson(),_e=c().getDocumentState();if(!d()||ae===$n.after||ae===$n.inside||d().type!==ae&&d().type!==$n.multi||!Pl($,d(),o(j)))if(sr(sr().selecting=!0),sr(sr().selectionAnchor=o(j)),sr(sr().selectionAnchorType=ae),sr(sr().selectionFocus=o(j)),ee.shiftKey){var ne=c().getSelection();ne&&c().onSelect(Qr(wi(ne),o(j)))}else if(ae===$n.multi)if(o(r)&&ee.target.hasAttribute("data-path")){var Ue=ht(dw(i(),_e));c().onSelect(xv(Ue))}else c().onSelect(Qr(o(j),o(j)));else $!==void 0&&c().onSelect(Jh(ae,o(j)));else ee.button===0&&v()(ee)}}),be("mousemove",We,function(ee){if(sr().selecting){ee.preventDefault(),ee.stopPropagation(),sr().selectionFocus===void 0&&window.getSelection&&window.getSelection().empty();var q=xd(ee.target);Zt(o(j),sr().selectionFocus)&&q===sr().selectionAnchorType||(sr(sr().selectionFocus=o(j)),sr(sr().selectionAnchorType=q),c().onSelect(Qr(sr().selectionAnchor||sr().selectionFocus,sr().selectionFocus)))}}),be("mouseover",We,function(ee){sr().selecting||sr().dragging||(ee.stopPropagation(),Ga(ee.target,"data-type","selectable-value")?p(g,zh):Ga(ee.target,"data-type","selectable-key")?p(g,void 0):Ga(ee.target,"data-type","insert-selection-area-inside")?p(g,ul):Ga(ee.target,"data-type","insert-selection-area-after")&&p(g,wd),clearTimeout(m))}),be("mouseout",We,function(ee){ee.stopPropagation(),m=window.setTimeout(()=>p(g,void 0))}),I(e,We),ut()}var Mz={prefix:"fas",iconName:"jsoneditor-expand",icon:[512,512,[],"","M 0,448 V 512 h 512 v -64 z M 0,0 V 64 H 512 V 0 Z M 256,96 128,224 h 256 z M 256,416 384,288 H 128 Z"]},zz={prefix:"fas",iconName:"jsoneditor-collapse",icon:[512,512,[],"","m 0,224 v 64 h 512 v -64 z M 256,192 384,64 H 128 Z M 256,320 128,448 h 256 z"]},ug={prefix:"fas",iconName:"jsoneditor-format",icon:[512,512,[],"","M 0,32 v 64 h 416 v -64 z M 160,160 v 64 h 352 v -64 z M 160,288 v 64 h 288 v -64 z M 0,416 v 64 h 320 v -64 z"]},Pz={prefix:"fas",iconName:"jsoneditor-compact",icon:[512,512,[],"","M 0,32 v 64 h 512 v -64 z M 0,160 v 64 h 512 v -64 z M 0,288 v 64 h 352 v -64 z"]};function Tz(e,t){e.stopPropagation(),t.onCreateObject()}function Iz(e,t){e.stopPropagation(),t.onCreateArray()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-welcome.svelte-1eamlhk {
  flex: 1;
  overflow: auto;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  display: flex;
  flex-direction: column;
  align-items: center;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-welcome.svelte-1eamlhk:last-child {
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-welcome.svelte-1eamlhk .jse-space.jse-before:where(.svelte-1eamlhk) {
  flex: 1;
}
.jse-welcome.svelte-1eamlhk .jse-space.jse-after:where(.svelte-1eamlhk) {
  flex: 2;
}
.jse-welcome.svelte-1eamlhk .jse-contents:where(.svelte-1eamlhk) {
  display: flex;
  flex-direction: column;
  max-width: 300px;
  margin: 2em var(--jse-padding, 10px);
  gap: var(--jse-padding, 10px);
}
.jse-welcome.svelte-1eamlhk .jse-contents:where(.svelte-1eamlhk) .jse-welcome-info:where(.svelte-1eamlhk) {
  color: var(--jse-panel-color-readonly, #b2b2b2);
}
.jse-welcome.svelte-1eamlhk .jse-contents:where(.svelte-1eamlhk) button:where(.svelte-1eamlhk) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-primary-background, var(--jse-theme-color, #3883fa));
  color: var(--jse-button-primary-color, #fff);
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-welcome.svelte-1eamlhk .jse-contents:where(.svelte-1eamlhk) button:where(.svelte-1eamlhk):hover {
  background: var(--jse-button-primary-background-highlight, var(--jse-theme-color-highlight, #5f9dff));
}
.jse-welcome.svelte-1eamlhk .jse-contents:where(.svelte-1eamlhk) button:where(.svelte-1eamlhk):disabled {
  background: var(--jse-button-primary-background-disabled, #9d9d9d);
}`);var Nz=(e,t)=>t.onClick(),Lz=G('<div class="jse-welcome-info svelte-1eamlhk">You can paste clipboard data using <b>Ctrl+V</b>, or use the following options:</div> <button class="svelte-1eamlhk">Create object</button> <button class="svelte-1eamlhk">Create array</button>',1),Uz=G('<div class="jse-welcome svelte-1eamlhk" role="none"><div class="jse-space jse-before svelte-1eamlhk"></div> <div class="jse-contents svelte-1eamlhk"><div class="jse-welcome-title">Empty document</div> <!></div> <div class="jse-space jse-after svelte-1eamlhk"></div></div>');function Rv(e,t){var n=typeof e=="string"?e.toLowerCase():e,r=typeof t=="string"?t.toLowerCase():t;return M1(n,r)}function Dw(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:[],n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:[],r=arguments.length>3&&arguments[3]!==void 0?arguments[3]:1,a=Ke(e,t);if(zr(a)){if(n===void 0)throw new Error("Cannot sort: no property selected by which to sort the array");return function(i){var s=arguments.length>1&&arguments[1]!==void 0?arguments[1]:[],l=arguments.length>2&&arguments[2]!==void 0?arguments[2]:[],u=arguments.length>3&&arguments[3]!==void 0?arguments[3]:1,d=function(v,f){return function(g,m){var b=Ke(g,v),j=Ke(m,v);return b===void 0?f:j===void 0?-f:typeof b!="string"&&typeof j!="string"?b>j?f:b<j?-f:0:f*Rv(b,j)}}(l,u),c=Ke(i,s);return[{op:"replace",path:zt(s),value:c.slice(0).sort(d)}]}(e,t,n,r)}if(On(a))return function(i){var s=arguments.length>1&&arguments[1]!==void 0?arguments[1]:[],l=arguments.length>2&&arguments[2]!==void 0?arguments[2]:1,u=Ke(i,s),d=Object.keys(u).slice();d.sort((v,f)=>l*Rv(v,f));var c={};return d.forEach(v=>c[v]=u[v]),[{op:"replace",path:zt(s),value:c}]}(e,t,r);throw new Error("Cannot sort: no array or object")}Zl(["click"]);jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-navigation-bar-dropdown.svelte-2nnd2m {
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 3;
  background: var(--jse-navigation-bar-background, var(--jse-background-color, #fff));
  color: var(--jse-navigation-bar-dropdown-color, #656565);
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
  display: flex;
  flex-direction: column;
  max-height: 300px;
  overflow: auto;
  min-width: 80px;
}
.jse-navigation-bar-dropdown.svelte-2nnd2m button.jse-navigation-bar-dropdown-item:where(.svelte-2nnd2m) {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  outline: none;
  text-align: left;
  white-space: nowrap;
  box-sizing: border-box;
  padding: calc(0.5 * var(--jse-padding, 10px)) 36px;
}
.jse-navigation-bar-dropdown.svelte-2nnd2m button.jse-navigation-bar-dropdown-item:where(.svelte-2nnd2m):focus, .jse-navigation-bar-dropdown.svelte-2nnd2m button.jse-navigation-bar-dropdown-item:where(.svelte-2nnd2m):hover {
  background: var(--jse-navigation-bar-background-highlight, #e5e5e5);
}
.jse-navigation-bar-dropdown.svelte-2nnd2m button.jse-navigation-bar-dropdown-item.jse-selected:where(.svelte-2nnd2m) {
  background: var(--jse-navigation-bar-dropdown-color, #656565);
  color: var(--jse-navigation-bar-background, var(--jse-background-color, #fff));
}`);var Dz=G('<button type="button"> </button>'),qz=G('<button type="button" class="jse-navigation-bar-dropdown-item svelte-2nnd2m">...</button>'),$z=G('<div class="jse-navigation-bar-dropdown svelte-2nnd2m"><!> <!></div>');function Fz(e,t){lt(t,!1);var n=h(t,"items",9),r=h(t,"selectedItem",9),a=h(t,"onSelect",9);St(!0);var i=$z(),s=z(i);jr(s,1,()=>Vy(n(),100),d=>d,(d,c)=>{var v,f=Dz(),g=z(f);Ee((m,b,j)=>{v=Mt(f,1,"jse-navigation-bar-dropdown-item svelte-2nnd2m",null,v,m),Cn(f,"title",b),pt(g,j)},[()=>({"jse-selected":o(c)===r()}),()=>o(c).toString(),()=>El(o(c).toString(),30)],de),be("click",f,xa(()=>a()(o(c)))),I(d,f)});var l=F(s,2),u=d=>{var c=qz();Cn(c,"title","Limited to ".concat(100," items")),I(d,c)};re(l,d=>{n().length>100&&d(u)}),I(e,i),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-navigation-bar-item.svelte-752ro1 {
  position: relative;
  display: flex;
}
.jse-navigation-bar-item.svelte-752ro1 button.jse-navigation-bar-button:where(.svelte-752ro1) {
  font-family: inherit;
  font-size: inherit;
  padding: calc(0.5 * var(--jse-padding, 10px)) 2px;
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  outline: none;
  min-width: 2em;
  white-space: nowrap;
}
.jse-navigation-bar-item.svelte-752ro1 button.jse-navigation-bar-button:where(.svelte-752ro1):focus, .jse-navigation-bar-item.svelte-752ro1 button.jse-navigation-bar-button:where(.svelte-752ro1):hover {
  background: var(--jse-panel-button-background-highlight, #e0e0e0);
  color: var(--panel-button-color-highlight, var(--jse-text-color, #4d4d4d));
}
.jse-navigation-bar-item.svelte-752ro1 button.jse-navigation-bar-button.jse-navigation-bar-arrow:where(.svelte-752ro1) {
  padding: 2px var(--jse-padding, 10px) 0;
}
.jse-navigation-bar-item.svelte-752ro1 button.jse-navigation-bar-button.jse-navigation-bar-arrow.jse-open:where(.svelte-752ro1) {
  background: var(--jse-navigation-bar-background, var(--jse-background-color, #fff));
  color: var(--jse-navigation-bar-dropdown-color, #656565);
}
.jse-navigation-bar-item.svelte-752ro1:last-child {
  padding-right: var(--jse-padding, 10px);
}`);var Bz=G('<button type="button" class="jse-navigation-bar-button svelte-752ro1"> </button>'),Wz=G('<div class="jse-navigation-bar-item svelte-752ro1"><button type="button"><!></button> <!></div>');function cg(e,t){lt(t,!1);var n,r=P(void 0,!0),a=P(void 0,!0),{openAbsolutePopup:i,closeAbsolutePopup:s}=vi("absolute-popup"),l=h(t,"path",9),u=h(t,"index",9),d=h(t,"onSelect",9),c=h(t,"getItems",9),v=P(void 0,!0),f=P(!1,!0);function g(T){s(n),d()(o(r).concat(T))}W(()=>(M(l()),M(u())),()=>{p(r,l().slice(0,u()))}),W(()=>(M(l()),M(u())),()=>{p(a,l()[u()])}),_n(),St(!0);var m,b=Wz(),j=z(b);dn(z(j),{data:Gg});var w=F(j,2),O=T=>{var R=Bz(),k=z(R);Ee(()=>pt(k,o(a))),be("click",R,()=>g(o(a))),I(T,R)};re(w,T=>{o(a)!==void 0&&T(O)}),tr(b,T=>p(v,T),()=>o(v)),Ee(T=>m=Mt(j,1,"jse-navigation-bar-button jse-navigation-bar-arrow svelte-752ro1",null,m,T),[()=>({"jse-open":o(f)})],de),be("click",j,function(){if(o(v)){p(f,!0);var T={items:c()(o(r)),selectedItem:o(a),onSelect:g};n=i(Fz,T,{anchor:o(v),closeOnOuterClick:!0,onClose:()=>{p(f,!1)}})}}),I(e,b),ut()}function jp(e){var t,n;if(navigator.clipboard)return navigator.clipboard.writeText(e);if((t=(n=document).queryCommandSupported)!==null&&t!==void 0&&t.call(n,"copy")){var r=document.createElement("textarea");r.value=e,r.style.position="fixed",r.style.opacity="0",document.body.appendChild(r),r.select();try{document.execCommand("copy")}catch(a){console.error(a)}finally{document.body.removeChild(r)}return Promise.resolve()}return console.error("Copy failed."),Promise.resolve()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-navigation-bar-path-editor.svelte-zc2wx7 {
  flex: 1;
  display: flex;
  border: var(--jse-edit-outline, 2px solid #656565);
  background: var(--jse-background-color, #fff);
}
.jse-navigation-bar-path-editor.svelte-zc2wx7 input.jse-navigation-bar-text:where(.svelte-zc2wx7) {
  flex: 1;
  font-family: inherit;
  font-size: inherit;
  padding: 0 5px 1px;
  background: var(--jse-background-color, #fff);
  color: var(--jse-text-color, #4d4d4d);
  border: none;
  outline: none;
}
.jse-navigation-bar-path-editor.svelte-zc2wx7 button:where(.svelte-zc2wx7) {
  border: none;
  background: var(--jse-background-color, #fff);
  cursor: pointer;
  font-family: inherit;
  font-size: 80%;
  color: inherit;
}
.jse-navigation-bar-path-editor.svelte-zc2wx7 button.jse-navigation-bar-copy.copied:where(.svelte-zc2wx7) {
  color: var(--message-success-background, #9ac45d);
}
.jse-navigation-bar-path-editor.svelte-zc2wx7 button.jse-navigation-bar-validation-error:where(.svelte-zc2wx7) {
  color: var(--jse-error-color, #ee5341);
}
.jse-navigation-bar-path-editor.error.svelte-zc2wx7 {
  border-color: var(--jse-error-color, #ee5341);
}
.jse-navigation-bar-path-editor.error.svelte-zc2wx7 input.jse-navigation-bar-text:where(.svelte-zc2wx7) {
  color: var(--jse-error-color, #ee5341);
}
.jse-navigation-bar-path-editor.svelte-zc2wx7 .jse-copied-text:where(.svelte-zc2wx7) {
  background: var(--message-success-background, #9ac45d);
  color: var(--jse-message-success-color, #fff);
  position: relative;
  margin: 2px;
  padding: 0 5px;
  border-radius: 3px;
}`);var Hz=G('<button type="button" class="jse-navigation-bar-validation-error svelte-zc2wx7"><!></button>'),Vz=G('<div class="jse-copied-text svelte-zc2wx7">Copied!</div>'),Jz=G('<div><input type="text" class="jse-navigation-bar-text svelte-zc2wx7"> <!> <!> <button type="button" title="Copy selected path to the clipboard"><!></button></div>');function Gz(e,t){lt(t,!1);var n=P(),r=vi("absolute-popup"),a=h(t,"path",8),i=h(t,"pathParser",8),s=h(t,"onChange",8),l=h(t,"onClose",8),u=h(t,"onError",8),d=h(t,"pathExists",8),c=P(),v=P(),f=P(!1),g=void 0,m=P(!1);function b(){o(c).focus()}function j(J){try{var Z=i().parse(J);return function(Y){if(!d()(Y))throw new Error("Path does not exist in current document")}(Z),{path:Z,error:void 0}}catch(Y){return{path:void 0,error:Y}}}Yr(()=>{b()}),zo(()=>{clearTimeout(g)}),W(()=>(M(i()),M(a())),()=>{p(v,i().stringify(a()))}),W(()=>(o(f),o(v)),()=>{p(n,o(f)?j(o(v)).error:void 0)}),_n(),St();var w,O=Jz(),T=z(O);tr(T,J=>p(c,J),()=>o(c));var R=F(T,2),k=J=>{var Z=Hz();dn(z(Z),{data:Ei}),eo(Z,(Y,le)=>_s?.(Y,le),()=>Se({text:String(o(n)||"")},r)),I(J,Z)};re(R,J=>{o(n)&&J(k)});var D=F(R,2),H=J=>{I(J,Vz())};re(D,J=>{o(m)&&J(H)});var V,A=F(D,2);dn(z(A),{data:Va}),Ee((J,Z)=>{w=Mt(O,1,"jse-navigation-bar-path-editor svelte-zc2wx7",null,w,J),Mi(T,o(v)),V=Mt(A,1,"jse-navigation-bar-copy svelte-zc2wx7",null,V,Z)},[()=>({error:o(n)}),()=>({copied:o(m)})],de),be("keydown",T,xa(function(J){var Z=Pa(J);if(Z==="Escape"&&(J.preventDefault(),l()()),Z==="Enter"){J.preventDefault(),p(f,!0);var Y=j(o(v));Y.path!==void 0?s()(Y.path):u()(Y.error)}})),be("input",T,function(J){p(v,J.currentTarget.value)}),be("click",A,function(){jp(o(v)),p(m,!0),g=window.setTimeout(()=>p(m,!1),1e3),b()}),I(e,O),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-navigation-bar.svelte-xs03gj {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  background: var(--jse-panel-background, #ebebeb);
  color: var(--jse-panel-button-color, inherit);
  padding: 0;
  margin: 0;
  display: flex;
  overflow: auto;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-navigation-bar.svelte-xs03gj .jse-navigation-bar-edit:where(.svelte-xs03gj) {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px);
  color: var(--jse-panel-color-readonly, #b2b2b2);
  background: transparent;
  border: none;
  display: flex;
  cursor: pointer;
  outline: none;
  align-items: center;
}
.jse-navigation-bar.svelte-xs03gj .jse-navigation-bar-edit.flex:where(.svelte-xs03gj) {
  flex: 1;
}
.jse-navigation-bar.svelte-xs03gj .jse-navigation-bar-edit:where(.svelte-xs03gj):focus, .jse-navigation-bar.svelte-xs03gj .jse-navigation-bar-edit:where(.svelte-xs03gj):hover, .jse-navigation-bar.svelte-xs03gj .jse-navigation-bar-edit.editing:where(.svelte-xs03gj) {
  background: var(--jse-panel-button-background-highlight, #e0e0e0);
  color: var(--panel-button-color-highlight, var(--jse-text-color, #4d4d4d));
  transition: color 0.2s ease-in, background 0.2s ease-in;
}
.jse-navigation-bar.svelte-xs03gj .jse-navigation-bar-edit:where(.svelte-xs03gj) .jse-navigation-bar-space:where(.svelte-xs03gj) {
  flex: 1;
  text-align: left;
}`);var Kz=G("<!> <!>",1),Yz=G('<div class="jse-navigation-bar svelte-xs03gj"><!> <button type="button"><span class="jse-navigation-bar-space svelte-xs03gj"> </span> <!></button></div>');function Xz(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=Fr("jsoneditor:NavigationBar"),i=h(t,"json",9),s=h(t,"selection",9),l=h(t,"onSelect",9),u=h(t,"onError",9),d=h(t,"pathParser",9),c=P(void 0,!0),v=P(!1,!0);function f(Z){a("get items for path",Z);var Y=Ke(i(),Z);if(Array.isArray(Y))return lc(0,Y.length).map(String);if(On(Y)){var le=Object.keys(Y).slice(0);return le.sort(Rv),le}return[]}function g(Z){return ja(i(),Z)}function m(Z){a("select path",JSON.stringify(Z)),l()(Qr(Z,Z))}function b(){p(v,!1)}function j(Z){b(),m(Z)}W(()=>(M(s()),Qe),()=>{p(n,s()?Qe(s()):[])}),W(()=>(M(i()),o(n)),()=>{p(r,Ar(Ke(i(),o(n))))}),W(()=>o(n),()=>{o(n),setTimeout(()=>{if(o(c)&&o(c).scrollTo){var Z=o(c).scrollWidth-o(c).clientWidth;Z>0&&(a("scrollTo ",Z),o(c).scrollTo({left:Z,behavior:"smooth"}))}})}),_n(),St(!0);var w=Yz(),O=z(w),T=Z=>{var Y=Kz(),le=ft(Y);jr(le,1,()=>o(n),Cr,(we,$e,Ne)=>{cg(we,{getItems:f,get path(){return o(n)},index:Ne,onSelect:m})});var Ae=F(le,2),ce=we=>{cg(we,{getItems:f,get path(){return o(n)},get index(){return o(n).length},onSelect:m})};re(Ae,we=>{o(r)&&we(ce)}),I(Z,Y)},R=Z=>{Gz(Z,{get path(){return o(n)},onClose:b,onChange:j,get onError(){return u()},pathExists:g,get pathParser(){return d()}})};re(O,Z=>{o(v)?Z(R,!1):Z(T)});var k,D=F(O,2),H=z(D),V=z(H),A=F(H,2),J=de(()=>o(v)?ik:sk);dn(A,{get data(){return o(J)}}),tr(w,Z=>p(c,Z),()=>o(c)),Ee((Z,Y)=>{k=Mt(D,1,"jse-navigation-bar-edit svelte-xs03gj",null,k,Z),Cn(D,"title",o(v)?"Cancel editing the selected path":"Edit the selected path"),pt(V,Y)},[()=>({flex:!o(v),editing:o(v)}),()=>Ar(i())||o(v)?" ":"Navigation bar"],de),be("click",D,function(){p(v,!o(v))}),I(e,w),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-search-box.svelte-1mxl2uo {
  border: var(--jse-panel-border, var(--jse-main-border, 1px solid #d7d7d7));
  border-radius: 3px;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  background: var(--jse-panel-background, #ebebeb);
  color: var(--jse-panel-color-readonly, #b2b2b2);
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
  display: inline-block;
  width: 400px;
  max-width: 100%;
  overflow: auto;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) {
  display: flex;
  align-items: stretch;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) button:where(.svelte-1mxl2uo),
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) input:where(.svelte-1mxl2uo) {
  font-family: inherit;
  font-size: inherit;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) button:where(.svelte-1mxl2uo) {
  display: block;
  text-align: center;
  border: none;
  padding: 0 5px;
  margin: 0;
  cursor: pointer;
  color: var(--jse-panel-button-color, inherit);
  background: var(--jse-panel-button-background, transparent);
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) button:where(.svelte-1mxl2uo):hover {
  color: var(--panel-button-color-highlight, var(--jse-text-color, #4d4d4d));
  background: var(--jse-panel-button-background-highlight, #e0e0e0);
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) input:where(.svelte-1mxl2uo) {
  color: var(--jse-panel-color, var(--jse-text-color, #4d4d4d));
  border: var(--jse-input-border, 1px solid #d8dbdf);
  border-radius: 3px;
  background: var(--jse-input-background, var(--jse-background-color, #fff));
  height: 28px;
  padding: 0 5px;
  margin: 0;
  flex: 1;
  width: 0;
  min-width: 50px;
  outline: none;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-replace-toggle:where(.svelte-1mxl2uo) {
  padding: var(--jse-padding, 10px) calc(0.5 * var(--jse-padding, 10px));
  min-width: 20px;
  background: var(--jse-panel-button-background-highlight, #e0e0e0);
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: calc(0.5 * var(--jse-padding, 10px));
  gap: calc(0.5 * var(--jse-padding, 10px));
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-search-section:where(.svelte-1mxl2uo) {
  flex: 1;
  display: flex;
  align-items: center;
  position: relative;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-search-section:where(.svelte-1mxl2uo) .jse-search-icon:where(.svelte-1mxl2uo) {
  color: inherit;
  cursor: inherit;
  background: inherit;
  width: 32px;
  text-align: center;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-search-section:where(.svelte-1mxl2uo) label.jse-search-input-label:where(.svelte-1mxl2uo) {
  flex: 1;
  display: flex;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-search-section:where(.svelte-1mxl2uo) .jse-search-count:where(.svelte-1mxl2uo) {
  color: inherit;
  font-size: 80%;
  visibility: hidden;
  padding: 0 5px;
  min-width: 36px;
  text-align: center;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-search-section:where(.svelte-1mxl2uo) .jse-search-count.jse-visible:where(.svelte-1mxl2uo) {
  visibility: visible;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-replace-section:where(.svelte-1mxl2uo) {
  flex: 1;
  display: flex;
  padding-left: 32px;
}
.jse-search-box.svelte-1mxl2uo .jse-search-form:where(.svelte-1mxl2uo) .jse-search-contents:where(.svelte-1mxl2uo) .jse-replace-section:where(.svelte-1mxl2uo) button:where(.svelte-1mxl2uo) {
  width: auto;
}`);var Qz=G('<button type="button" class="jse-replace-toggle svelte-1mxl2uo" title="Toggle visibility of replace options (Ctrl+H)"><!></button>'),Zz=G('<div class="jse-replace-section svelte-1mxl2uo"><input class="jse-replace-input svelte-1mxl2uo" title="Enter replacement text" type="text" placeholder="Replace"> <button type="button" title="Replace current occurrence (Ctrl+Enter)" class="svelte-1mxl2uo">Replace</button> <button type="button" title="Replace all occurrences" class="svelte-1mxl2uo">All</button></div>'),eP=G('<div class="jse-search-box svelte-1mxl2uo"><form class="jse-search-form svelte-1mxl2uo"><!> <div class="jse-search-contents svelte-1mxl2uo"><div class="jse-search-section svelte-1mxl2uo"><div class="jse-search-icon svelte-1mxl2uo"><!></div> <label class="jse-search-input-label svelte-1mxl2uo" about="jse-search input"><input class="jse-search-input svelte-1mxl2uo" title="Enter text to search" type="text" placeholder="Find"></label> <div> </div> <button type="button" class="jse-search-next svelte-1mxl2uo" title="Go to next search result (Enter)"><!></button> <button type="button" class="jse-search-previous svelte-1mxl2uo" title="Go to previous search result (Shift+Enter)"><!></button> <button type="button" class="jse-search-clear svelte-1mxl2uo" title="Close search box (Esc)"><!></button></div> <!></div></form></div>');function qw(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=P(void 0,!0),i=Fr("jsoneditor:SearchBox"),s=h(t,"json",9),l=h(t,"documentState",9),u=h(t,"parser",9),d=h(t,"showSearch",9),c=h(t,"showReplace",13),v=h(t,"readOnly",9),f=h(t,"columns",9),g=h(t,"onSearch",9),m=h(t,"onFocus",9),b=h(t,"onPatch",9),j=h(t,"onClose",9),w=P("",!0),O="",T=P("",!0),R=P(!1,!0),k=P(void 0,!0),D=Si(function(ne){return me.apply(this,arguments)},300),H=Si(function(ne){return ot.apply(this,arguments)},300);function V(){c(!c()&&!v())}function A(ne){ne.stopPropagation();var Ue=Pa(ne);Ue==="Enter"&&(ne.preventDefault(),o(w)!==O?D.flush():Ne()),Ue==="Shift+Enter"&&(ne.preventDefault(),ze()),Ue==="Ctrl+Enter"&&(ne.preventDefault(),c()?le():Ne()),Ue==="Ctrl+H"&&(ne.preventDefault(),V()),Ue==="Escape"&&(ne.preventDefault(),q())}function J(ne){Pa(ne)==="Enter"&&(ne.preventDefault(),ne.stopPropagation(),le())}function Z(){return Y.apply(this,arguments)}function Y(){return(Y=Rt(function*(){pr(),yield D.flush()})).apply(this,arguments)}function le(){return Ae.apply(this,arguments)}function Ae(){return(Ae=Rt(function*(){var ne;if(!v()){var Ue=(ne=o(k))===null||ne===void 0?void 0:ne.activeItem;if(i("handleReplace",{replaceText:o(T),activeItem:Ue}),o(k)&&Ue&&s()!==void 0){p(k,Se(Se({},Kh(o(k))),{},{activeIndex:o(r)}));var{operations:X,newSelection:L}=CR(s(),l(),o(T),Ue,u());b()(X,(yt,Ze)=>({state:Ze,selection:L})),pr(),yield H.flush(),yield We()}}})).apply(this,arguments)}function ce(){return we.apply(this,arguments)}function we(){return(we=Rt(function*(){if(!v()){i("handleReplaceAll",{text:o(w),replaceText:o(T)});var{operations:ne,newSelection:Ue}=function(X,L,yt,Ze,Ce){for(var st=Yh(yt,X,{maxResults:1/0}),Me=[],at=0;at<st.length;at++){var Tt=st[at-1],Je=st[at];at!==0&&Je.field===Tt.field&&Zt(Je.path,Tt.path)?ht(Me).items.push(Je):Me.push({path:Je.path,field:Je.field,items:[Je]})}Me.sort((_,E)=>_.field!==E.field?_.field===Vo.key?1:-1:E.path.length-_.path.length);var qt,x=[];return Me.forEach(_=>{var{field:E,path:U,items:te}=_;if(E===Vo.key){var fe=sn(U),xe=Ke(X,fe),N=ht(U),Fe=ou(fe,Object.keys(xe),N,Qh(N,Ze,te));x=x.concat(Fe),qt=ks(X,Fe)}else{if(E!==Vo.value)throw new Error("Cannot replace: unknown type of search result field ".concat(E));var Ge=Ke(X,U);if(Ge===void 0)throw new Error("Cannot replace: path not found ".concat(zt(U)));var Et=typeof Ge=="string"?Ge:String(Ge),pe=Oa(X,L,U),vt=Qh(Et,Ze,te),Vt=[{op:"replace",path:zt(U),value:pe?vt:Js(vt,Ce)}];x=x.concat(Vt),qt=ks(X,Vt)}}),{operations:x,newSelection:qt}}(s(),l(),o(w),o(T),u());b()(ne,(X,L)=>({state:L,selection:Ue})),yield We()}})).apply(this,arguments)}function $e(ne){ne.select()}function Ne(){return ye.apply(this,arguments)}function ye(){return(ye=Rt(function*(){p(k,o(k)?Kh(o(k)):void 0),yield We()})).apply(this,arguments)}function ze(){return Re.apply(this,arguments)}function Re(){return Re=Rt(function*(){p(k,o(k)?function(ne){var Ue=ne.activeIndex>0?ne.activeIndex-1:ne.items.length-1,X=ne.items[Ue],L=ne.items.map((yt,Ze)=>Se(Se({},yt),{},{active:Ze===Ue}));return Se(Se({},ne),{},{items:L,activeItem:X,activeIndex:Ue})}(o(k)):void 0),yield We()}),Re.apply(this,arguments)}function We(){return he.apply(this,arguments)}function he(){return(he=Rt(function*(){var ne;i("handleFocus",o(k));var Ue=(ne=o(k))===null||ne===void 0?void 0:ne.activeItem;Ue&&s()!==void 0&&(yield m()(Ue.path,Ue.resultIndex))})).apply(this,arguments)}function ue(){return ue=Rt(function*(ne){yield Ot(ne,o(w),s())}),ue.apply(this,arguments)}function me(){return me=Rt(function*(ne){yield Ot(d(),ne,s()),yield We()}),me.apply(this,arguments)}function ot(){return ot=Rt(function*(ne){yield Ot(d(),o(w),ne)}),ot.apply(this,arguments)}function Ot(ne,Ue,X){return ee.apply(this,arguments)}function ee(){return ee=Rt(function*(ne,Ue,X){return ne?(i("applySearch",{showSearch:ne,text:Ue}),Ue===""?(i("clearing search result"),o(k)!==void 0&&p(k,void 0),Promise.resolve()):(O=Ue,p(R,!0),new Promise(L=>{setTimeout(()=>{var yt=Yh(Ue,X,{maxResults:jd,columns:f()});p(k,function(Ze,Ce){var st=Ce!=null&&Ce.activeItem?Zh(Ce.activeItem):void 0,Me=Ze.findIndex(Je=>Zt(st,Zh(Je))),at=Me!==-1?Me:Ce?.activeIndex!==void 0&&Ce?.activeIndex<Ze.length?Ce?.activeIndex:Ze.length>0?0:-1,Tt=Ze.map((Je,qt)=>Se(Se({resultIndex:qt},Je),{},{active:qt===at}));return{items:Tt,activeItem:Tt[at],activeIndex:at}}(yt,o(k))),p(R,!1),L()})}))):(o(k)&&p(k,void 0),Promise.resolve())}),ee.apply(this,arguments)}function q(){i("handleClose"),D.cancel(),H.cancel(),Ot(!1,o(w),s()),j()()}W(()=>o(k),()=>{var ne;p(n,((ne=o(k))===null||ne===void 0||(ne=ne.items)===null||ne===void 0?void 0:ne.length)||0)}),W(()=>o(k),()=>{var ne;p(r,((ne=o(k))===null||ne===void 0?void 0:ne.activeIndex)||0)}),W(()=>(o(n),jd),()=>{p(a,o(n)>=jd?"".concat(999,"+"):String(o(n)))}),W(()=>(M(g()),o(k)),()=>{g()(o(k))}),W(()=>M(d()),()=>{(function(ne){ue.apply(this,arguments)})(d())}),W(()=>o(w),()=>{D(o(w))}),W(()=>M(s()),()=>{H(s())}),_n(),St(!0);var ae=xr(),$=ft(ae),_e=ne=>{var Ue=eP(),X=z(Ue),L=z(X),yt=N=>{var Fe=Qz(),Ge=z(Fe),Et=de(()=>c()?ti:jl);dn(Ge,{get data(){return o(Et)}}),be("click",Fe,V),I(N,Fe)};re(L,N=>{v()||N(yt)});var Ze=z(F(L,2)),Ce=z(Ze),st=z(Ce),Me=N=>{dn(N,{data:ck,spin:!0})},at=N=>{dn(N,{data:fc})};re(st,N=>{o(R)?N(Me):N(at,!1)});var Tt=F(Ce,2),Je=z(Tt);qr(()=>Hu(Je,()=>o(w),N=>p(w,N))),eo(Je,N=>$e?.(N)),qr(()=>be("paste",Je,Z));var qt,x=F(Tt,2),_=z(x),E=F(x,2);dn(z(E),{data:lk});var U=F(E,2);dn(z(U),{data:uk});var te=F(U,2);dn(z(te),{data:vc});var fe=F(Ze,2),xe=N=>{var Fe=Zz(),Ge=z(Fe),Et=F(Ge,2),pe=F(Et,2);Hu(Ge,()=>o(T),vt=>p(T,vt)),be("keydown",Ge,J),be("click",Et,le),be("click",pe,ce),I(N,Fe)};re(fe,N=>{c()&&!v()&&N(xe)}),Ee(N=>{var Fe,Ge;qt=Mt(x,1,"jse-search-count svelte-1mxl2uo",null,qt,N),pt(_,"".concat((Fe=o(r)!==-1&&o(r)<o(n)?"".concat(o(r)+1,"/"):"")!==null&&Fe!==void 0?Fe:"").concat((Ge=o(a))!==null&&Ge!==void 0?Ge:""))},[()=>({"jse-visible":o(w)!==""})],de),be("click",E,Ne),be("click",U,ze),be("click",te,q),be("keydown",X,A),I(ne,Ue)};re($,ne=>{d()&&ne(_e)}),I(e,ae),ut()}var Ll=Symbol("path");function tP(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:1/0,r={};Array.isArray(e)&&function(i,s,l){if(i.length<s)i.forEach(l);else for(var u=s>1?(i.length-1)/(s-1):i.length,d=0;d<s;d++){var c=Math.floor(d*u);l(i[c],c,i)}}(e,n,i=>{On(i)?$w(i,r,t):r[Ll]=!0});var a=[];return Ll in r&&a.push([]),Fw(r,[],a,t),a}function $w(e,t,n){for(var r in e){var a=e[r],i=t[r]||(t[r]={});On(a)&&n?$w(a,i,n):i[Ll]===void 0&&(i[Ll]=!0)}}function Fw(e,t,n,r){for(var a in e){var i=t.concat(a),s=e[a];s&&s[Ll]===!0&&n.push(i),$r(s)&&r&&Fw(s,i,n,r)}}function nP(e,t,n,r,a,i){for(var s=arguments.length>6&&arguments[6]!==void 0?arguments[6]:80,l=zr(n)?n.length:0,u=function(O,T){var R=Object.values(O);if(Pn(R))return T;var k=(D,H)=>D+H;return R.reduce(k)/R.length}(r,a),d=e-s,c=t+2*s,v=O=>r[O]||a,f=0,g=i;g<d&&f<l;)g+=v(f),f++;f>0&&(g-=v(--f));for(var m=f,b=0;b<c&&m<l;)b+=v(m),m++;for(var j=0,w=m;w<l;w++)j+=v(w);return{startIndex:f,endIndex:m,startHeight:g,endHeight:j,averageItemHeight:u,visibleHeight:b,visibleItems:zr(n)?n.slice(f,m):[]}}function dg(e,t,n,r){for(var{rowIndex:a}=So(e,t),i=0,s=0;s<a;s++)i+=n[s]||r;return i}function So(e,t){var[n,...r]=e,a=parseInt(n,10);return{rowIndex:isNaN(a)?-1:a,columnIndex:t.findIndex(i=>Ta(r,i))}}function hi(e,t){var{rowIndex:n,columnIndex:r}=e;return[String(n),...t[r]]}function rP(e,t){var[n,r]=Hv(e,s=>Yf(s.path[0])),a=Wv(n,oP),i=Gv(a,s=>{var l={row:[],columns:{}};return s.forEach(u=>{var d=function(c,v){var f=So(c.path,v);return f.columnIndex!==-1?f.columnIndex:-1}(u,t);d!==-1?(l.columns[d]===void 0&&(l.columns[d]=[]),l.columns[d].push(u)):l.row.push(u)}),l});return{root:r,rows:i}}function Nd(e,t){if(t&&t.length!==0)return t.length===1?t[0]:{path:e,message:"Multiple validation issues: "+t.map(n=>qo(n.path)+" "+n.message).join(", "),severity:jo.warning}}function oP(e){return parseInt(e.path[0],10)}function aP(e,t,n){var r=t.some(a=>function(i,s,l){if(!i)return!1;if(s.op==="replace"){var u=Fo(s.path),{rowIndex:d,columnIndex:c}=So(u,l),v=l.findIndex(f=>Zt(f,i.path));if(d!==-1&&c!==-1&&c!==v)return!1}return!0}(e,a,n));return r?void 0:e}var Zr=Fr("jsoneditor:actions");function Bw(e){return Mv.apply(this,arguments)}function Mv(){return Mv=Rt(function*(e){var{json:t,selection:n,indentation:r,readOnly:a,parser:i,onPatch:s}=e;if(!a&&t!==void 0&&n&&as(n)){var l=pw(t,n,r,i);if(l!==void 0){Zr("cut",{selection:n,clipboard:l,indentation:r}),yield jp(l);var{operations:u,newSelection:d}=xw(t,n);s(u,(c,v)=>({state:v,selection:d}))}}}),Mv.apply(this,arguments)}function Ww(e){return zv.apply(this,arguments)}function zv(){return zv=Rt(function*(e){var{json:t,selection:n,indentation:r,parser:a}=e,i=pw(t,n,r,a);i!==void 0&&(Zr("copy",{clipboard:i,indentation:r}),yield jp(i))}),zv.apply(this,arguments)}function Hw(e){var{clipboardText:t,json:n,selection:r,readOnly:a,parser:i,onPatch:s,onChangeText:l,openRepairModal:u}=e;if(!a)try{d(t)}catch{u(t,v=>{Zr("repaired pasted text: ",v),d(v)})}function d(c){if(n!==void 0){var v=r||rn([]),f=bw(n,v,c,i);Zr("paste",{pastedText:c,operations:f,ensureSelection:v}),s(f,(g,m)=>{var b=m;return f.filter(j=>(Nv(j)||ic(j))&&Ar(j.value)).forEach(j=>{var w=Bo(n,j.path);b=Pi(g,b,w)}),{state:b}})}else Zr("paste text",{pastedText:c}),l(t,(g,m)=>{if(g)return{state:Pi(g,m,[])}})}}function Vw(e){var{json:t,text:n,selection:r,keepSelection:a,readOnly:i,onChange:s,onPatch:l}=e;if(!i&&r){var u=t!==void 0&&(Dr(r)||zn(r))?Qr(r.path,r.path):r;if(Pn(Qe(r)))Zr("remove root",{selection:r}),s&&s({text:"",json:void 0},t!==void 0?{text:void 0,json:t}:{text:n||"",json:t},{contentErrors:void 0,patchResult:void 0});else if(t!==void 0){var{operations:d,newSelection:c}=xw(t,u);Zr("remove",{operations:d,selection:r,newSelection:c}),l(d,(v,f)=>({state:f,selection:a?r:c}))}}}function ac(e){var{insertType:t,selectInside:n,initialValue:r,json:a,selection:i,readOnly:s,parser:l,onPatch:u,onReplaceJson:d}=e;if(!s){var c=function(b,j,w){if(w==="object")return{};if(w==="array")return[];if(w==="structure"&&b!==void 0){var O=j?vw(j):[],T=Ke(b,O);if(Array.isArray(T)&&!Pn(T)){var R=Eo(T);return Ar(R)?Jv(R,k=>Array.isArray(k)?[]:On(k)?void 0:""):""}}return""}(a,i,t);if(a!==void 0){var v=l.stringify(c),f=bw(a,i,v,l);Zr("onInsert",{insertType:t,operations:f,newValue:c,data:v});var g=ht(f.filter(b=>b.op==="add"||b.op==="replace"));u(f,(b,j,w)=>{if(g){var O=Bo(b,g.path);if(Ar(c))return{state:Uo(b,j,O,dp),selection:n?Na(O):w};if(c===""){var T=Pn(O)?void 0:Ke(b,sn(O));return{state:Uo(b,j,O,_u),selection:On(T)?vp(O,r):Yu(O,r)}}}}),Zr("after patch")}else{Zr("onInsert",{insertType:t,newValue:c});var m=[];d(c,(b,j)=>({state:Pi(b,j,m),selection:Ar(c)?Na(m):Yu(m)}))}}}function Jw(e){return Pv.apply(this,arguments)}function Pv(){return Pv=Rt(function*(e){var{char:t,selectInside:n,json:r,selection:a,readOnly:i,parser:s,onPatch:l,onReplaceJson:u,onSelect:d}=e;i||(Dr(a)?d(Se(Se({},a),{},{edit:!0,initialValue:t})):t==="{"?ac({insertType:"object",selectInside:n,initialValue:void 0,json:r,selection:a,readOnly:i,parser:s,onPatch:l,onReplaceJson:u}):t==="["?ac({insertType:"array",selectInside:n,initialValue:void 0,json:r,selection:a,readOnly:i,parser:s,onPatch:l,onReplaceJson:u}):zn(a)&&r!==void 0?Ar(Ke(r,a.path))||d(Se(Se({},a),{},{edit:!0,initialValue:t})):(Zr("onInsertValueWithCharacter",{char:t}),yield function(c){return Tv.apply(this,arguments)}({char:t,json:r,selection:a,readOnly:i,parser:s,onPatch:l,onReplaceJson:u})))}),Pv.apply(this,arguments)}function Tv(){return Tv=Rt(function*(e){var{char:t,json:n,selection:r,readOnly:a,parser:i,onPatch:s,onReplaceJson:l}=e;a||ac({insertType:"value",selectInside:!1,initialValue:t,json:n,selection:r,readOnly:a,parser:i,onPatch:s,onReplaceJson:l})}),Tv.apply(this,arguments)}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-json-preview.svelte-1vjn89h {
  flex: 1;
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  color: var(--jse-panel-color-readonly, #b2b2b2);
  overflow: auto;
  white-space: pre-wrap;
  padding: 2px;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}`);var iP=G('<div class="jse-json-preview svelte-1vjn89h"> </div>');function Gw(e,t){lt(t,!1);var n=P(),r=P(),a=h(t,"text",8),i=h(t,"json",8),s=h(t,"indentation",8),l=h(t,"parser",8);W(()=>(M(i()),M(a())),()=>{p(n,i()!==void 0?{json:i()}:{text:a()||""})}),W(()=>(o(n),M(s()),M(l()),gv),()=>{p(r,El(fv(o(n),s(),l()),gv))}),_n(),St();var u=iP(),d=z(u);Ee(()=>pt(d,o(r))),I(e,u),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
button.jse-context-menu-button.svelte-1idfykj {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  flex: 1;
  white-space: nowrap;
  padding: var(--jse-padding, 10px);
  color: inherit;
}
button.jse-context-menu-button.svelte-1idfykj:hover {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
}
button.jse-context-menu-button.svelte-1idfykj:focus {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
  z-index: 1;
}
button.jse-context-menu-button.svelte-1idfykj:disabled {
  color: var(--jse-context-menu-color-disabled, #9d9d9d);
  background: unset;
}
button.jse-context-menu-button.left.svelte-1idfykj {
  text-align: left;
}
button.jse-context-menu-button.svelte-1idfykj svg {
  width: 16px;
}`);var sP=G('<button type="button"><!> <!></button>');function Ld(e,t){lt(t,!1);var n=h(t,"item",8),r=h(t,"className",8,void 0),a=h(t,"onRequestClose",8);St();var i=sP(),s=z(i),l=c=>{dn(c,{get data(){return n().icon}})};re(s,c=>{n().icon&&c(l)});var u=F(s,2),d=c=>{var v=Br();Ee(()=>pt(v,n().text)),I(c,v)};re(u,c=>{n().text&&c(d)}),Ee(c=>{Mt(i,1,c,"svelte-1idfykj"),Cn(i,"title",n().title),i.disabled=n().disabled||!1},[()=>ai(Ks("jse-context-menu-button",r(),n().className))],de),be("click",i,c=>{a()(),n().onClick(c)}),I(e,i),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-dropdown-button.svelte-11rxb2m {
  flex: 1;
  line-height: normal;
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  position: relative;
  padding: 0;
  display: flex;
}
.jse-dropdown-button.svelte-11rxb2m ul:where(.svelte-11rxb2m) {
  margin: 0;
  padding: 0;
}
.jse-dropdown-button.svelte-11rxb2m ul:where(.svelte-11rxb2m) li:where(.svelte-11rxb2m) {
  margin: 0;
  padding: 0;
  list-style-type: none;
}
.jse-dropdown-button.svelte-11rxb2m button.jse-open-dropdown:where(.svelte-11rxb2m) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  width: 2em;
  background: var(--jse-context-menu-background, #656565);
  color: var(--jse-context-menu-color, var(--jse-text-color-inverse, #fff));
  border-radius: 0;
}
.jse-dropdown-button.svelte-11rxb2m button.jse-open-dropdown.jse-visible:where(.svelte-11rxb2m) {
  background: var(--jse-context-menu-background, #656565);
}
.jse-dropdown-button.svelte-11rxb2m button.jse-open-dropdown:where(.svelte-11rxb2m):hover {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
}
.jse-dropdown-button.svelte-11rxb2m button.jse-open-dropdown:where(.svelte-11rxb2m):focus {
  z-index: 1;
}
.jse-dropdown-button.svelte-11rxb2m button.jse-open-dropdown:where(.svelte-11rxb2m):disabled {
  color: var(--jse-context-menu-color-disabled, #9d9d9d);
  background: unset;
}
.jse-dropdown-button.svelte-11rxb2m .jse-dropdown-items:where(.svelte-11rxb2m) {
  display: none;
  position: absolute;
  top: 100%;
  left: 0;
  z-index: 1;
  background: var(--jse-context-menu-background, #656565);
  color: var(--jse-context-menu-color, var(--jse-text-color-inverse, #fff));
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
}
.jse-dropdown-button.svelte-11rxb2m .jse-dropdown-items.jse-visible:where(.svelte-11rxb2m) {
  display: block;
}
.jse-dropdown-button.svelte-11rxb2m .jse-dropdown-items:where(.svelte-11rxb2m) button:where(.svelte-11rxb2m) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  width: 100%;
  text-align: left;
  padding: var(--jse-padding, 10px);
  margin: 0;
}
.jse-dropdown-button.svelte-11rxb2m .jse-dropdown-items:where(.svelte-11rxb2m) button:where(.svelte-11rxb2m):hover {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
}
.jse-dropdown-button.svelte-11rxb2m .jse-dropdown-items:where(.svelte-11rxb2m) button:where(.svelte-11rxb2m):disabled {
  color: var(--jse-context-menu-color-disabled, #9d9d9d);
  background: unset;
}`);var lP=G('<li class="svelte-11rxb2m"><button type="button"><!> </button></li>'),uP=G('<div role="button" tabindex="0" class="jse-dropdown-button svelte-11rxb2m"><!> <button type="button" data-type="jse-open-dropdown"><!></button> <div><ul class="svelte-11rxb2m"></ul></div></div>');jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
button.jse-context-menu-button.svelte-1idfykj {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  flex: 1;
  white-space: nowrap;
  padding: var(--jse-padding, 10px);
  color: inherit;
}
button.jse-context-menu-button.svelte-1idfykj:hover {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
}
button.jse-context-menu-button.svelte-1idfykj:focus {
  background: var(--jse-context-menu-background-highlight, #7a7a7a);
  z-index: 1;
}
button.jse-context-menu-button.svelte-1idfykj:disabled {
  color: var(--jse-context-menu-color-disabled, #9d9d9d);
  background: unset;
}
button.jse-context-menu-button.left.svelte-1idfykj {
  text-align: left;
}
button.jse-context-menu-button.svelte-1idfykj svg {
  width: 16px;
}`);var cP=G('<button type="button" slot="defaultItem"><!> </button>');function Ud(e,t){lt(t,!1);var n=P(),r=h(t,"item",8),a=h(t,"className",8,void 0),i=h(t,"onRequestClose",8);W(()=>(M(r()),M(i())),()=>{p(n,r().items.map(s=>Se(Se({},s),{},{onClick:l=>{i()(),s.onClick(l)}})))}),_n(),St(),function(s,l){lt(l,!1);var u=P(void 0,!0),d=h(l,"items",25,()=>[]),c=h(l,"title",9,void 0),v=h(l,"width",9,"120px"),f=P(!1,!0);function g(){p(f,!1)}function m(k){Pa(k)==="Escape"&&(k.preventDefault(),p(f,!1))}Yr(()=>{document.addEventListener("click",g),document.addEventListener("keydown",m)}),zo(()=>{document.removeEventListener("click",g),document.removeEventListener("keydown",m)}),W(()=>M(d()),()=>{p(u,d().every(k=>k.disabled===!0))}),_n(),St(!0);var b=uP(),j=z(b);_r(j,l,"defaultItem",{},null);var w,O=F(j,2);dn(z(O),{data:ti});var T,R=F(O,2);jr(z(R),5,d,Cr,(k,D)=>{var H=lP(),V=z(H),A=z(V),J=Y=>{dn(Y,{get data(){return o(D).icon}})};re(A,Y=>{o(D).icon&&Y(J)});var Z=F(A);Ee(()=>{var Y;Cn(V,"title",o(D).title),V.disabled=o(D).disabled,Mt(V,1,ai(o(D).className),"svelte-11rxb2m"),pt(Z," ".concat((Y=o(D).text)!==null&&Y!==void 0?Y:""))}),be("click",V,Y=>o(D).onClick(Y)),I(k,H)}),Ee((k,D)=>{var H;Cn(b,"title",c()),w=Mt(O,1,"jse-open-dropdown svelte-11rxb2m",null,w,k),O.disabled=o(u),T=Mt(R,1,"jse-dropdown-items svelte-11rxb2m",null,T,D),Ho(R,"width: ".concat((H=v())!==null&&H!==void 0?H:"",";"))},[()=>({"jse-visible":o(f)}),()=>({"jse-visible":o(f)})],de),be("click",O,function(){var k=o(f);setTimeout(()=>p(f,!k))}),be("click",b,g),I(s,b),ut()}(e,{get width(){return r().width},get items(){return o(n)},$$slots:{defaultItem:(s,l)=>{var u=cP(),d=z(u),c=f=>{dn(f,{get data(){return r().main.icon}})};re(d,f=>{r().main.icon&&f(c)});var v=F(d);Ee(f=>{var g;Mt(u,1,f,"svelte-1idfykj"),Cn(u,"title",r().main.title),u.disabled=r().main.disabled||!1,pt(v," ".concat((g=r().main.text)!==null&&g!==void 0?g:""))},[()=>ai(Ks("jse-context-menu-button",a(),r().main.className))],de),be("click",u,f=>{i()(),r().main.onClick(f)}),I(s,u)}}}),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-contextmenu.svelte-12z7bz1 {
  box-shadow: var(--jse-controls-box-shadow, 0 2px 6px 0 rgba(0, 0, 0, 0.24));
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  background: var(--jse-context-menu-background, #656565);
  color: var(--jse-context-menu-color, var(--jse-text-color-inverse, #fff));
}
.jse-contextmenu.svelte-12z7bz1 .jse-row:where(.svelte-12z7bz1) {
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: stretch;
}
.jse-contextmenu.svelte-12z7bz1 .jse-row:where(.svelte-12z7bz1) div.jse-label:where(.svelte-12z7bz1) {
  flex: 1;
  white-space: nowrap;
  padding: var(--jse-padding, 10px);
  color: var(--jse-context-menu-color-disabled, #9d9d9d);
  line-height: normal;
}
.jse-contextmenu.svelte-12z7bz1 .jse-row:where(.svelte-12z7bz1) div.jse-tip:where(.svelte-12z7bz1) {
  flex: 1;
  background: var(--jse-context-menu-tip-background, rgba(255, 255, 255, 0.2));
  color: var(--context-menu-tip-color, inherit);
  margin: calc(0.5 * var(--jse-padding, 10px));
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px);
  font-size: 80%;
  line-height: 1.3em;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  gap: var(--jse-padding, 10px);
  border-radius: 3px;
}
.jse-contextmenu.svelte-12z7bz1 .jse-row:where(.svelte-12z7bz1) div.jse-tip:where(.svelte-12z7bz1) div.jse-tip-icon:where(.svelte-12z7bz1) {
  padding-top: calc(0.5 * var(--jse-padding, 10px));
}
.jse-contextmenu.svelte-12z7bz1 .jse-column:where(.svelte-12z7bz1) {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: stretch;
}
.jse-contextmenu.svelte-12z7bz1 .jse-column:where(.svelte-12z7bz1):not(:last-child) {
  border-right: 1px solid var(--jse-context-menu-separator-color, #7a7a7a);
}
.jse-contextmenu.svelte-12z7bz1 .jse-separator:where(.svelte-12z7bz1) {
  width: 100%;
  height: 1px;
  background: var(--jse-context-menu-separator-color, #7a7a7a);
}`);var dP=G('<div class="jse-separator svelte-12z7bz1"></div>'),vP=G('<div class="jse-label svelte-12z7bz1"> </div>'),fP=G('<div class="jse-column svelte-12z7bz1"></div>'),pP=G('<div class="jse-separator svelte-12z7bz1"></div>'),hP=G('<div class="jse-row svelte-12z7bz1"></div>'),gP=G('<div class="jse-separator svelte-12z7bz1"></div>'),mP=G('<div class="jse-row svelte-12z7bz1"><div class="jse-tip svelte-12z7bz1"><div class="jse-tip-icon svelte-12z7bz1"><!></div> <div class="jse-tip-text"> </div></div></div>'),bP=G('<div role="menu" tabindex="-1" class="jse-contextmenu svelte-12z7bz1"><!> <!></div>');function Kw(e,t){lt(t,!1);var n=h(t,"items",9),r=h(t,"onRequestClose",9),a=h(t,"tip",9),i=P(void 0,!0);Yr(()=>{var f=Array.from(o(i).querySelectorAll("button")).find(g=>!g.disabled);f&&f.focus()});var s={ArrowUp:"Up",ArrowDown:"Down",ArrowLeft:"Left",ArrowRight:"Right"};function l(f){return console.error("Unknown type of context menu item",f),"???"}St(!0);var u=bP(),d=z(u);jr(d,1,n,Cr,(f,g)=>{var m=xr(),b=ft(m),j=O=>{Ld(O,{get item(){return o(g)},get onRequestClose(){return r()}})},w=(O,T)=>{var R=D=>{Ud(D,{get item(){return o(g)},get onRequestClose(){return r()}})},k=(D,H)=>{var V=J=>{var Z=hP();jr(Z,5,()=>o(g).items,Cr,(Y,le)=>{var Ae=xr(),ce=ft(Ae),we=Ne=>{Ld(Ne,{get item(){return o(le)},get onRequestClose(){return r()}})},$e=(Ne,ye)=>{var ze=We=>{Ud(We,{get item(){return o(le)},get onRequestClose(){return r()}})},Re=(We,he)=>{var ue=ot=>{var Ot=fP();jr(Ot,5,()=>o(le).items,Cr,(ee,q)=>{var ae=xr(),$=ft(ae),_e=Ue=>{Ld(Ue,{className:"left",get item(){return o(q)},get onRequestClose(){return r()}})},ne=(Ue,X)=>{var L=Ze=>{Ud(Ze,{className:"left",get item(){return o(q)},get onRequestClose(){return r()}})},yt=(Ze,Ce)=>{var st=at=>{I(at,dP())},Me=(at,Tt)=>{var Je=x=>{var _=vP(),E=z(_);Ee(()=>pt(E,o(q).text)),I(x,_)},qt=x=>{var _=Br();Ee(E=>pt(_,E),[()=>l(o(q))],de),I(x,_)};re(at,x=>{gR(o(q))?x(Je):x(qt,!1)},Tt)};re(Ze,at=>{ku(o(q))?at(st):at(Me,!1)},Ce)};re(Ue,Ze=>{_d(o(q))?Ze(L):Ze(yt,!1)},X)};re($,Ue=>{vs(o(q))?Ue(_e):Ue(ne,!1)}),I(ee,ae)}),I(ot,Ot)},me=(ot,Ot)=>{var ee=ae=>{I(ae,pP())},q=ae=>{var $=Br();Ee(_e=>pt($,_e),[()=>l(o(le))],de),I(ae,$)};re(ot,ae=>{ku(o(le))?ae(ee):ae(q,!1)},Ot)};re(We,ot=>{bR(o(le))?ot(ue):ot(me,!1)},he)};re(Ne,We=>{_d(o(le))?We(ze):We(Re,!1)},ye)};re(ce,Ne=>{vs(o(le))?Ne(we):Ne($e,!1)}),I(Y,Ae)}),I(J,Z)},A=(J,Z)=>{var Y=Ae=>{I(Ae,gP())},le=Ae=>{var ce=Br();Ee(we=>pt(ce,we),[()=>l(o(g))],de),I(Ae,ce)};re(J,Ae=>{ku(o(g))?Ae(Y):Ae(le,!1)},Z)};re(D,J=>{mR(o(g))?J(V):J(A,!1)},H)};re(O,D=>{_d(o(g))?D(R):D(k,!1)},T)};re(b,O=>{vs(o(g))?O(j):O(w,!1)}),I(f,m)});var c=F(d,2),v=f=>{var g=mP(),m=z(g),b=z(m);dn(z(b),{data:G1});var j=z(F(b,2));Ee(()=>pt(j,a())),I(f,g)};re(c,f=>{a()&&f(v)}),tr(u,f=>p(i,f),()=>o(i)),be("keydown",u,function(f){var g=Pa(f),m=s[g];if(m&&f.target){f.preventDefault();var b=XA({allElements:Array.from(o(i).querySelectorAll("button:not([disabled])")),currentElement:f.target,direction:m,hasPrio:j=>j.getAttribute("data-type")!=="jse-open-dropdown"});b&&b.focus()}}),I(e,u),ut()}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-value.jse-string.svelte-6ttr41 {
  color: var(--jse-value-color-string, #008000);
}
.jse-value.jse-object.svelte-6ttr41, .jse-value.jse-array.svelte-6ttr41 {
  min-width: 16px;
  color: var(--jse-delimiter-color, rgba(0, 0, 0, 0.38));
}
.jse-value.jse-number.svelte-6ttr41 {
  color: var(--jse-value-color-number, #ee422e);
}
.jse-value.jse-boolean.svelte-6ttr41 {
  color: var(--jse-value-color-boolean, #ff8c00);
}
.jse-value.jse-null.svelte-6ttr41 {
  color: var(--jse-value-color-null, #004ed0);
}
.jse-value.jse-invalid.svelte-6ttr41 {
  color: var(--jse-text-color, #4d4d4d);
}
.jse-value.jse-url.svelte-6ttr41 {
  color: var(--jse-value-color-url, #008000);
  text-decoration: underline;
}

.jse-enum-value.svelte-6ttr41 {
  background: var(--jse-hover-background-color, rgba(0, 0, 0, 0.06));
  border: none;
  padding: 0;
  font-family: inherit;
  font-size: inherit;
  cursor: pointer;
  outline: none;
}
.jse-enum-value.jse-selected.svelte-6ttr41 {
  background: var(--jse-selection-background-color, #d3d3d3);
  color: inherit;
}
.jse-enum-value.jse-value.svelte-6ttr41:focus {
  color: var(--jse-text-color, #4d4d4d);
}`);var xP=G("<option> </option>"),jP=G("<select></select>");function yP(e,t){lt(t,!1);var n=h(t,"path",9),r=h(t,"value",9),a=h(t,"mode",9),i=h(t,"parser",9),s=h(t,"readOnly",9),l=h(t,"selection",9),u=h(t,"onPatch",9),d=h(t,"options",9),c=P(void 0,!0),v=P(r(),!0);W(()=>M(r()),()=>{p(v,r())}),W(()=>M(l()),()=>{(function(m){m&&o(c)&&o(c).focus()})(l())}),_n(),St(!0);var f,g=jP();Ee(()=>{o(v),mA(()=>{a(),i(),l(),o(c),d()})}),jr(g,5,d,Cr,(m,b)=>{var j=xP(),w={},O=z(j);Ee(()=>{w!==(w=o(b).value)&&(j.value=(j.__value=o(b).value)==null?"":o(b).value),pt(O,o(b).text)}),I(m,j)}),tr(g,m=>p(c,m),()=>o(c)),Ee((m,b)=>f=Mt(g,1,m,"svelte-6ttr41",f,b),[()=>"jse-enum-value ".concat(fp(o(v),a(),i())),()=>({"jse-selected":zn(l())})],de),CA(g,()=>o(v),m=>p(v,m)),be("change",g,function(m){m.stopPropagation(),s()||u()([{op:"replace",path:zt(n()),value:o(v)}])}),be("mousedown",g,function(m){m.stopPropagation()}),I(e,g),ut()}function wP(e,t,n){var r=ts(e,{},n);return r?function(a){if(Array.isArray(a.enum))return a.enum;var i=a.oneOf||a.anyOf||a.allOf;if(Array.isArray(i)){var s=i.filter(l=>l.enum);if(s.length>0)return s[0].enum}}(r):void 0}function ts(e,t,n){var r=arguments.length>3&&arguments[3]!==void 0?arguments[3]:e,a=n.slice(1,n.length),i=n[0],s=[r];for(var l of[r.oneOf,r.anyOf,r.allOf])Array.isArray(l)&&(s=s.concat(l));for(var u of s){if("$ref"in(r=u)&&typeof r.$ref=="string"){var d,c=r.$ref;if(c in t)r=t[c];else{if(!c.startsWith("#/")){if(((d=c.match(/#\//g))===null||d===void 0?void 0:d.length)===1){var[v,f]=c.split("#/");if(v in t){var g=t[v],m={$ref:"#/".concat(f)},b=[];return b.push(i),a.length>0&&b.push(...a),ts(g,t,b,m)}throw Error("Unable to resolve reference ".concat(c))}throw Error("Unable to resolve reference ".concat(c))}var j=c.substring(2).split("/");for(var w of(r=e,j)){if(!(w in r))throw Error("Unable to resolve reference ".concat(c));r=r[w]}}}if(i===void 0)return r;if(typeof r.properties=="object"&&r.properties&&i in r.properties)return ts(e,t,a,r=r.properties[i]);if(typeof r.patternProperties=="object"&&r.patternProperties){for(var O in r.patternProperties)if(i.match(O))return ts(e,t,a,r=r.patternProperties[O])}if(typeof r.additionalProperties=="object")return ts(e,t,a,r=r.additionalProperties);if(typeof r.items=="object"&&r.items)return ts(e,t,a,r=r.items)}}function kP(e,t,n){var r=wP(t,n,e.path);if(r){var a=r.map(s=>({value:s,text:s})),i=r.includes(e.value)?a:[{value:e.value,text:e.value}].concat(a);return[{component:yP,props:Se(Se({},e),{},{options:i})}]}}function _P(e){return CP(SP(e).compile(e.schema),e)}function SP(e){var t,n,{schemaDefinitions:r,ajvOptions:a}=e,i=new P1(Se({allErrors:!0,verbose:!0,$data:!0},a));if(r&&Object.keys(r).forEach(s=>{i.addSchema(r[s],s)}),(i=(t=(n=e.onCreateAjv)===null||n===void 0?void 0:n.call(e,i))!==null&&t!==void 0?t:i).opts.verbose===!1)throw new Error("Ajv must be configured with the option verbose=true");return i}function CP(e,t){if(e.errors)throw e.errors[0];return function(n){var r;return e(n),((r=e.errors)!==null&&r!==void 0?r:[]).map(OP).map(a=>function(i,s,l){var u,d;return{path:Bo(i,s.instancePath),message:(u=s.message)!==null&&u!==void 0?u:"Unknown error",severity:(d=l.errorSeverity)!==null&&d!==void 0?d:jo.warning}}(n,a,t))}}function OP(e){var t=void 0;if(e.keyword==="enum"&&Array.isArray(e.schema)){var n=e.schema;if(n){if((n=n.map(a=>JSON.stringify(a))).length>5){var r=["("+(n.length-5)+" more...)"];(n=n.slice(0,5)).push(r)}t="should be equal to one of: "+n.join(", ")}}return e.keyword==="additionalProperties"&&(t="should NOT have additional property: "+e.params.additionalProperty),t?Se(Se({},e),{},{message:t}):e}var EP={id:"jmespath",name:"JMESPath",description:`
<p>
  Enter a <a href="https://jmespath.org" target="_blank" rel="noopener noreferrer">JMESPath</a> query 
  to filter, sort, or transform the JSON data.
 To learn JMESPath, go to <a href="https://jmespath.org/tutorial.html" target="_blank" rel="noopener noreferrer">the interactive tutorial</a>.
</p>
`,createQuery:function(e,t){var{sort:n,filter:r,projection:a}=t,i="";if(r&&r.path&&r.relation&&r.value){var s=["0"].concat(r.path),l=Ke(e,s),u=Wc(r.value),d=typeof l=="string"&&u!=null?'"'.concat(r.value,'"'):u;i+="[? "+cl(r.path)+" "+r.relation+" `"+d+"`]"}else i+=Array.isArray(e)?"[*]":"@";if(n&&n.path&&n.direction&&(n.direction==="desc"?i+=" | reverse(sort_by(@, &"+cl(n.path)+"))":i+=" | sort_by(@, &"+cl(n.path)+")"),a&&a.paths)if(i[i.length-1]!=="]"&&(i+=" | [*]"),a.paths.length===1){var c=a.paths[0];i+=c.length===0?"":"."+cl(c)}else a.paths.length>1&&(i+=".{"+a.paths.map(v=>Yw(v[v.length-1])+": "+cl(v)).join(", ")+"}");return i},executeQuery:function(e,t,n){var r=Vu(n,JSON)?e:function(a){var i=n.stringify(a);return i!==void 0?JSON.parse(i):void 0}(e);return oy.search(r,t)}};function cl(e){if(e.length===0)return"@";var t=e.map(n=>typeof n=="number"?"["+n+"]":"."+Yw(String(n))).join("");return t[0]==="."?t.slice(1):t}function Yw(e){return e.match(/^[A-Za-z\d_$]+$/)?e:JSON.stringify(e)}var AP={id:"jsonpath",name:"JSONPath",description:`
<p>
  Enter a <a href="https://github.com/JSONPath-Plus/JSONPath" target="_blank" 
  rel="noopener noreferrer"><code>JSONPath</code></a> expression to filter, sort, or transform the data.
</p>`,createQuery:function(e,t){var{filter:n,sort:r,projection:a}=t,i="$";if(n&&n.path&&n.relation&&n.value){var s=Wc(n.value),l=JSON.stringify(s);i+="[?(@".concat(vg(n.path)," ").concat(n.relation," ").concat(l,")]")}if(r&&r.path&&r.direction)throw new Error("Sorting is not supported by JSONPath. Please clear the sorting fields");if(a&&a.paths){if(a.paths.length>1)throw new Error("Picking multiple fields is not supported by JSONPath. Please select only one field");i.endsWith("]")||(i+="[*]"),i+="".concat(vg(a.paths[0])).replace(/^\.\.\./,"..")}return i},executeQuery:function(e,t){var n=In({json:e,path:t});return n!==void 0?n:null}};function vg(e){var t=/^[A-z]+$/;return e.map(n=>t.test(n)?".".concat(n):JSON.stringify([n])).join("")}var RP={id:"lodash",name:"Lodash",description:`
<p>
  Enter a JavaScript function to filter, sort, or transform the data.
  You can use <a href="https://lodash.com" target="_blank" rel="noopener noreferrer">Lodash</a>
  functions like <code>_.map</code>, <code>_.filter</code>,
  <code>_.orderBy</code>, <code>_.sortBy</code>, <code>_.groupBy</code>,
  <code>_.pick</code>, <code>_.uniq</code>, <code>_.get</code>, etcetera.
</p>
`,createQuery:function(e,t){var{filter:n,sort:r,projection:a}=t,i=[`  return _.chain(data)
`];if(n&&n.path&&n.relation&&n.value){var s="item => item".concat(Rd(n.path)),l=Wc(n.value),u=typeof l=="string"?"'".concat(n.value,"'"):LA(n.value)&&!Number.isSafeInteger(l)?"".concat(n.value,"n"):n.value;i.push("    .filter(".concat(s," ").concat(n.relation," ").concat(u,`)
`))}if(r&&r.path&&r.direction&&i.push("    .orderBy([".concat(function(v){return v.length===0?"":v.every(f=>Jc.test(f)||pp.test(f))?"'"+v.map(DR).join("").replace(/^\./,"")+"'":JSON.stringify(v)}(r.path),"], ['").concat(r.direction,`'])
`)),a&&a.paths)if(a.paths.length>1){var d=a.paths.map(v=>{var f=ht(v)||"item";return"      ".concat(JSON.stringify(f),": item").concat(Rd(v))});i.push(`    .map(item => ({
`.concat(d.join(`,
`),`
    }))
`))}else{var c=a.paths[0];i.push("    .map(item => item".concat(Rd(c),`)
`))}return i.push(`    .value()
`),`function query (data) {
`.concat(i.join(""),"}")},executeQuery:function(e,t){(function(r){var a,i,s=(a=r.match(/_\.chain\(/g))===null||a===void 0?void 0:a.length,l=(i=r.match(/\.value\(\)/g))===null||i===void 0?void 0:i.length;if(s!==l)throw new Error("Cannot execute query: Lodash _.chain(...) must end with .value()")})(t);var n=new Function("_",`"use strict";

`+t+`

if (typeof query !== "function") {
  throw new Error("Cannot execute query: expecting a function named 'query' but is undefined")
}

return query;
`)(ny)(e);return n!==void 0?n:null}},mu,bu;function xu(e,t){return mu||(bu=new WeakMap,mu=new ResizeObserver(n=>{for(var r of n){var a=bu.get(r.target);a&&a(r.target)}})),bu.set(e,t),mu.observe(e),{destroy:()=>{bu.delete(e),mu.unobserve(e)}}}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-tree-mode.svelte-vrx1dr {
  flex: 1;
  display: flex;
  flex-direction: column;
  position: relative;
  background: var(--jse-background-color, #fff);
  min-width: 0;
  min-height: 0;
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  color: var(--jse-text-color, #4d4d4d);
  line-height: var(--jse-line-height, calc(1em + 4px));
}
.jse-tree-mode.svelte-vrx1dr .jse-hidden-input-label:where(.svelte-vrx1dr) .jse-hidden-input:where(.svelte-vrx1dr) {
  position: fixed;
  top: -10px;
  left: -10px;
  width: 1px;
  height: 1px;
  padding: 0;
  border: 0;
  outline: none;
}
.jse-tree-mode.no-main-menu.svelte-vrx1dr {
  border-top: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-tree-mode.svelte-vrx1dr .jse-search-box-container:where(.svelte-vrx1dr) {
  position: relative;
  height: 0;
  top: var(--jse-padding, 10px);
  margin-right: calc(var(--jse-padding, 10px) + 20px);
  margin-left: var(--jse-padding, 10px);
  text-align: right;
  z-index: 3;
}
.jse-tree-mode.svelte-vrx1dr .jse-contents:where(.svelte-vrx1dr) {
  flex: 1;
  overflow: auto;
  position: relative;
  padding: 2px;
  display: flex;
  flex-direction: column;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-tree-mode.svelte-vrx1dr .jse-contents:where(.svelte-vrx1dr):last-child {
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-tree-mode.svelte-vrx1dr .jse-contents:where(.svelte-vrx1dr) .jse-loading-space:where(.svelte-vrx1dr) {
  flex: 1;
}
.jse-tree-mode.svelte-vrx1dr .jse-contents:where(.svelte-vrx1dr) .jse-loading:where(.svelte-vrx1dr) {
  flex: 2;
  text-align: center;
  color: var(--jse-panel-color-readonly, #b2b2b2);
  box-sizing: border-box;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
}
.jse-tree-mode.svelte-vrx1dr .jse-contents:where(.svelte-vrx1dr) .jse-search-box-background:where(.svelte-vrx1dr) {
  border: 50px solid var(--jse-modal-background, #f5f5f5);
  margin: -2px;
  margin-bottom: 2px;
  display: inline-block;
}`);var MP=G("<!> <!>",1),zP=G('<div class="jse-search-box-background svelte-vrx1dr"></div>'),PP=G('<div class="jse-search-box-container svelte-vrx1dr"><!></div> <div class="jse-contents svelte-vrx1dr"><!> <!></div> <!> <!> <!>',1),TP=G('<label class="jse-hidden-input-label svelte-vrx1dr"><input type="text" tabindex="-1" class="jse-hidden-input svelte-vrx1dr"></label> <!>',1),IP=G('<div class="jse-contents svelte-vrx1dr"><div class="jse-loading-space svelte-vrx1dr"></div> <div class="jse-loading svelte-vrx1dr">loading...</div></div>'),NP=G('<div role="tree" tabindex="-1"><!> <!> <!></div> <!> <!>',1);function Iv(e,t){lt(t,!1);var n=P(void 0,!0),r=Fr("jsoneditor:TreeMode"),a=typeof window>"u";r("isSSR:",a);var i=ei(),s=ei(),{openAbsolutePopup:l,closeAbsolutePopup:u}=vi("absolute-popup"),d=P(void 0,!0),c=P(void 0,!0),v=P(void 0,!0),f=!1,g=Tw(),m=h(t,"readOnly",9),b=h(t,"externalContent",9),j=h(t,"externalSelection",9),w=h(t,"history",9),O=h(t,"truncateTextSize",9),T=h(t,"mainMenuBar",9),R=h(t,"navigationBar",9),k=h(t,"escapeControlCharacters",9),D=h(t,"escapeUnicodeCharacters",9),H=h(t,"parser",9),V=h(t,"parseMemoizeOne",9),A=h(t,"validator",9),J=h(t,"validationParser",9),Z=h(t,"pathParser",9),Y=h(t,"indentation",9),le=h(t,"onError",9),Ae=h(t,"onChange",9),ce=h(t,"onChangeMode",9),we=h(t,"onSelect",9),$e=h(t,"onUndo",9),Ne=h(t,"onRedo",9),ye=h(t,"onRenderValue",9),ze=h(t,"onRenderMenu",9),Re=h(t,"onRenderContextMenu",9),We=h(t,"onClassName",9),he=h(t,"onFocus",9),ue=h(t,"onBlur",9),me=h(t,"onSortModal",9),ot=h(t,"onTransformModal",9),Ot=h(t,"onJSONEditorModal",9),ee=!1,q=P(!1,!0),ae=P(void 0,!0);bp({onMount:Yr,onDestroy:zo,getWindow:()=>tu(o(v)),hasFocus:()=>ee&&document.hasFocus()||ep(o(v)),onFocus:()=>{f=!0,he()&&he()()},onBlur:()=>{f=!1,ue()&&ue()()}});var $=P(void 0,!0),_e=P(void 0,!0),ne=void 0,Ue=!1,X=P(bv({json:o($)}),!0),L=P(zl(j())?j():void 0,!0);function yt(S){p(L,S)}Yr(()=>{if(o(L)){var S=Qe(o(L));p(X,Uo(o($),o(X),S,_u)),setTimeout(()=>Fn(S))}});var Ze,Ce=P(void 0,!0),st=P(void 0,!0),Me=P(void 0,!0),at=P(!1,!0),Tt=P(!1,!0);function Je(S){p(Me,(Ze=S)?yw(o($),Ze.items):void 0)}function qt(S,K){return x.apply(this,arguments)}function x(){return(x=Rt(function*(S,K){p(X,Uo(o($),o(X),S,_u));var ge=Un(K);yield Ut(S,{element:ge})})).apply(this,arguments)}function _(){p(at,!1),p(Tt,!1),qe()}function E(S){r("select validation error",S),p(L,rn(S.path)),Ut(S.path)}function U(S){var K=arguments.length>1&&arguments[1]!==void 0?arguments[1]:Bh;r("expand"),p(X,Uo(o($),o(X),S,K))}function te(S,K){p(X,Dh(o($),o(X),S,K)),o(L)&&function(ge,Ve){return Ta(Qe(ge),Ve)&&(Qe(ge).length>Ve.length||Gr(ge))}(o(L),S)&&p(L,void 0)}var fe=P(!1,!0),xe=P([],!0),N=P(void 0,!0),Fe=Ci(Iw);function Ge(S,K,ge,Ve){ss(()=>{var De;try{De=Fe(S,K,ge,Ve)}catch(Ie){De=[{path:[],message:"Failed to validate: "+Ie.message,severity:jo.warning}]}Zt(De,o(xe))||(r("validationErrors changed:",De),p(xe,De),p(N,function(Ie,Le){var Ye;return Le.forEach(Pt=>{Ye=lg(Ie,Ye,Pt.path,(pn,nn)=>Se(Se({},nn),{},{validationError:Pt}))}),Le.forEach(Pt=>{for(var pn=Pt.path;pn.length>0;)pn=sn(pn),Ye=lg(Ie,Ye,pn,(nn,qn)=>qn.validationError?qn:Se(Se({},qn),{},{validationError:{isChildError:!0,path:pn,message:"Contains invalid data",severity:jo.warning}}))}),Ye}(S,o(xe))))},De=>r("validationErrors updated in ".concat(De," ms")))}function Et(){return r("validate"),ne?{parseError:ne,isRepairable:!1}:(Ge(o($),A(),H(),J()),Pn(o(xe))?void 0:{validationErrors:o(xe)})}function pe(){return o($)}function vt(){return o(X)}function Vt(){return o(L)}function rr(S){r("applyExternalContent",{updatedContent:S}),Ol(S)?function(K){if(K!==void 0){var ge=!Zt(o($),K);if(r("update external json",{isChanged:ge,currentlyText:o($)===void 0}),!!ge){var Ve={documentState:o(X),selection:o(L),json:o($),text:o(_e),textIsRepaired:o(fe)};p($,K),p(X,ho(K,o(X))),fn(o($)),p(_e,void 0),p(fe,!1),ne=void 0,$t(o($)),Ln(Ve)}}}(S.json):Cl(S)&&function(K){if(!(K===void 0||Ol(b()))){var ge=K!==o(_e);if(r("update external text",{isChanged:ge}),!!ge){var Ve={documentState:o(X),selection:o(L),json:o($),text:o(_e),textIsRepaired:o(fe)};try{p($,V()(K)),p(X,ho(o($),o(X))),fn(o($)),p(_e,K),p(fe,!1),ne=void 0}catch(De){try{p($,V()(Wo(K))),p(X,ho(o($),o(X))),fn(o($)),p(_e,K),p(fe,!0),ne=void 0,$t(o($))}catch{p($,void 0),p(X,void 0),p(_e,b().text),p(fe,!1),ne=o(_e)!==void 0&&o(_e)!==""?ys(o(_e),De.message||String(De)):void 0}}$t(o($)),Ln(Ve)}}}(S.text)}function fn(S){Ue||(Ue=!0,p(X,Pi(S,o(X),[])))}function $t(S){o(L)&&(ja(S,wi(o(L)))&&ja(S,Qe(o(L)))||(r("clearing selection: path does not exist anymore",o(L)),p(L,Gi(S,o(X)))))}function Ln(S){if(S.json!==void 0||S.text!==void 0){var K=o($)!==void 0&&S.json!==void 0;w().add({type:"tree",undo:{patch:K?[{op:"replace",path:"",value:S.json}]:void 0,json:S.json,text:S.text,documentState:S.documentState,textIsRepaired:S.textIsRepaired,selection:aa(S.selection),sortedColumn:void 0},redo:{patch:K?[{op:"replace",path:"",value:o($)}]:void 0,json:o($),text:o(_e),documentState:o(X),textIsRepaired:o(fe),selection:aa(o(L)),sortedColumn:void 0}})}}function wt(S,K){var ge;if(r("patch",S,K),o($)===void 0)throw new Error("Cannot apply patch: no JSON");var Ve=o($),De={json:void 0,text:o(_e),documentState:o(X),selection:aa(o(L)),textIsRepaired:o(fe),sortedColumn:void 0},Ie=jw(o($),S),Le=uw(o($),o(X),S),Ye=(ge=ks(o($),S))!==null&&ge!==void 0?ge:o(L),Pt=typeof K=="function"?K(Le.json,Le.documentState,Ye):void 0;return p($,Pt?.json!==void 0?Pt.json:Le.json),p(X,Pt?.state!==void 0?Pt.state:Le.documentState),p(L,Pt?.selection!==void 0?Pt.selection:Ye),p(_e,void 0),p(fe,!1),p(st,void 0),ne=void 0,$t(o($)),w().add({type:"tree",undo:Se({patch:Ie},De),redo:{patch:S,json:void 0,text:o(_e),documentState:o(X),selection:aa(o(L)),sortedColumn:void 0,textIsRepaired:o(fe)}}),{json:o($),previousJson:Ve,undo:Ie,redo:S}}function hn(){!m()&&o(L)&&p(L,vp(Qe(o(L))))}function en(){if(!m()&&o(L)){var S=Qe(o(L)),K=Ke(o($),S);Ar(K)?function(ge,Ve){r("openJSONEditorModal",{path:ge,value:Ve}),ee=!0,Ot()({content:{json:Ve},path:ge,onPatch:o(wr).onPatch,onClose:()=>{ee=!1,setTimeout(qe)}})}(S,K):p(L,Yu(S))}}function Jt(){if(!m()&&zn(o(L))){var S=Qe(o(L)),K=zt(S),ge=Ke(o($),S),Ve=!Oa(o($),o(X),S),De=Ve?String(ge):Js(String(ge),H());r("handleToggleEnforceString",{enforceString:Ve,value:ge,updatedValue:De}),Wt([{op:"replace",path:K,value:De}],(Ie,Le)=>({state:Hc(o($),Le,S,{type:"value",enforceString:Ve})}))}}function gt(){return o(fe)&&o($)!==void 0&&Gt(o($)),o($)!==void 0?{json:o($)}:{text:o(_e)||""}}function on(){return it.apply(this,arguments)}function it(){return it=Rt(function*(){var S=!(arguments.length>0&&arguments[0]!==void 0)||arguments[0];yield Bw({json:o($),selection:o(L),indentation:S?Y():void 0,readOnly:m(),parser:H(),onPatch:Wt})}),it.apply(this,arguments)}function Ft(){return Yt.apply(this,arguments)}function Yt(){return Yt=Rt(function*(){var S=!(arguments.length>0&&arguments[0]!==void 0)||arguments[0];o($)!==void 0&&(yield Ww({json:o($),selection:o(L),indentation:S?Y():void 0,parser:H()}))}),Yt.apply(this,arguments)}function En(S){var K;S.preventDefault(),Or((K=S.clipboardData)===null||K===void 0?void 0:K.getData("text/plain"))}function vr(){return An.apply(this,arguments)}function An(){return(An=Rt(function*(){try{Or(yield navigator.clipboard.readText())}catch(S){console.error(S),p(q,!0)}})).apply(this,arguments)}function Or(S){S!==void 0&&Hw({clipboardText:S,json:o($),selection:o(L),readOnly:m(),parser:H(),onPatch:Wt,onChangeText:or,openRepairModal:yr})}function yr(S,K){p(ae,{text:S,onParse:ge=>Fc(ge,Ve=>eu(Ve,H())),onRepair:Gy,onApply:K,onClose:qe})}function Sr(){Vw({json:o($),text:o(_e),selection:o(L),keepSelection:!1,readOnly:m(),onChange:Ae(),onPatch:Wt})}function Ir(){!m()&&o($)!==void 0&&o(L)&&as&&!Pn(Qe(o(L)))&&(r("duplicate",{selection:o(L)}),Wt(gw(o($),ii(o($),o(L)))))}function Er(){m()||!o(L)||!ur(o(L))&&!zn(o(L))||Pn(Qe(o(L)))||(r("extract",{selection:o(L)}),Wt(mw(o($),o(L)),(S,K)=>{if(Ar(S))return{state:Cd(S,K,[])}}))}function Vn(S){ac({insertType:S,selectInside:!0,initialValue:void 0,json:o($),selection:o(L),readOnly:m(),parser:H(),onPatch:Wt,onReplaceJson:Gt})}function Jn(S){Dr(o(L))&&p(L,rn(o(L).path)),o(L)||p(L,Gi(o($),o(X))),Vn(S)}function gr(S){if(!m()&&o(L))if(fu(o(L)))try{var K=wi(o(L)),ge=Ke(o($),K),Ve=function(Ie,Le,Ye){if(Le==="array"){if(Array.isArray(Ie))return Ie;if(On(Ie))return Oh(Ie);if(typeof Ie=="string")try{var Pt=Ye.parse(Ie);if(Array.isArray(Pt))return Pt;if(On(Pt))return Oh(Pt)}catch{return[Ie]}return[Ie]}if(Le==="object"){if(Array.isArray(Ie))return Ch(Ie);if(On(Ie))return Ie;if(typeof Ie=="string")try{var pn=Ye.parse(Ie);if(On(pn))return pn;if(Array.isArray(pn))return Ch(pn)}catch{return{value:Ie}}return{value:Ie}}if(Le==="value")return Ar(Ie)?Ye.stringify(Ie):Ie;throw new Error("Cannot convert ".concat(Xf(Ie,Ye)," to ").concat(Le))}(ge,S,H());if(Ve===ge)return;var De=[{op:"replace",path:zt(K),value:Ve}];r("handleConvert",{selection:o(L),path:K,type:S,operations:De}),Wt(De,(Ie,Le)=>({state:o(L)?Pi(Ie,Le,Qe(o(L))):o(X)}))}catch(Ie){le()(Ie)}else le()(new Error("Cannot convert current selection to ".concat(S)))}function je(){if(o(L)){var S=Wh(o($),o(X),o(L),!1),K=sn(Qe(o(L)));S&&!Pn(Qe(S))&&Zt(K,sn(Qe(S)))?p(L,Ea(Qe(S))):p(L,Na(K)),r("insert before",{selection:o(L),selectionBefore:S,parentPath:K}),pr(),Xn()}}function an(){if(o(L)){var S=Za(o($),o(L));r("insert after",S),p(L,Ea(S)),pr(),Xn()}}function Q(S){return Te.apply(this,arguments)}function Te(){return(Te=Rt(function*(S){yield Jw({char:S,selectInside:!0,json:o($),selection:o(L),readOnly:m(),parser:H(),onPatch:Wt,onReplaceJson:Gt,onSelect:yt})})).apply(this,arguments)}function tt(){if(!m()&&w().canUndo){var S=w().undo();if(Gu(S)){var K={json:o($),text:o(_e)};p($,S.undo.patch?$o(o($),S.undo.patch):S.undo.json),p(X,S.undo.documentState),p(L,S.undo.selection),p(_e,S.undo.text),p(fe,S.undo.textIsRepaired),ne=void 0,r("undo",{item:S,json:o($),documentState:o(X),selection:o(L)}),Xt(K,S.undo.patch&&S.redo.patch?{json:o($),previousJson:K.json,redo:S.undo.patch,undo:S.redo.patch}:void 0),qe(),o(L)&&Ut(Qe(o(L)),{scrollToWhenVisible:!1})}else $e()(S)}}function Nt(){if(!m()&&w().canRedo){var S=w().redo();if(Gu(S)){var K={json:o($),text:o(_e)};p($,S.redo.patch?$o(o($),S.redo.patch):S.redo.json),p(X,S.redo.documentState),p(L,S.redo.selection),p(_e,S.redo.text),p(fe,S.redo.textIsRepaired),ne=void 0,r("redo",{item:S,json:o($),documentState:o(X),selection:o(L)}),Xt(K,S.undo.patch&&S.redo.patch?{json:o($),previousJson:K.json,redo:S.redo.patch,undo:S.undo.patch}:void 0),qe(),o(L)&&Ut(Qe(o(L)),{scrollToWhenVisible:!1})}else Ne()(S)}}function et(S){var K;m()||o($)===void 0||(ee=!0,me()({id:i,json:o($),rootPath:S,onSort:(K=Rt(function*(ge){var{operations:Ve}=ge;r("onSort",S,Ve),Wt(Ve,(De,Ie)=>({state:Cd(De,Ie,S),selection:rn(S)}))}),function(ge){return K.apply(this,arguments)}),onClose:()=>{ee=!1,setTimeout(qe)}}))}function Bt(){o(L)&&et(Vh(o($),o(L)))}function yn(){et([])}function Lt(S){if(o($)!==void 0){var{id:K,onTransform:ge,onClose:Ve}=S,De=S.rootPath||[];ee=!0,ot()({id:K||s,json:o($),rootPath:De,onTransform:Ie=>{ge?ge({operations:Ie,json:o($),transformedJson:$o(o($),Ie)}):(r("onTransform",De,Ie),Wt(Ie,(Le,Ye)=>({state:Cd(Le,Ye,De),selection:rn(De)})))},onClose:()=>{ee=!1,setTimeout(qe),Ve&&Ve()}})}}function Sn(){o(L)&&Lt({rootPath:Vh(o($),o(L))})}function mt(){Lt({rootPath:[]})}function Ut(S){return dt.apply(this,arguments)}function dt(){return dt=Rt(function*(S){var{scrollToWhenVisible:K=!0,element:ge}=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};p(X,Uo(o($),o(X),S,_u));var Ve=ge??kt(S);if(r("scrollTo",{path:S,elem:Ve,refContents:o(d)}),!Ve||!o(d))return Promise.resolve();var De=o(d).getBoundingClientRect(),Ie=Ve.getBoundingClientRect();if(!K&&Ie.bottom>De.top&&Ie.top<De.bottom)return Promise.resolve();var Le=-De.height/4;return new Promise(Ye=>{g(Ve,{container:o(d),offset:Le,duration:300,callback:()=>Ye()})})}),dt.apply(this,arguments)}function kt(S){var K,ge;return pr(),(K=(ge=o(d))===null||ge===void 0?void 0:ge.querySelector('div[data-path="'.concat(pv(S),'"]')))!==null&&K!==void 0?K:void 0}function Un(S){var K,ge;return pr(),(K=(ge=o(d))===null||ge===void 0?void 0:ge.querySelector('span[data-search-result-index="'.concat(S,'"]')))!==null&&K!==void 0?K:void 0}function Fn(S){var K=kt(S);if(K&&o(d)){var ge=o(d).getBoundingClientRect(),Ve=K.getBoundingClientRect(),De=Ar(Ke(o($),S))?20:Ve.height;Ve.top<ge.top+20?g(K,{container:o(d),offset:-20,duration:0}):Ve.top+De>ge.bottom-20&&g(K,{container:o(d),offset:-(ge.height-De-20),duration:0})}}function Xt(S,K){if(S.json!==void 0||S?.text!==void 0){if(o(_e)!==void 0){var ge,Ve={text:o(_e),json:void 0};(ge=Ae())===null||ge===void 0||ge(Ve,S,{contentErrors:Et(),patchResult:K})}else if(o($)!==void 0){var De,Ie={text:void 0,json:o($)};(De=Ae())===null||De===void 0||De(Ie,S,{contentErrors:Et(),patchResult:K})}}}function Wt(S,K){r("handlePatch",S,K);var ge={json:o($),text:o(_e)},Ve=wt(S,K);return Xt(ge,Ve),Ve}function Gt(S,K){var ge={json:o($),text:o(_e)},Ve={documentState:o(X),selection:o(L),json:o($),text:o(_e),textIsRepaired:o(fe)},De=Uo(o($),ho(S,o(X)),[],gl),Ie=typeof K=="function"?K(S,De,o(L)):void 0;p($,Ie?.json!==void 0?Ie.json:S),p(X,Ie?.state!==void 0?Ie.state:De),p(L,Ie?.selection!==void 0?Ie.selection:o(L)),p(_e,void 0),p(fe,!1),ne=void 0,$t(o($)),Ln(Ve),Xt(ge,void 0)}function or(S,K){r("handleChangeText");var ge={json:o($),text:o(_e)},Ve={documentState:o(X),selection:o(L),json:o($),text:o(_e),textIsRepaired:o(fe)};try{p($,V()(S)),p(X,Uo(o($),ho(o($),o(X)),[],gl)),p(_e,void 0),p(fe,!1),ne=void 0}catch(Ie){try{p($,V()(Wo(S))),p(X,Uo(o($),ho(o($),o(X)),[],gl)),p(_e,S),p(fe,!0),ne=void 0}catch{p($,void 0),p(X,bv({json:o($),expand:gl})),p(_e,S),p(fe,!1),ne=o(_e)!==""?ys(o(_e),Ie.message||String(Ie)):void 0}}if(typeof K=="function"){var De=K(o($),o(X),o(L));p($,De?.json!==void 0?De.json:o($)),p(X,De?.state!==void 0?De.state:o(X)),p(L,De?.selection!==void 0?De.selection:o(L))}$t(o($)),Ln(Ve),Xt(ge,void 0)}function B(S,K){var ge=arguments.length>2&&arguments[2]!==void 0&&arguments[2];r("handleExpand",{path:S,expanded:K,recursive:ge}),K?U(S,ge?dp:Bh):te(S,ge),qe()}function ie(){B([],!0,!0)}function Oe(){B([],!1,!0)}function Dt(S){r("openFind",{findAndReplace:S}),p(at,!1),p(Tt,!1),pr(),p(at,!0),p(Tt,S)}function bn(S,K){r("handleExpandSection",S,K),p(X,function(ge,Ve,De,Ie){return ws(ge,Ve,De,(Le,Ye)=>{if(!Kr(Ye))return Ye;var Pt=iw(Ye.visibleSections.concat(Ie));return Se(Se({},Ye),{},{visibleSections:Pt})})}(o($),o(X),S,K))}function un(S){r("pasted json as text",S),p(st,S)}function Rn(S){var K,{anchor:ge,left:Ve,top:De,width:Ie,height:Le,offsetTop:Ye,offsetLeft:Pt,showTip:pn}=S,nn=function(Wn){var{json:Zn,documentState:jn,selection:Xe,readOnly:nt,onEditKey:wn,onEditValue:fr,onToggleEnforceString:kr,onCut:Tn,onCopy:Mn,onPaste:Ht,onRemove:Rr,onDuplicate:Jr,onExtract:Io,onInsertBefore:na,onInsert:No,onConvert:Hr,onInsertAfter:no,onSort:ga,onTransform:Fi}=Wn,ko=Zn!==void 0,Mr=!!Xe,ir=!!Xe&&Pn(Qe(Xe)),Ur=Xe?Ke(Zn,Qe(Xe)):void 0,ma=Array.isArray(Ur)?"Edit array":On(Ur)?"Edit object":"Edit value",lo=ko&&(ur(Xe)||Dr(Xe)||zn(Xe)),Ys=Xe&&!ir?Ke(Zn,sn(Qe(Xe))):void 0,Xs=!nt&&ko&&Ku(Xe)&&!ir&&!Array.isArray(Ys),Bi=!nt&&ko&&Xe!==void 0&&Ku(Xe),Qc=Bi&&!Ar(Ur),Qs=!nt&&lo,Zs=lo,Zc=!nt&&Mr,ed=!nt&&ko&&lo&&!ir,td=!nt&&ko&&Xe!==void 0&&(ur(Xe)||zn(Xe))&&!ir,er=lo,Xr=er?"Convert to:":"Insert:",el=!nt&&(Gr(Xe)&&Array.isArray(Ur)||Oo(Xe)&&Array.isArray(Ys)),tl=!nt&&(er?fu(Xe)&&!On(Ur):Mr),pi=!nt&&(er?fu(Xe)&&!Array.isArray(Ur):Mr),uo=!nt&&(er?fu(Xe)&&Ar(Ur):Mr),nd=Xe!==void 0&&Oa(Zn,jn,Qe(Xe));function Wi(nl){lo?nl!=="structure"&&Hr(nl):No(nl)}return[{type:"row",items:[{type:"button",onClick:()=>wn(),icon:ls,text:"Edit key",title:"Edit the key (Double-click on the key)",disabled:!Xs},{type:"dropdown-button",main:{type:"button",onClick:()=>fr(),icon:ls,text:ma,title:"Edit the value (Double-click on the value)",disabled:!Bi},width:"11em",items:[{type:"button",icon:ls,text:ma,title:"Edit the value (Double-click on the value)",onClick:()=>fr(),disabled:!Bi},{type:"button",icon:nd?Bg:Wg,text:"Enforce string",title:"Enforce keeping the value as string when it contains a numeric value",onClick:()=>kr(),disabled:!Qc}]}]},{type:"separator"},{type:"row",items:[{type:"dropdown-button",main:{type:"button",onClick:()=>Tn(!0),icon:us,text:"Cut",title:"Cut selected contents, formatted with indentation (Ctrl+X)",disabled:!Qs},width:"10em",items:[{type:"button",icon:us,text:"Cut formatted",title:"Cut selected contents, formatted with indentation (Ctrl+X)",onClick:()=>Tn(!0),disabled:!Qs},{type:"button",icon:us,text:"Cut compacted",title:"Cut selected contents, without indentation (Ctrl+Shift+X)",onClick:()=>Tn(!1),disabled:!Qs}]},{type:"dropdown-button",main:{type:"button",onClick:()=>Mn(!0),icon:Va,text:"Copy",title:"Copy selected contents, formatted with indentation (Ctrl+C)",disabled:!Zs},width:"12em",items:[{type:"button",icon:Va,text:"Copy formatted",title:"Copy selected contents, formatted with indentation (Ctrl+C)",onClick:()=>Mn(!0),disabled:!Zs},{type:"button",icon:Va,text:"Copy compacted",title:"Copy selected contents, without indentation (Ctrl+Shift+C)",onClick:()=>Mn(!1),disabled:!Zs}]},{type:"button",onClick:()=>Ht(),icon:Hg,text:"Paste",title:"Paste clipboard contents (Ctrl+V)",disabled:!Zc}]},{type:"separator"},{type:"row",items:[{type:"column",items:[{type:"button",onClick:()=>Jr(),icon:Vg,text:"Duplicate",title:"Duplicate selected contents (Ctrl+D)",disabled:!ed},{type:"button",onClick:()=>Io(),icon:rk,text:"Extract",title:"Extract selected contents",disabled:!td},{type:"button",onClick:()=>ga(),icon:Mu,text:"Sort",title:"Sort array or object contents",disabled:nt||!lo},{type:"button",onClick:()=>Fi(),icon:zu,text:"Transform",title:"Transform array or object contents (filter, sort, project)",disabled:nt||!lo},{type:"button",onClick:()=>Rr(),icon:qd,text:"Remove",title:"Remove selected contents (Delete)",disabled:nt||!lo}]},{type:"column",items:[{type:"label",text:Xr},{type:"button",onClick:()=>Wi("structure"),icon:er?iu:rs,text:"Structure",title:Xr+" structure like the first item in the array",disabled:!el},{type:"button",onClick:()=>Wi("object"),icon:er?iu:rs,text:"Object",title:Xr+" object",disabled:!tl},{type:"button",onClick:()=>Wi("array"),icon:er?iu:rs,text:"Array",title:Xr+" array",disabled:!pi},{type:"button",onClick:()=>Wi("value"),icon:er?iu:rs,text:"Value",title:Xr+" value",disabled:!uo}]}]},{type:"separator"},{type:"row",items:[{type:"button",onClick:()=>na(),icon:ok,text:"Insert before",title:"Select area before current entry to insert or paste contents",disabled:nt||!lo||ir},{type:"button",onClick:()=>no(),icon:ak,text:"Insert after",title:"Select area after current entry to insert or paste contents",disabled:nt||!lo||ir}]}]}({json:o($),documentState:o(X),selection:o(L),readOnly:m(),onEditKey:hn,onEditValue:en,onToggleEnforceString:Jt,onCut:on,onCopy:Ft,onPaste:vr,onRemove:Sr,onDuplicate:Ir,onExtract:Er,onInsertBefore:je,onInsert:Jn,onInsertAfter:an,onConvert:gr,onSort:Bt,onTransform:Sn}),qn=(K=Re()(nn))!==null&&K!==void 0?K:nn;if(qn!==!1){var bt={left:Ve,top:De,offsetTop:Ye,offsetLeft:Pt,width:Ie,height:Le,anchor:ge,closeOnOuterClick:!0,onClose:()=>{ee=!1,qe()}};ee=!0;var mr=l(Kw,{tip:pn?"Tip: you can open this context menu via right-click or with Ctrl+Q":void 0,items:qn,onRequestClose:()=>u(mr)},bt)}}function Xn(S){if(!vo(o(L)))if(S&&(S.stopPropagation(),S.preventDefault()),S&&S.type==="contextmenu"&&S.target!==o(c))Rn({left:S.clientX,top:S.clientY,width:wa,height:ya,showTip:!1});else{var K,ge=(K=o(d))===null||K===void 0?void 0:K.querySelector(".jse-context-menu-pointer.jse-selected");if(ge)Rn({anchor:ge,offsetTop:2,width:wa,height:ya,showTip:!1});else{var Ve,De=(Ve=o(d))===null||Ve===void 0?void 0:Ve.getBoundingClientRect();De&&Rn({top:De.top+2,left:De.left+2,width:wa,height:ya,showTip:!1})}}}function Gn(S){Rn({anchor:rw(S.target,"BUTTON"),offsetTop:0,width:wa,height:ya,showTip:!0})}function ar(){return At.apply(this,arguments)}function At(){return(At=Rt(function*(){if(r("apply pasted json",o(st)),o(st)){var{onPasteAsJson:S}=o(st);p(st,void 0),S(),setTimeout(qe)}})).apply(this,arguments)}function Qn(){r("clear pasted json"),p(st,void 0),qe()}function xt(){ce()(Lr.text)}function Nr(S){p(L,S),qe(),Ut(Qe(S))}function qe(){r("focus"),o(c)&&(o(c).focus(),o(c).select())}function gn(S){return function(K,ge,Ve){var De=sn(Ve),Ie=[ht(Ve)],Le=Ke(K,De),Ye=Le?Sd(Le,ge,Ie):void 0;return Ye?rn(De.concat(Ye)):Ea(Ve)}(o($),o(X),S)}function Dn(S){o(n)&&o(n).onDrag(S)}function xn(){o(n)&&o(n).onDragEnd()}var wr=P(void 0,!0);W(()=>o(L),()=>{var S;S=o(L),Zt(S,j())||(r("onSelect",S),we()(S))}),W(()=>(M(k()),M(D())),()=>{p(Ce,Qf({escapeControlCharacters:k(),escapeUnicodeCharacters:D()}))}),W(()=>o(at),()=>{(function(S){o(d)&&S&&o(d).scrollTop===0&&(go(d,o(d).style.overflowAnchor="none"),go(d,o(d).scrollTop+=hl),setTimeout(()=>{o(d)&&go(d,o(d).style.overflowAnchor="")}))})(o(at))}),W(()=>M(b()),()=>{rr(b())}),W(()=>M(j()),()=>{(function(S){Zt(o(L),S)||(r("applyExternalSelection",{selection:o(L),externalSelection:S}),zl(S)&&p(L,S))})(j())}),W(()=>(o($),M(A()),M(H()),M(J())),()=>{Ge(o($),A(),H(),J())}),W(()=>(o(d),sg),()=>{p(n,o(d)?sg(o(d)):void 0)}),W(()=>(M(m()),M(O()),M(H()),o(Ce),M(ye()),M(We())),()=>{p(wr,{mode:Lr.tree,readOnly:m(),truncateTextSize:O(),parser:H(),normalization:o(Ce),getJson:pe,getDocumentState:vt,getSelection:Vt,findElement:kt,findNextInside:gn,focus:qe,onPatch:Wt,onInsert:Vn,onExpand:B,onSelect:yt,onFind:Dt,onExpandSection:bn,onPasteJson:un,onRenderValue:ye(),onContextMenu:Rn,onClassName:We()||(()=>{}),onDrag:Dn,onDragEnd:xn})}),W(()=>o(wr),()=>{r("context changed",o(wr))}),_n(),St(!0);var to=NP();be("mousedown",Sa,function(S){!Gs(S.target,K=>K===o(v))&&vo(o(L))&&(r("click outside the editor, exit edit mode"),p(L,aa(o(L))),f&&o(c)&&(o(c).focus(),o(c).blur()),r("blur (outside editor)"),o(c)&&o(c).blur())});var C,oe=ft(to),ve=z(oe),ke=S=>{(function(K,ge){lt(ge,!1);var Ve=P(void 0,!0),De=P(void 0,!0),Ie=P(void 0,!0),Le=h(ge,"json",9),Ye=h(ge,"selection",9),Pt=h(ge,"readOnly",9),pn=h(ge,"showSearch",13,!1),nn=h(ge,"history",9),qn=h(ge,"onExpandAll",9),bt=h(ge,"onCollapseAll",9),mr=h(ge,"onUndo",9),Wn=h(ge,"onRedo",9),Zn=h(ge,"onSort",9),jn=h(ge,"onTransform",9),Xe=h(ge,"onContextMenu",9),nt=h(ge,"onCopy",9),wn=h(ge,"onRenderMenu",9);function fr(){pn(!pn())}var kr=P(void 0,!0),Tn=P(void 0,!0),Mn=P(void 0,!0),Ht=P(void 0,!0);W(()=>M(Le()),()=>{p(Ve,Le()!==void 0)}),W(()=>(o(Ve),M(Ye()),zn),()=>{p(De,o(Ve)&&(ur(Ye())||Dr(Ye())||zn(Ye())))}),W(()=>(M(qn()),M(Le())),()=>{p(kr,{type:"button",icon:Mz,title:"Expand all",className:"jse-expand-all",onClick:qn(),disabled:!Ar(Le())})}),W(()=>(M(bt()),M(Le())),()=>{p(Tn,{type:"button",icon:zz,title:"Collapse all",className:"jse-collapse-all",onClick:bt(),disabled:!Ar(Le())})}),W(()=>M(Le()),()=>{p(Mn,{type:"button",icon:fc,title:"Search (Ctrl+F)",className:"jse-search",onClick:fr,disabled:Le()===void 0})}),W(()=>(M(Pt()),o(kr),o(Tn),M(Zn()),M(Le()),M(jn()),o(Mn),M(Xe()),M(mr()),M(nn()),M(Wn()),M(nt()),o(De)),()=>{p(Ht,Pt()?[o(kr),o(Tn),{type:"separator"},{type:"button",icon:Va,title:"Copy (Ctrl+C)",className:"jse-copy",onClick:nt(),disabled:!o(De)},{type:"separator"},o(Mn),{type:"space"}]:[o(kr),o(Tn),{type:"separator"},{type:"button",icon:Mu,title:"Sort",className:"jse-sort",onClick:Zn(),disabled:Pt()||Le()===void 0},{type:"button",icon:zu,title:"Transform contents (filter, sort, project)",className:"jse-transform",onClick:jn(),disabled:Pt()||Le()===void 0},o(Mn),{type:"button",icon:Jg,title:rp,className:"jse-contextmenu",onClick:Xe()},{type:"separator"},{type:"button",icon:Zv,title:"Undo (Ctrl+Z)",className:"jse-undo",onClick:mr(),disabled:!nn().canUndo},{type:"button",icon:ef,title:"Redo (Ctrl+Shift+Z)",className:"jse-redo",onClick:Wn(),disabled:!nn().canRedo},{type:"space"}])}),W(()=>(M(wn()),o(Ht)),()=>{p(Ie,wn()(o(Ht))||o(Ht))}),_n(),St(!0),Xc(K,{get items(){return o(Ie)}}),ut()})(S,{get json(){return o($)},get selection(){return o(L)},get readOnly(){return m()},get history(){return w()},onExpandAll:ie,onCollapseAll:Oe,onUndo:tt,onRedo:Nt,onSort:yn,onTransform:mt,onContextMenu:Gn,onCopy:Ft,get onRenderMenu(){return ze()},get showSearch(){return o(at)},set showSearch(K){p(at,K)},$$legacy:!0})};re(ve,S=>{T()&&S(ke)});var Pe=F(ve,2),Be=S=>{Xz(S,{get json(){return o($)},get selection(){return o(L)},onSelect:Nr,get onError(){return le()},get pathParser(){return Z()}})};re(Pe,S=>{R()&&S(Be)});var He=F(Pe,2),ct=S=>{var K=TP(),ge=ft(K),Ve=z(ge);Ve.readOnly=!0,tr(Ve,Ye=>p(c,Ye),()=>o(c));var De=F(ge,2),Ie=Ye=>{var Pt=xr(),pn=ft(Pt),nn=bt=>{(function(mr,Wn){lt(Wn,!0);var Zn=Uz();Zn.__click=[Nz,Wn];var jn=F(z(Zn),2),Xe=F(z(jn),2),nt=wn=>{var fr=Lz(),kr=F(ft(fr),2);Cn(kr,"title","Create an empty JSON object (press '{')"),kr.__click=[Tz,Wn];var Tn=F(kr,2);Cn(Tn,"title","Create an empty JSON array (press '[')"),Tn.__click=[Iz,Wn],I(wn,fr)};re(Xe,wn=>{Wn.readOnly||wn(nt)}),I(mr,Zn),ut()})(bt,{get readOnly(){return m()},onCreateObject:()=>{qe(),Q("{")},onCreateArray:()=>{qe(),Q("[")},onClick:()=>{qe()}})},qn=bt=>{var mr=MP(),Wn=ft(mr),Zn=de(()=>m()?[]:[{icon:Pu,text:"Repair manually",title:'Open the document in "code" mode and repair it manually',onClick:xt}]);Yo(Wn,{type:"error",message:"The loaded JSON document is invalid and could not be repaired automatically.",get actions(){return o(Zn)}}),Gw(F(Wn,2),{get text(){return o(_e)},get json(){return o($)},get indentation(){return Y()},get parser(){return H()}}),I(bt,mr)};re(pn,bt=>{o(_e)===""||o(_e)===void 0?bt(nn):bt(qn,!1)}),I(Ye,Pt)},Le=Ye=>{var Pt=PP(),pn=ft(Pt);qw(z(pn),{get json(){return o($)},get documentState(){return o(X)},get parser(){return H()},get showSearch(){return o(at)},get showReplace(){return o(Tt)},get readOnly(){return m()},columns:void 0,onSearch:Je,onFocus:qt,onPatch:Wt,onClose:_});var nn=F(pn,2);Cn(nn,"data-jsoneditor-scrollable-contents",!0);var qn=z(nn),bt=Xe=>{I(Xe,zP())};re(qn,Xe=>{o(at)&&Xe(bt)}),Av(F(qn,2),{get value(){return o($)},pointer:"",get state(){return o(X)},get validationErrors(){return o(N)},get searchResults(){return o(Me)},get selection(){return o(L)},get context(){return o(wr)},onDragSelectionStart:br}),tr(nn,Xe=>p(d,Xe),()=>o(d));var mr=F(nn,2),Wn=Xe=>{var nt=de(()=>"You pasted a JSON ".concat(Array.isArray(o(st).contents)?"array":"object"," as text"));Yo(Xe,{type:"info",get message(){return o(nt)},actions:[{icon:bs,text:"Paste as JSON instead",title:"Replace the value with the pasted JSON",onMouseDown:ar},{text:"Leave as is",title:"Keep the JSON embedded in the value",onClick:Qn}]})};re(mr,Xe=>{o(st)&&Xe(Wn)});var Zn=F(mr,2),jn=Xe=>{var nt=de(()=>m()?[]:[{icon:tf,text:"Ok",title:"Accept the repaired document",onClick:gt},{icon:Pu,text:"Repair manually instead",title:"Leave the document unchanged and repair it manually instead",onClick:xt}]);Yo(Xe,{type:"success",message:"The loaded JSON document was invalid but is successfully repaired.",get actions(){return o(nt)},onClose:qe})};re(Zn,Xe=>{o(fe)&&Xe(jn)}),xp(F(Zn,2),{get validationErrors(){return o(xe)},selectError:E}),I(Ye,Pt)};re(De,Ye=>{o($)===void 0?Ye(Ie):Ye(Le,!1)}),be("paste",Ve,En),I(S,K)},Qt=S=>{I(S,IP())};re(He,S=>{a?S(Qt,!1):S(ct)}),tr(oe,S=>p(v,S),()=>o(v));var cn=F(oe,2),tn=S=>{Nw(S,{onClose:()=>p(q,!1)})};re(cn,S=>{o(q)&&S(tn)});var It=F(cn,2),Bn=S=>{Lw(S,Xa(()=>o(ae),{onClose:()=>{var K;(K=o(ae))===null||K===void 0||K.onClose(),p(ae,void 0)}}))};return re(It,S=>{o(ae)&&S(Bn)}),Ee(S=>C=Mt(oe,1,"jse-tree-mode svelte-vrx1dr",null,C,S),[()=>({"no-main-menu":!T()})],de),be("keydown",oe,function(S){var K=Pa(S),ge=S.shiftKey;if(r("keydown",{combo:K,key:S.key}),K==="Ctrl+X"&&(S.preventDefault(),on(!0)),K==="Ctrl+Shift+X"&&(S.preventDefault(),on(!1)),K==="Ctrl+C"&&(S.preventDefault(),Ft(!0)),K==="Ctrl+Shift+C"&&(S.preventDefault(),Ft(!1)),K==="Ctrl+D"&&(S.preventDefault(),Ir()),K!=="Delete"&&K!=="Backspace"||(S.preventDefault(),Sr()),K==="Insert"&&(S.preventDefault(),Vn("structure")),K==="Ctrl+A"&&(S.preventDefault(),p(L,rn([]))),K==="Ctrl+Q"&&Xn(S),K==="ArrowUp"||K==="Shift+ArrowUp"){S.preventDefault();var Ve=o(L)?Wh(o($),o(X),o(L),ge)||o(L):Gi(o($),o(X));p(L,Ve),Fn(Qe(Ve))}if(K==="ArrowDown"||K==="Shift+ArrowDown"){S.preventDefault();var De=o(L)?function(nn,qn,bt){var mr=arguments.length>3&&arguments[3]!==void 0&&arguments[3];if(bt){var Wn=mr?Qe(bt):Za(nn,bt),Zn=Ar(Ke(nn,Wn))?Dh(nn,qn,Wn,!0):qn,jn=Sd(nn,qn,Wn),Xe=Sd(nn,Zn,Wn);if(mr)return Gr(bt)?jn!==void 0?Qr(jn,jn):void 0:Oo(bt)?Xe!==void 0?Qr(Xe,Xe):void 0:Xe!==void 0?Qr(wi(bt),Xe):void 0;if(Oo(bt))return Xe!==void 0?rn(Xe):void 0;if(Gr(bt)||zn(bt))return jn!==void 0?rn(jn):void 0;if(Dr(bt)){if(jn===void 0||jn.length===0)return;var nt=sn(jn),wn=Ke(nn,nt);return Array.isArray(wn)?rn(jn):Ia(jn)}return ur(bt)?Xe!==void 0?rn(Xe):jn!==void 0?rn(jn):void 0:void 0}}(o($),o(X),o(L),ge)||o(L):Gi(o($),o(X));p(L,De),Fn(Qe(De))}if(K==="ArrowLeft"||K==="Shift+ArrowLeft"){S.preventDefault();var Ie=o(L)?function(nn,qn,bt){var mr=arguments.length>3&&arguments[3]!==void 0&&arguments[3],Wn=!(arguments.length>4&&arguments[4]!==void 0)||arguments[4];if(bt){var{caret:Zn,previous:jn}=Hh(nn,qn,bt,Wn);if(mr)return ur(bt)?void 0:Qr(bt.path,bt.path);if(Zn&&jn)return xv(jn);var Xe=sn(Qe(bt)),nt=Ke(nn,Xe);return zn(bt)&&Array.isArray(nt)?Qr(bt.path,bt.path):ur(bt)&&!Array.isArray(nt)?Ia(bt.focusPath):void 0}}(o($),o(X),o(L),ge,!m())||o(L):Gi(o($),o(X));p(L,Ie),Fn(Qe(Ie))}if(K==="ArrowRight"||K==="Shift+ArrowRight"){S.preventDefault();var Le=o(L)&&o($)!==void 0?function(nn,qn,bt){var mr=arguments.length>3&&arguments[3]!==void 0&&arguments[3],Wn=!(arguments.length>4&&arguments[4]!==void 0)||arguments[4];if(bt){var{caret:Zn,next:jn}=Hh(nn,qn,bt,Wn);return mr?ur(bt)?void 0:Qr(bt.path,bt.path):Zn&&jn?xv(jn):ur(bt)?rn(bt.focusPath):void 0}}(o($),o(X),o(L),ge,!m())||o(L):Gi(o($),o(X));p(L,Le),Fn(Qe(Le))}if(K==="Enter"&&o(L)){if(Vc(o(L))){var Ye=o(L).focusPath,Pt=Ke(o($),sn(Ye));Array.isArray(Pt)&&(S.preventDefault(),p(L,rn(Ye)))}Dr(o(L))&&(S.preventDefault(),p(L,Se(Se({},o(L)),{},{edit:!0}))),zn(o(L))&&(S.preventDefault(),Ar(Ke(o($),o(L).path))?B(o(L).path,!0):p(L,Se(Se({},o(L)),{},{edit:!0})))}if(K.replace(/^Shift\+/,"").length===1&&o(L))return S.preventDefault(),void Q(S.key);if(K==="Enter"&&(Oo(o(L))||Gr(o(L))))return S.preventDefault(),void Q("");if(K==="Ctrl+Enter"&&zn(o(L))){var pn=Ke(o($),o(L).path);$c(pn)&&window.open(String(pn),"_blank")}K==="Escape"&&o(L)&&(S.preventDefault(),p(L,void 0)),K==="Ctrl+F"&&(S.preventDefault(),Dt(!1)),K==="Ctrl+H"&&(S.preventDefault(),Dt(!0)),K==="Ctrl+Z"&&(S.preventDefault(),tt()),K==="Ctrl+Shift+Z"&&(S.preventDefault(),Nt())}),be("mousedown",oe,function(S){r("handleMouseDown",S);var K=S.target;nw(K,"BUTTON")||K.isContentEditable||(qe(),o(L)||o($)!==void 0||o(_e)!==""&&o(_e)!==void 0||(r("createDefaultSelection"),p(L,rn([]))))}),be("contextmenu",oe,Xn),I(e,to),_t(t,"expand",U),_t(t,"collapse",te),_t(t,"validate",Et),_t(t,"getJson",pe),_t(t,"patch",wt),_t(t,"acceptAutoRepair",gt),_t(t,"openTransformModal",Lt),_t(t,"scrollTo",Ut),_t(t,"findElement",kt),_t(t,"findSearchResult",Un),_t(t,"focus",qe),ut({expand:U,collapse:te,validate:Et,getJson:pe,patch:wt,acceptAutoRepair:gt,openTransformModal:Lt,scrollTo:Ut,findElement:kt,findSearchResult:Un,focus:qe})}function Xw(e){return typeof(t=e)!="object"||t===null?e:new Proxy(e,{get:(n,r,a)=>Xw(Reflect.get(n,r,a)),set:()=>!1,deleteProperty:()=>!1});var t}var ju=Fr("jsoneditor:History");function Qw(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},t=e.maxItems||1e3,n=[],r=0;function a(){return r<n.length}function i(){return r>0}function s(){return{canUndo:a(),canRedo:i(),items:()=>n.slice().reverse(),add:u,undo:c,redo:v,clear:d}}function l(){e.onChange&&e.onChange(s())}function u(f){ju("add",f),n=[f].concat(n.slice(r)).slice(0,t),r=0,l()}function d(){ju("clear"),n=[],r=0,l()}function c(){if(a()){var f=n[r];return r+=1,ju("undo",f),l(),f}}function v(){if(i())return ju("redo",n[r-=1]),l(),n[r]}return{get:s}}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-transform-modal-inner.svelte-rrrjnb {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) {
  color: inherit;
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 0;
  overflow: auto;
  min-width: 0;
  min-height: 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-actions:where(.svelte-rrrjnb) {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding-top: var(--jse-padding, 10px);
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-actions:where(.svelte-rrrjnb) button.jse-primary:where(.svelte-rrrjnb) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-primary-background, var(--jse-theme-color, #3883fa));
  color: var(--jse-button-primary-color, #fff);
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-actions:where(.svelte-rrrjnb) button.jse-primary:where(.svelte-rrrjnb):hover {
  background: var(--jse-button-primary-background-highlight, var(--jse-theme-color-highlight, #5f9dff));
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-actions:where(.svelte-rrrjnb) button.jse-primary:where(.svelte-rrrjnb):disabled {
  background: var(--jse-button-primary-background-disabled, #9d9d9d);
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) {
  flex: 1;
  display: flex;
  gap: calc(2 * var(--jse-padding, 10px));
  min-height: 0;
  box-sizing: border-box;
  padding: 0 calc(2 * var(--jse-padding, 10px)) var(--jse-padding, 10px);
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) {
  flex: 1;
  display: flex;
  flex-direction: column;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) .jse-description:where(.svelte-rrrjnb) p {
  margin: var(--jse-padding, 10px) 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) .jse-description:where(.svelte-rrrjnb) p:first-child {
  margin-top: 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) .jse-description:where(.svelte-rrrjnb) p:last-child {
  margin-bottom: 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) .jse-description:where(.svelte-rrrjnb) code {
  background: var(--jse-modal-code-background, rgba(0, 0, 0, 0.05));
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) .query-error:where(.svelte-rrrjnb) {
  color: var(--jse-error-color, #ee5341);
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) textarea.jse-query:where(.svelte-rrrjnb) {
  flex: 1;
  outline: none;
  resize: vertical;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-data-contents:where(.svelte-rrrjnb) {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: calc(2 * var(--jse-padding, 10px));
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-data-contents:where(.svelte-rrrjnb) .jse-original-data:where(.svelte-rrrjnb) {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
  box-sizing: border-box;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-data-contents:where(.svelte-rrrjnb) .jse-original-data.jse-hide:where(.svelte-rrrjnb) {
  flex: none;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-data-contents:where(.svelte-rrrjnb) .jse-preview-data:where(.svelte-rrrjnb) {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
  box-sizing: border-box;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-data-contents.jse-hide-original-data:where(.svelte-rrrjnb) {
  flex-direction: column;
  gap: 0;
  margin-bottom: 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-actions:where(.svelte-rrrjnb) {
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px)) calc(2 * var(--jse-padding, 10px));
}
@media screen and (max-width: 1200px) {
  .jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) {
    flex-direction: column;
    overflow: auto;
  }
  .jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-query-contents:where(.svelte-rrrjnb) textarea.jse-query:where(.svelte-rrrjnb) {
    min-height: 150px;
    flex: none;
  }
  .jse-transform-modal-inner.svelte-rrrjnb .jse-modal-contents:where(.svelte-rrrjnb) .jse-main-contents:where(.svelte-rrrjnb) .jse-data-contents:where(.svelte-rrrjnb) .jse-tree-mode {
    height: 300px;
    flex: none;
  }
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-label:where(.svelte-rrrjnb) {
  font-weight: bold;
  display: block;
  box-sizing: border-box;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-label:where(.svelte-rrrjnb) .jse-label-inner:where(.svelte-rrrjnb) {
  margin-top: calc(2 * var(--jse-padding, 10px));
  margin-bottom: calc(0.5 * var(--jse-padding, 10px));
  box-sizing: border-box;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-label:where(.svelte-rrrjnb) .jse-label-inner:where(.svelte-rrrjnb) button:where(.svelte-rrrjnb) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  font-weight: bold;
  padding: 0;
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-tree-mode {
  flex: 1;
  background: var(--jse-input-background-readonly, transparent);
  box-shadow: none;
  box-sizing: border-box;
  --jse-main-border: var(--jse-input-border, 1px solid #d8dbdf);
}
.jse-transform-modal-inner.svelte-rrrjnb input:where(.svelte-rrrjnb),
.jse-transform-modal-inner.svelte-rrrjnb textarea:where(.svelte-rrrjnb) {
  border: var(--jse-input-border, 1px solid #d8dbdf);
  outline: none;
  box-sizing: border-box;
  padding: calc(0.5 * var(--jse-padding, 10px));
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  color: inherit;
  background: var(--jse-input-background, var(--jse-background-color, #fff));
}
.jse-transform-modal-inner.svelte-rrrjnb input:where(.svelte-rrrjnb):focus,
.jse-transform-modal-inner.svelte-rrrjnb textarea:where(.svelte-rrrjnb):focus {
  border: var(--jse-input-border-focus, 1px solid var(--jse-input-border-focus, var(--jse-theme-color, #3883fa)));
}
.jse-transform-modal-inner.svelte-rrrjnb input:where(.svelte-rrrjnb):read-only,
.jse-transform-modal-inner.svelte-rrrjnb textarea:where(.svelte-rrrjnb):read-only {
  background: var(--jse-input-background-readonly, transparent);
}
.jse-transform-modal-inner.svelte-rrrjnb .jse-preview.jse-error:where(.svelte-rrrjnb) {
  flex: 1;
  background: var(--jse-input-background-readonly, transparent);
  border: var(--jse-input-border, 1px solid #d8dbdf);
  color: var(--jse-error-color, #ee5341);
  padding: calc(0.5 * var(--jse-padding, 10px));
}
.jse-transform-modal-inner.svelte-rrrjnb a {
  color: var(--jse-a-color, #156fc5);
}
.jse-transform-modal-inner.svelte-rrrjnb a:hover {
  color: var(--jse-a-color-highlight, #0f508d);
}`);var dl=qc(()=>qR),Ki=qc(()=>$R),LP=G('<div class="query-error svelte-rrrjnb"> </div>'),UP=G("<!> <!>",1),DP=G('<div class="jse-preview jse-error svelte-rrrjnb"> </div>'),qP=G('<!> <div class="jse-modal-contents svelte-rrrjnb"><div class="jse-main-contents svelte-rrrjnb"><div class="jse-query-contents svelte-rrrjnb"><div class="jse-label svelte-rrrjnb"><div class="jse-label-inner svelte-rrrjnb">Language</div></div> <div class="jse-description svelte-rrrjnb"><!></div> <div class="jse-label svelte-rrrjnb"><div class="jse-label-inner svelte-rrrjnb">Path</div></div> <input class="jse-path svelte-rrrjnb" type="text" readonly="" title="Selected path"> <div class="jse-label svelte-rrrjnb"><div class="jse-label-inner svelte-rrrjnb"><button type="button" class="svelte-rrrjnb"><!> Wizard</button></div></div> <!> <div class="jse-label svelte-rrrjnb"><div class="jse-label-inner svelte-rrrjnb">Query</div></div> <textarea class="jse-query svelte-rrrjnb" spellcheck="false"></textarea></div> <div><div><div class="jse-label svelte-rrrjnb"><div class="jse-label-inner svelte-rrrjnb"><button type="button" class="svelte-rrrjnb"><!> Original</button></div></div> <!></div> <div class="jse-preview-data svelte-rrrjnb"><div class="jse-label svelte-rrrjnb"><div class="jse-label-inner svelte-rrrjnb">Preview</div></div> <!></div></div></div> <div class="jse-actions svelte-rrrjnb"><button type="button" class="jse-primary svelte-rrrjnb">Transform</button></div></div>',1),$P=G('<div class="jse-transform-modal-inner svelte-rrrjnb"><!></div>');function FP(e,t){var n,r,a;lt(t,!1);var i=Fr("jsoneditor:TransformModal"),s=h(t,"id",25,()=>"transform-modal-"+os()),l=h(t,"json",9),u=h(t,"rootPath",25,()=>[]),d=h(t,"indentation",9),c=h(t,"truncateTextSize",9),v=h(t,"escapeControlCharacters",9),f=h(t,"escapeUnicodeCharacters",9),g=h(t,"parser",9),m=h(t,"parseMemoizeOne",9),b=h(t,"validationParser",9),j=h(t,"pathParser",9),w=h(t,"queryLanguages",9),O=h(t,"queryLanguageId",13),T=h(t,"onChangeQueryLanguage",9),R=h(t,"onRenderValue",9),k=h(t,"onRenderMenu",9),D=h(t,"onRenderContextMenu",9),H=h(t,"onClassName",9),V=h(t,"onTransform",9),A=h(t,"onClose",9),J=P(void 0,!0),Z=P(Qw({onChange:X=>p(Z,X)}).get(),!0),Y=P(void 0,!0),le=P(void 0,!0),Ae=P(!1,!0),ce="".concat(s(),":").concat(zt(u())),we=(n=dl()[ce])!==null&&n!==void 0?n:{},$e=P(Ki().showWizard!==!1,!0),Ne=P(Ki().showOriginal!==!1,!0),ye=P((r=we.queryOptions)!==null&&r!==void 0?r:{},!0),ze=P(O()===we.queryLanguageId&&we.query?we.query:"",!0),Re=P((a=we.isManual)!==null&&a!==void 0&&a,!0),We=P(void 0,!0),he=P(void 0,!0),ue=P({text:""},!0);function me(X){var L;return(L=w().find(yt=>yt.id===X))!==null&&L!==void 0?L:w()[0]}function ot(X){try{p(ye,X),p(ze,me(O()).createQuery(o(Y),X)),p(We,void 0),p(Re,!1),i("updateQueryByWizard",{queryOptions:o(ye),query:o(ze),isManual:o(Re)})}catch(L){p(We,String(L))}}function Ot(X){p(ze,X.target.value),p(Re,!0),i("handleChangeQuery",{query:o(ze),isManual:o(Re)})}o(Re)||ot(o(ye)),Yr(()=>{var X;(X=o(J))===null||X===void 0||X.focus()});var ee=Si(function(X,L){if(X===void 0)return p(ue,{text:""}),void p(he,"Error: No JSON");if(L.trim()!=="")try{i("previewTransform",{query:L});var yt=me(O()).executeQuery(X,L,g());p(ue,{json:yt}),p(he,void 0)}catch(Ze){p(ue,{text:""}),p(he,String(Ze))}else p(ue,{json:X})},300);function q(){if(o(Y)===void 0)return p(ue,{text:""}),void p(he,"Error: No JSON");try{i("handleTransform",{query:o(ze)});var X=me(O()).executeQuery(o(Y),o(ze),g());V()([{op:"replace",path:zt(u()),value:X}]),A()()}catch(L){console.error(L),p(ue,{text:""}),p(he,String(L))}}function ae(){p($e,!o($e)),Ki(Ki().showWizard=o($e))}function $(){p(Ne,!o(Ne)),Ki(Ki().showOriginal=o(Ne))}function _e(X){X.focus()}function ne(X){i("handleChangeQueryLanguage",X),O(X),T()(X),ot(o(ye))}function Ue(){o(Ae)?p(Ae,!o(Ae)):A()()}W(()=>(M(l()),M(u())),()=>{p(Y,Xw(Ke(l(),u())))}),W(()=>o(Y),()=>{p(le,o(Y)?{json:o(Y)}:{text:""})}),W(()=>(o(Y),o(ze)),()=>{ee(o(Y),o(ze))}),W(()=>(dl(),o(ye),o(ze),M(O()),o(Re)),()=>{dl(dl()[ce]={queryOptions:o(ye),query:o(ze),queryLanguageId:O(),isManual:o(Re)}),i("store state in memory",ce,dl()[ce])}),_n(),St(!0),Nl(e,{get onClose(){return A()},className:"jse-transform-modal",get fullscreen(){return o(Ae)},children:(X,L)=>{var yt=$P();hv(z(yt),{children:(Ze,Ce)=>{var st=qP(),Me=ft(st);(function(it,Ft){lt(Ft,!1);var Yt,En=h(Ft,"queryLanguages",9),vr=h(Ft,"queryLanguageId",9),An=h(Ft,"fullscreen",13),Or=h(Ft,"onChangeQueryLanguage",9),yr=h(Ft,"onClose",9),Sr=P(void 0,!0),{openAbsolutePopup:Ir,closeAbsolutePopup:Er}=vi("absolute-popup");function Vn(){var Jn={queryLanguages:En(),queryLanguageId:vr(),onChangeQueryLanguage:gr=>{Er(Yt),Or()(gr)}};Yt=Ir(kM,Jn,{offsetTop:-2,offsetLeft:0,anchor:o(Sr),closeOnOuterClick:!0})}St(!0),rc(it,{title:"Transform",fullScreenButton:!0,get onClose(){return yr()},get fullscreen(){return An()},set fullscreen(Jn){An(Jn)},$$slots:{actions:(Jn,gr)=>{var je,an=CM();dn(z(an),{data:vk}),tr(an,Q=>p(Sr,Q),()=>o(Sr)),Ee(Q=>je=Mt(an,1,"jse-config svelte-1kpylsp",null,je,Q),[()=>({hide:En().length<=1})],de),be("click",an,Vn),I(Jn,an)}},$$legacy:!0}),ut()})(Me,{get queryLanguages(){return w()},get queryLanguageId(){return O()},onChangeQueryLanguage:ne,get onClose(){return A()},get fullscreen(){return o(Ae)},set fullscreen(it){p(Ae,it)},$$legacy:!0});var at=z(F(Me,2)),Tt=z(at),Je=F(z(Tt),2);Ly(z(Je),()=>me(O()).description,!1,!1);var qt=F(Je,4),x=F(qt,2),_=z(x),E=z(_),U=z(E),te=de(()=>o($e)?ti:jl);dn(U,{get data(){return o(te)}});var fe=F(x,2),xe=it=>{var Ft=xr(),Yt=ft(Ft),En=An=>{var Or=UP(),yr=ft(Or);jM(yr,{get queryOptions(){return o(ye)},get json(){return o(Y)},onChange:ot});var Sr=F(yr,2),Ir=Er=>{var Vn=LP(),Jn=z(Vn);Ee(()=>pt(Jn,o(We))),I(Er,Vn)};re(Sr,Er=>{o(We)&&Er(Ir)}),I(An,Or)},vr=An=>{I(An,Br("(Only available for arrays, not for objects)"))};re(Yt,An=>{Array.isArray(o(Y))?An(En):An(vr,!1)}),I(it,Ft)};re(fe,it=>{o($e)&&it(xe)});var N=F(fe,4);tr(N,it=>p(J,it),()=>o(J));var Fe,Ge,Et=F(Tt,2),pe=z(Et),vt=z(pe),Vt=z(vt),rr=z(Vt),fn=z(rr),$t=de(()=>o(Ne)?ti:jl);dn(fn,{get data(){return o($t)}});var Ln=F(vt,2),wt=it=>{Iv(it,{get externalContent(){return o(le)},externalSelection:void 0,get history(){return o(Z)},readOnly:!0,get truncateTextSize(){return c()},mainMenuBar:!1,navigationBar:!1,get indentation(){return d()},get escapeControlCharacters(){return v()},get escapeUnicodeCharacters(){return f()},get parser(){return g()},get parseMemoizeOne(){return m()},get onRenderValue(){return R()},get onRenderMenu(){return k()},get onRenderContextMenu(){return D()},onError:console.error,onChange:br,onChangeMode:br,onSelect:br,onUndo:br,onRedo:br,onFocus:br,onBlur:br,onSortModal:br,onTransformModal:br,onJSONEditorModal:br,get onClassName(){return H()},validator:void 0,get validationParser(){return b()},get pathParser(){return j()}})};re(Ln,it=>{o(Ne)&&it(wt)});var hn=F(pe,2),en=F(z(hn),2),Jt=it=>{Iv(it,{get externalContent(){return o(ue)},externalSelection:void 0,get history(){return o(Z)},readOnly:!0,get truncateTextSize(){return c()},mainMenuBar:!1,navigationBar:!1,get indentation(){return d()},get escapeControlCharacters(){return v()},get escapeUnicodeCharacters(){return f()},get parser(){return g()},get parseMemoizeOne(){return m()},get onRenderValue(){return R()},get onRenderMenu(){return k()},get onRenderContextMenu(){return D()},onError:console.error,onChange:br,onChangeMode:br,onSelect:br,onUndo:br,onRedo:br,onFocus:br,onBlur:br,onSortModal:br,onTransformModal:br,onJSONEditorModal:br,get onClassName(){return H()},validator:void 0,get validationParser(){return b()},get pathParser(){return j()}})},gt=it=>{var Ft=DP(),Yt=z(Ft);Ee(()=>pt(Yt,o(he))),I(it,Ft)};re(en,it=>{o(he)?it(gt,!1):it(Jt)});var on=z(F(at,2));qr(()=>be("click",on,q)),eo(on,it=>_e?.(it)),Ee((it,Ft,Yt)=>{Mi(qt,it),Mi(N,o(ze)),Fe=Mt(Et,1,"jse-data-contents svelte-rrrjnb",null,Fe,Ft),Ge=Mt(pe,1,"jse-original-data svelte-rrrjnb",null,Ge,Yt),on.disabled=!!o(he)},[()=>Pn(u())?"(document root)":qo(u()),()=>({"jse-hide-original-data":!o(Ne)}),()=>({"jse-hide":!o(Ne)})],de),be("click",E,ae),be("input",N,Ot),be("click",rr,$),I(Ze,st)},$$slots:{default:!0}}),eo(yt,(Ze,Ce)=>oc?.(Ze,Ce),()=>Ue),I(X,yt)},$$slots:{default:!0}}),ut()}function Co(){}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-status-bar.svelte-1ulj7zd {
  background: var(--jse-panel-background, #ebebeb);
  color: var(--jse-panel-color-readonly, #b2b2b2);
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  margin: 0;
  border-top: var(--jse-panel-border, var(--jse-main-border, 1px solid #d7d7d7));
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
  display: flex;
  gap: var(--jse-padding, 10px);
}
.jse-status-bar.svelte-1ulj7zd:last-child {
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-status-bar.svelte-1ulj7zd .jse-status-bar-info:where(.svelte-1ulj7zd) {
  padding: 2px;
}`);var BP=G('<div class="jse-status-bar-info svelte-1ulj7zd"> </div>'),WP=G('<div class="jse-status-bar-info svelte-1ulj7zd"> </div>'),HP=G('<div class="jse-status-bar-info svelte-1ulj7zd"> </div>'),VP=G('<div class="jse-status-bar svelte-1ulj7zd"><!> <!> <!></div>'),yp=mk.define([{tag:ol.propertyName,color:"var(--internal-key-color)"},{tag:ol.number,color:"var(--internal-value-color-number)"},{tag:ol.bool,color:"var(--internal-value-color-boolean)"},{tag:ol.string,color:"var(--internal-value-color-string)"},{tag:ol.keyword,color:"var(--internal-value-color-null)"}]),JP=Kg(yp),GP=yp.style;yp.style=e=>GP(e||[]);var KP=[bk.fromClass(class{constructor(e){this.view=e,this.indentUnit=Cp(e.state),this.initialPaddingLeft=null,this.isChrome=window?.navigator.userAgent.includes("Chrome"),this.generate(e.state)}update(e){var t=Cp(e.state);(t!==this.indentUnit||e.docChanged||e.viewportChanged)&&(this.indentUnit=t,this.generate(e.state))}generate(e){var t=new xk;this.initialPaddingLeft?this.addStyleToBuilder(t,e,this.initialPaddingLeft):this.view.requestMeasure({read:n=>{var r=n.contentDOM.querySelector(".cm-line");r&&(this.initialPaddingLeft=window.getComputedStyle(r).getPropertyValue("padding-left"),this.addStyleToBuilder(t,n.state,this.initialPaddingLeft)),this.decorations=t.finish()}}),this.decorations=t.finish()}addStyleToBuilder(e,t,n){var r=this.getVisibleLines(t);for(var a of r){var{numColumns:i,containsTab:s}=this.numColumns(a.text,t.tabSize),l="calc(".concat(i+this.indentUnit,"ch + ").concat(n,")"),u=this.isChrome?"calc(-".concat(i+this.indentUnit,"ch - ").concat(s?1:0,"px)"):"-".concat(i+this.indentUnit,"ch");e.add(a.from,a.from,jk.line({attributes:{style:"padding-left: ".concat(l,"; text-indent: ").concat(u,";")}}))}}getVisibleLines(e){var t=new Set,n=null;for(var{from:r,to:a}of this.view.visibleRanges)for(var i=r;i<=a;){var s=e.doc.lineAt(i);n!==s&&(t.add(s),n=s),i=s.to+1}return t}numColumns(e,t){var n=0,r=!1;e:for(var a=0;a<e.length;a++)switch(e[a]){case" ":n+=1;continue e;case"	":n+=t-n%t,r=!0;continue e;case"\r":continue e;default:break e}return{numColumns:n,containsTab:r}}},{decorations:e=>e.decorations})];jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-text-mode.svelte-xt61xw {
  --internal-key-color: var(--jse-key-color, #1a1a1a);
  --internal-value-color-number: var(--jse-value-color-number, #ee422e);
  --internal-value-color-boolean: var(--jse-value-color-boolean, #ff8c00);
  --internal-value-color-string: var(--jse-value-color-string, #008000);
  --internal-value-color-null: var(--jse-value-color-null, #004ed0);
  flex: 1;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  background: var(--jse-background-color, #fff);
}
.jse-text-mode.no-main-menu.svelte-xt61xw {
  border-top: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) {
  flex: 1;
  display: flex;
  position: relative;
  flex-direction: column;
  overflow: hidden;
  min-width: 0;
  min-height: 0;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw):last-child {
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-text-mode.svelte-xt61xw .jse-contents.jse-hidden:where(.svelte-xt61xw) {
  visibility: hidden;
  position: absolute;
  top: 0;
  left: 0;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor {
  flex: 1;
  overflow: hidden;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-scroller {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  line-height: var(--jse-line-height, calc(1em + 4px));
  color: var(--jse-delimiter-color, rgba(0, 0, 0, 0.38));
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-gutters {
  background: var(--jse-panel-background, #ebebeb);
  color: var(--jse-panel-color-readonly, #b2b2b2);
  border-right: var(--jse-panel-border, var(--jse-main-border, 1px solid #d7d7d7));
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-activeLine,
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-activeLineGutter {
  background: var(--jse-active-line-background-color, rgba(0, 0, 0, 0.06));
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-selectionBackground {
  background: var(--jse-selection-background-color, #d3d3d3);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-searchMatch {
  background-color: var(--jse-search-match-color, #ffe665);
  outline: var(--jse-search-match-outline, none);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-searchMatch.cm-searchMatch-selected {
  background-color: var(--jse-search-match-active-color, var(--jse-search-match-color, #ffe665));
  outline: var(--jse-search-match-outline, 2px solid #e0be00);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-selectionMatch {
  background-color: var(--jse-search-match-background-color, rgba(153, 255, 119, 0.5019607843));
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-foldPlaceholder {
  background: var(--jse-tag-background, rgba(0, 0, 0, 0.2));
  color: var(--jse-tag-color, var(--jse-text-color-inverse, #fff));
  border: none;
  padding: 0 var(--jse-padding, 10px);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-tooltip {
  font-size: var(--jse-font-size, 16px);
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  color: var(--jse-tooltip-color, var(--jse-text-color, #4d4d4d));
  background: var(--jse-tooltip-background, var(--jse-modal-background, #f5f5f5));
  border: var(--jse-tooltip-border, var(--jse-main-border, 1px solid #d7d7d7));
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-diagnosticAction {
  background: var(--jse-tooltip-action-button-color, var(--jse-text-color-inverse, #fff));
  background: var(--jse-tooltip-action-button-background, #4d4d4d);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-panels {
  border-bottom: var(--jse-panel-border, var(--jse-main-border, 1px solid #d7d7d7));
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search {
  background: var(--jse-panel-background, #ebebeb);
  color: var(--jse-panel-color, var(--jse-text-color, #4d4d4d));
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search input {
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size-text-mode-search, 80%);
  color: var(--jse-input-color, var(--jse-text-color, #4d4d4d));
  border: var(--jse-input-border, 1px solid #d8dbdf);
  background: var(--jse-input-background, var(--jse-background-color, #fff));
  margin-right: 2px;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search button {
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size-text-mode-search, 80%);
  color: var(--jse-panel-button-color, inherit);
  background: var(--jse-panel-button-background, transparent);
  border: none;
  cursor: pointer;
  text-transform: capitalize;
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px);
  margin: 0;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search button:hover {
  color: var(--panel-button-color-highlight, var(--jse-text-color, #4d4d4d));
  background: var(--jse-panel-button-background-highlight, #e0e0e0);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search label {
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size-text-mode-search, 80%);
  padding-left: var(--jse-padding, 10px);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search label input {
  margin-right: 2px;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-search button[name="close"] {
  width: 32px;
  height: 32px;
  font-size: 24px;
  line-height: 24px;
  padding: 0;
  right: 0;
  top: -4px;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .cm-editor .cm-cursor-primary {
  border-color: var(--jse-text-color, #4d4d4d);
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .jse-loading-space:where(.svelte-xt61xw) {
  flex: 1;
}
.jse-text-mode.svelte-xt61xw .jse-contents:where(.svelte-xt61xw) .jse-loading:where(.svelte-xt61xw) {
  flex: 2;
  text-align: center;
  color: var(--jse-panel-color-readonly, #b2b2b2);
  box-sizing: border-box;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
}
.jse-text-mode.svelte-xt61xw .jse-contents.jse-preview:where(.svelte-xt61xw) {
  flex: 1;
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  color: var(--jse-panel-color-readonly, #b2b2b2);
  overflow: auto;
  white-space: pre-wrap;
  word-break: break-word;
  padding: 2px;
}`);var YP=G('<!> <div class="jse-contents jse-preview svelte-xt61xw"> </div>',1),XP=G("<!> <!> <!> <!>",1),QP=G("<div></div> <!> <!>",1),ZP=G('<div class="jse-contents svelte-xt61xw"><div class="jse-loading-space svelte-xt61xw"></div> <div class="jse-loading svelte-xt61xw">loading...</div></div>'),eT=G("<div><!> <!></div>");function tT(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=h(t,"readOnly",9),i=h(t,"mainMenuBar",9),s=h(t,"statusBar",9),l=h(t,"askToFormat",9),u=h(t,"externalContent",9),d=h(t,"externalSelection",9),c=h(t,"history",9),v=h(t,"indentation",9),f=h(t,"tabSize",9),g=h(t,"escapeUnicodeCharacters",9),m=h(t,"parser",9),b=h(t,"validator",9),j=h(t,"validationParser",9),w=h(t,"onChange",9),O=h(t,"onChangeMode",9),T=h(t,"onSelect",9),R=h(t,"onUndo",9),k=h(t,"onRedo",9),D=h(t,"onError",9),H=h(t,"onFocus",9),V=h(t,"onBlur",9),A=h(t,"onRenderMenu",9),J=h(t,"onSortModal",9),Z=h(t,"onTransformModal",9),Y=Fr("jsoneditor:TextMode"),le={key:"Mod-i",run:Ce,shift:st,preventDefault:!0},Ae=typeof window>"u";Y("isSSR:",Ae);var ce,we=P(void 0,!0),$e=P(void 0,!0),Ne=P(void 0,!0),ye=P(!1,!0),ze=P(l(),!0),Re=P([],!0),We=new al,he=new al,ue=new al,me=new al,ot=new al,Ot=u(),ee=P(fv(Ot,v(),m()),!0),q=Vk.define(),ae=null;function $(){if(!ae||ae.length===0)return!1;var Q=ae[0].startState,Te=ae[ae.length-1].state,tt=ae.map(et=>et.changes).reduce((et,Bt)=>et.compose(Bt)),Nt={type:"text",undo:{changes:tt.invert(Q.doc).toJSON(),selection:it(Q.selection)},redo:{changes:tt.toJSON(),selection:it(Te.selection)}};return Y("add history item",Nt),c().add(Nt),ae=null,!0}var _e=P(g(),!0);Yr(Rt(function*(){if(!Ae)try{ce=function(Q){var{target:Te,initialText:tt,readOnly:Nt,indentation:et}=Q;Y("Create CodeMirror editor",{readOnly:Nt,indentation:et});var Bt=function(Lt,Sn){return Od(Lt)?Lt.ranges.every(mt=>mt.anchor<Sn.length&&mt.head<Sn.length):!1}(d(),tt)?rr(d()):void 0,yn=Hi.create({doc:tt,selection:Bt,extensions:[Op.of([Uk,le]),We.of(Fe()),yk(),wk(),kk(),_k(),Sk(),Ck(),Ok(),Hi.allowMultipleSelections.of(!0),Ek(),Kg(Dk,{fallback:!0}),Ak(),Rk(),Mk(),zk(),Pk(),Tk(),Ik(),Op.of([...qk,...$k,...Fk,{key:"Mod-z",run:x,preventDefault:!0},{key:"Mod-y",mac:"Mod-Shift-z",run:_,preventDefault:!0},{key:"Ctrl-Shift-z",run:_,preventDefault:!0},...Bk,...Wk,...Hk]),JP,z1({hideFirstIndent:!0}),Vi.domEventHandlers({dblclick:N}),Vi.updateListener.of(Lt=>{p(Ne,Lt.state),Lt.docChanged&&(Lt.transactions.some(Sn=>!!Sn.annotation(q))||(ae=[...ae??[],Lt]),en()),Lt.selectionSet&&on()}),Nk(),Lk({top:!0}),Vi.lineWrapping,he.of(Hi.readOnly.of(Nt)),me.of(Hi.tabSize.of(f())),ue.of(hn(et)),ot.of(Vi.theme({},{dark:Ge()}))]});return ce=new Vi({state:yn,parent:Te}),Bt&&ce.dispatch(ce.state.update({selection:Bt.main,scrollIntoView:!0})),ce}({target:o(we),initialText:Ft(o(ee),o(ye))?"":o(n).escapeValue(o(ee)),readOnly:a(),indentation:v()})}catch(Q){console.error(Q)}})),zo(()=>{Jt(),ce&&(Y("Destroy CodeMirror editor"),ce.destroy())});var ne=ei(),Ue=ei();function X(){ce&&(Y("focus"),ce.focus())}var L=!1;function yt(Q){return Ze(Q,!1)}function Ze(Q,Te){Y("handlePatch",Q,Te);var tt=m().parse(o(ee)),Nt=$o(tt,Q),et=Uv(tt,Q);return Vt({text:m().stringify(Nt,null,v())},Te,!1),{json:Nt,previousJson:tt,undo:et,redo:Q}}function Ce(){if(Y("format"),a())return!1;try{var Q=m().parse(o(ee));return Vt({text:m().stringify(Q,null,v())},!0,!1),p(ze,l()),!0}catch(Te){D()(Te)}return!1}function st(){if(Y("compact"),a())return!1;try{var Q=m().parse(o(ee));return Vt({text:m().stringify(Q)},!0,!1),p(ze,!1),!0}catch(Te){D()(Te)}return!1}function Me(){if(Y("repair"),!a())try{Vt({text:Wo(o(ee))},!0,!1),p(Yt,kd),p(En,void 0)}catch(Q){D()(Q)}}function at(){var Q;if(!a())try{var Te=m().parse(o(ee));L=!0,J()({id:ne,json:Te,rootPath:[],onSort:(Q=Rt(function*(tt){var{operations:Nt}=tt;Y("onSort",Nt),Ze(Nt,!0)}),function(tt){return Q.apply(this,arguments)}),onClose:()=>{L=!1,X()}})}catch(tt){D()(tt)}}function Tt(Q){var{id:Te,rootPath:tt,onTransform:Nt,onClose:et}=Q;try{var Bt=m().parse(o(ee));L=!0,Z()({id:Te||Ue,json:Bt,rootPath:tt||[],onTransform:yn=>{Nt?Nt({operations:yn,json:Bt,transformedJson:$o(Bt,yn)}):(Y("onTransform",yn),Ze(yn,!0))},onClose:()=>{L=!1,X(),et&&et()}})}catch(yn){D()(yn)}}function Je(){a()||Tt({rootPath:[]})}function qt(){ce&&(o(we)&&o(we).querySelector(".cm-search")?Kk(ce):Yk(ce))}function x(){if(a())return!1;Jt();var Q=c().undo();return Y("undo",Q),Lh(Q)?(ce.dispatch({annotations:q.of("undo"),changes:Ep.fromJSON(Q.undo.changes),selection:ad.fromJSON(Q.undo.selection),scrollIntoView:!0}),!0):(R()(Q),!1)}function _(){if(a())return!1;Jt();var Q=c().redo();return Y("redo",Q),Lh(Q)?(ce.dispatch({annotations:q.of("redo"),changes:Ep.fromJSON(Q.redo.changes),selection:ad.fromJSON(Q.redo.selection),scrollIntoView:!0}),!0):(k()(Q),!1)}function E(){p(ye,!0),Vt(u(),!0,!0)}function U(){O()(Lr.tree)}function te(){Ln()}function fe(Q){Y("select validation error",Q);var{from:Te,to:tt}=Et(Q);Te!==void 0&&tt!==void 0&&(xe(Te,tt),X())}function xe(Q,Te){Y("setSelection",{anchor:Q,head:Te}),ce&&ce.dispatch(ce.state.update({selection:{anchor:Q,head:Te},scrollIntoView:!0}))}function N(Q,Te){if(Te.state.selection.ranges.length===1){var tt=Te.state.selection.ranges[0],Nt=o(ee).slice(tt.from,tt.to);if(Nt==="{"||Nt==="["){var et=kp.parse(o(ee)),Bt=Object.keys(et.pointers).find(Lt=>{var Sn;return((Sn=et.pointers[Lt].value)===null||Sn===void 0?void 0:Sn.pos)===tt.from}),yn=et.pointers[Bt];Bt&&yn&&yn.value&&yn.valueEnd&&(Y("pointer found, selecting inner contents of path:",Bt,yn),xe(yn.value.pos+1,yn.valueEnd.pos-1))}}}function Fe(){return Jk(vr,{delay:300})}function Ge(){return!!o(we)&&getComputedStyle(o(we)).getPropertyValue("--jse-theme").includes("dark")}function Et(Q){var{path:Te,message:tt,severity:Nt}=Q,{line:et,column:Bt,from:yn,to:Lt}=function(Sn,mt){try{var Ut=kp.parse(Sn),dt=zt(mt),kt=Ut.pointers[dt];if(kt)return{path:mt,line:kt.key?kt.key.line:kt.value?kt.value.line:0,column:kt.key?kt.key.column:kt.value?kt.value.column:0,from:kt.key?kt.key.pos:kt.value?kt.value.pos:0,to:kt.keyEnd?kt.keyEnd.pos:kt.valueEnd?kt.valueEnd.pos:0}}catch(Un){console.error(Un)}return{path:mt,line:0,column:0,from:0,to:0}}(o(n).escapeValue(o(ee)),Te);return{path:Te,line:et,column:Bt,from:yn,to:Lt,message:tt,severity:Nt,actions:[]}}function pe(Q,Te){var{line:tt,column:Nt,position:et,message:Bt}=Q;return{path:[],line:tt,column:Nt,from:et,to:et,severity:jo.error,message:Bt,actions:Te&&!a()?[{name:"Auto repair",apply:()=>Me()}]:void 0}}function vt(Q){return{from:Q.from||0,to:Q.to||0,message:Q.message||"",actions:Q.actions,severity:Q.severity}}function Vt(Q,Te,tt){var Nt=fv(Q,v(),m()),et=!Zt(Q,Ot),Bt=Ot;Y("setCodeMirrorContent",{isChanged:et,emitChange:Te,forceUpdate:tt}),ce&&(et||tt)&&(Ot=Q,p(ee,Nt),Ft(o(ee),o(ye))||ce.dispatch({changes:{from:0,to:ce.state.doc.length,insert:o(n).escapeValue(o(ee))}}),$(),et&&Te&&gt(Ot,Bt))}function rr(Q){return Od(Q)?ad.fromJSON(Q):void 0}function fn(){return $t.apply(this,arguments)}function $t(){return $t=Rt(function*(){Y("refresh"),yield function(){return wt.apply(this,arguments)}()}),$t.apply(this,arguments)}function Ln(){if(ce){var Q=ce?o(n).unescapeValue(ce.state.doc.toString()):"",Te=Q!==o(ee);if(Y("onChangeCodeMirrorValue",{isChanged:Te}),Te){var tt=Ot;p(ee,Q),Ot={text:o(ee)},$(),gt(Ot,tt),pr(),on()}}}function wt(){return(wt=Rt(function*(){if(pr(),ce){var Q=Ge();return Y("updateTheme",{dark:Q}),ce.dispatch({effects:[ot.reconfigure(Vi.theme({},{dark:Q}))]}),new Promise(Te=>setTimeout(Te))}return Promise.resolve()})).apply(this,arguments)}function hn(Q){var Te=Gk.of(typeof Q=="number"?" ".repeat(Q):Q);return Q==="	"?[Te]:[Te,KP]}bp({onMount:Yr,onDestroy:zo,getWindow:()=>tu(o($e)),hasFocus:()=>L&&document.hasFocus()||ep(o($e)),onFocus:H(),onBlur:()=>{Jt(),V()()}});var en=Si(Ln,300);function Jt(){en.flush()}function gt(Q,Te){w()&&w()(Q,Te,{contentErrors:An(),patchResult:void 0})}function on(){T()(it(o(Ne).selection))}function it(Q){return Se({type:$n.text},Q.toJSON())}function Ft(Q,Te){return!!Q&&Q.length>Mh&&!Te}var Yt=P(kd,!0),En=P(void 0,!0);function vr(){if(Ft(o(ee),o(ye)))return[];var Q=An();if(Ih(Q)){var{parseError:Te,isRepairable:tt}=Q;return[vt(pe(Te,tt))]}return xR(Q)?Q.validationErrors.map(Et).map(vt):[]}function An(){Y("validate:start"),Jt();var Q=Or(o(n).escapeValue(o(ee)),b(),m(),j());return Ih(Q)?(p(Yt,Q.isRepairable?Ph:"invalid"),p(En,Q.parseError),p(Re,[])):(p(Yt,kd),p(En,void 0),p(Re,Q?.validationErrors||[])),Y("validate:end"),Q}var Or=Ci(AM);function yr(){o(En)&&function(Q){Y("select parse error",Q);var Te=pe(Q,!1);xe(Te.from!=null?Te.from:0,Te.to!=null?Te.to:0),X()}(o(En))}var Sr={icon:pk,text:"Show me",title:"Move to the parse error location",onClick:yr};W(()=>M(g()),()=>{p(n,Qf({escapeControlCharacters:!1,escapeUnicodeCharacters:g()}))}),W(()=>M(u()),()=>{Vt(u(),!1,!1)}),W(()=>M(d()),()=>{(function(Q){if(Od(Q)){var Te=rr(Q);!ce||!Te||o(Ne)&&o(Ne).selection.eq(Te)||(Y("applyExternalSelection",Te),ce.dispatch({selection:Te}))}})(d())}),W(()=>M(b()),()=>{(function(Q){Y("updateLinter",Q),ce&&ce.dispatch({effects:We.reconfigure(Fe())})})(b())}),W(()=>M(v()),()=>{(function(Q){ce&&(Y("updateIndentation",Q),ce.dispatch({effects:ue.reconfigure(hn(Q))}))})(v())}),W(()=>M(f()),()=>{(function(Q){ce&&(Y("updateTabSize",Q),ce.dispatch({effects:me.reconfigure(Hi.tabSize.of(Q))}))})(f())}),W(()=>M(a()),()=>{(function(Q){ce&&(Y("updateReadOnly",Q),ce.dispatch({effects:[he.reconfigure(Hi.readOnly.of(Q))]}))})(a())}),W(()=>(o(_e),M(g())),()=>{o(_e)!==g()&&(p(_e,g()),Y("forceUpdateText",{escapeUnicodeCharacters:g()}),ce&&ce.dispatch({changes:{from:0,to:ce.state.doc.length,insert:o(n).escapeValue(o(ee))}}))}),W(()=>(o(Yt),M(a()),bs),()=>{p(r,o(Yt)!==Ph||a()?[Sr]:[{icon:bs,text:"Auto repair",title:"Automatically repair JSON",onClick:Me},Sr])}),_n(),St(!0);var Ir,Er=eT(),Vn=z(Er),Jn=Q=>{var Te=de(()=>o(ee).length===0),tt=de(()=>!o(Te)),Nt=de(()=>!o(Te)),et=de(()=>!o(Te)),Bt=de(()=>!o(Te));(function(yn,Lt){lt(Lt,!1);var Sn=P(void 0,!0),mt=h(Lt,"readOnly",9,!1),Ut=h(Lt,"onFormat",9),dt=h(Lt,"onCompact",9),kt=h(Lt,"onSort",9),Un=h(Lt,"onTransform",9),Fn=h(Lt,"onToggleSearch",9),Xt=h(Lt,"onUndo",9),Wt=h(Lt,"onRedo",9),Gt=h(Lt,"canUndo",9),or=h(Lt,"canRedo",9),B=h(Lt,"canFormat",9),ie=h(Lt,"canCompact",9),Oe=h(Lt,"canSort",9),Dt=h(Lt,"canTransform",9),bn=h(Lt,"onRenderMenu",9),un={type:"button",icon:fc,title:"Search (Ctrl+F)",className:"jse-search",onClick:Fn()},Rn=P(void 0,!0);W(()=>(M(mt()),M(Ut()),M(B()),M(dt()),M(ie()),M(kt()),M(Oe()),M(Un()),M(Dt()),M(Xt()),M(Gt()),M(Wt()),M(or())),()=>{p(Rn,mt()?[un,{type:"space"}]:[{type:"button",icon:ug,title:"Format JSON: add proper indentation and new lines (Ctrl+I)",className:"jse-format",onClick:Ut(),disabled:mt()||!B()},{type:"button",icon:Pz,title:"Compact JSON: remove all white spacing and new lines (Ctrl+Shift+I)",className:"jse-compact",onClick:dt(),disabled:mt()||!ie()},{type:"separator"},{type:"button",icon:Mu,title:"Sort",className:"jse-sort",onClick:kt(),disabled:mt()||!Oe()},{type:"button",icon:zu,title:"Transform contents (filter, sort, project)",className:"jse-transform",onClick:Un(),disabled:mt()||!Dt()},un,{type:"separator"},{type:"button",icon:Zv,title:"Undo (Ctrl+Z)",className:"jse-undo",onClick:Xt(),disabled:!Gt()},{type:"button",icon:ef,title:"Redo (Ctrl+Shift+Z)",className:"jse-redo",onClick:Wt(),disabled:!or()},{type:"space"}])}),W(()=>(M(bn()),o(Rn)),()=>{p(Sn,bn()(o(Rn))||o(Rn))}),_n(),St(!0),Xc(yn,{get items(){return o(Sn)}}),ut()})(Q,{get readOnly(){return a()},onFormat:Ce,onCompact:st,onSort:at,onTransform:Je,onToggleSearch:qt,onUndo:x,onRedo:_,get canFormat(){return o(tt)},get canCompact(){return o(Nt)},get canSort(){return o(et)},get canTransform(){return o(Bt)},get canUndo(){return c().canUndo},get canRedo(){return c().canRedo},get onRenderMenu(){return A()}})};re(Vn,Q=>{i()&&Q(Jn)});var gr=F(Vn,2),je=Q=>{var Te,tt=QP(),Nt=de(()=>Ft(o(ee),o(ye))),et=ft(tt);tr(et,mt=>p(we,mt),()=>o(we));var Bt=F(et,2),yn=mt=>{var Ut=YP(),dt=ft(Ut),kt=de(()=>"The JSON document is larger than ".concat(kv(Mh),", ")+"and may crash your browser when loading it in text mode. Actual size: ".concat(kv(o(ee).length),"."));Yo(dt,{icon:Ei,type:"error",get message(){return o(kt)},actions:[{text:"Open anyway",title:"Open the document in text mode. This may freeze or crash your browser.",onClick:E},{text:"Open in tree mode",title:"Open the document in tree mode. Tree mode can handle large documents.",onClick:U},{text:"Cancel",title:"Cancel opening this large document.",onClick:te}],onClose:X});var Un=z(F(dt,2));Ee(Fn=>pt(Un,Fn),[()=>El(o(ee)||"",gv)],de),I(mt,Ut)};re(Bt,mt=>{o(Nt)&&mt(yn)});var Lt=F(Bt,2),Sn=mt=>{var Ut=XP(),dt=ft(Ut),kt=Gt=>{(function(or,B){lt(B,!1);var ie=h(B,"editorState",8),Oe=P(),Dt=P(),bn=P(),un=P(),Rn=P();W(()=>M(ie()),()=>{var qe;p(Oe,(qe=ie())===null||qe===void 0||(qe=qe.selection)===null||qe===void 0||(qe=qe.main)===null||qe===void 0?void 0:qe.head)}),W(()=>(o(Oe),M(ie())),()=>{var qe;p(Dt,o(Oe)!==void 0?(qe=ie())===null||qe===void 0||(qe=qe.doc)===null||qe===void 0?void 0:qe.lineAt(o(Oe)):void 0)}),W(()=>o(Dt),()=>{p(bn,o(Dt)!==void 0?o(Dt).number:void 0)}),W(()=>(o(Dt),o(Oe)),()=>{p(un,o(Dt)!==void 0&&o(Oe)!==void 0?o(Oe)-o(Dt).from+1:void 0)}),W(()=>M(ie()),()=>{var qe;p(Rn,(qe=ie())===null||qe===void 0||(qe=qe.selection)===null||qe===void 0||(qe=qe.ranges)===null||qe===void 0?void 0:qe.reduce((gn,Dn)=>gn+Dn.to-Dn.from,0))}),_n(),St();var Xn=VP(),Gn=z(Xn),ar=qe=>{var gn=BP(),Dn=z(gn);Ee(()=>{var xn;return pt(Dn,"Line: ".concat((xn=o(bn))!==null&&xn!==void 0?xn:""))}),I(qe,gn)};re(Gn,qe=>{o(bn)!==void 0&&qe(ar)});var At=F(Gn,2),Qn=qe=>{var gn=WP(),Dn=z(gn);Ee(()=>{var xn;return pt(Dn,"Column: ".concat((xn=o(un))!==null&&xn!==void 0?xn:""))}),I(qe,gn)};re(At,qe=>{o(un)!==void 0&&qe(Qn)});var xt=F(At,2),Nr=qe=>{var gn=HP(),Dn=z(gn);Ee(()=>{var xn;return pt(Dn,"Selection: ".concat((xn=o(Rn))!==null&&xn!==void 0?xn:""," characters"))}),I(qe,gn)};re(xt,qe=>{o(Rn)!==void 0&&o(Rn)>0&&qe(Nr)}),I(or,Xn),ut()})(Gt,{get editorState(){return o(Ne)}})};re(dt,Gt=>{s()&&Gt(kt)});var Un=F(dt,2),Fn=Gt=>{Yo(Gt,{type:"error",icon:Ei,get message(){return o(En).message},get actions(){return o(r)},onClick:yr,onClose:X})};re(Un,Gt=>{o(En)&&Gt(Fn)});var Xt=F(Un,2),Wt=Gt=>{Yo(Gt,{type:"success",message:"Do you want to format the JSON?",actions:[{icon:ug,text:"Format",title:"Format JSON: add proper indentation and new lines (Ctrl+I)",onClick:Ce},{icon:vc,text:"No thanks",title:"Close this message",onClick:()=>p(ze,!1)}],onClose:X})};re(Xt,Gt=>{var or,B;!o(En)&&o(ze)&&(or=o(ee),!(B=or.substring(0,999).trim()).includes(`
`)&&HA.test(B))&&Gt(Wt)}),xp(F(Xt,2),{get validationErrors(){return o(Re)},selectError:fe}),I(mt,Ut)};re(Lt,mt=>{o(Nt)||mt(Sn)}),Ee(mt=>Te=Mt(et,1,"jse-contents svelte-xt61xw",null,Te,mt),[()=>({"jse-hidden":o(Nt)})],de),I(Q,tt)},an=Q=>{I(Q,ZP())};return re(gr,Q=>{Ae?Q(an,!1):Q(je)}),tr(Er,Q=>p($e,Q),()=>o($e)),Ee(Q=>Ir=Mt(Er,1,"jse-text-mode svelte-xt61xw",null,Ir,Q),[()=>({"no-main-menu":!i()})],de),I(e,Er),_t(t,"focus",X),_t(t,"patch",yt),_t(t,"handlePatch",Ze),_t(t,"openTransformModal",Tt),_t(t,"refresh",fn),_t(t,"flush",Jt),_t(t,"validate",An),ut({focus:X,patch:yt,handlePatch:Ze,openTransformModal:Tt,refresh:fn,flush:Jt,validate:An})}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-inline-value.svelte-h57m0p {
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  line-height: var(--jse-line-height, calc(1em + 4px));
  border: none;
  padding: 0 calc(0.5 * var(--jse-padding, 10px));
  background: transparent;
  color: inherit;
  cursor: inherit;
}
.jse-inline-value.jse-highlight.svelte-h57m0p {
  background-color: var(--jse-search-match-color, #ffe665);
  outline: var(--jse-search-match-outline, none);
}
.jse-inline-value.jse-highlight.jse-active.svelte-h57m0p {
  background-color: var(--jse-search-match-active-color, var(--jse-search-match-color, #ffe665));
  outline: var(--jse-search-match-outline, 2px solid #e0be00);
}`);var nT=G('<button type="button"> </button>');jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-column-header.svelte-2i3vdx {
  background: none;
  border: none;
  font-family: inherit;
  font-size: inherit;
  color: inherit;
  display: flex;
  gap: var(--jse-padding, 10px);
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px) calc(0.5 * var(--jse-padding, 10px)) calc(0.5 * var(--jse-padding, 10px));
  width: 100%;
}
.jse-column-header.svelte-2i3vdx:hover {
  background: var(--jse-table-header-background-highlight, #e8e8e8);
}
.jse-column-header.svelte-2i3vdx:not(.jse-column-header.jse-readonly) {
  cursor: pointer;
}
.jse-column-header.svelte-2i3vdx span.jse-column-sort-icon:where(.svelte-2i3vdx) {
  height: 1em;
}`);var rT=G('<span class="jse-column-sort-icon svelte-2i3vdx"><!></span>'),oT=G('<button type="button"><span class="jse-column-name"> </span> <!></button>');jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-table-mode-welcome.svelte-17xl1jx {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: auto;
  align-items: center;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-table-mode-welcome.svelte-17xl1jx:last-child {
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-space.jse-before:where(.svelte-17xl1jx) {
  flex: 1;
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) {
  display: flex;
  flex-direction: column;
  gap: var(--jse-padding, 10px);
  max-width: 400px;
  margin: 2em var(--jse-padding, 10px);
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) .jse-nested-arrays-info:where(.svelte-17xl1jx) {
  color: var(--jse-panel-color-readonly, #b2b2b2);
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) .jse-nested-property:where(.svelte-17xl1jx) {
  display: flex;
  align-items: center;
  gap: var(--jse-padding, 10px);
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) .jse-nested-property:where(.svelte-17xl1jx) .jse-nested-property-path:where(.svelte-17xl1jx) {
  flex: 1;
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) .jse-nested-property:where(.svelte-17xl1jx) .jse-nested-property-path:where(.svelte-17xl1jx) .jse-nested-property-count:where(.svelte-17xl1jx) {
  opacity: 0.5;
  white-space: nowrap;
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) button.jse-nested-array-action:where(.svelte-17xl1jx) {
  text-align: left;
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-primary-background, var(--jse-theme-color, #3883fa));
  color: var(--jse-button-primary-color, #fff);
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) button.jse-nested-array-action:where(.svelte-17xl1jx):hover {
  background: var(--jse-button-primary-background-highlight, var(--jse-theme-color-highlight, #5f9dff));
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-nested-arrays:where(.svelte-17xl1jx) button.jse-nested-array-action:where(.svelte-17xl1jx):disabled {
  background: var(--jse-button-primary-background-disabled, #9d9d9d);
}
.jse-table-mode-welcome.svelte-17xl1jx .jse-space.jse-after:where(.svelte-17xl1jx) {
  flex: 2;
}`);var aT=(e,t)=>t.onClick(),iT=G(`An empty document cannot be opened in table mode. You can go to tree mode instead, or paste
        a JSON Array using <b>Ctrl+V</b>.`,1),sT=(e,t,n)=>t.openJSONEditorModal(o(n)),lT=(e,t,n)=>t.extractPath(o(n)),uT=G('<button type="button" class="jse-nested-array-action svelte-17xl1jx">Extract</button>'),cT=G('<div class="jse-nested-property svelte-17xl1jx"><div class="jse-nested-property-path svelte-17xl1jx"> <span class="jse-nested-property-count svelte-17xl1jx"> </span></div> <button type="button" class="jse-nested-array-action svelte-17xl1jx"> </button> <!></div>'),dT=(e,t)=>t.onChangeMode(Lr.tree),vT=G('<div class="jse-table-mode-welcome svelte-17xl1jx" role="none"><div class="jse-space jse-before svelte-17xl1jx"></div> <div class="jse-nested-arrays svelte-17xl1jx"><div class="jse-nested-arrays-title"> </div> <div class="jse-nested-arrays-info svelte-17xl1jx"><!></div> <!> <button type="button" class="jse-nested-array-action svelte-17xl1jx">Switch to tree mode</button></div> <div class="jse-space jse-after svelte-17xl1jx"></div></div>');function fT(e,t){lt(t,!0);var n=co(()=>t.json?function(b){var j=arguments.length>1&&arguments[1]!==void 0?arguments[1]:2,w=[];return function O(T,R){$r(T)&&R.length<j&&Object.keys(T).forEach(k=>{O(T[k],R.concat(k))}),zr(T)&&w.push(R)}(b,[]),w}(t.json).slice(0,99).filter(b=>b.length>0):[]),r=co(()=>!Pn(o(n))),a=co(()=>t.json===void 0&&(t.text===""||t.text===void 0)),i=co(()=>o(r)?"Object with nested arrays":o(a)?"An empty document":$r(t.json)?"An object":zr(t.json)?"An empty array":"A ".concat(Xf(t.json,t.parser))),s=vT();s.__click=[aT,t];var l=F(z(s),2),u=z(l),d=z(u),c=F(u,2),v=z(c),f=b=>{I(b,Br(`An object cannot be opened in table mode. You can open a nested array instead, or open the
        document in tree mode.`))},g=(b,j)=>{var w=T=>{I(T,iT())},O=T=>{var R=Br();Ee(()=>{var k;return pt(R,"".concat((k=o(i))!==null&&k!==void 0?k:""," cannot be opened in table mode. You can open the document in tree mode instead."))}),I(T,R)};re(b,T=>{o(a)&&!t.readOnly?T(w):T(O,!1)},j)};re(v,b=>{o(r)?b(f):b(g,!1)});var m=F(c,2);jr(m,17,()=>o(n),Cr,(b,j)=>{var w=cT(),O=co(()=>function(J){return Ke(t.json,J).length}(o(j))),T=z(w),R=z(T),k=z(F(R)),D=F(T,2);D.__click=[sT,t,j];var H=z(D),V=F(D,2),A=J=>{var Z=uT();Z.__click=[lT,t,j],I(J,Z)};re(V,J=>{t.readOnly||J(A)}),Ee(J=>{var Z,Y;pt(R,'"'.concat(J??"",'" ')),pt(k,"(".concat((Z=o(O))!==null&&Z!==void 0?Z:""," ").concat((Y=o(O)!==1?"items":"item")!==null&&Y!==void 0?Y:"",")")),pt(H,t.readOnly?"View":"Edit")},[()=>qo(o(j))]),I(b,w)}),F(m,2).__click=[dT,t],Ee(()=>pt(d,o(i))),I(e,s),ut()}Zl(["click"]);jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-column-header.svelte-fzj761 {
  background: none;
  border: none;
  font-family: inherit;
  font-size: inherit;
  color: inherit;
  display: flex;
  gap: var(--jse-padding, 10px);
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px) calc(0.5 * var(--jse-padding, 10px)) calc(0.5 * var(--jse-padding, 10px));
  width: 100%;
}
.jse-column-header.svelte-fzj761:hover {
  background: var(--jse-table-header-background-highlight, #e8e8e8);
}
.jse-column-header.svelte-fzj761:not(.jse-column-header.jse-readonly) {
  cursor: pointer;
}`);var pT=G('<button type="button"><!></button>');jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-table-mode.svelte-u14cgx {
  flex: 1;
  display: flex;
  flex-direction: column;
  position: relative;
  background: var(--jse-background-color, #fff);
  min-width: 0;
  min-height: 0;
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  color: var(--jse-text-color, #4d4d4d);
  line-height: var(--jse-line-height, calc(1em + 4px));
}
.jse-table-mode.no-main-menu.svelte-u14cgx {
  border-top: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-table-mode.svelte-u14cgx .jse-search-box-container:where(.svelte-u14cgx) {
  position: relative;
  height: 0;
  top: calc(var(--jse-line-height, calc(1em + 4px)) + 2 * var(--jse-padding, 10px));
  margin-right: calc(var(--jse-padding, 10px) + 20px);
  margin-left: var(--jse-padding, 10px);
  text-align: right;
  z-index: 3;
}
.jse-table-mode.svelte-u14cgx .jse-hidden-input-label:where(.svelte-u14cgx) {
  position: fixed;
  right: 0;
  top: 0;
  width: 0;
  height: 0;
}
.jse-table-mode.svelte-u14cgx .jse-hidden-input-label:where(.svelte-u14cgx) .jse-hidden-input:where(.svelte-u14cgx) {
  width: 0;
  height: 0;
  padding: 0;
  border: 0;
  outline: none;
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) {
  flex: 1;
  align-items: flex-start;
  flex-direction: column;
  display: flex;
  overflow: auto;
  overflow-anchor: none;
  scrollbar-gutter: stable;
  border-left: var(--jse-main-border, 1px solid #d7d7d7);
  border-right: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx):last-child {
  border-bottom: var(--jse-main-border, 1px solid #d7d7d7);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) {
  border-collapse: collapse;
  border-spacing: 0;
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-invisible-start-section:where(.svelte-u14cgx) td:where(.svelte-u14cgx),
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-invisible-end-section:where(.svelte-u14cgx) td:where(.svelte-u14cgx) {
  margin: 0;
  padding: 0;
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-search-box-background:where(.svelte-u14cgx) {
  background: var(--jse-table-header-background, #f5f5f5);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-invisible-end-section:where(.svelte-u14cgx) td:where(.svelte-u14cgx) {
  padding-bottom: var(--jse-padding, 10px);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx):hover {
  background-color: var(--jse-table-row-odd-background, rgba(0, 0, 0, 0.05));
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell:where(.svelte-u14cgx) {
  padding: 0 var(--jse-padding, 10px) 0 0;
  vertical-align: top;
  white-space: nowrap;
  height: var(--jse-line-height, calc(1em + 4px));
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell.jse-table-cell-header:where(.svelte-u14cgx), .jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell.jse-table-cell-gutter:where(.svelte-u14cgx) {
  font-weight: normal;
  text-align: left;
  color: var(--jse-text-readonly, #8d8d8d);
  background: var(--jse-table-header-background, #f5f5f5);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell.jse-table-cell-header:where(.svelte-u14cgx) {
  padding: 0;
  position: sticky;
  top: 0;
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell.jse-table-cell-header:where(.svelte-u14cgx) .jse-table-root-error:where(.svelte-u14cgx) {
  padding: calc(0.5 * var(--jse-padding, 10px)) var(--jse-padding, 10px) calc(0.5 * var(--jse-padding, 10px)) calc(0.5 * var(--jse-padding, 10px));
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell.jse-table-cell-gutter:where(.svelte-u14cgx) {
  padding: 0 var(--jse-padding, 10px) 0 calc(0.5 * var(--jse-padding, 10px));
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell:where(.svelte-u14cgx) .jse-value-outer:where(.svelte-u14cgx) {
  display: inline-block;
  cursor: var(--jse-contents-cursor, pointer);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell:where(.svelte-u14cgx) .jse-value-outer:where(.svelte-u14cgx):hover {
  background: var(--jse-hover-background-color, rgba(0, 0, 0, 0.06));
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell:where(.svelte-u14cgx) .jse-value-outer.jse-selected-value:where(.svelte-u14cgx) {
  background: var(--jse-selection-background-color, #d3d3d3);
}
.jse-table-mode.svelte-u14cgx .jse-contents:where(.svelte-u14cgx) table.jse-table-main:where(.svelte-u14cgx) .jse-table-row:where(.svelte-u14cgx) .jse-table-cell:where(.svelte-u14cgx) .jse-context-menu-anchor:where(.svelte-u14cgx) {
  display: inline-flex;
  position: relative;
  vertical-align: top;
}
.jse-table-mode.svelte-u14cgx .jse-contents.jse-contents-loading:where(.svelte-u14cgx) {
  align-items: unset;
}
.jse-table-mode.svelte-u14cgx .jse-contents.jse-contents-loading:where(.svelte-u14cgx) .jse-loading-space:where(.svelte-u14cgx) {
  flex: 1;
}
.jse-table-mode.svelte-u14cgx .jse-contents.jse-contents-loading:where(.svelte-u14cgx) .jse-loading:where(.svelte-u14cgx) {
  flex: 2;
  text-align: center;
  color: var(--jse-panel-color-readonly, #b2b2b2);
  box-sizing: border-box;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
}`);var hT=G('<div class="jse-table-root-error svelte-u14cgx"><!></div>'),gT=G('<th class="jse-table-cell jse-table-cell-header svelte-u14cgx"><!></th>'),mT=G('<th class="jse-table-cell jse-table-cell-header svelte-u14cgx"><!></th>'),bT=G('<th class="jse-table-cell jse-table-cell-gutter svelte-u14cgx"> <!></th>'),xT=G('<div class="jse-context-menu-anchor svelte-u14cgx"><!></div>'),jT=G('<td class="jse-table-cell svelte-u14cgx"><div><!><!></div> <!></td>'),yT=G('<td class="jse-table-cell svelte-u14cgx"></td>'),wT=G('<tr class="jse-table-row svelte-u14cgx"><!><!><!></tr>'),kT=G('<div class="jse-search-box-container svelte-u14cgx"><!></div> <div class="jse-contents svelte-u14cgx"><table class="jse-table-main svelte-u14cgx"><tbody><tr class="jse-table-row jse-table-row-header svelte-u14cgx"><th class="jse-table-cell jse-table-cell-header svelte-u14cgx"><!></th><!><!></tr><tr><td class="svelte-u14cgx"></td></tr><!><tr class="jse-table-invisible-end-section svelte-u14cgx"><td class="svelte-u14cgx"></td></tr></tbody></table></div> <!> <!> <!>',1),_T=G("<!> <!>",1),ST=G('<label class="jse-hidden-input-label svelte-u14cgx"><input type="text" tabindex="-1" class="jse-hidden-input svelte-u14cgx"></label> <!>',1),CT=G('<div class="jse-contents jse-contents-loading svelte-u14cgx"><div class="jse-loading-space svelte-u14cgx"></div> <div class="jse-loading svelte-u14cgx">loading...</div></div>'),OT=G('<div role="table"><!> <!></div> <!> <!>',1);function ET(e,t){lt(t,!1);var n=P(void 0,!0),r=P(void 0,!0),a=P(void 0,!0),i=Fr("jsoneditor:TableMode"),{openAbsolutePopup:s,closeAbsolutePopup:l}=vi("absolute-popup"),u=Tw(),d=ei(),c=ei(),v=typeof window>"u";i("isSSR:",v);var f=h(t,"readOnly",9),g=h(t,"externalContent",9),m=h(t,"externalSelection",9),b=h(t,"history",9),j=h(t,"truncateTextSize",9),w=h(t,"mainMenuBar",9),O=h(t,"escapeControlCharacters",9),T=h(t,"escapeUnicodeCharacters",9),R=h(t,"flattenColumns",9),k=h(t,"parser",9),D=h(t,"parseMemoizeOne",9),H=h(t,"validator",9),V=h(t,"validationParser",9),A=h(t,"indentation",9),J=h(t,"onChange",9),Z=h(t,"onChangeMode",9),Y=h(t,"onSelect",9),le=h(t,"onUndo",9),Ae=h(t,"onRedo",9),ce=h(t,"onRenderValue",9),we=h(t,"onRenderMenu",9),$e=h(t,"onRenderContextMenu",9),Ne=h(t,"onFocus",9),ye=h(t,"onBlur",9),ze=h(t,"onSortModal",9),Re=h(t,"onTransformModal",9),We=h(t,"onJSONEditorModal",9),he=P(void 0,!0),ue=P(void 0,!0),me=P(void 0,!0),ot=P(void 0,!0),Ot=P(void 0,!0);bp({onMount:Yr,onDestroy:zo,getWindow:()=>tu(o(ue)),hasFocus:()=>Tt&&document.hasFocus()||ep(o(ue)),onFocus:()=>{Je=!0,Ne()&&Ne()()},onBlur:()=>{Je=!1,ye()&&ye()()}});var ee,q=P(void 0,!0),ae=P(void 0,!0),$=P(void 0,!0),_e=P(void 0,!0),ne=P(void 0,!0),Ue=P(!1,!0),X=P(!1,!0);function L(C){p(ne,(ee=C)?yw(o(q),ee.items):void 0)}function yt(C){return Ze.apply(this,arguments)}function Ze(){return(Ze=Rt(function*(C){p(N,void 0),yield Yt(C)})).apply(this,arguments)}function Ce(){p(Ue,!1),p(X,!1),gt()}var st=P(1e4,!0),Me=P([],!0),at=P(void 0,!0),Tt=!1,Je=!1,qt=P(!1,!0),x=P({},!0),_=P(600,!0),E=P(0,!0),U=18;function te(C){p(N,C)}function fe(C){o(N)&&C!==void 0&&(ja(C,wi(o(N)))&&ja(C,Qe(o(N)))||(i("clearing selection: path does not exist anymore",o(N)),p(N,void 0)))}var xe=P(o(q)!==void 0?bv({json:o(q)}):void 0,!0),N=P(zl(m())?m():void 0,!0),Fe=P(void 0,!0),Ge=P(!1,!0);function Et(C){if(!f()){i("onSortByHeader",C);var oe=C.sortDirection===Lo.desc?-1:1;wt(Dw(o(q),[],C.path,oe),(ve,ke)=>({state:ke,sortedColumn:C}))}}Yr(()=>{o(N)&&vr(Qe(o(N)))});var pe=P(void 0,!0);function vt(C){if(C.json!==void 0||C.text!==void 0){var oe=o(q)!==void 0&&C.json!==void 0;b().add({type:"tree",undo:{patch:oe?[{op:"replace",path:"",value:C.json}]:void 0,json:C.json,text:C.text,documentState:C.documentState,textIsRepaired:C.textIsRepaired,selection:aa(C.selection),sortedColumn:C.sortedColumn},redo:{patch:oe?[{op:"replace",path:"",value:o(q)}]:void 0,json:o(q),text:o(ae),documentState:o(xe),textIsRepaired:o(Ge),selection:aa(o(N)),sortedColumn:o(Fe)}})}}var Vt=P([],!0),rr=Ci(Iw);function fn(C,oe,ve,ke){ss(()=>{var Pe;try{Pe=rr(C,oe,ve,ke)}catch(Be){Pe=[{path:[],message:"Failed to validate: "+Be.message,severity:jo.warning}]}Zt(Pe,o(Vt))||(i("validationErrors changed:",Pe),p(Vt,Pe))},Pe=>i("validationErrors updated in ".concat(Pe," ms")))}function $t(){return i("validate"),o($)?{parseError:o($),isRepairable:!1}:(fn(o(q),H(),k(),V()),Pn(o(Vt))?void 0:{validationErrors:o(Vt)})}function Ln(C,oe){if(i("patch",C,oe),o(q)===void 0)throw new Error("Cannot apply patch: no JSON");var ve=o(q),ke={json:void 0,text:o(ae),documentState:o(xe),selection:aa(o(N)),sortedColumn:o(Fe),textIsRepaired:o(Ge)},Pe=jw(o(q),C),Be=uw(o(q),o(xe),C),He=aP(o(Fe),C,o(Me)),ct=typeof oe=="function"?oe(Be.json,Be.documentState,o(N)):void 0;return p(q,ct?.json!==void 0?ct.json:Be.json),p(xe,ct?.state!==void 0?ct.state:Be.documentState),p(N,ct?.selection!==void 0?ct.selection:o(N)),p(Fe,ct?.sortedColumn!==void 0?ct.sortedColumn:He),p(ae,void 0),p(Ge,!1),p(_e,void 0),p($,void 0),b().add({type:"tree",undo:Se({patch:Pe},ke),redo:{patch:C,json:void 0,text:void 0,documentState:o(xe),selection:aa(o(N)),sortedColumn:o(Fe),textIsRepaired:o(Ge)}}),{json:o(q),previousJson:ve,undo:Pe,redo:C}}function wt(C,oe){i("handlePatch",C,oe);var ve={json:o(q),text:o(ae)},ke=Ln(C,oe);return hn(ve,ke),ke}function hn(C,oe){if((C.json!==void 0||C?.text!==void 0)&&J()){if(o(ae)!==void 0){var ve={text:o(ae),json:void 0};J()(ve,C,{contentErrors:$t(),patchResult:oe})}else if(o(q)!==void 0){var ke={text:void 0,json:o(q)};J()(ke,C,{contentErrors:$t(),patchResult:oe})}}}function en(C){i("pasted json as text",C),p(_e,C)}function Jt(C){var oe=parseInt(C[0],10),ve=[String(oe+1),...C.slice(1)];return ja(o(q),ve)?rn(ve):rn(C)}function gt(){i("focus"),o(ot)&&(o(ot).focus(),o(ot).select())}function on(C){p(E,C.target.scrollTop)}function it(){o(N)||p(N,function(){if(zr(o(q))&&!Pn(o(q))&&!Pn(o(Me)))return rn(["0",...o(Me)[0]])}())}function Ft(){if(o(Ge)&&o(q)!==void 0){var C={json:o(q),text:o(ae)},oe={json:o(q),documentState:o(xe),selection:o(N),sortedColumn:o(Fe),text:o(ae),textIsRepaired:o(Ge)};p(ae,void 0),p(Ge,!1),fe(o(q)),vt(oe),hn(C,void 0)}return{json:o(q),text:o(ae)}}function Yt(C){var{scrollToWhenVisible:oe=!0}=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},ve=o(Ue)?hl:0,ke=dg(C,o(Me),x,U),Pe=ke-o(E)+ve+U,Be=An(C);if(i("scrollTo",{path:C,top:ke,scrollTop:o(E),elem:Be}),!o(me))return Promise.resolve();var He=o(me).getBoundingClientRect();if(Be&&!oe){var ct=Be.getBoundingClientRect();if(ct.bottom>He.top&&ct.top<He.bottom)return Promise.resolve()}var Qt=-Math.max(ve+2*U,He.height/4);return new Promise(Be?cn=>{u(Be,{container:o(me),offset:Qt,duration:300,callback:()=>{En(C),cn()}})}:cn=>{u(Pe,{container:o(me),offset:Qt,duration:300,callback:()=>{pr(),En(C),cn()}})})}function En(C){var oe=An(C);if(oe&&o(me)){var ve=o(me).getBoundingClientRect(),ke=oe.getBoundingClientRect();if(ke.right>ve.right){var Pe=ke.right-ve.right;go(me,o(me).scrollLeft+=Pe)}if(ke.left<ve.left){var Be=ve.left-ke.left;go(me,o(me).scrollLeft-=Be)}}}function vr(C){(function(oe){if(o(me)){var{rowIndex:ve}=So(oe,o(Me)),ke=dg(oe,o(Me),x,U),Pe=ke+(x[ve]||U),Be=U,He=o(me).getBoundingClientRect(),ct=o(E),Qt=o(E)+He.height-Be;if(Pe>Qt){var cn=Pe-Qt;go(me,o(me).scrollTop+=cn)}if(ke<ct){var tn=ct-ke;go(me,o(me).scrollTop-=tn)}}})(C),En(C)}function An(C){var oe,ve,ke=o(Me).find(Be=>Ta(C.slice(1),Be)),Pe=ke?C.slice(0,1).concat(ke):C;return(oe=(ve=o(me))===null||ve===void 0?void 0:ve.querySelector('td[data-path="'.concat(pv(Pe),'"]')))!==null&&oe!==void 0?oe:void 0}function Or(C){var oe,{anchor:ve,left:ke,top:Pe,width:Be,height:He,offsetTop:ct,offsetLeft:Qt,showTip:cn}=C,tn=function(K){var{json:ge,documentState:Ve,selection:De,readOnly:Ie,onEditValue:Le,onEditRow:Ye,onToggleEnforceString:Pt,onCut:pn,onCopy:nn,onPaste:qn,onRemove:bt,onDuplicateRow:mr,onInsertBeforeRow:Wn,onInsertAfterRow:Zn,onRemoveRow:jn}=K,Xe=ge!==void 0,nt=!!De,wn=ge!==void 0&&De?Ke(ge,Qe(De)):void 0,fr=Xe&&(ur(De)||Dr(De)||zn(De)),kr=!Ie&&Xe&&De!==void 0&&Ku(De),Tn=kr&&!Ar(wn),Mn=!Ie&&fr,Ht=De!==void 0&&Oa(ge,Ve,Qe(De));return[{type:"separator"},{type:"row",items:[{type:"column",items:[{type:"label",text:"Table cell:"},{type:"dropdown-button",main:{type:"button",onClick:()=>Le(),icon:ls,text:"Edit",title:"Edit the value (Double-click on the value)",disabled:!kr},width:"11em",items:[{type:"button",icon:ls,text:"Edit",title:"Edit the value (Double-click on the value)",onClick:()=>Le(),disabled:!kr},{type:"button",icon:Ht?Bg:Wg,text:"Enforce string",title:"Enforce keeping the value as string when it contains a numeric value",onClick:()=>Pt(),disabled:!Tn}]},{type:"dropdown-button",main:{type:"button",onClick:()=>pn(!0),icon:us,text:"Cut",title:"Cut selected contents, formatted with indentation (Ctrl+X)",disabled:!Mn},width:"10em",items:[{type:"button",icon:us,text:"Cut formatted",title:"Cut selected contents, formatted with indentation (Ctrl+X)",onClick:()=>pn(!0),disabled:Ie||!fr},{type:"button",icon:us,text:"Cut compacted",title:"Cut selected contents, without indentation (Ctrl+Shift+X)",onClick:()=>pn(!1),disabled:Ie||!fr}]},{type:"dropdown-button",main:{type:"button",onClick:()=>nn(!0),icon:Va,text:"Copy",title:"Copy selected contents, formatted with indentation (Ctrl+C)",disabled:!fr},width:"12em",items:[{type:"button",icon:Va,text:"Copy formatted",title:"Copy selected contents, formatted with indentation (Ctrl+C)",onClick:()=>nn(!1),disabled:!fr},{type:"button",icon:Va,text:"Copy compacted",title:"Copy selected contents, without indentation (Ctrl+Shift+C)",onClick:()=>nn(!1),disabled:!fr}]},{type:"button",onClick:()=>qn(),icon:Hg,text:"Paste",title:"Paste clipboard contents (Ctrl+V)",disabled:Ie||!nt},{type:"button",onClick:()=>bt(),icon:qd,text:"Remove",title:"Remove selected contents (Delete)",disabled:Ie||!fr}]},{type:"column",items:[{type:"label",text:"Table row:"},{type:"button",onClick:()=>Ye(),icon:ls,text:"Edit row",title:"Edit the current row",disabled:Ie||!nt||!Xe},{type:"button",onClick:()=>mr(),icon:Vg,text:"Duplicate row",title:"Duplicate the current row (Ctrl+D)",disabled:Ie||!nt||!Xe},{type:"button",onClick:()=>Wn(),icon:rs,text:"Insert before",title:"Insert a row before the current row",disabled:Ie||!nt||!Xe},{type:"button",onClick:()=>Zn(),icon:rs,text:"Insert after",title:"Insert a row after the current row",disabled:Ie||!nt||!Xe},{type:"button",onClick:()=>jn(),icon:qd,text:"Remove row",title:"Remove current row",disabled:Ie||!nt||!Xe}]}]}]}({json:o(q),documentState:o(xe),selection:o(N),readOnly:f(),onEditValue:Ir,onEditRow:Er,onToggleEnforceString:Vn,onCut:tt,onCopy:et,onPaste:je,onRemove:yn,onDuplicateRow:Sn,onInsertBeforeRow:mt,onInsertAfterRow:Ut,onRemoveRow:dt}),It=(oe=$e()(tn))!==null&&oe!==void 0?oe:tn;if(It!==!1){var Bn={left:ke,top:Pe,offsetTop:ct,offsetLeft:Qt,width:Be,height:He,anchor:ve,closeOnOuterClick:!0,onClose:()=>{Tt=!1,gt()}};Tt=!0;var S=s(Kw,{tip:cn?"Tip: you can open this context menu via right-click or with Ctrl+Q":void 0,items:It,onRequestClose(){l(S),gt()}},Bn)}}function yr(C){if(!vo(o(N)))if(C&&(C.stopPropagation(),C.preventDefault()),C&&C.type==="contextmenu"&&C.target!==o(ot))Or({left:C.clientX,top:C.clientY,width:wa,height:ya,showTip:!1});else{var oe,ve=(oe=o(me))===null||oe===void 0?void 0:oe.querySelector(".jse-table-cell.jse-selected-value");if(ve)Or({anchor:ve,offsetTop:2,width:wa,height:ya,showTip:!1});else{var ke,Pe=(ke=o(me))===null||ke===void 0?void 0:ke.getBoundingClientRect();Pe&&Or({top:Pe.top+2,left:Pe.left+2,width:wa,height:ya,showTip:!1})}}}function Sr(C){Or({anchor:rw(C.target,"BUTTON"),offsetTop:0,width:wa,height:ya,showTip:!0})}function Ir(){if(!f()&&o(N)){var C=Qe(o(N));Ar(Ke(o(q),C))?B(C):p(N,rn(C))}}function Er(){!f()&&o(N)&&B(Qe(o(N)).slice(0,1))}function Vn(){if(!f()&&zn(o(N))){var C=o(N).path,oe=zt(C),ve=Ke(o(q),C),ke=!Oa(o(q),o(xe),C),Pe=ke?String(ve):Js(String(ve),k());i("handleToggleEnforceString",{enforceString:ke,value:ve,updatedValue:Pe}),wt([{op:"replace",path:oe,value:Pe}],(Be,He)=>({state:Hc(o(q),He,C,{type:"value",enforceString:ke})}))}}function Jn(){return gr.apply(this,arguments)}function gr(){return(gr=Rt(function*(){if(i("apply pasted json",o(_e)),o(_e)){var{onPasteAsJson:C}=o(_e);C(),setTimeout(gt)}})).apply(this,arguments)}function je(){return an.apply(this,arguments)}function an(){return(an=Rt(function*(){try{Fn(yield navigator.clipboard.readText())}catch(C){console.error(C),p(qt,!0)}})).apply(this,arguments)}function Q(){i("clear pasted json"),p(_e,void 0),gt()}function Te(){Z()(Lr.text)}function tt(C){return Nt.apply(this,arguments)}function Nt(){return(Nt=Rt(function*(C){yield Bw({json:o(q),selection:o(N),indentation:C?A():void 0,readOnly:f(),parser:k(),onPatch:wt})})).apply(this,arguments)}function et(){return Bt.apply(this,arguments)}function Bt(){return Bt=Rt(function*(){var C=!(arguments.length>0&&arguments[0]!==void 0)||arguments[0];o(q)!==void 0&&(yield Ww({json:o(q),selection:o(N),indentation:C?A():void 0,parser:k()}))}),Bt.apply(this,arguments)}function yn(){Vw({json:o(q),text:o(ae),selection:o(N),keepSelection:!0,readOnly:f(),onChange:J(),onPatch:wt})}function Lt(C){f()||(i("extract",{path:C}),wt(mw(o(q),rn(C))))}function Sn(){(function(C){var{json:oe,selection:ve,columns:ke,readOnly:Pe,onPatch:Be}=C;if(!Pe&&oe!==void 0&&ve&&as(ve)){var{rowIndex:He,columnIndex:ct}=So(Qe(ve),ke);Zr("duplicate row",{rowIndex:He});var Qt=[String(He)];Be(gw(oe,[Qt]),(cn,tn)=>({state:tn,selection:rn(hi({rowIndex:He<oe.length?He+1:He,columnIndex:ct},ke))}))}})({json:o(q),selection:o(N),columns:o(Me),readOnly:f(),onPatch:wt})}function mt(){(function(C){var{json:oe,selection:ve,columns:ke,readOnly:Pe,onPatch:Be}=C;if(!Pe&&oe!==void 0&&ve&&as(ve)){var{rowIndex:He}=So(Qe(ve),ke);Zr("insert before row",{rowIndex:He}),Be(is(oe,[String(He)],[{key:"",value:$r(oe[0])?{}:""}]))}})({json:o(q),selection:o(N),columns:o(Me),readOnly:f(),onPatch:wt})}function Ut(){(function(C){var{json:oe,selection:ve,columns:ke,readOnly:Pe,onPatch:Be}=C;if(!Pe&&oe!==void 0&&ve&&as(ve)){var{rowIndex:He,columnIndex:ct}=So(Qe(ve),ke);Zr("insert after row",{rowIndex:He});var Qt=He+1,cn=[String(Qt)],tn=[{key:"",value:$r(oe[0])?{}:""}];Be(Qt<oe.length?is(oe,cn,tn):jv(oe,[],tn),(It,Bn)=>({state:Bn,selection:rn(hi({rowIndex:Qt,columnIndex:ct},ke))}))}})({json:o(q),selection:o(N),columns:o(Me),readOnly:f(),onPatch:wt})}function dt(){(function(C){var{json:oe,selection:ve,columns:ke,readOnly:Pe,onPatch:Be}=C;if(!Pe&&oe!==void 0&&ve&&as(ve)){var{rowIndex:He,columnIndex:ct}=So(Qe(ve),ke);Zr("remove row",{rowIndex:He}),Be(Xu([[String(He)]]),(Qt,cn)=>{var tn=He<Qt.length?He:He>0?He-1:void 0,It=tn!==void 0?rn(hi({rowIndex:tn,columnIndex:ct},ke)):void 0;return Zr("remove row new selection",{rowIndex:He,newRowIndex:tn,newSelection:It}),{state:cn,selection:It}})}})({json:o(q),selection:o(N),columns:o(Me),readOnly:f(),onPatch:wt})}function kt(){return(kt=Rt(function*(C){yield Jw({char:C,selectInside:!1,json:o(q),selection:o(N),readOnly:f(),parser:k(),onPatch:wt,onReplaceJson:Xt,onSelect:te})})).apply(this,arguments)}function Un(C){var oe;C.preventDefault(),Fn((oe=C.clipboardData)===null||oe===void 0?void 0:oe.getData("text/plain"))}function Fn(C){C!==void 0&&Hw({clipboardText:C,json:o(q),selection:o(N),readOnly:f(),parser:k(),onPatch:wt,onChangeText:Wt,openRepairModal:ie})}function Xt(C,oe){var ve={json:o(q),text:o(ae)},ke={json:o(q),documentState:o(xe),selection:o(N),sortedColumn:o(Fe),text:o(ae),textIsRepaired:o(Ge)},Pe=ho(C,o(xe)),Be=typeof oe=="function"?oe(C,Pe,o(N)):void 0;p(q,Be?.json!==void 0?Be.json:C),p(xe,Be?.state!==void 0?Be.state:Pe),p(N,Be?.selection!==void 0?Be.selection:o(N)),p(Fe,void 0),p(ae,void 0),p(Ge,!1),p($,void 0),fe(o(q)),vt(ke),hn(ve,void 0)}function Wt(C,oe){i("handleChangeText");var ve={json:o(q),text:o(ae)},ke={json:o(q),documentState:o(xe),selection:o(N),sortedColumn:o(Fe),text:o(ae),textIsRepaired:o(Ge)};try{p(q,D()(C)),p(xe,ho(o(q),o(xe))),p(ae,void 0),p(Ge,!1),p($,void 0)}catch(Be){try{p(q,D()(Wo(C))),p(xe,ho(o(q),o(xe))),p(ae,C),p(Ge,!0),p($,void 0)}catch{p(q,void 0),p(xe,void 0),p(ae,C),p(Ge,!1),p($,o(ae)!==""?ys(o(ae),Be.message||String(Be)):void 0)}}if(typeof oe=="function"){var Pe=oe(o(q),o(xe),o(N));p(q,Pe?.json!==void 0?Pe.json:o(q)),p(xe,Pe?.state!==void 0?Pe.state:o(xe)),p(N,Pe?.selection!==void 0?Pe.selection:o(N))}fe(o(q)),vt(ke),hn(ve,void 0)}function Gt(C){i("select validation error",C),p(N,rn(C.path)),Yt(C.path)}function or(C){if(o(q)!==void 0){var{id:oe,onTransform:ve,onClose:ke}=C,Pe=C.rootPath||[];Tt=!0,Re()({id:oe||c,json:o(q),rootPath:Pe||[],onTransform:Be=>{ve?ve({operations:Be,json:o(q),transformedJson:$o(o(q),Be)}):(i("onTransform",Pe,Be),wt(Be))},onClose:()=>{Tt=!1,setTimeout(gt),ke&&ke()}})}}function B(C){i("openJSONEditorModal",{path:C}),Tt=!0,We()({content:{json:Ke(o(q),C)},path:C,onPatch:wt,onClose:()=>{Tt=!1,setTimeout(gt)}})}function ie(C,oe){p(Ot,{text:C,onParse:ve=>Fc(ve,ke=>eu(ke,k())),onRepair:Gy,onApply:oe,onClose:gt})}function Oe(){(function(C){f()||o(q)===void 0||(Tt=!0,ze()({id:d,json:o(q),rootPath:C,onSort:oe=>{var{operations:ve,itemPath:ke,direction:Pe}=oe;i("onSort",ve,C,ke,Pe),wt(ve,(Be,He)=>({state:He,sortedColumn:{path:ke,sortDirection:Pe===-1?Lo.desc:Lo.asc}}))},onClose:()=>{Tt=!1,setTimeout(gt)}}))})([])}function Dt(){or({rootPath:[]})}function bn(C){i("openFind",{findAndReplace:C}),p(Ue,!1),p(X,!1),pr(),p(Ue,!0),p(X,C)}function un(){if(!f()&&b().canUndo){var C=b().undo();if(Gu(C)){var oe={json:o(q),text:o(ae)};p(q,C.undo.patch?$o(o(q),C.undo.patch):C.undo.json),p(xe,C.undo.documentState),p(N,C.undo.selection),p(Fe,C.undo.sortedColumn),p(ae,C.undo.text),p(Ge,C.undo.textIsRepaired),p($,void 0),i("undo",{item:C,json:o(q)}),hn(oe,C.undo.patch&&C.redo.patch?{json:o(q),previousJson:oe.json,redo:C.undo.patch,undo:C.redo.patch}:void 0),gt(),o(N)&&Yt(Qe(o(N)),{scrollToWhenVisible:!1})}else le()(C)}}function Rn(){if(!f()&&b().canRedo){var C=b().redo();if(Gu(C)){var oe={json:o(q),text:o(ae)};p(q,C.redo.patch?$o(o(q),C.redo.patch):C.redo.json),p(xe,C.redo.documentState),p(N,C.redo.selection),p(Fe,C.redo.sortedColumn),p(ae,C.redo.text),p(Ge,C.redo.textIsRepaired),p($,void 0),i("redo",{item:C,json:o(q)}),hn(oe,C.undo.patch&&C.redo.patch?{json:o(q),previousJson:oe.json,redo:C.redo.patch,undo:C.undo.patch}:void 0),gt(),o(N)&&Yt(Qe(o(N)),{scrollToWhenVisible:!1})}else Ae()(C)}}function Xn(C){p(_,C.getBoundingClientRect().height)}W(()=>(M(O()),M(T())),()=>{p(he,Qf({escapeControlCharacters:O(),escapeUnicodeCharacters:T()}))}),W(()=>o(Ue),()=>{(function(C){if(o(me)){var oe=C?hl:-100;o(me).scrollTo({top:go(me,o(me).scrollTop+=oe),left:o(me).scrollLeft})}})(o(Ue))}),W(()=>M(g()),()=>{(function(C){var oe={json:o(q)},ve=Cl(C)?C.text!==o(ae):!Zt(oe.json,C.json);if(i("update external content",{isChanged:ve}),ve){var ke={json:o(q),documentState:o(xe),selection:o(N),sortedColumn:o(Fe),text:o(ae),textIsRepaired:o(Ge)};if(Cl(C))try{p(q,D()(C.text)),p(xe,ho(o(q),o(xe))),p(ae,C.text),p(Ge,!1),p($,void 0)}catch(Pe){try{p(q,D()(Wo(C.text))),p(xe,ho(o(q),o(xe))),p(ae,C.text),p(Ge,!0),p($,void 0)}catch{p(q,void 0),p(xe,void 0),p(ae,C.text),p(Ge,!1),p($,o(ae)!==""?ys(o(ae),Pe.message||String(Pe)):void 0)}}else p(q,C.json),p(xe,ho(o(q),o(xe))),p(ae,void 0),p(Ge,!1),p($,void 0);fe(o(q)),p(Fe,void 0),vt(ke)}})(g())}),W(()=>M(m()),()=>{(function(C){Zt(o(N),C)||(i("applyExternalSelection",{selection:o(N),externalSelection:C}),zl(C)&&p(N,C))})(m())}),W(()=>(o(Me),o(q),M(R()),o(st)),()=>{p(Me,zr(o(q))?function(C,oe){var ve=new Set(oe.map(zt)),ke=new Set(C.map(zt));for(var Pe of ve)ke.has(Pe)||ve.delete(Pe);for(var Be of ke)ve.has(Be)||ve.add(Be);return[...ve].map(Fo)}(tP(o(q),R(),o(st)),o(Me)):[])}),W(()=>(o(q),o(Me)),()=>{p(at,!(!o(q)||Pn(o(Me))))}),W(()=>(o(q),o(st)),()=>{p(n,Array.isArray(o(q))&&o(q).length>o(st))}),W(()=>(o(E),o(_),o(q),o(Ue),hl),()=>{p(r,nP(o(E),o(_),o(q),x,U,o(Ue)?hl:0))}),W(()=>o(q),()=>{o(q),o(me)&&o(me).scrollTo({top:o(me).scrollTop,left:o(me).scrollLeft})}),W(()=>o(N),()=>{var C;C=o(N),Zt(C,m())||(i("onSelect",C),Y()(C))}),W(()=>(M(f()),M(j()),M(k()),o(he),o(q),o(xe),M(ce())),()=>{p(pe,{mode:Lr.table,readOnly:f(),truncateTextSize:j(),parser:k(),normalization:o(he),getJson:()=>o(q),getDocumentState:()=>o(xe),findElement:An,findNextInside:Jt,focus:gt,onPatch:(C,oe)=>wt(function(ve,ke){return ve.flatMap(Pe=>{if(ic(Pe)){var Be=Fo(Pe.path);if(Be.length>0){for(var He=[Pe],ct=sn(Be);ct.length>0&&!ja(ke,ct);)He.unshift({op:"add",path:zt(ct),value:{}}),ct=sn(ct);return He}}return Pe})}(C,o(q)),oe),onSelect:te,onFind:bn,onPasteJson:en,onRenderValue:ce()})}),W(()=>(o(q),M(H()),M(k()),M(V())),()=>{fn(o(q),H(),k(),V())}),W(()=>(o(Vt),o(Me)),()=>{p(a,rP(o(Vt),o(Me)))}),_n(),St(!0);var Gn=OT();be("mousedown",Sa,function(C){!Gs(C.target,oe=>oe===o(ue))&&vo(o(N))&&(i("click outside the editor, exit edit mode"),p(N,aa(o(N))),Je&&o(ot)&&(o(ot).focus(),o(ot).blur()),i("blur (outside editor)"),o(ot)&&o(ot).blur())});var ar,At=ft(Gn),Qn=z(At),xt=C=>{(function(oe,ve){lt(ve,!1);var ke=h(ve,"containsValidArray",9),Pe=h(ve,"readOnly",9),Be=h(ve,"showSearch",13,!1),He=h(ve,"history",9),ct=h(ve,"onSort",9),Qt=h(ve,"onTransform",9),cn=h(ve,"onContextMenu",9),tn=h(ve,"onUndo",9),It=h(ve,"onRedo",9),Bn=h(ve,"onRenderMenu",9);function S(){Be(!Be())}var K=P(void 0,!0),ge=P(void 0,!0);W(()=>(M(Pe()),M(ct()),M(ke()),M(Qt()),M(cn()),M(tn()),M(He()),M(It())),()=>{p(K,Pe()?[{type:"space"}]:[{type:"button",icon:Mu,title:"Sort",className:"jse-sort",onClick:ct(),disabled:Pe()||!ke()},{type:"button",icon:zu,title:"Transform contents (filter, sort, project)",className:"jse-transform",onClick:Qt(),disabled:Pe()||!ke()},{type:"button",icon:fc,title:"Search (Ctrl+F)",className:"jse-search",onClick:S,disabled:!ke()},{type:"button",icon:Jg,title:rp,className:"jse-contextmenu",onClick:cn()},{type:"separator"},{type:"button",icon:Zv,title:"Undo (Ctrl+Z)",className:"jse-undo",onClick:tn(),disabled:!He().canUndo},{type:"button",icon:ef,title:"Redo (Ctrl+Shift+Z)",className:"jse-redo",onClick:It(),disabled:!He().canRedo},{type:"space"}])}),W(()=>(M(Bn()),o(K)),()=>{p(ge,Bn()(o(K))||o(K))}),_n(),St(!0),Xc(oe,{get items(){return o(ge)}}),ut()})(C,{get containsValidArray(){return o(at)},get readOnly(){return f()},get history(){return b()},onSort:Oe,onTransform:Dt,onUndo:un,onRedo:Rn,onContextMenu:Sr,get onRenderMenu(){return we()},get showSearch(){return o(Ue)},set showSearch(oe){p(Ue,oe)},$$legacy:!0})};re(Qn,C=>{w()&&C(xt)});var Nr=F(Qn,2),qe=C=>{var oe=ST(),ve=ft(oe),ke=z(ve);ke.readOnly=!0,tr(ke,ct=>p(ot,ct),()=>o(ot));var Pe=F(ve,2),Be=ct=>{var Qt=kT(),cn=ft(Qt);qw(z(cn),{get json(){return o(q)},get documentState(){return o(xe)},get parser(){return k()},get showSearch(){return o(Ue)},get showReplace(){return o(X)},get readOnly(){return f()},get columns(){return o(Me)},onSearch:L,onFocus:yt,onPatch:wt,onClose:Ce});var tn=F(cn,2),It=z(tn),Bn=z(It),S=z(Bn),K=z(S),ge=z(K),Ve=nt=>{var wn=xr(),fr=de(()=>{var Mn;return Nd([],(Mn=o(a))===null||Mn===void 0?void 0:Mn.root)}),kr=ft(wn),Tn=Mn=>{var Ht=hT();hs(z(Ht),{get validationError(){return o(fr)},onExpand:Co}),I(Mn,Ht)};re(kr,Mn=>{o(fr)&&Mn(Tn)}),I(nt,wn)};re(ge,nt=>{var wn;Pn((wn=o(a))===null||wn===void 0?void 0:wn.root)||nt(Ve)});var De=F(K);jr(De,1,()=>o(Me),Cr,(nt,wn)=>{var fr=gT();(function(kr,Tn){lt(Tn,!1);var Mn=P(void 0,!0),Ht=P(void 0,!0),Rr=P(void 0,!0),Jr=h(Tn,"path",9),Io=h(Tn,"sortedColumn",9),na=h(Tn,"readOnly",9),No=h(Tn,"onSort",9);W(()=>(M(Jr()),qo),()=>{p(Mn,Pn(Jr())?"values":qo(Jr()))}),W(()=>(M(Io()),M(Jr())),()=>{var ir;p(Ht,Io()&&Zt(Jr(),(ir=Io())===null||ir===void 0?void 0:ir.path)?Io().sortDirection:void 0)}),W(()=>(o(Ht),Th),()=>{p(Rr,o(Ht)?Th[o(Ht)]:void 0)}),_n(),St(!0);var Hr,no=oT(),ga=z(no),Fi=z(ga),ko=F(ga,2),Mr=ir=>{var Ur=rT(),ma=z(Ur),lo=de(()=>o(Ht)===Lo.asc?ti:hk);dn(ma,{get data(){return o(lo)}}),Ee(()=>Cn(Ur,"title","Currently sorted in ".concat(o(Rr)," order"))),I(ir,Ur)};re(ko,ir=>{o(Ht)!==void 0&&ir(Mr)}),Ee((ir,Ur)=>{Hr=Mt(no,1,"jse-column-header svelte-2i3vdx",null,Hr,ir),Cn(no,"title",na()?o(Mn):o(Mn)+" (Click to sort the data by this column)"),pt(Fi,Ur)},[()=>({"jse-readonly":na()}),()=>El(o(Mn),50)],de),be("click",no,function(){na()||No()({path:Jr(),sortDirection:o(Ht)===Lo.asc?Lo.desc:Lo.asc})}),I(kr,no),ut()})(z(fr),{get path(){return o(wn)},get sortedColumn(){return o(Fe)},get readOnly(){return f()},onSort:Et}),I(nt,fr)});var Ie=F(De),Le=nt=>{var wn=mT(),fr=z(wn),kr=de(()=>Array.isArray(o(q))?o(q).length:0);(function(Tn,Mn){lt(Mn,!1);var Ht=h(Mn,"count",9),Rr=h(Mn,"maxSampleCount",9),Jr=h(Mn,"readOnly",9),Io=h(Mn,"onRefresh",9);St(!0);var na,No=pT();dn(z(No),{data:gk}),Ee(Hr=>{na=Mt(No,1,"jse-column-header svelte-fzj761",null,na,Hr),Cn(No,"title","The Columns are created by sampling ".concat(Rr()," items out of ").concat(Ht(),". ")+"If you're missing a column, click here to sample all of the items instead of a subset. This is slower.")},[()=>({"jse-readonly":Jr()})],de),be("click",No,()=>Io()()),I(Tn,No),ut()})(fr,{get count(){return o(kr)},get maxSampleCount(){return o(st)},get readOnly(){return f()},onRefresh:()=>p(st,1/0)}),I(nt,wn)};re(Ie,nt=>{o(n)&&nt(Le)});var Ye,Pt,pn=F(S),nn=z(pn),qn=F(pn);jr(qn,1,()=>o(r).visibleItems,Cr,(nt,wn,fr)=>{var kr=wT(),Tn=de(()=>o(r).startIndex+fr),Mn=de(()=>o(a).rows[o(Tn)]),Ht=de(()=>{var Hr;return Nd([String(o(Tn))],(Hr=o(Mn))===null||Hr===void 0?void 0:Hr.row)}),Rr=de(()=>yi(o(q),o(ne),[String(o(Tn))])),Jr=z(kr);Ny(Jr,()=>o(Tn),Hr=>{var no=bT(),ga=z(no),Fi=F(ga),ko=Mr=>{hs(Mr,{get validationError(){return o(Ht)},onExpand:Co})};re(Fi,Mr=>{o(Ht)&&Mr(ko)}),eo(no,(Mr,ir)=>xu?.(Mr,ir),()=>Mr=>function(ir,Ur){x[Ur]=ir.getBoundingClientRect().height}(Mr,o(Tn))),Ee(()=>{var Mr;return pt(ga,"".concat((Mr=o(Tn))!==null&&Mr!==void 0?Mr:""," "))}),I(Hr,no)});var Io=F(Jr);jr(Io,1,()=>o(Me),Cr,(Hr,no,ga,Fi)=>{var ko,Mr=jT(),ir=de(()=>[String(o(Tn))].concat(o(no))),Ur=de(()=>Ke(o(wn),o(no))),ma=de(()=>zn(o(N))&&Ta(o(N).path,o(ir))),lo=de(()=>{var er;return(er=o(Mn))===null||er===void 0?void 0:er.columns[ga]}),Ys=de(()=>Nd(o(ir),o(lo))),Xs=z(Mr),Bi=z(Xs),Qc=er=>{var Xr=de(()=>wv(yi(o(wn),o(Rr),o(no)))),el=de(()=>!!o(Xr)&&o(Xr).some(pi=>pi.active)),tl=de(()=>!Pn(o(Xr)));(function(pi,uo){lt(uo,!1);var nd=h(uo,"path",9),Wi=h(uo,"value",9),nl=h(uo,"parser",9),Zw=h(uo,"isSelected",9),e1=h(uo,"containsSearchResult",9),t1=h(uo,"containsActiveSearchResult",9),n1=h(uo,"onEdit",9);St(!0);var wp,au=nT(),r1=z(au);Ee((rl,o1)=>{wp=Mt(au,1,"jse-inline-value svelte-h57m0p",null,wp,rl),pt(r1,o1)},[()=>({"jse-selected":Zw(),"jse-highlight":e1(),"jse-active":t1()}),()=>{var rl;return El((rl=nl().stringify(Wi()))!==null&&rl!==void 0?rl:"",50)}],de),be("dblclick",au,()=>n1()(nd())),I(pi,au),ut()})(er,{get path(){return o(ir)},get value(){return o(Ur)},get parser(){return k()},get isSelected(){return o(ma)},get containsSearchResult(){return o(tl)},get containsActiveSearchResult(){return o(el)},onEdit:B})},Qs=er=>{var Xr=de(()=>{var uo;return(uo=yi(o(q),o(ne),o(ir)))===null||uo===void 0?void 0:uo.searchResults}),el=de(()=>o(Ur)!==void 0?o(Ur):""),tl=de(()=>Oa(o(q),o(xe),o(ir))),pi=de(()=>o(ma)?o(N):void 0);Uw(er,{get path(){return o(ir)},get value(){return o(el)},get enforceString(){return o(tl)},get selection(){return o(pi)},get searchResultItems(){return o(Xr)},get context(){return o(pe)}})};re(Bi,er=>{Ar(o(Ur))?er(Qc):er(Qs,!1)});var Zs=F(Bi),Zc=er=>{var Xr=xT();Wa(z(Xr),{selected:!0,onContextMenu:Or}),I(er,Xr)};re(Zs,er=>{f()||!o(ma)||vo(o(N))||er(Zc)});var ed=F(Xs,2),td=er=>{hs(er,{get validationError(){return o(Ys)},onExpand:Co})};re(ed,er=>{o(Ys)&&er(td)}),Ee((er,Xr)=>{Cn(Mr,"data-path",er),ko=Mt(Xs,1,"jse-value-outer svelte-u14cgx",null,ko,Xr)},[()=>pv(o(ir)),()=>({"jse-selected-value":o(ma)})],de),I(Hr,Mr)});var na=F(Io),No=Hr=>{I(Hr,yT())};re(na,Hr=>{o(n)&&Hr(No)}),I(nt,kr)});var bt,mr=z(F(qn));tr(tn,nt=>p(me,nt),()=>o(me)),eo(tn,(nt,wn)=>xu?.(nt,wn),()=>Xn),qr(()=>be("scroll",tn,on));var Wn=F(tn,2),Zn=nt=>{var wn=de(()=>"You pasted a JSON ".concat(Array.isArray(o(_e).contents)?"array":"object"," as text"));Yo(nt,{type:"info",get message(){return o(wn)},actions:[{icon:bs,text:"Paste as JSON instead",title:"Paste the text as JSON instead of a single value",onMouseDown:Jn},{text:"Leave as is",title:"Keep the pasted content as a single value",onClick:Q}]})};re(Wn,nt=>{o(_e)&&nt(Zn)});var jn=F(Wn,2),Xe=nt=>{var wn=de(()=>f()?[]:[{icon:tf,text:"Ok",title:"Accept the repaired document",onClick:Ft},{icon:Pu,text:"Repair manually instead",title:"Leave the document unchanged and repair it manually instead",onClick:Te}]);Yo(nt,{type:"success",message:"The loaded JSON document was invalid but is successfully repaired.",get actions(){return o(wn)},onClose:gt})};re(jn,nt=>{o(Ge)&&nt(Xe)}),xp(F(jn,2),{get validationErrors(){return o(Vt)},selectError:Gt}),Ee(nt=>{Ye=Mt(pn,1,"jse-table-invisible-start-section svelte-u14cgx",null,Ye,nt),Cn(nn,"colspan",o(Me).length),Pt=Ho(nn,"",Pt,{height:o(r).startHeight+"px"}),Cn(mr,"colspan",o(Me).length),bt=Ho(mr,"",bt,{height:o(r).endHeight+"px"})},[()=>({"jse-search-box-background":o(Ue)})],de),I(ct,Qt)},He=(ct,Qt)=>{var cn=It=>{var Bn=_T(),S=ft(Bn),K=de(()=>f()?[]:[{icon:Pu,text:"Repair manually",title:'Open the document in "code" mode and repair it manually',onClick:Te}]);Yo(S,{type:"error",message:"The loaded JSON document is invalid and could not be repaired automatically.",get actions(){return o(K)}}),Gw(F(S,2),{get text(){return o(ae)},get json(){return o(q)},get indentation(){return A()},get parser(){return k()}}),I(It,Bn)},tn=It=>{fT(It,{get text(){return o(ae)},get json(){return o(q)},get readOnly(){return f()},get parser(){return k()},openJSONEditorModal:B,extractPath:Lt,get onChangeMode(){return Z()},onClick:()=>{gt()}})};re(ct,It=>{o($)&&o(ae)!==void 0&&o(ae)!==""?It(cn):It(tn,!1)},Qt)};re(Pe,ct=>{o(at)?ct(Be):ct(He,!1)}),be("paste",ke,Un),I(C,oe)},gn=C=>{I(C,CT())};re(Nr,C=>{v?C(gn,!1):C(qe)}),tr(At,C=>p(ue,C),()=>o(ue));var Dn=F(At,2),xn=C=>{Nw(C,{onClose:()=>p(qt,!1)})};re(Dn,C=>{o(qt)&&C(xn)});var wr=F(Dn,2),to=C=>{Lw(C,Xa(()=>o(Ot),{onClose:()=>{var oe;(oe=o(Ot))===null||oe===void 0||oe.onClose(),p(Ot,void 0)}}))};return re(wr,C=>{o(Ot)&&C(to)}),Ee(C=>ar=Mt(At,1,"jse-table-mode svelte-u14cgx",null,ar,C),[()=>({"no-main-menu":!w()})],de),be("mousedown",At,function(C){if(C.buttons===1||C.buttons===2){var oe=C.target;oe.isContentEditable||gt();var ve=ow(oe);if(ve){if(vo(o(N))&&Pl(o(q),o(N),ve))return;p(N,rn(ve)),C.preventDefault()}}}),be("keydown",At,function(C){var oe=Pa(C);if(i("keydown",{combo:oe,key:C.key}),oe==="Ctrl+X"&&(C.preventDefault(),tt(!0)),oe==="Ctrl+Shift+X"&&(C.preventDefault(),tt(!1)),oe==="Ctrl+C"&&(C.preventDefault(),et(!0)),oe==="Ctrl+Shift+C"&&(C.preventDefault(),et(!1)),oe==="Ctrl+D"&&(C.preventDefault(),Sn()),oe!=="Delete"&&oe!=="Backspace"||(C.preventDefault(),yn()),oe==="Insert"&&C.preventDefault(),oe==="Ctrl+A"&&C.preventDefault(),oe==="Ctrl+Q"&&yr(C),oe==="ArrowLeft"&&(C.preventDefault(),it(),o(N))){var ve=function(Qt,cn){var{rowIndex:tn,columnIndex:It}=So(Qe(cn),Qt);return It>0?rn(hi({rowIndex:tn,columnIndex:It-1},Qt)):cn}(o(Me),o(N));p(N,ve),vr(Qe(ve))}if(oe==="ArrowRight"&&(C.preventDefault(),it(),o(N))){var ke=function(Qt,cn){var{rowIndex:tn,columnIndex:It}=So(Qe(cn),Qt);return It<Qt.length-1?rn(hi({rowIndex:tn,columnIndex:It+1},Qt)):cn}(o(Me),o(N));p(N,ke),vr(Qe(ke))}if(oe==="ArrowUp"&&(C.preventDefault(),it(),o(N))){var Pe=function(Qt,cn){var{rowIndex:tn,columnIndex:It}=So(Qe(cn),Qt);return tn>0?rn(hi({rowIndex:tn-1,columnIndex:It},Qt)):cn}(o(Me),o(N));p(N,Pe),vr(Qe(Pe))}if(oe==="ArrowDown"&&(C.preventDefault(),it(),o(N))){var Be=function(Qt,cn,tn){var{rowIndex:It,columnIndex:Bn}=So(Qe(tn),cn);return It<Qt.length-1?rn(hi({rowIndex:It+1,columnIndex:Bn},cn)):tn}(o(q),o(Me),o(N));p(N,Be),vr(Qe(Be))}if(oe==="Enter"&&o(N)&&zn(o(N))){C.preventDefault();var He=o(N).path;Ar(Ke(o(q),He))?B(He):f()||p(N,Se(Se({},o(N)),{},{edit:!0}))}if(oe.replace(/^Shift\+/,"").length===1&&o(N))return C.preventDefault(),void function(Qt){kt.apply(this,arguments)}(C.key);if(oe==="Ctrl+Enter"&&zn(o(N))){C.preventDefault();var ct=Ke(o(q),o(N).path);$c(ct)&&window.open(String(ct),"_blank")}oe==="Escape"&&o(N)&&(C.preventDefault(),p(N,void 0)),oe==="Ctrl+F"&&(C.preventDefault(),bn(!1)),oe==="Ctrl+H"&&(C.preventDefault(),bn(!0)),oe==="Ctrl+Z"&&(C.preventDefault(),un()),oe==="Ctrl+Shift+Z"&&(C.preventDefault(),Rn())}),be("contextmenu",At,yr),I(e,Gn),_t(t,"validate",$t),_t(t,"patch",Ln),_t(t,"focus",gt),_t(t,"acceptAutoRepair",Ft),_t(t,"scrollTo",Yt),_t(t,"findElement",An),_t(t,"openTransformModal",or),ut({validate:$t,patch:Ln,focus:gt,acceptAutoRepair:Ft,scrollTo:Yt,findElement:An,openTransformModal:or})}function fg(e,t){lt(t,!1);var n=h(t,"content",8),r=h(t,"selection",12),a=h(t,"readOnly",8),i=h(t,"indentation",8),s=h(t,"tabSize",8),l=h(t,"truncateTextSize",8),u=h(t,"externalMode",8),d=h(t,"mainMenuBar",8),c=h(t,"navigationBar",8),v=h(t,"statusBar",8),f=h(t,"askToFormat",8),g=h(t,"escapeControlCharacters",8),m=h(t,"escapeUnicodeCharacters",8),b=h(t,"flattenColumns",8),j=h(t,"parser",8),w=h(t,"parseMemoizeOne",8),O=h(t,"validator",8),T=h(t,"validationParser",8),R=h(t,"pathParser",8),k=h(t,"insideModal",8),D=h(t,"onChange",8),H=h(t,"onChangeMode",8),V=h(t,"onSelect",8),A=h(t,"onRenderValue",8),J=h(t,"onClassName",8),Z=h(t,"onRenderMenu",8),Y=h(t,"onRenderContextMenu",8),le=h(t,"onError",8),Ae=h(t,"onFocus",8),ce=h(t,"onBlur",8),we=h(t,"onSortModal",8),$e=h(t,"onTransformModal",8),Ne=h(t,"onJSONEditorModal",8),ye=P(),ze=P(),Re=P(),We=Fr("jsoneditor:JSONEditorRoot"),he=P(Qw({onChange:x=>p(he,x)}).get()),ue=P(u());function me(x){if(Uh(x)){p(ue,x.undo.mode);var _=o(he).items(),E=_.findIndex(te=>te===x),U=E!==-1?_[E-1]:void 0;We("handleUndo",{index:E,item:x,items:_,prevItem:U}),U&&r(U.redo.selection),H()(o(ue))}}function ot(x){if(Uh(x)){p(ue,x.redo.mode);var _=o(he).items(),E=_.findIndex(te=>te===x),U=E!==-1?_[E+1]:void 0;We("handleRedo",{index:E,item:x,items:_,nextItem:U}),U&&r(U.undo.selection),H()(o(ue))}}var Ot=P(),ee={type:"separator"},q=P(),ae=P();function $(x){if(o(ye))return o(ye).patch(x);if(o(ze))return o(ze).patch(x);if(o(Re))return o(Re).patch(x);throw new Error('Method patch is not available in mode "'.concat(o(ue),'"'))}function _e(x,_){if(o(ye))return o(ye).expand(x,_);throw new Error('Method expand is not available in mode "'.concat(o(ue),'"'))}function ne(x,_){if(o(ye))return o(ye).collapse(x,_);throw new Error('Method collapse is not available in mode "'.concat(o(ue),'"'))}function Ue(x){if(o(Re))o(Re).openTransformModal(x);else if(o(ye))o(ye).openTransformModal(x);else{if(!o(ze))throw new Error('Method transform is not available in mode "'.concat(o(ue),'"'));o(ze).openTransformModal(x)}}function X(){if(o(Re))return o(Re).validate();if(o(ye))return o(ye).validate();if(o(ze))return o(ze).validate();throw new Error('Method validate is not available in mode "'.concat(o(ue),'"'))}function L(){return o(ye)?o(ye).acceptAutoRepair():n()}function yt(x){if(o(ye))return o(ye).scrollTo(x);if(o(ze))return o(ze).scrollTo(x);throw new Error('Method scrollTo is not available in mode "'.concat(o(ue),'"'))}function Ze(x){if(o(ye))return o(ye).findElement(x);if(o(ze))return o(ze).findElement(x);throw new Error('Method findElement is not available in mode "'.concat(o(ue),'"'))}function Ce(){o(Re)?o(Re).focus():o(ye)?o(ye).focus():o(ze)&&o(ze).focus()}function st(){return Me.apply(this,arguments)}function Me(){return(Me=Rt(function*(){o(Re)&&(yield o(Re).refresh())})).apply(this,arguments)}W(()=>M(u()),()=>{(function(x){if(x!==o(ue)){var _={type:"mode",undo:{mode:o(ue),selection:void 0},redo:{mode:x,selection:void 0}};o(ue)==="text"&&o(Re)&&o(Re).flush(),We("add history item",_),o(he).add(_),p(ue,x)}})(u())}),W(()=>(o(ue),M(H())),()=>{p(Ot,[{type:"button",text:"text",title:"Switch to text mode (current mode: ".concat(o(ue),")"),className:"jse-group-button jse-first"+(o(ue)===Lr.text?" jse-selected":""),onClick:()=>H()(Lr.text)},{type:"button",text:"tree",title:"Switch to tree mode (current mode: ".concat(o(ue),")"),className:"jse-group-button "+(o(ue)===Lr.tree?" jse-selected":""),onClick:()=>H()(Lr.tree)},{type:"button",text:"table",title:"Switch to table mode (current mode: ".concat(o(ue),")"),className:"jse-group-button jse-last"+(o(ue)===Lr.table?" jse-selected":""),onClick:()=>H()(Lr.table)}])}),W(()=>(o(Ot),M(Z()),o(ue),M(k()),M(a())),()=>{p(q,x=>{var _=sw(x[0])?o(Ot).concat(x):o(Ot).concat(ee,x),E=xl(_);return Z()(_,{mode:o(ue),modal:k(),readOnly:a()})||E})}),W(()=>(M(Y()),o(ue),M(k()),M(a()),M(r())),()=>{p(ae,x=>{var _,E=xl(x);return(_=Y()(x,{mode:o(ue),modal:k(),readOnly:a(),selection:r()}))!==null&&_!==void 0?_:!a()&&E})}),_n(),St();var at=xr(),Tt=ft(at),Je=x=>{tr(tT(x,{get externalContent(){return n()},get externalSelection(){return r()},get history(){return o(he)},get readOnly(){return a()},get indentation(){return i()},get tabSize(){return s()},get mainMenuBar(){return d()},get statusBar(){return v()},get askToFormat(){return f()},get escapeUnicodeCharacters(){return m()},get parser(){return j()},get validator(){return O()},get validationParser(){return T()},get onChange(){return D()},get onChangeMode(){return H()},get onSelect(){return V()},onUndo:me,onRedo:ot,get onError(){return le()},get onFocus(){return Ae()},get onBlur(){return ce()},get onRenderMenu(){return o(q)},get onSortModal(){return we()},get onTransformModal(){return $e()},$$legacy:!0}),_=>p(Re,_),()=>o(Re))},qt=(x,_)=>{var E=te=>{tr(ET(te,{get externalContent(){return n()},get externalSelection(){return r()},get history(){return o(he)},get readOnly(){return a()},get truncateTextSize(){return l()},get mainMenuBar(){return d()},get escapeControlCharacters(){return g()},get escapeUnicodeCharacters(){return m()},get flattenColumns(){return b()},get parser(){return j()},get parseMemoizeOne(){return w()},get validator(){return O()},get validationParser(){return T()},get indentation(){return i()},get onChange(){return D()},get onChangeMode(){return H()},get onSelect(){return V()},onUndo:me,onRedo:ot,get onRenderValue(){return A()},get onFocus(){return Ae()},get onBlur(){return ce()},get onRenderMenu(){return o(q)},get onRenderContextMenu(){return o(ae)},get onSortModal(){return we()},get onTransformModal(){return $e()},get onJSONEditorModal(){return Ne()},$$legacy:!0}),fe=>p(ze,fe),()=>o(ze))},U=te=>{tr(Iv(te,{get externalContent(){return n()},get externalSelection(){return r()},get history(){return o(he)},get readOnly(){return a()},get indentation(){return i()},get truncateTextSize(){return l()},get mainMenuBar(){return d()},get navigationBar(){return c()},get escapeControlCharacters(){return g()},get escapeUnicodeCharacters(){return m()},get parser(){return j()},get parseMemoizeOne(){return w()},get validator(){return O()},get validationParser(){return T()},get pathParser(){return R()},get onError(){return le()},get onChange(){return D()},get onChangeMode(){return H()},get onSelect(){return V()},onUndo:me,onRedo:ot,get onRenderValue(){return A()},get onClassName(){return J()},get onFocus(){return Ae()},get onBlur(){return ce()},get onRenderMenu(){return o(q)},get onRenderContextMenu(){return o(ae)},get onSortModal(){return we()},get onTransformModal(){return $e()},get onJSONEditorModal(){return Ne()},$$legacy:!0}),fe=>p(ye,fe),()=>o(ye))};re(x,te=>{o(ue)===Lr.table?te(E):te(U,!1)},_)};return re(Tt,x=>{o(ue)===Lr.text||String(o(ue))==="code"?x(Je):x(qt,!1)}),I(e,at),_t(t,"patch",$),_t(t,"expand",_e),_t(t,"collapse",ne),_t(t,"transform",Ue),_t(t,"validate",X),_t(t,"acceptAutoRepair",L),_t(t,"scrollTo",yt),_t(t,"findElement",Ze),_t(t,"focus",Ce),_t(t,"refresh",st),ut({patch:$,expand:_e,collapse:ne,transform:Ue,validate:X,acceptAutoRepair:L,scrollTo:yt,findElement:Ze,focus:Ce,refresh:st})}jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-modal-wrapper.svelte-v0el4e {
  flex: 1;
  display: flex;
  min-width: 0;
  min-height: 0;
  flex-direction: column;
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 20px;
  overflow: auto;
  min-width: 0;
  min-height: 0;
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-actions:where(.svelte-v0el4e) {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding-top: var(--jse-padding, 10px);
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-actions:where(.svelte-v0el4e) button.jse-primary:where(.svelte-v0el4e) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-primary-background, var(--jse-theme-color, #3883fa));
  color: var(--jse-button-primary-color, #fff);
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-actions:where(.svelte-v0el4e) button.jse-primary:where(.svelte-v0el4e):hover {
  background: var(--jse-button-primary-background-highlight, var(--jse-theme-color-highlight, #5f9dff));
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-actions:where(.svelte-v0el4e) button.jse-primary:where(.svelte-v0el4e):disabled {
  background: var(--jse-button-primary-background-disabled, #9d9d9d);
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-label:where(.svelte-v0el4e) {
  font-weight: bold;
  display: block;
  box-sizing: border-box;
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-label:where(.svelte-v0el4e) .jse-label-inner:where(.svelte-v0el4e) {
  margin-top: calc(2 * var(--jse-padding, 10px));
  margin-bottom: calc(0.5 * var(--jse-padding, 10px));
  box-sizing: border-box;
}
.jse-modal-wrapper.svelte-v0el4e .jse-modal-contents:where(.svelte-v0el4e) .jse-modal-inline-editor:where(.svelte-v0el4e) {
  flex: 1;
  min-height: 150px;
  min-width: 0;
  max-width: 100%;
  display: flex;
  --jse-theme-color: var(--jse-modal-editor-theme-color, #707070);
  --jse-theme-color-highlight: var(--jse-modal-editor-theme-color-highlight, #646464);
}
.jse-modal-wrapper.svelte-v0el4e .jse-actions:where(.svelte-v0el4e) {
  gap: var(--jse-padding, 10px);
  align-items: center;
}
.jse-modal-wrapper.svelte-v0el4e .jse-actions:where(.svelte-v0el4e) .jse-error:where(.svelte-v0el4e) {
  flex: 1;
  color: var(--jse-error-color, #ee5341);
}
.jse-modal-wrapper.svelte-v0el4e .jse-actions:where(.svelte-v0el4e) button.jse-secondary:where(.svelte-v0el4e) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-secondary-background, #d3d3d3);
  color: var(--jse-button-secondary-color, var(--jse-text-color, #4d4d4d));
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-modal-wrapper.svelte-v0el4e .jse-actions:where(.svelte-v0el4e) button.jse-secondary:where(.svelte-v0el4e):hover {
  background: var(--jse-button-secondary-background-highlight, #e1e1e1);
}
.jse-modal-wrapper.svelte-v0el4e .jse-actions:where(.svelte-v0el4e) button.jse-secondary:where(.svelte-v0el4e):disabled {
  background: var(--jse-button-secondary-background-disabled, #9d9d9d);
}
.jse-modal-wrapper.svelte-v0el4e input:where(.svelte-v0el4e) {
  border: var(--jse-input-border, 1px solid #d8dbdf);
  outline: none;
  box-sizing: border-box;
  padding: calc(0.5 * var(--jse-padding, 10px));
  font-family: var(--jse-font-family-mono, consolas, menlo, monaco, "Ubuntu Mono", "source-code-pro", monospace);
  font-size: var(--jse-font-size-mono, 14px);
  color: inherit;
  background: var(--jse-input-background, var(--jse-background-color, #fff));
}
.jse-modal-wrapper.svelte-v0el4e input:where(.svelte-v0el4e):focus {
  border: var(--jse-input-border-focus, 1px solid var(--jse-input-border-focus, var(--jse-theme-color, #3883fa)));
}
.jse-modal-wrapper.svelte-v0el4e input:where(.svelte-v0el4e):read-only {
  background: var(--jse-input-background-readonly, transparent);
}`);var AT=G('<div class="jse-error svelte-v0el4e"> </div>'),RT=G('<button type="button" class="jse-secondary svelte-v0el4e"><!> Back</button>'),MT=G('<button type="button" class="jse-primary svelte-v0el4e">Apply</button>'),zT=G('<button type="button" class="jse-primary svelte-v0el4e">Close</button>'),PT=G('<!> <div class="jse-modal-contents svelte-v0el4e"><div class="jse-label svelte-v0el4e"><div class="jse-label-inner svelte-v0el4e">Path</div></div> <input class="jse-path svelte-v0el4e" type="text" readonly="" title="Selected path"> <div class="jse-label svelte-v0el4e"><div class="jse-label-inner svelte-v0el4e">Contents</div></div> <div class="jse-modal-inline-editor svelte-v0el4e"><!></div> <div class="jse-actions svelte-v0el4e"><!> <!> <!></div></div>',1),TT=G('<div class="jse-modal-wrapper svelte-v0el4e"><!></div>'),IT={};jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-modal-contents.svelte-1v9c92j {
  flex: 1;
  display: flex;
  flex-direction: column;
  padding: 20px;
  overflow: auto;
  min-width: 0;
  min-height: 0;
}
.jse-modal-contents.svelte-1v9c92j .jse-actions:where(.svelte-1v9c92j) {
  display: flex;
  flex-direction: row;
  justify-content: flex-end;
  padding-top: var(--jse-padding, 10px);
}
.jse-modal-contents.svelte-1v9c92j .jse-actions:where(.svelte-1v9c92j) button.jse-primary:where(.svelte-1v9c92j) {
  border: none;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  padding: 5px;
  margin: 0;
  background: var(--jse-button-primary-background, var(--jse-theme-color, #3883fa));
  color: var(--jse-button-primary-color, #fff);
  padding: var(--jse-padding, 10px) calc(2 * var(--jse-padding, 10px));
  border-radius: 3px;
}
.jse-modal-contents.svelte-1v9c92j .jse-actions:where(.svelte-1v9c92j) button.jse-primary:where(.svelte-1v9c92j):hover {
  background: var(--jse-button-primary-background-highlight, var(--jse-theme-color-highlight, #5f9dff));
}
.jse-modal-contents.svelte-1v9c92j .jse-actions:where(.svelte-1v9c92j) button.jse-primary:where(.svelte-1v9c92j):disabled {
  background: var(--jse-button-primary-background-disabled, #9d9d9d);
}
.jse-modal-contents.svelte-1v9c92j table:where(.svelte-1v9c92j) {
  width: 100%;
  border-collapse: collapse;
  border-spacing: 0;
}
.jse-modal-contents.svelte-1v9c92j table:where(.svelte-1v9c92j) th:where(.svelte-1v9c92j),
.jse-modal-contents.svelte-1v9c92j table:where(.svelte-1v9c92j) td:where(.svelte-1v9c92j) {
  text-align: left;
  vertical-align: middle;
  font-weight: normal;
  padding-bottom: var(--jse-padding, 10px);
}
.jse-modal-contents.svelte-1v9c92j input.jse-path:where(.svelte-1v9c92j) {
  width: 100%;
  box-sizing: border-box;
  padding: 5px 10px;
  border: var(--jse-input-border, 1px solid #d8dbdf);
  border-radius: var(--jse-input-radius, 3px);
  font-family: inherit;
  font-size: inherit;
  background: inherit;
  background: var(--jse-input-background-readonly, transparent);
  color: inherit;
  outline: none;
}
.jse-modal-contents.svelte-1v9c92j .svelte-select input {
  box-sizing: border-box;
}
.jse-modal-contents.svelte-1v9c92j .jse-space:where(.svelte-1v9c92j) {
  height: 200px;
}
.jse-modal-contents.svelte-1v9c92j .jse-space:where(.svelte-1v9c92j) .jse-error:where(.svelte-1v9c92j) {
  color: var(--jse-error-color, #ee5341);
}`);var Yi=qc(()=>IT),NT=G('<tr><th class="svelte-1v9c92j">Property</th><td class="svelte-1v9c92j"><!></td></tr>'),LT=G('<div class="jse-error svelte-1v9c92j"> </div>'),UT=G('<!> <div class="jse-modal-contents svelte-1v9c92j"><table class="svelte-1v9c92j"><colgroup><col width="25%"><col width="75%"></colgroup><tbody><tr><th class="svelte-1v9c92j">Path</th><td class="svelte-1v9c92j"><input class="jse-path svelte-1v9c92j" type="text" readonly="" title="Selected path"></td></tr><!><tr><th class="svelte-1v9c92j">Direction</th><td class="svelte-1v9c92j"><!></td></tr></tbody></table> <div class="jse-space svelte-1v9c92j"><!></div> <div class="jse-actions svelte-1v9c92j"><button type="button" class="jse-primary svelte-1v9c92j">Sort</button></div></div>',1);jt(`/* over all fonts, sizes, and colors */
/* "consolas" for Windows, "menlo" for Mac with fallback to "monaco", 'Ubuntu Mono' for Ubuntu */
/* (at Mac this font looks too large at 14px, but 13px is too small for the font on Windows) */
/* main, menu, modal */
/* jsoneditor modal */
/* tooltip in text mode */
/* panels: navigation bar, gutter, search box */
/* navigation-bar */
/* context menu */
/* contents: json key and values */
/* contents: selected or hovered */
/* contents: section of collapsed items in an array */
/* contents: highlighting of search matches */
/* contents: inline tags inside the JSON document */
/* contents: table */
/* controls in modals: inputs, buttons, and \`a\` */
/* messages */
/* svelte-select */
/* color picker */
.jse-main.svelte-57bmz4 {
  width: 100%;
  height: 100%;
  min-width: 0;
  min-height: 150px;
  font-family: var(--jse-font-family, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif);
  font-size: var(--jse-font-size, 16px);
  line-height: normal;
  position: relative;
  display: flex;
  flex-direction: row;
}
.jse-main.svelte-57bmz4:not(.jse-focus) {
  --jse-selection-background-color: var(--jse-selection-background-inactive-color, #e8e8e8);
  --jse-context-menu-pointer-background: var(--jse-context-menu-pointer-hover-background, #b2b2b2);
}`);var DT=G('<div role="none"><!></div> <!> <!> <!>',1);function qT(e,t){lt(t,!1);var n=P(void 0,!0),r=Fr("jsoneditor:JSONEditor"),a={text:""},i=void 0,s=!1,l=Lr.tree,u=!0,d=!0,c=!0,v=!0,f=!1,g=!1,m=!0,b=JSON,j=void 0,w=JSON,O={parse:UR,stringify:qo},T=[aw],R=T[0].id,k=Co,D=void 0,H=void 0,V=_v,A=Co,J=Co,Z=Co,Y=Co,le=je=>{console.error(je),alert(je.toString())},Ae=Co,ce=Co,we=h(t,"content",13,a),$e=h(t,"selection",13,i),Ne=h(t,"readOnly",13,s),ye=h(t,"indentation",13,2),ze=h(t,"tabSize",13,4),Re=h(t,"truncateTextSize",13,1e3),We=h(t,"mode",13,l),he=h(t,"mainMenuBar",13,u),ue=h(t,"navigationBar",13,d),me=h(t,"statusBar",13,c),ot=h(t,"askToFormat",13,v),Ot=h(t,"escapeControlCharacters",13,f),ee=h(t,"escapeUnicodeCharacters",13,g),q=h(t,"flattenColumns",13,m),ae=h(t,"parser",13,b),$=h(t,"validator",13,j),_e=h(t,"validationParser",13,w),ne=h(t,"pathParser",13,O),Ue=h(t,"queryLanguages",13,T),X=h(t,"queryLanguageId",13,R),L=h(t,"onChangeQueryLanguage",13,k),yt=h(t,"onChange",13,D),Ze=h(t,"onSelect",13,H),Ce=h(t,"onRenderValue",13,V),st=h(t,"onClassName",13,A),Me=h(t,"onRenderMenu",13,J),at=h(t,"onRenderContextMenu",13,Z),Tt=h(t,"onChangeMode",13,Y),Je=h(t,"onError",13,le),qt=h(t,"onFocus",13,Ae),x=h(t,"onBlur",13,ce),_=P(os(),!0),E=P(!1,!0),U=P(void 0,!0),te=P(void 0,!0),fe=P(void 0,!0),xe=P(void 0,!0),N=P(ae(),!0);function Fe(){return we()}function Ge(je){r("set");var an=bd(je);if(an)throw new Error(an);p(_,os()),we(je),pr()}function Et(je){r("update");var an=bd(je);if(an)throw new Error(an);we(je),pr()}function pe(je){var an=o(U).patch(je);return pr(),an}function vt(je){$e(je),pr()}function Vt(je,an){o(U).expand(je,an),pr()}function rr(je){var an=arguments.length>1&&arguments[1]!==void 0&&arguments[1];o(U).collapse(je,an),pr()}function fn(){var je=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};o(U).transform(je),pr()}function $t(){return o(U).validate()}function Ln(){var je=o(U).acceptAutoRepair();return pr(),je}function wt(je){return hn.apply(this,arguments)}function hn(){return(hn=Rt(function*(je){yield o(U).scrollTo(je)})).apply(this,arguments)}function en(je){return o(U).findElement(je)}function Jt(){o(U).focus(),pr()}function gt(){return on.apply(this,arguments)}function on(){return(on=Rt(function*(){yield o(U).refresh()})).apply(this,arguments)}function it(je){var an,Q,Te,tt,Nt,et,Bt,yn,Lt,Sn,mt,Ut,dt,kt,Un,Fn,Xt,Wt,Gt,or,B,ie,Oe,Dt,bn,un,Rn,Xn,Gn,ar,At,Qn=Object.keys(je);for(var xt of Qn)switch(xt){case"content":we((an=je[xt])!==null&&an!==void 0?an:a);break;case"selection":$e((Q=je[xt])!==null&&Q!==void 0?Q:i);break;case"readOnly":Ne((Te=je[xt])!==null&&Te!==void 0?Te:s);break;case"indentation":ye((tt=je[xt])!==null&&tt!==void 0?tt:2);break;case"tabSize":ze((Nt=je[xt])!==null&&Nt!==void 0?Nt:4);break;case"truncateTextSize":Re((et=je[xt])!==null&&et!==void 0?et:1e3);break;case"mode":We((Bt=je[xt])!==null&&Bt!==void 0?Bt:l);break;case"mainMenuBar":he((yn=je[xt])!==null&&yn!==void 0?yn:u);break;case"navigationBar":ue((Lt=je[xt])!==null&&Lt!==void 0?Lt:d);break;case"statusBar":me((Sn=je[xt])!==null&&Sn!==void 0?Sn:c);break;case"askToFormat":ot((mt=je[xt])!==null&&mt!==void 0?mt:v);break;case"escapeControlCharacters":Ot((Ut=je[xt])!==null&&Ut!==void 0?Ut:f);break;case"escapeUnicodeCharacters":ee((dt=je[xt])!==null&&dt!==void 0?dt:g);break;case"flattenColumns":q((kt=je[xt])!==null&&kt!==void 0?kt:m);break;case"parser":ae((Un=je[xt])!==null&&Un!==void 0?Un:b);break;case"validator":$((Fn=je[xt])!==null&&Fn!==void 0?Fn:j);break;case"validationParser":_e((Xt=je[xt])!==null&&Xt!==void 0?Xt:w);break;case"pathParser":ne((Wt=je[xt])!==null&&Wt!==void 0?Wt:O);break;case"queryLanguages":Ue((Gt=je[xt])!==null&&Gt!==void 0?Gt:T);break;case"queryLanguageId":X((or=je[xt])!==null&&or!==void 0?or:R);break;case"onChangeQueryLanguage":L((B=je[xt])!==null&&B!==void 0?B:k);break;case"onChange":yt((ie=je[xt])!==null&&ie!==void 0?ie:D);break;case"onRenderValue":Ce((Oe=je[xt])!==null&&Oe!==void 0?Oe:V);break;case"onClassName":st((Dt=je[xt])!==null&&Dt!==void 0?Dt:A);break;case"onRenderMenu":Me((bn=je[xt])!==null&&bn!==void 0?bn:J);break;case"onRenderContextMenu":at((un=je[xt])!==null&&un!==void 0?un:Z);break;case"onChangeMode":Tt((Rn=je[xt])!==null&&Rn!==void 0?Rn:Y);break;case"onSelect":Ze((Xn=je[xt])!==null&&Xn!==void 0?Xn:H);break;case"onError":Je((Gn=je[xt])!==null&&Gn!==void 0?Gn:le);break;case"onFocus":qt((ar=je[xt])!==null&&ar!==void 0?ar:Ae);break;case"onBlur":x((At=je[xt])!==null&&At!==void 0?At:ce);break;default:Nr(xt)}function Nr(qe){r('Unknown property "'.concat(qe,'"'))}Ue().some(qe=>qe.id===X())||X(Ue()[0].id),pr()}function Ft(){return Yt.apply(this,arguments)}function Yt(){return(Yt=Rt(function*(){throw new Error("class method destroy() is deprecated. It is replaced with a method destroy() in the vanilla library.")})).apply(this,arguments)}function En(je,an,Q){we(je),yt()&&yt()(je,an,Q)}function vr(je){$e(je),Ze()&&Ze()(xl(je))}function An(){p(E,!0),qt()&&qt()()}function Or(){p(E,!1),x()&&x()()}function yr(je){return Sr.apply(this,arguments)}function Sr(){return(Sr=Rt(function*(je){We()!==je&&(We(je),pr(),Jt(),Tt()(je))})).apply(this,arguments)}function Ir(je){r("handleChangeQueryLanguage",je),X(je),L()(je)}function Er(je){var{id:an,json:Q,rootPath:Te,onTransform:tt,onClose:Nt}=je;Ne()||p(xe,{id:an,json:Q,rootPath:Te,indentation:ye(),truncateTextSize:Re(),escapeControlCharacters:Ot(),escapeUnicodeCharacters:ee(),parser:ae(),parseMemoizeOne:o(n),validationParser:_e(),pathParser:ne(),queryLanguages:Ue(),queryLanguageId:X(),onChangeQueryLanguage:Ir,onRenderValue:Ce(),onRenderMenu:et=>Me()(et,{mode:We(),modal:!0,readOnly:Ne()}),onRenderContextMenu:et=>at()(et,{mode:We(),modal:!0,readOnly:Ne(),selection:$e()}),onClassName:st(),onTransform:tt,onClose:Nt})}function Vn(je){Ne()||p(fe,je)}function Jn(je){var{content:an,path:Q,onPatch:Te,onClose:tt}=je;r("onJSONEditorModal",{content:an,path:Q}),p(te,{content:an,path:Q,onPatch:Te,readOnly:Ne(),indentation:ye(),tabSize:ze(),truncateTextSize:Re(),mainMenuBar:he(),navigationBar:ue(),statusBar:me(),askToFormat:ot(),escapeControlCharacters:Ot(),escapeUnicodeCharacters:ee(),flattenColumns:q(),parser:ae(),validator:void 0,validationParser:_e(),pathParser:ne(),onRenderValue:Ce(),onClassName:st(),onRenderMenu:Me(),onRenderContextMenu:at(),onSortModal:Vn,onTransformModal:Er,onClose:tt})}function gr(je){je.stopPropagation()}return W(()=>(M(ae()),o(N),M(we()),os),()=>{if(!Vu(ae(),o(N))){if(r("parser changed, recreate editor"),Ol(we())){var je=o(N).stringify(we().json);we({json:je!==void 0?ae().parse(je):void 0})}p(N,ae()),p(_,os())}}),W(()=>M(we()),()=>{var je=bd(we());je&&console.error("Error: "+je)}),W(()=>M($e()),()=>{$e()===null&&console.warn("selection is invalid: it is null but should be undefined")}),W(()=>M(ae()),()=>{p(n,Ci(ae().parse))}),W(()=>M(We()),()=>{r("mode changed to",We())}),_n(),St(!0),hv(e,{children:(je,an)=>{var Q,Te=DT(),tt=ft(Te);Ny(z(tt),()=>o(_),mt=>{tr(fg(mt,{get externalMode(){return We()},get content(){return we()},get selection(){return $e()},get readOnly(){return Ne()},get indentation(){return ye()},get tabSize(){return ze()},get truncateTextSize(){return Re()},get statusBar(){return me()},get askToFormat(){return ot()},get mainMenuBar(){return he()},get navigationBar(){return ue()},get escapeControlCharacters(){return Ot()},get escapeUnicodeCharacters(){return ee()},get flattenColumns(){return q()},get parser(){return ae()},get parseMemoizeOne(){return o(n)},get validator(){return $()},get validationParser(){return _e()},get pathParser(){return ne()},insideModal:!1,get onError(){return Je()},onChange:En,onChangeMode:yr,onSelect:vr,get onRenderValue(){return Ce()},get onClassName(){return st()},onFocus:An,onBlur:Or,get onRenderMenu(){return Me()},get onRenderContextMenu(){return at()},onSortModal:Vn,onTransformModal:Er,onJSONEditorModal:Jn,$$legacy:!0}),Ut=>p(U,Ut),()=>o(U))});var Nt=F(tt,2),et=mt=>{(function(Ut,dt){var kt,Un;lt(dt,!1);var Fn=P(void 0,!0),Xt=P(void 0,!0),Wt=P(void 0,!0),Gt=P(void 0,!0),or=Fr("jsoneditor:SortModal"),B=h(dt,"id",9),ie=h(dt,"json",9),Oe=h(dt,"rootPath",9),Dt=h(dt,"onSort",9),bn=h(dt,"onClose",9),un={value:1,label:"ascending"},Rn=[un,{value:-1,label:"descending"}],Xn="".concat(B(),":").concat(zt(Oe())),Gn=P((kt=Yi()[Xn])===null||kt===void 0?void 0:kt.selectedProperty,!0),ar=P(((Un=Yi()[Xn])===null||Un===void 0?void 0:Un.selectedDirection)||un,!0),At=P(void 0,!0);function Qn(){try{var Nr,qe,gn;p(At,void 0);var Dn=((Nr=o(Gn))===null||Nr===void 0?void 0:Nr.value)||((qe=o(Gt))===null||qe===void 0||(qe=qe[0])===null||qe===void 0?void 0:qe.value)||[],xn=(gn=o(ar))===null||gn===void 0?void 0:gn.value,wr=Dw(ie(),Oe(),Dn,xn);Dt()!==void 0&&Oe()!==void 0&&Dt()({operations:wr,rootPath:Oe(),itemPath:Dn,direction:xn}),bn()()}catch(to){p(At,String(to))}}function xt(Nr){Nr.focus()}W(()=>(M(ie()),M(Oe())),()=>{p(Fn,Ke(ie(),Oe()))}),W(()=>o(Fn),()=>{p(Xt,Array.isArray(o(Fn)))}),W(()=>(o(Xt),o(Fn)),()=>{p(Wt,o(Xt)?vv(o(Fn)):void 0)}),W(()=>(o(Wt),Ha),()=>{p(Gt,o(Wt)?o(Wt).map(Ha):void 0)}),W(()=>(Yi(),o(Gn),o(ar)),()=>{Yi(Yi()[Xn]={selectedProperty:o(Gn),selectedDirection:o(ar)}),or("store state in memory",Xn,Yi()[Xn])}),_n(),St(!0),Nl(Ut,{get onClose(){return bn()},className:"jse-sort-modal",children:(Nr,qe)=>{var gn=UT(),Dn=ft(gn),xn=de(()=>o(Xt)?"Sort array items":"Sort object keys");rc(Dn,{get title(){return o(xn)},get onClose(){return bn()}});var wr=z(F(Dn,2)),to=F(z(wr)),C=z(to),oe=F(z(C)),ve=z(oe),ke=F(C),Pe=It=>{var Bn=NT(),S=F(z(Bn));mi(z(S),{showChevron:!0,get items(){return o(Gt)},get value(){return o(Gn)},set value(K){p(Gn,K)},$$legacy:!0}),I(It,Bn)};re(ke,It=>{var Bn;o(Xt)&&(o(Gt)&&((Bn=o(Gt))===null||Bn===void 0?void 0:Bn.length)>1||o(Gn)===void 0)&&It(Pe)});var Be=F(ke),He=F(z(Be));mi(z(He),{showChevron:!0,clearable:!1,items:Rn,get value(){return o(ar)},set value(It){p(ar,It)},$$legacy:!0});var ct=F(wr,2),Qt=z(ct),cn=It=>{var Bn=LT(),S=z(Bn);Ee(()=>pt(S,o(At))),I(It,Bn)};re(Qt,It=>{o(At)&&It(cn)});var tn=z(F(ct,2));qr(()=>be("click",tn,Qn)),eo(tn,It=>xt?.(It)),Ee(It=>{var Bn;Mi(ve,It),tn.disabled=!!(o(Xt)&&o(Gt)&&((Bn=o(Gt))===null||Bn===void 0?void 0:Bn.length)>1)&&!o(Gn)},[()=>Oe()&&!Pn(Oe())?qo(Oe()):"(document root)"],de),I(Nr,gn)},$$slots:{default:!0}}),ut()})(mt,Xa(()=>o(fe),{onClose:()=>{var Ut;(Ut=o(fe))===null||Ut===void 0||Ut.onClose(),p(fe,void 0)}}))};re(Nt,mt=>{o(fe)&&mt(et)});var Bt=F(Nt,2),yn=mt=>{FP(mt,Xa(()=>o(xe),{onClose:()=>{var Ut;(Ut=o(xe))===null||Ut===void 0||Ut.onClose(),p(xe,void 0)}}))};re(Bt,mt=>{o(xe)&&mt(yn)});var Lt=F(Bt,2),Sn=mt=>{(function(Ut,dt){lt(dt,!1);var kt=P(void 0,!0),Un=P(void 0,!0),Fn=P(void 0,!0),Xt=P(void 0,!0),Wt=Fr("jsoneditor:JSONEditorModal"),Gt=h(dt,"content",9),or=h(dt,"path",9),B=h(dt,"onPatch",9),ie=h(dt,"readOnly",9),Oe=h(dt,"indentation",9),Dt=h(dt,"tabSize",9),bn=h(dt,"truncateTextSize",9),un=h(dt,"mainMenuBar",9),Rn=h(dt,"navigationBar",9),Xn=h(dt,"statusBar",9),Gn=h(dt,"askToFormat",9),ar=h(dt,"escapeControlCharacters",9),At=h(dt,"escapeUnicodeCharacters",9),Qn=h(dt,"flattenColumns",9),xt=h(dt,"parser",9),Nr=h(dt,"validator",9),qe=h(dt,"validationParser",9),gn=h(dt,"pathParser",9),Dn=h(dt,"onRenderValue",9),xn=h(dt,"onClassName",9),wr=h(dt,"onRenderMenu",9),to=h(dt,"onRenderContextMenu",9),C=h(dt,"onSortModal",9),oe=h(dt,"onTransformModal",9),ve=h(dt,"onClose",9),ke=P(void 0,!0),Pe=P(void 0,!0),Be={mode:Qt(Gt()),content:Gt(),selection:void 0,relativePath:or()},He=P([Be],!0),ct=P(void 0,!0);function Qt(Le){return Ol(Le)&&zr(Le.json)?Lr.table:Lr.tree}function cn(){var Le,Ye=(Le=ht(o(He)))===null||Le===void 0?void 0:Le.selection;zl(Ye)&&o(ke).scrollTo(Qe(Ye))}function tn(){if(Wt("handleApply"),!ie())try{p(ct,void 0);var Le=o(kt).relativePath,Ye=o(kt).content,Pt=[{op:"replace",path:zt(Le),value:Ah(Ye,xt()).json}];if(o(He).length>1){var pn=Ah(o(He)[o(He).length-2].content,xt()).json,nn={json:$o(pn,Pt)},qn=Se(Se({},o(He)[o(He).length-2]||Be),{},{content:nn});p(He,[...o(He).slice(0,o(He).length-2),qn]),pr(),cn()}else B()(Pt),ve()()}catch(bt){p(ct,String(bt))}}function It(){if(Wt("handleClose"),o(Pe))p(Pe,!1);else if(o(He).length>1){var Le;p(He,sn(o(He))),pr(),(Le=o(ke))===null||Le===void 0||Le.focus(),cn(),p(ct,void 0)}else ve()()}function Bn(Le){Wt("handleChange",Le),ge(Ye=>Se(Se({},Ye),{},{content:Le}))}function S(Le){Wt("handleChangeSelection",Le),ge(Ye=>Se(Se({},Ye),{},{selection:Le}))}function K(Le){Wt("handleChangeMode",Le),ge(Ye=>Se(Se({},Ye),{},{mode:Le}))}function ge(Le){var Ye=Le(ht(o(He)));p(He,[...sn(o(He)),Ye])}function Ve(Le){p(ct,Le.toString()),console.error(Le)}function De(Le){var Ye,{content:Pt,path:pn}=Le;Wt("handleJSONEditorModal",{content:Pt,path:pn});var nn={mode:Qt(Pt),content:Pt,selection:void 0,relativePath:pn};p(He,[...o(He),nn]),pr(),(Ye=o(ke))===null||Ye===void 0||Ye.focus()}function Ie(Le){Le.focus()}Yr(()=>{var Le;(Le=o(ke))===null||Le===void 0||Le.focus()}),W(()=>o(He),()=>{p(kt,ht(o(He))||Be)}),W(()=>o(He),()=>{p(Un,o(He).flatMap(Le=>Le.relativePath))}),W(()=>(o(Un),qo),()=>{p(Fn,Pn(o(Un))?"(document root)":qo(o(Un)))}),W(()=>M(xt()),()=>{p(Xt,Ci(xt().parse))}),_n(),St(!0),Nl(Ut,{onClose:It,className:"jse-jsoneditor-modal",get fullscreen(){return o(Pe)},children:(Le,Ye)=>{var Pt=TT();hv(z(Pt),{children:(pn,nn)=>{var qn=PT(),bt=ft(qn),mr=de(()=>o(He).length>1?" (".concat(o(He).length,")"):"");rc(bt,{get title(){var Ht;return"Edit nested content ".concat((Ht=o(mr))!==null&&Ht!==void 0?Ht:"")},fullScreenButton:!0,onClose:It,get fullscreen(){return o(Pe)},set fullscreen(Ht){p(Pe,Ht)},$$legacy:!0});var Wn=F(bt,2),Zn=F(z(Wn),2),jn=F(Zn,4);tr(fg(z(jn),{get externalMode(){return o(kt).mode},get content(){return o(kt).content},get selection(){return o(kt).selection},get readOnly(){return ie()},get indentation(){return Oe()},get tabSize(){return Dt()},get truncateTextSize(){return bn()},get statusBar(){return Xn()},get askToFormat(){return Gn()},get mainMenuBar(){return un()},get navigationBar(){return Rn()},get escapeControlCharacters(){return ar()},get escapeUnicodeCharacters(){return At()},get flattenColumns(){return Qn()},get parser(){return xt()},get parseMemoizeOne(){return o(Xt)},get validator(){return Nr()},get validationParser(){return qe()},get pathParser(){return gn()},insideModal:!0,onError:Ve,onChange:Bn,onChangeMode:K,onSelect:S,get onRenderValue(){return Dn()},get onClassName(){return xn()},onFocus:Co,onBlur:Co,get onRenderMenu(){return wr()},get onRenderContextMenu(){return to()},get onSortModal(){return C()},get onTransformModal(){return oe()},onJSONEditorModal:De,$$legacy:!0}),Ht=>p(ke,Ht),()=>o(ke));var Xe=z(F(jn,2)),nt=Ht=>{var Rr=AT(),Jr=z(Rr);Ee(()=>pt(Jr,o(ct))),I(Ht,Rr)};re(Xe,Ht=>{o(ct)&&Ht(nt)});var wn=F(Xe,2),fr=Ht=>{var Rr=RT();dn(z(Rr),{data:fk}),be("click",Rr,It),I(Ht,Rr)};re(wn,Ht=>{o(He).length>1&&Ht(fr)});var kr=F(wn,2),Tn=Ht=>{var Rr=MT();qr(()=>be("click",Rr,tn)),eo(Rr,Jr=>Ie?.(Jr)),I(Ht,Rr)},Mn=Ht=>{var Rr=zT();be("click",Rr,It),I(Ht,Rr)};re(kr,Ht=>{ie()?Ht(Mn,!1):Ht(Tn)}),Ee(()=>Mi(Zn,o(Fn))),I(pn,qn)},$$slots:{default:!0}}),I(Le,Pt)},$$slots:{default:!0}}),ut()})(mt,Xa(()=>o(te),{onClose:()=>{var Ut;(Ut=o(te))===null||Ut===void 0||Ut.onClose(),p(te,void 0)}}))};re(Lt,mt=>{o(te)&&mt(Sn)}),Ee(mt=>Q=Mt(tt,1,"jse-main svelte-57bmz4",null,Q,mt),[()=>({"jse-focus":o(E)})],de),be("keydown",tt,gr),I(je,Te)},$$slots:{default:!0}}),_t(t,"get",Fe),_t(t,"set",Ge),_t(t,"update",Et),_t(t,"patch",pe),_t(t,"select",vt),_t(t,"expand",Vt),_t(t,"collapse",rr),_t(t,"transform",fn),_t(t,"validate",$t),_t(t,"acceptAutoRepair",Ln),_t(t,"scrollTo",wt),_t(t,"findElement",en),_t(t,"focus",Jt),_t(t,"refresh",gt),_t(t,"updateProps",it),_t(t,"destroy",Ft),ut({get:Fe,set:Ge,update:Et,patch:pe,select:vt,expand:Vt,collapse:rr,transform:fn,validate:$t,acceptAutoRepair:Ln,scrollTo:wt,findElement:en,focus:Jt,refresh:gt,updateProps:it,destroy:Ft})}function $T(e){var{target:t,props:n}=e,r=kA(qT,{target:t,props:n});return r.destroy=Rt(function*(){return function(a,i){var s=cv.get(a);return s?(cv.delete(a),s(i)):Promise.resolve()}(r)}),pr(),r}const FT={$schema:"http://json-schema.org/draft-07/schema#",$id:"http://json-schema.org/draft-07/schema#",title:"Core schema meta-schema",definitions:{schemaArray:{type:"array",minItems:1,items:{$ref:"#"}},nonNegativeInteger:{type:"integer",minimum:0},nonNegativeIntegerDefault0:{allOf:[{$ref:"#/definitions/nonNegativeInteger"},{default:0}]},simpleTypes:{enum:["array","boolean","integer","null","number","object","string"]},stringArray:{type:"array",items:{type:"string"},uniqueItems:!0,default:[]}},type:["object","boolean"],properties:{$id:{type:"string",format:"uri-reference"},$schema:{type:"string",format:"uri"},$ref:{type:"string",format:"uri-reference"},$comment:{type:"string"},title:{type:"string"},description:{type:"string"},default:!0,readOnly:{type:"boolean",default:!1},examples:{type:"array",items:!0},multipleOf:{type:"number",exclusiveMinimum:0},maximum:{type:"number"},exclusiveMaximum:{type:"number"},minimum:{type:"number"},exclusiveMinimum:{type:"number"},maxLength:{$ref:"#/definitions/nonNegativeInteger"},minLength:{$ref:"#/definitions/nonNegativeIntegerDefault0"},pattern:{type:"string",format:"regex"},additionalItems:{$ref:"#"},items:{anyOf:[{$ref:"#"},{$ref:"#/definitions/schemaArray"}],default:!0},maxItems:{$ref:"#/definitions/nonNegativeInteger"},minItems:{$ref:"#/definitions/nonNegativeIntegerDefault0"},uniqueItems:{type:"boolean",default:!1},contains:{$ref:"#"},maxProperties:{$ref:"#/definitions/nonNegativeInteger"},minProperties:{$ref:"#/definitions/nonNegativeIntegerDefault0"},required:{$ref:"#/definitions/stringArray"},additionalProperties:{$ref:"#"},definitions:{type:"object",additionalProperties:{$ref:"#"},default:{}},properties:{type:"object",additionalProperties:{$ref:"#"},default:{}},patternProperties:{type:"object",additionalProperties:{$ref:"#"},propertyNames:{format:"regex"},default:{}},dependencies:{type:"object",additionalProperties:{anyOf:[{$ref:"#"},{$ref:"#/definitions/stringArray"}]}},propertyNames:{$ref:"#"},const:!0,enum:{type:"array",items:!0,minItems:1,uniqueItems:!0},type:{anyOf:[{$ref:"#/definitions/simpleTypes"},{type:"array",items:{$ref:"#/definitions/simpleTypes"},minItems:1,uniqueItems:!0}]},format:{type:"string"},contentMediaType:{type:"string"},contentEncoding:{type:"string"},if:{$ref:"#"},then:{$ref:"#"},else:{$ref:"#"},allOf:{$ref:"#/definitions/schemaArray"},anyOf:{$ref:"#/definitions/schemaArray"},oneOf:{$ref:"#/definitions/schemaArray"},not:{$ref:"#"}},default:!0},pg=Ng("jsoneditoronline:createValidator");function BT({schema:e,schemaDefinitions:t,parser:n}){if(e)try{pg("createAjvValidator",{schema:e,schemaDefinitions:t});const r=Vu(n,JSON)?e:hg(e,n),a=t?Vu(n,JSON)?t:hg(t,n):void 0;return _P({schema:r,schemaDefinitions:a,onCreateAjv:()=>{const i=e.$schema==="https://json-schema.org/draft/2020-12/schema"?T1:I1,s=new i({allErrors:!0,verbose:!0,$data:!0});return s.addMetaSchema(N1),s.addMetaSchema(FT),L1(s),s}})}catch(r){return pg("failed to compile validator:",String(r)),()=>[{path:[],message:String(r),severity:jo.error}]}else return}function hg(e,t){const n=t.stringify(e);return n!==void 0?JSON.parse(n):void 0}const WT={prefix:"fas",iconName:"jsoneditor-smart-format",icon:[512,512,[],"","m 448,512 -15,-49 -49,-15 49,-15 15,-49 15,49 49,15 -45,15 zM 335,512 294,376 156,335 292,294 333,156 374,292 512,333 376,374 Z M 0,32 V 96 H 512 V 32 Z M 0,288 v 64 h 128 v -64 Z M 0,160 v 64 h 256 v -64 Z "]};window._=ny;window.jsonrepair=Wo;window.Ajv=U1;window.jsonquery=Ig;window.jmespath=qE;window.JSONPathPlus=In;window.patch=Zk;const gg=Ng("jsoneditoronline:JSONEditorComponent"),mg=["id","onJsonEditorRef","maxLineLength","schema"],HT=[{...aw,name:"JSON Query"},EP,AP,{...RP,name:"JavaScript"}];class i4 extends Z1.PureComponent{jsoneditor;schema;container;constructor(t){super(t),this.jsoneditor=null,this.schema=null,this.container=null}memoizeValidator=Ci(BT,Zt);memoizeOnRenderValue=Ci(function(t){return t?function(r){return kP(r,t)||_v(r)}:_v});onRenderMenu(t,n){let r=t;if(n.mode===Lr.text&&!n.modal&&!this.props.readOnly){const a=t.findIndex(s=>vs(s)&&s.className==="jse-compact");if(a===-1){console.error("Cannot find button Compact");return}const i=t[a].disabled;r=[...r],r.splice(a,0,{type:"button",icon:WT,title:"Smart format JSON: "+D1+" (Ctrl+J)",className:"jse-format-smart",onClick:this.handleSmartFormat.bind(this),disabled:i})}return this.props.onRenderMenu?.(r,n)||r}componentDidMount(){if(gg("componentDidMount"),!this.container)throw new Error("container not found");this.jsoneditor=$T({target:this.container,props:{onError:t=>{console.error(t),Ap(rd.jsx("div",{className:"parse-error",children:rd.jsx("code",{children:t.toString()})}))},validator:this.memoizeValidator({schema:this.props.schema??null,parser:this.props.parser}),onRenderValue:this.memoizeOnRenderValue(this.props.schema),queryLanguages:HT,...Iu(this.props,mg),onRenderMenu:this.onRenderMenu.bind(this)}}),this.props.onJsonEditorRef&&this.jsoneditor&&this.props.onJsonEditorRef(this.jsoneditor),this.props.id&&(window.jsoneditors||(window.jsoneditors={}),this.jsoneditor&&(window.jsoneditors[this.props.id]=this.jsoneditor))}componentDidUpdate(t){if(!this.jsoneditor)return;const n=VT(Iu(this.props,mg),t);this.props.schema!==t.schema&&(n.validator=this.memoizeValidator({schema:this.props.schema??null,parser:n.parser??JSON}),n.onRenderValue=this.memoizeOnRenderValue(this.props.schema)),n.onRenderMenu=this.onRenderMenu.bind(this),this.jsoneditor.updateProps(n)}componentWillUnmount(){gg("componentWillUnmount"),this.jsoneditor&&(this.jsoneditor.destroy().catch(console.error),this.jsoneditor=null,this.schema=null)}async handleKeyDown(t){const n=t;n.ctrlKey&&n.key==="j"&&(n.preventDefault(),n.stopPropagation(),await this.handleSmartFormat())}async handleSmartFormat(){if(!this.jsoneditor)return;const{onChange:t,indentation:n,parser:r,maxLineLength:a}=this.props,i=this.jsoneditor.get(),s=Yy(i,n,r).text;if(s.length>q1){Ap(F1);return}const l=await Xk(s,n||2,a);t?t({text:l}):this.jsoneditor.update({text:l})}render(){return rd.jsx("div",{onKeyDown:this.handleKeyDown.bind(this),className:$1("jsoneditor-react-container",this.props.className,{"read-only":this.props.readOnly}),ref:t=>{this.container=t}})}}function VT(e,t){return Object.fromEntries(Object.entries(e).filter(([n,r])=>r!==t[n]))}export{i4 as J,Lr as W,uf as a,BT as c,Gx as o,Sj as t,Pj as u};
